# PDF paragraph integration checkpoints -- v0.3.32

The register tracks **mathematical passage-level checkpoints**, including
numbered theorem statements, theorem subparts, and already-authored finite
proof components. It is a selective semantic paragraph index, not an assertion
that all 52 pages or all literal typeset paragraphs are represented.

**Checkpoint contract:** The runner prints `PARAGRAPH_CHECKPOINT=INTEGRATED`
only after the mapped Lean module has passed or obtained a valid frozen-cache
hit. A typed specification is integrated but unproved; a proof component is
not an entire theorem. `SCAFFOLD` and `CONJECTURE` remain BLUEPRINT-only.

## Current source-level counts (NOT compiler status)

| Stage | Entries |
|---|---:|
| CERTIFIED_CORE_TARGET | 21 |
| SPEC_TYPED | 87 |
| CORRECTED_SPEC | 6 |
| PROOF_COMPONENT | 54 |
| PROVED_SUBTARGET | 7 |
| SCAFFOLD | 35 |
| CONJECTURE | 2 |

**Total checkpoints indexed:** 212
**Source mathematical items:** 47 (including conjecture 4.11, not required for closure)

## Proof status boundaries

- `CERTIFIED_CORE_TARGET`: core target is connected to prior successful proof; the specific manuscript item may contain stronger prose than the named target.
- `PROVED_SUBTARGET`: a particular theorem or lemma fragment is proved once its module passes, NOT the full printed paper theorem.
- `PROOF_COMPONENT`: module contains mathematical lemmas; no claim that those lemmas imply the entire PDF item.
- `SPEC_TYPED`: the paper passage has a nontrivial typed Lean goal, still unproved.
- `CORRECTED_SPEC`: manuscript statement needs an explicit mathematical correction.
- `SCAFFOLD`: a named structure with outstanding arbitrary Prop fields; not counted integrated.
- `CONJECTURE`: excluded from mandatory full-paper theorem closure.

## All semantic paragraph targets

| Paragraph id | PDF p. | Status | Lean module |
|---|---:|---|---|
| `definition_2_1__native_definition` | 3 | PROVED_SUBTARGET | `PaperChronology.S02_Definition_2_1` |
| `lemma_2_2__native_pullback` | 4 | PROVED_SUBTARGET | `PaperChronology.S02_Lemma_2_2` |
| `lemma_2_3__native_reflection_difference` | 5 | PROVED_SUBTARGET | `PaperChronology.S02_Lemma_2_3` |
| `theorem_2_4__native_basis_covariance` | 6 | PROVED_SUBTARGET | `PaperChronology.S02_Theorem_2_4` |
| `theorem_2_5__native_diagonal` | 6 | PROVED_SUBTARGET | `PaperChronology.S02_Theorem_2_5` |
| `theorem_4_1__general_transfer` | 14 | PROOF_COMPONENT | `Theorem_4_1_Spectral_Irrationality_Measure_Criterion` |
| `theorem_3_1__concrete_moments` | 7 | PROOF_COMPONENT | `Theorem_3_1_Concrete_Moment_Realization` |
| `theorem_3_1__pole_integral` | 7 | PROOF_COMPONENT | `Theorem_3_1_Pole_Integral_Identity` |
| `theorem_3_1__native_spectral_core` | 7 | PROVED_SUBTARGET | `PaperChronology.S03_Theorem_3_1` |
| `proposition_3_2__native_continuous_pencil` | 8 | PROVED_SUBTARGET | `PaperChronology.S03_Proposition_3_2` |
| `theorem_5_1__beukers_initial` | 22 | PROOF_COMPONENT | `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7` |
| `definition_2_1__monomial_moment` | 3 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `definition_2_1__pole_moment` | 3 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `definition_2_1__statement` | 3 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_2__pole_pullback` | 4 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_2__polynomial_pullback` | 4 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_2__statement` | 4 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_3__difference` | 5 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_3__reflection` | 5 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `lemma_2_3__statement` | 5 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_4__change_basis` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_4__primitive_normalization` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_4__statement` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_5__derivative_factor` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_5__diagonal` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_5__off_diagonal` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `theorem_2_5__statement` | 6 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S02` |
| `corollary_3_5_corrected__schur_fraction` | 10 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `corollary_3_5_corrected__spectral_edge` | 10 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `corollary_3_5_corrected__statement` | 10 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `corollary_3_6_corrected__finite_support_rank` | 11 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `corollary_3_6_corrected__reciprocal_moments` | 11 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `corollary_3_6_corrected__statement` | 11 | CORRECTED_SPEC | `PaperBlueprint.Chapters.S03` |
| `proposition_3_2__continuous_weight` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `proposition_3_2__hyperbolicity` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `proposition_3_2__statement` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_1__det_degree` | 7 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S03` |
| `theorem_3_1__positive_density` | 7 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S03` |
| `theorem_3_1__positive_gram` | 7 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S03` |
| `theorem_3_1__root_gap` | 7 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S03` |
| `theorem_3_1__statement` | 7 | CERTIFIED_CORE_TARGET | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__carleman` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__inertia` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__leading_sign` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__mixed_minors` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__moment_realization` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__root_signature` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_3__statement` | 8 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_4__dodgson` | 9 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_4__interlacing` | 9 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_4__statement` | 9 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_7__newton` | 11 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_7__shifted_newton` | 11 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_7__statement` | 11 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_7__turan` | 11 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_8__jacobi` | 12 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_8__pole_kernel` | 12 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_8__statement` | 12 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_9__dirichlet` | 13 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_9__hurwitz` | 13 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `theorem_3_9__statement` | 13 | SPEC_TYPED | `PaperBlueprint.Chapters.S03` |
| `conjecture_4_11__statement` | 22 | CONJECTURE | `PaperBlueprint.Chapters.S04` |
| `conjecture_4_11__variational_constant` | 22 | CONJECTURE | `PaperBlueprint.Chapters.S04` |
| `proposition_4_2__height` | 15 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_2__resultant` | 15 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_2__statement` | 15 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_3__padic_disk` | 15 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_3__statement` | 15 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_8__factor_degree` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_8__rational_exclusion` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_4_8__statement` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_1__quadratic_decay` | 14 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_1__rational_transfer` | 14 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_1__root_disk` | 14 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_1__statement` | 14 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_4__integer_normalization` | 16 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_4__irrationality_measure` | 16 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_4__spectral_growth` | 16 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_4__statement` | 16 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_5__coupling` | 18 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_5__mixed_arithmetic` | 18 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_5__positive_weight` | 18 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_5__statement` | 18 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_6__det_asymptotic` | 19 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_6__height_bound` | 19 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_6__statement` | 19 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_7__clustering` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_7__factor_separation` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_7__opposite_gap` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `theorem_4_7__statement` | 21 | SPEC_TYPED | `PaperBlueprint.Chapters.S04` |
| `proposition_5_3__beta_dual` | 24 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `proposition_5_3__beta_moments` | 24 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `proposition_5_3__statement` | 24 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_1__diagonal_moment` | 22 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_1__kernel` | 22 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_1__offdiagonal_moment` | 22 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_1__statement` | 22 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_2__dual_slope` | 23 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_2__infinite_krein` | 23 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_2__polynomial_cones` | 23 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_2__statement` | 23 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_4__even_pole` | 25 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_4__statement` | 25 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_6__inner_tail` | 26 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_6__outer_prime_integral` | 26 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_6__pole_order` | 26 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_6__statement` | 26 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_7__local_valuations` | 28 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_7__qadic_nonzero` | 28 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `theorem_5_7__statement` | 28 | SPEC_TYPED | `PaperBlueprint.Chapters.S05` |
| `corollary_6_8__linear_independence` | 38 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `corollary_6_8__statement` | 38 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_10__dual_growth` | 39 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_10__potential_gap` | 39 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_10__statement` | 39 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_11__distribution` | 40 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_11__dyadic` | 40 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_11__statement` | 40 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_12__nonvanishing` | 42 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_12__sign_flip` | 42 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_12__statement` | 42 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_13__central_factorial` | 43 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_13__secant_annihilation` | 43 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_13__statement` | 43 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_14__coupled_pencil` | 45 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_14__even_scaling` | 45 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_14__statement` | 45 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_15__rank_one` | 46 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_15__statement` | 46 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_15__transcendence` | 46 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_16__slope` | 47 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_16__statement` | 47 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_16__zeta_beta_pencil` | 47 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_17__beukers_zeta_beta` | 48 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_17__signed_krein` | 48 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_17__statement` | 48 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_18__dyadic_minors` | 49 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_18__heights` | 49 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_18__statement` | 49 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_1__divided_valuation` | 29 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_1__fiber` | 29 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_1__local_block` | 29 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_1__statement` | 29 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_2__denominator` | 31 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_2__joint_moments` | 31 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_2__statement` | 31 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_3__cone` | 32 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_3__qadic` | 32 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_3__statement` | 32 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_4__character_sign` | 33 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_4__positive_slope` | 33 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_4__statement` | 33 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_5__delta_nonzero` | 34 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_5__statement` | 34 | SPEC_TYPED | `PaperBlueprint.Chapters.S06` |
| `theorem_6_6__mixed_kernel` | 35 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_6__spectral` | 35 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_6__statement` | 35 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_7__multi_krein` | 37 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_7__statement` | 37 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_9__multiweight` | 38 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_9__statement` | 38 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_6_9__triple_pole` | 38 | SCAFFOLD | `PaperBlueprint.Chapters.S06` |
| `theorem_3_3__proof_twoatomminors` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_TwoAtomMinors` |
| `theorem_3_3__proof_threeatommoment` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_ThreeAtomMoment` |
| `theorem_3_3__proof_arbitraryfinitegram` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram` |
| `theorem_3_3__proof_atomicmomentenergy` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy` |
| `theorem_3_3__proof_momentdeterminantbridge` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge` |
| `theorem_3_3__proof_shiftedmomentdeterminant` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant` |
| `theorem_3_3__proof_rootsidetransfer` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_RootSideTransfer` |
| `theorem_3_3__proof_signedresidueproducts` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_SignedResidueProducts` |
| `theorem_3_3__proof_residueparityratio` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_ResidueParityRatio` |
| `theorem_3_3__proof_alternatingpolesign` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_AlternatingPoleSign` |
| `theorem_3_3__proof_signbypoleparity` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_SignByPoleParity` |
| `theorem_3_3__proof_inertianormalform` | 8 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_3_InertiaNormalForm` |
| `theorem_3_4__proof_twobytwointerlacing` | 9 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing` |
| `theorem_3_4__proof_dodgson` | 9 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_4_Dodgson` |
| `corollary_3_5_corrected__proof_schur` | 10 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_5_Schur` |
| `corollary_3_6_corrected__proof_finiteatoms` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_6_FiniteAtoms` |
| `corollary_3_6_corrected__proof_twoatomrank` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_6_TwoAtomRank` |
| `corollary_3_6_corrected__proof_reciprocalroots` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_6_ReciprocalRoots` |
| `corollary_3_6_corrected__proof_reciprocaldeterminants` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants` |
| `corollary_3_6_corrected__proof_finiteannihilator` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Corollary_3_6_FiniteAnnihilator` |
| `theorem_3_7__proof_turan` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_7_Turan` |
| `theorem_3_7__proof_threerootnewton` | 11 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_7_ThreeRootNewton` |
| `theorem_3_8__proof_polekernel` | 12 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_8_PoleKernel` |
| `theorem_3_9__proof_characterfeketekernels` | 13 | PROOF_COMPONENT | `PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels` |
| `proposition_4_3__proof_padicdisk` | 15 | PROOF_COMPONENT | `PaperProofs.S04_Proposition_4_3_PadicDisk` |
| `proposition_4_3__proof_residuedisk` | 15 | PROOF_COMPONENT | `PaperProofs.S04_Proposition_4_3_ResidueDisk` |
| `theorem_4_1__proof_transferwindow` | 14 | PROOF_COMPONENT | `PaperProofs.S04_Theorem_4_1_TransferWindow` |
| `theorem_5_2__dual_initial` | 23 | PROOF_COMPONENT | `Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil` |
| `theorem_5_2__proof_dualslope` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_DualSlope` |
| `theorem_5_2__proof_dualenergy` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_DualEnergy` |
| `theorem_5_2__proof_dualdeterminant` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_DualDeterminant` |
| `theorem_5_2__proof_principalhyperbolicity` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity` |
| `theorem_5_2__proof_actualdualpencil` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_ActualDualPencil` |
| `theorem_5_2__proof_finitekreinsplit` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_FiniteKreinSplit` |
| `theorem_5_2__proof_exactfifthkernel` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_ExactFifthKernel` |
| `theorem_5_2__proof_truncatedkernel` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_TruncatedKernel` |
| `theorem_5_2__proof_exactconeenergy` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_ExactConeEnergy` |
| `theorem_5_2__proof_finitefeaturekernel` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel` |
| `theorem_5_2__proof_exactkreinquadratic` | 23 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_2_ExactKreinQuadratic` |
| `theorem_6_1__proof_localobstruction` | 29 | PROOF_COMPONENT | `PaperProofs.S06_Theorem_6_1_LocalObstruction` |
| `theorem_5_4__proof_evenpole` | 25 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_4_EvenPole` |
| `theorem_5_6__proof_outerpieces` | 26 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_6_OuterPieces` |
| `theorem_5_6__proof_outerpartition` | 26 | PROOF_COMPONENT | `PaperProofs.S05_Theorem_5_6_OuterPartition` |
| `theorem_6_1__proof_divideddifference` | 29 | PROOF_COMPONENT | `PaperProofs.S06_Theorem_6_1_DividedDifference` |
| `theorem_6_10__proof_gramdet` | 39 | PROOF_COMPONENT | `PaperProofs.S06_Theorem_6_10_GramDet` |
| `theorem_6_3__qadic_base` | 32 | PROOF_COMPONENT | `Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7` |
| `theorem_6_4__character_base` | 33 | PROOF_COMPONENT | `Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4` |
| `theorem_6_16__merge_arithmetic` | 47 | PROOF_COMPONENT | `Zeta5Merge.Theorem6_16` |
| `theorem_6_17__merge_krein` | 48 | PROOF_COMPONENT | `Zeta5Merge.Theorem6_17` |
| `theorem_6_18__merge_dyadic` | 49 | PROOF_COMPONENT | `Zeta5Merge.Theorem6_18` |
