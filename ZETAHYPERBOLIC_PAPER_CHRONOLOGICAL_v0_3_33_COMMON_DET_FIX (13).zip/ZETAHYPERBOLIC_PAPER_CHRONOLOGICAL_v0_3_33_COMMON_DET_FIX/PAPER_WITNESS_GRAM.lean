import MAIN_CHAIN_ASSEMBLED
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5
import Mathlib.Tactic.Omega

/-!
# Unconditional Gram lemma for the actual weight-five paper family

Separate compilation checkpoint before the single-witness endpoint.
No quantitative input or auxiliary axiom occurs in these two proofs.
-/

noncomputable section
namespace PaperSingleWitness

open ManuscriptChain

/-- Paper parameters K=30n, N=3n, k=2, m=3 are admissible for n>0. -/
theorem main_parameters_admissible (n : ℕ) (hn : 0 < n) :
    Real.Admissible (Real.mainParameters n) := by
  refine ⟨by decide, by decide, ?_, ?_⟩
  · change 0 < 3 * n
    omega
  · change 3 * n < 30 * n
    omega

/-- The existing unconditional general theorem supplies the actual Gram positivity. -/
theorem main_gram_positive (start : ℕ) :
    ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef := by
  intro n hn
  have hnpos : 0 < n := by omega
  have hgram : General.GramPositive (Real.mainParameters n) :=
    ManuscriptChain.GRAM_POSITIVE
      (Real.mainParameters n) (main_parameters_admissible n hnpos)
  exact hgram

end PaperSingleWitness

#print axioms PaperSingleWitness.main_parameters_admissible
#print axioms PaperSingleWitness.main_gram_positive
