import Definition_2_1_Order_s_Rational_Moment_Functional
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Mathlib

/-!
# Paper hypotheses: mathematical vocabulary

All definitions here are DATA or PROPOSITIONS, not proofs or axioms.
They reference the actual rational Hankel pencil of Definition 2.1.
The PDF is the source for the intended statements, not evidence that they hold.
No `sorry`, `axiom` or `opaque` declarations occur in PaperBlueprint.
-/

noncomputable section
open scoped BigOperators

namespace PaperBlueprint

abbrev Parameters := ManuscriptChain.Real.Parameters

/-- Weight-five parameters for the paper's n-th arithmetic determinant. -/
def weightFive (n : ℕ) : Parameters := ⟨2, 3, 3*n, 30*n⟩

/-- Weight-seven parameters for the paper's arithmetic determinant. -/
def weightSeven (n : ℕ) : Parameters := ⟨3, 4, 3*n, 40*n⟩

/-- Actual (not an arbitrary proxy) continued Hankel moment from Section 2.
The identity with the integral moment remains a separate analytic obligation. -/
def actualMoment (p : Parameters) (r : ℕ) : ℝ :=
  (ManuscriptChain.Real.entryA p r 0 : ℝ) +
    (ManuscriptChain.Real.entryM p r 0 : ℝ) *
      ManuscriptChain.Real.zeta p.weight

/-- The actual Hankel Gram matrix evaluated at its zeta center. -/
def actualGram (p : Parameters) : Matrix (Fin p.h) (Fin p.h) ℝ :=
  ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)

/-- An arbitrary mixed minor of the actual Hankel matrix. -/
def mixedMinor (p : Parameters) {r : ℕ}
    (rows cols : Fin r → Fin p.h) : ℝ :=
  Matrix.det (fun i j : Fin r =>
    actualGram p (rows i) (cols j))

/-- Actual Hankel minor from the first r rows and columns, not a generic toy matrix. -/
def leadingMinor (p : Parameters) (r : ℕ) (hr : r ≤ p.h) (x : ℝ) : ℝ :=
  Matrix.det (fun i j : Fin r =>
    (ManuscriptChain.Real.gram p x)
      (Fin.castLE hr i) (Fin.castLE hr j))

/-- Finite mixed-minor total positivity. For r=0, the determinant is 1. -/
def StrictTotalPositivity (p : Parameters) : Prop :=
  ∀ (r : ℕ) (rows cols : Fin r → Fin p.h),
    StrictMono rows → StrictMono cols → 0 < mixedMinor p rows cols

/-- Real spectral data with the exact determinant factorization. -/
abbrev RootSpectrum (p : Parameters) :=
  ManuscriptChain.Spectral.RootFactorization
    (ManuscriptChain.Real.manuscriptPencil p)

/-- Rational approximation measure, as in manuscript Theorem 4.1. -/
def EffectiveMeasure (x : ℝ) (mu : ℕ) : Prop :=
  ∃ b₀ : ℕ, ∀ (a : ℤ) (b : ℕ),
    0 < b → b₀ ≤ b →
    (1 : ℝ) / (b : ℝ) ^ mu < |x - (a : ℝ) / (b : ℝ)|

/-- Matrix positivity expressed without an extra hypothesis or surrogate cone. -/
def PositiveQuadratic {n : ℕ} (G : Matrix (Fin n) (Fin n) ℝ) : Prop :=
  ∀ v : Fin n → ℝ, v ≠ 0 →
    0 < ∑ i : Fin n, ∑ j : Fin n, v i * G i j * v j

/-- The two-variable coefficient pencil appearing in PDF equation (5.3). -/
def dualMatrix {h K : ℕ}
    (s : ℕ) (C : Fin h → Fin (K+1) → ℚ) (x : ℝ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j =>
    (ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.dualEntry s C i j)).eval x

/-- Full-row-rank criterion for the coefficient matrix of the actual dual pencil. -/
def FullRowRank {h K : ℕ} (C : Fin h → Fin (K+1) → ℚ) : Prop :=
  ∀ v : Fin h → ℝ,
    (∀ j : Fin (K+1),
      (∑ i : Fin h, v i * (C i j : ℝ)) = 0) →
      v = 0

/-- The paper's real center for a linear odd-zeta combination. -/
def mixedZeta35 (a b : ℤ) : ℝ :=
  (a : ℝ) * ManuscriptChain.Real.zeta 3 +
    (b : ℝ) * ManuscriptChain.Real.zeta 5

/-- Printed positivity cone for b*zeta(5)+a*zeta(3) (PDF Theorem 4.5). -/
def MixedCone (a b : ℤ) : Prop :=
  0 < b ∧ (a : ℝ) < (Real.pi ^ 2 / 3) * (b : ℝ)

/-- Naive absolute coefficient height, for algebraic transfer. -/
def polynomialHeight (P : Polynomial ℤ) : ℕ :=
  P.support.sup (fun i => (P.coeff i).natAbs)

/-- Real Dirichlet beta series; used only in explicitly open conjectural targets. -/
def beta (s : ℕ) : ℝ :=
  ∑' n : ℕ,
    (if Even n then (1 : ℝ) else -1) / ((2*n + 1 : ℕ) : ℝ) ^ s

end PaperBlueprint
