import PaperBlueprint.Common
import Zetahyperbolic.Section2Checked
import Mathlib.MeasureTheory.Integral.SetIntegral

/-!
# Section 5: actual integral kernels and unproved analytic bridges

These are hypotheses to be discharged, NOT assertions. In particular,
the exact finite Krein truncation already proved in PaperProofs is not
promoted to convergence of the infinite signed expansion.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory
namespace PaperBlueprint.S05

/-- The actual two-variable density from equation (5.1). -/
def beukersKernel7 (x y : ℝ) : ℝ :=
  (-Real.log (x*y)) ^ 5 / (720 * (1-x*y))

/-- The exact PDF double moment integral on (0,1)^2. -/
def beukersMoment7 (r s : ℕ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    ∫ y in Set.Ioo (0 : ℝ) 1,
      x ^ r * y ^ s * beukersKernel7 x y

/-- Theorem 5.1: diagonal zeta(7) and rational off-diagonal moments. -/
def ExactBeukersMoments7 : Prop :=
  ∀ r s : ℕ,
    if r = s then
      beukersMoment7 r s =
        ManuscriptChain.Real.zeta 7 - (ManuscriptChain.Real.harmonic 7 r : ℝ)
    else
      beukersMoment7 r s =
        ((ManuscriptChain.Real.harmonic 6 r : ℝ) -
          (ManuscriptChain.Real.harmonic 6 s : ℝ)) /
        (6 * ((r : ℝ) - (s : ℝ)))

/-- Theorem 5.2: the signed infinite modes from equation (5.4). -/
def featurePlus (m nu : ℕ) (f : ℝ → ℝ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    f x * x ^ m * ((-Real.log x) ^ nu + (-Real.log x) ^ (5-nu))

def featureMinus (m nu : ℕ) (f : ℝ → ℝ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    f x * x ^ m * ((-Real.log x) ^ nu - (-Real.log x) ^ (5-nu))

def signedKreinTerm (m : ℕ) (f : ℝ → ℝ) : ℝ :=
  ∑ nu ∈ Finset.range 3,
    (Nat.choose 5 nu : ℝ) *
      ((featurePlus m nu f)^2 - (featureMinus m nu f)^2)

/-- The PDF's bilinear form on L²(0,1), expressed directly in integrals. -/
def beukersEnergy7 (f : ℝ → ℝ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    ∫ y in Set.Ioo (0 : ℝ) 1,
      f x * f y * beukersKernel7 x y

/-- Theorem 5.2(2): analytically justified infinite signed Krein identity. -/
def InfiniteKreinDecomposition : Prop :=
  ∀ f : ℝ → ℝ,
    IntegrableOn (fun x => (f x)^2) (Set.Ioo (0 : ℝ) 1) →
    Summable (fun m : ℕ => signedKreinTerm m f) ∧
    beukersEnergy7 f = (1/1440 : ℝ) *
      ∑' m : ℕ, signedKreinTerm m f

/-- Theorem 5.2(3): genuine rational polynomial coefficient matrices
whose actual zeta(7) dual Gram forms have opposite strict signatures. -/
def OppositePolynomialCones : Prop :=
  ∀ h : ℕ, 0 < h →
    ∃ K : ℕ, h ≤ K+1 ∧
      ∃ (cpos cneg : Fin h → Fin (K+1) → ℚ),
        FullRowRank cpos ∧ FullRowRank cneg ∧
        PositiveQuadratic (dualMatrix 7 cpos (ManuscriptChain.Real.zeta 7)) ∧
        PositiveQuadratic (-(dualMatrix 7 cneg (ManuscriptChain.Real.zeta 7)))

/-- PDF Proposition 5.3 uses denominator 6, matching its diagonal beta(4)
identity and off-diagonal factor 1/12. -/
def betaKernel4 (x y : ℝ) : ℝ :=
  (-Real.log (x*y)) ^ 2 / (6 * (1+(x*y)^2))

def betaMoment4 (r s : ℕ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    ∫ y in Set.Ioo (0 : ℝ) 1,
      x ^ (4*r) * y ^ (4*s) * betaKernel4 x y

/-- Proposition 5.3, diagonal and off-diagonal beta moments. -/
def ExactBeukersMomentsBeta4 : Prop :=
  ∀ r s : ℕ,
    if r = s then
      betaMoment4 r s =
        PaperBlueprint.beta 4 -
          (∑ j ∈ Finset.range (2*r),
            (if Even j then (1 : ℝ) else -1) /
              ((2*j+1 : ℕ) : ℝ)^4)
    else
      ∃ rationalValue : ℚ,
        betaMoment4 r s = (rationalValue : ℝ)

/-- Theorem 5.4, the EXACT x-even simple-pole pair: this has a proof
candidate in PaperProofs, but is not assumed to be proved by this file. -/
def EvenPoleCancellation : Prop :=
  ∀ (k j : ℕ), 1 ≤ j →
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
      Polynomial.C (((j : ℚ) ^ (2*k+1))⁻¹)

/-- Theorem 5.6(1): original floor/max/min outer integrand, including
its change of formula at y=1/2. -/
def outerAlpha : ℝ := 3/40

def outerLambda : ℝ := 37/40

def outerPositive (x : ℝ) : ℝ := max 0 x

def outerV (y : ℝ) : ℝ := 1 - y * (Int.floor (1/y) : ℝ)

def outerU (y : ℝ) : ℝ := outerPositive (outerAlpha + outerV y - y)

def outerTildeT (y : ℝ) : ℝ := min outerAlpha (outerV y) + outerU y

def outerR (y : ℝ) : ℝ :=
  if y < 1/2 then
    9*(1-y) - 16*outerAlpha - 7*outerTildeT y +
      min (outerPositive (29/20 - 3*y)) (y + outerU y)
  else if y < 1 then
    9*(1-y) - 8*outerTildeT y +
      min (outerPositive (29/20 - 3*y)) (y - outerAlpha + outerU y)
  else 0

def outerIntegrand (y : ℝ) : ℝ :=
  outerR y - 2*outerLambda*(Int.floor (1/y) : ℝ) +
    7 * ∑ j ∈ Finset.Icc 1 7,
      outerPositive (2*outerLambda - (j : ℝ)*y)

/-- The printed rational exact integral (5.6). The 11 affine-area
calculations are already formalized; the floor-branch identity is open. -/
def ExactOuterPrimeSum : Prop :=
  (∫ y in Set.Icc (1/3 : ℝ) (37/20), outerIntegrand y) =
    (453803 : ℝ) / 288000

/-- Inner tail bound: `innerR` still needs a separate definitional
identification with the manuscript's Γ and N floor expressions. -/
structure InnerPrimeTail where
  innerR : ℝ → ℝ
  original_gamma_N_identification : Prop
  tail_integral_bound :
    (∫ x in Set.Ici (20 : ℝ), innerR x / x ^ 3) ≤
      -(33104 : ℝ) / 576000
  pole_order_weight_gain : Prop

/-- Theorem 5.7: two-pole determinant with q-adic nonvanishing and
p-adic minor bounds, tied to a supplied rational determinant family.
The valuation must later be identified with the true p-adic valuation. -/
structure DoublePoleValuation where
  determinants : ℕ → ℚ
  valuation : ℕ → ℚ → ℤ
  determinant_identification : Prop
  valuation_identification : Prop
  q_nonvanishing : ∀ (q : ℕ), Nat.Prime q → q > 11 → q % 9 = 1 →
    determinants (2*((q-1)/9)) ≠ 0
  outer_prime_minor_bound : Prop

/-- Explicit open theorem inputs in chronological Section 5. -/
structure Hypotheses where
  theorem_5_1 : ExactBeukersMoments7
  theorem_5_2_infinite : InfiniteKreinDecomposition
  theorem_5_2_cones : OppositePolynomialCones
  proposition_5_3 : ExactBeukersMomentsBeta4
  theorem_5_4 : EvenPoleCancellation
  theorem_5_6_outer : ExactOuterPrimeSum
  theorem_5_6_inner : InnerPrimeTail
  theorem_5_7 : DoublePoleValuation

end PaperBlueprint.S05
