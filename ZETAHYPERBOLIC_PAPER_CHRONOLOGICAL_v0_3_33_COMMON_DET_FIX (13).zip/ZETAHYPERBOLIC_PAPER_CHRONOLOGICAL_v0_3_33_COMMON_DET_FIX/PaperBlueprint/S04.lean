import PaperBlueprint.Common
import Mathlib.NumberTheory.Padics.Complex

/-!
# Section 4: Diophantine hypotheses and the paper's quantitative witness

The witness record below is evidence for infinitely many exact estimates;
it is NOT a finite, terminating witness checker. No existence theorem for
that record is asserted. The already formalized transfer principle is separate.
-/

noncomputable section
open scoped BigOperators
namespace PaperBlueprint.S04

/-- Algebraic version of the transfer conclusion (Theorem 4.2).
`P` is a primitive real minimal polynomial of degree at most `d`; the
minimality/irreducibility proof will form part of the later resultant bridge. -/
def AlgebraicApproximationBound : Prop :=
  ∀ (d : ℕ), 1 ≤ d → ∃ (mu : ℝ) (H₀ : ℕ),
    0 < mu ∧
    ∀ (P : Polynomial ℤ) (alpha : ℝ),
      P ≠ 0 → P.natDegree ≤ d →
      (ManuscriptChain.Real.realPolynomial
        (P.map (Int.castRingHom ℚ))).eval alpha = 0 →
      H₀ ≤ polynomialHeight P →
      ((polynomialHeight P : ℝ) ^ (-mu)) <
        |ManuscriptChain.Real.zeta 5 - alpha|

/-- Proposition 4.3, in the genuine p-adic complex field, not ZMod. -/
def PadicZeroFreeDisk : Prop :=
  ∀ (p : ℕ) [Fact (Nat.Prime p)],
    ∀ (Q : Polynomial ℤ) (xi alpha : ℂ_[p]),
      ‖xi‖ ≤ 1 →
      Q.eval₂ (Int.castRingHom (ℂ_[p])) xi ≠ 0 →
      ‖alpha - xi‖ < ‖Q.eval₂ (Int.castRingHom (ℂ_[p])) xi‖ →
      ‖Q.eval₂ (Int.castRingHom (ℂ_[p])) alpha‖ =
        ‖Q.eval₂ (Int.castRingHom (ℂ_[p])) xi‖ ∧
      Q.eval₂ (Int.castRingHom (ℂ_[p])) alpha ≠ 0

/-- Exact algebraic family for Theorem 4.4: multipliers are not free of the
paper polynomial. The polynomial identity binds them to the rational
Hankel determinant at K=30n, N=3n. -/
structure QuantitativeWitness where
  start : ℕ
  multiplier : ℕ → ℚ
  integerPolynomial : ℕ → Polynomial ℤ
  beta : (n : ℕ) → Fin ((weightFive n).h) → ℝ
  normalized_exactly : ∀ n, start ≤ n →
    (integerPolynomial n).map (Int.castRingHom ℚ) =
      Polynomial.C (multiplier n) *
        ManuscriptChain.Real.delta (weightFive n)
  multiplier_positive : ∀ n, start ≤ n → 0 < multiplier n
  spectral_identification : ∀ n, start ≤ n →
    ∃ f : RootSpectrum (weightFive n),
      ∀ i : Fin ((weightFive n).h), f.beta i = beta n i
  normalized_quadratic_decay : ∀ n, start ≤ n →
    let x := (ManuscriptChain.Real.realPolynomial
      ((integerPolynomial n).map (Int.castRingHom ℚ))).eval
        (ManuscriptChain.Real.zeta 5)
    0 < x ∧ x ≤ Real.exp (-(((30*n : ℕ) : ℝ)^2) / 2500)
  spectral_growth : ∀ n, start ≤ n →
    ∀ i : Fin ((weightFive n).h),
      |beta n i| ≤ Real.exp ((11411 : ℝ) / 1000 * ((30*n : ℕ) : ℝ))

/-- Theorem 4.4's claimed final result. Importing a quantitative witness
DOES NOT by itself count as an unconditional proof of this proposition. -/
def QuantitativeMeasure : Prop :=
  EffectiveMeasure (ManuscriptChain.Real.zeta 5) 25687

/-- Theorem 4.5, including the exact mixed-weight positivity cone. -/
def MixedWeightMeasure : Prop :=
  ∀ a b : ℤ, MixedCone a b →
    Irrational (mixedZeta35 a b) ∧
      EffectiveMeasure (mixedZeta35 a b) 25687

/-- Relative determinant of the actual matrices, without square roots. -/
def relativeDeterminant (n : ℕ) : ℝ :=
  (ManuscriptChain.Real.derivativeMatrix (weightFive n)).det /
    (actualGram (weightFive n)).det

/-- Theorem 4.6(1): liminf/limsup encoded in elementary epsilon form.
A uniform estimate with epsilon is the eventual analytic target. -/
def RelativeDetAsymptotic : Prop :=
  ∀ epsilon : ℝ, 0 < epsilon →
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → 0 < n →
      (23310 : ℝ)/100000 - epsilon ≤
        Real.log |relativeDeterminant n| / (((30*n : ℕ) : ℝ)^2) ∧
      Real.log |relativeDeterminant n| / (((30*n : ℕ) : ℝ)^2) ≤
        (373980 : ℝ)/100000 + epsilon

/-- Theorem 4.7: the actual polynomial roots, not anonymous numbers,
carry a macroscopic subset in the claimed exponential cluster disk. -/
def RootClustering : Prop :=
  ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → 0 < n →
    let p := weightFive n
    ∃ f : RootSpectrum p,
      ∃ cluster : Finset (Fin p.h),
        ((14 : ℝ)/1000) * (p.h : ℝ) ≤ (cluster.card : ℝ) ∧
        ∀ i : Fin p.h, i ∈ cluster →
          |f.beta i|⁻¹ ≤ Real.exp (-((30*n : ℕ) : ℝ)/10)

/-- Theorem 4.8(1): rational root exclusion in the small-denominator
regime for the genuine primitive-equivalent rational determinant. -/
def RationalRootExclusion : Prop :=
  ∃ n₀ : ℕ, ∀ (n : ℕ), n₀ ≤ n → 0 < n →
    ∀ (a : ℤ) (b : ℕ), 0 < b →
      (b : ℝ) ≤ Real.exp (((30*n : ℕ) : ℝ)/2251) →
      ManuscriptChain.Real.evalQ
        (ManuscriptChain.Real.delta (weightFive n))
        ((a : ℝ) / (b : ℝ)) ≠ 0

/-- The author's spectral-variational equality (Conjecture 4.11) is
kept OUTSIDE the theorem hypothesis bundle. -/
structure VariationalConjectureData where
  variationalEnergy : ℝ
  spectralLimit : ℝ

/-- This remains a conjecture and is not part of `Hypotheses`. -/
def VariationalConjecture (d : VariationalConjectureData) : Prop :=
  d.spectralLimit = d.variationalEnergy

/-- Explicit unfinished prerequisites; Theorem 4.1's proved transfer
is not reintroduced as an assumption. -/
structure Hypotheses where
  proposition_4_2 : AlgebraicApproximationBound
  proposition_4_3 : PadicZeroFreeDisk
  theorem_4_4_quantitative_witness : QuantitativeWitness
  theorem_4_5 : MixedWeightMeasure
  theorem_4_6 : RelativeDetAsymptotic
  theorem_4_7 : RootClustering
  proposition_4_8 : RationalRootExclusion

end PaperBlueprint.S04
