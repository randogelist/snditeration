import PaperChronology.S02_Theorem_2_5

/-!
# CHAPTER 2 -- five chronological manuscript objects

These are types of mathematical statements, not an extra axiom layer.
Definition 2.1 and Lemmas 2.2-2.3 are checked on their specified bases;
Theorems 2.4-2.5 are linked to the actual rational Hankel pencil.
The earlier modules are imported unchanged (PASS-once cache).
-/

noncomputable section
open Polynomial
namespace PaperBlueprint.Chapters.S02

/-- Definition 2.1: agreement of the real arithmetic center with Mathlib zeta. -/
def D21 : Prop :=
  ∀ s : ℕ, 1 < s →
    ManuscriptChain.Real.zeta s = (riemannZeta s).re

/-- Lemma 2.2: the monomial-pullback basis identity, for every odd weight. -/
def L22 : Prop :=
  ∀ k e : ℕ, 1 ≤ k →
    Zetahyperbolic.muMonomial k e =
      (-1 : ℚ)^e * Zetahyperbolic.tauMonomial k (2*e+2*k+1)

/-- Lemma 2.3: the original simple-pole difference formula. -/
def L23 : Prop :=
  ∀ (k : ℕ) (r : ℤ), r ≠ 0 → r ≠ 1 →
    Zetahyperbolic.tauPolePoly k (r-1) -
      Zetahyperbolic.tauPolePoly k r =
        Polynomial.C (-((r : ℚ)^(2*k+1))⁻¹)

/-- Theorem 2.4: rational change-of-basis determinant covariance. -/
def T24 : Prop :=
  ∀ {h : ℕ} (G : Matrix (Fin h) (Fin h) (Polynomial ℚ))
      (A B : Matrix (Fin h) (Fin h) ℚ),
    (ManuscriptChain.BasisInvariance.changeBasisPencil G A B).det =
      Polynomial.C (A.det * B.det) * G.det

/-- Theorem 2.5: pole diagonalization at the negative-square nodes. -/
def T25 : Prop :=
  ∀ (p : Zetahyperbolic.HankelParams) (k : ℕ), 1 ≤ k →
    Zetahyperbolic.M_deriv p k =
      Zetahyperbolic.V_pole p *
        Matrix.diagonal (Zetahyperbolic.gammaWeight p k) *
        (Zetahyperbolic.V_pole p).transpose

/-- Previously established core: no new mathematical premise. -/
theorem d21_from_frozen : D21 := by
  intro s hs
  exact PaperChronology.S02_Definition_2_1.center_is_riemann_zeta_re s hs

theorem l22_from_frozen : L22 := by
  intro k e hk
  exact PaperChronology.S02_Lemma_2_2.monomial k e hk

theorem l23_from_frozen : L23 := by
  intro k r hr0 hr1
  exact PaperChronology.S02_Lemma_2_3.difference_pole k r hr0 hr1

theorem t24_from_frozen : T24 := by
  intro h G A B
  exact PaperChronology.S02_Theorem_2_4.determinant_covariance G A B

theorem t25_from_frozen : T25 := by
  intro p k hk
  exact (PaperChronology.S02_Theorem_2_5.pole_diagonalization p k hk).1

end PaperBlueprint.Chapters.S02

#print axioms PaperBlueprint.Chapters.S02.d21_from_frozen
#print axioms PaperBlueprint.Chapters.S02.l22_from_frozen
#print axioms PaperBlueprint.Chapters.S02.l23_from_frozen
#print axioms PaperBlueprint.Chapters.S02.t24_from_frozen
#print axioms PaperBlueprint.Chapters.S02.t25_from_frozen
