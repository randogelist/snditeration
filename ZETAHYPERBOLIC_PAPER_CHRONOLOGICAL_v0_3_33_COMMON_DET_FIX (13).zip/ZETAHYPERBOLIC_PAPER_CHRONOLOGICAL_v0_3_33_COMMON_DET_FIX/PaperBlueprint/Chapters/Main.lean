import PaperBlueprint.Chapters.Registry
import PaperBlueprint.FullPaper

/-!
# Full chronological paper: hypotheses as explicit goals

Every numbered item has an entry in `PaperBlueprint.Chapters.Item`.
`FullPaperTarget` is an unproved proposition. `BlueprintEvidence` is an
unconstructed record. This file does not prove their existence and never
uses `sorry`, `axiom`, or `opaque`.

The imported formalized Chapter-2 and Theorem-3.1 endpoints remain unconditional.
-/

noncomputable section
namespace PaperBlueprint.Chapters

/-- Reuse the certified Chapter 3 spectral theorem, not a new hypothesis. -/
theorem original_spectral_core : S03.T31 := S03.t31_from_frozen

/-- The two unconditional chronological pillars available without a
section-3/4/5/6 completion record. -/
theorem foundation :
    (S02.D21 ∧ S02.L22 ∧ S02.L23 ∧ S02.T24 ∧ S02.T25) ∧ S03.T31 :=
  ⟨chapter2_certified, original_spectral_core⟩

end PaperBlueprint.Chapters

#print axioms PaperBlueprint.Chapters.original_spectral_core
#print axioms PaperBlueprint.Chapters.foundation
#print PaperBlueprint.Chapters.FullPaperTarget
