import PaperBlueprint.S04
import MAIN_CHAIN

/-!
# CHAPTER 4 -- all nine numbered arithmetic targets

4.1 is already a generic conditional transfer theorem. 4.4's quantitative
witness remains one explicit mathematical input for that endpoint only.
4.11 is a CONJECTURE and is not required by Chapter4.Complete.
-/
noncomputable section
namespace PaperBlueprint.Chapters.S04

/-- Theorem 4.1: the proved general transfer, with its three explicit
certificate premises. -/
def T41 : Prop :=
  ∀ {Q : ℕ → Polynomial ℤ} {xi : ℝ}
    {radius budget : ℕ → ℝ} {start exponent threshold : ℕ},
      ManuscriptChain.RealTransfer.LocalComparison Q xi radius start →
      ManuscriptChain.RealTransfer.Decay Q xi budget start →
      ManuscriptChain.RealTransfer.IndexBudget
        Q radius budget start exponent threshold →
      ManuscriptChain.RealTransfer.RationalMeasure xi exponent threshold ∧
        Irrational xi

/-- Proposition 4.2: algebraic resultant / height transfer. -/
def P42 : Prop := PaperBlueprint.S04.AlgebraicApproximationBound

/-- Proposition 4.3: ultrametric disk over the actual complex p-adics. -/
def P43 : Prop := PaperBlueprint.S04.PadicZeroFreeDisk

/-- Theorem 4.4: existence of the exact normalized family witness PLUS
the asserted measure conclusion (existence is not claimed here). -/
def T44 : Prop :=
  Nonempty PaperBlueprint.S04.QuantitativeWitness ∧
  PaperBlueprint.S04.QuantitativeMeasure

/-- Theorem 4.5: mixed (zeta5,zeta3) effective measure in the full cone. -/
def T45 : Prop := PaperBlueprint.S04.MixedWeightMeasure

/-- Additional degree/height statements in Theorem 4.6, not derivable
solely from its determinant liminf/limsup bounds. -/
def CoefficientHeightBounds : Prop :=
  ∀ (w : PaperBlueprint.S04.QuantitativeWitness),
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → 0 < n →
      (PaperBlueprint.polynomialHeight (w.integerPolynomial n) : ℝ) ≤
        Real.exp ((1027 : ℝ)/100 * (((30*n : ℕ) : ℝ)^2))

/-- Theorem 4.6 full determinant asymptotics and coefficient heights. -/
def T46 : Prop :=
  PaperBlueprint.S04.RelativeDetAsymptotic ∧ CoefficientHeightBounds

/-- Theorem 4.7(2): the opposite-side gap for the *actual* certified
spectral values, not an anonymous proposition-valued field. -/
def OppositeSideGap : Prop :=
  ∀ (w : PaperBlueprint.S04.QuantitativeWitness) (n : ℕ),
    w.start ≤ n → 0 < n →
    ∀ (i j : Fin ((PaperBlueprint.weightFive n).h)),
      0 < w.beta n i → w.beta n j < 0 →
        2 * Real.exp (-(11411 : ℝ)/1000 * ((30*n : ℕ) : ℝ)) ≤
          |(w.beta n i)⁻¹ - (w.beta n j)⁻¹|

/-- Irreducible-factor separation with the actual polynomial and a
coefficient-height/O(K log K) correction that must later be proved. -/
def SameFactorRootSeparation : Prop :=
  ∃ C : ℝ, 0 < C ∧
    ∀ (w : PaperBlueprint.S04.QuantitativeWitness) (n : ℕ),
      w.start ≤ n → 0 < n →
      ∀ (F : Polynomial ℤ) (z1 z2 : ℂ),
        F ∣ w.integerPolynomial n → Irreducible F →
        2 ≤ F.natDegree →
        (F.map (Int.castRingHom ℂ)).eval z1 = 0 →
        (F.map (Int.castRingHom ℂ)).eval z2 = 0 →
        z1 ≠ z2 →
          Real.exp (-(1027 : ℝ)/100 * (F.natDegree : ℝ) *
              (((30*n : ℕ) : ℝ)^2) -
              C * ((30*n : ℕ) : ℝ) * Real.log (((30*n+1 : ℕ) : ℝ))) ≤
            ‖z1-z2‖

/-- Theorem 4.7 includes genuine clustering and both separation claims. -/
def T47 : Prop :=
  PaperBlueprint.S04.RootClustering ∧
  OppositeSideGap ∧ SameFactorRootSeparation

/-- Proposition 4.8: a precise logarithmic lower bound on degree for
an integer factor of the actual normalized determinant. -/
def FactorDegreeBound : Prop :=
  ∀ (w : PaperBlueprint.S04.QuantitativeWitness) (n : ℕ),
    w.start ≤ n → 0 < n →
    ∀ (F : Polynomial ℤ),
      F ≠ 0 → F ∣ w.integerPolynomial n → 0 < F.natDegree →
        Real.log |((F.leadingCoeff : ℤ) : ℝ)| -
          Real.log |(ManuscriptChain.Real.realPolynomial
            (F.map (Int.castRingHom ℚ))).eval
              (ManuscriptChain.Real.zeta 5)| ≤
          (F.natDegree : ℝ) * ((11411 : ℝ)/1000) *
            ((30*n : ℕ) : ℝ)

/-- Proposition 4.8 has actual rational root exclusion and factor bound. -/
def P48 : Prop :=
  PaperBlueprint.S04.RationalRootExclusion ∧ FactorDegreeBound

/-- Conjecture 4.11 is NOT asserted; it is recorded separately. -/
def Conjecture411 (data : PaperBlueprint.S04.VariationalConjectureData) : Prop :=
  PaperBlueprint.S04.VariationalConjecture data

structure Complete where
  proposition_4_2 : P42
  proposition_4_3 : P43
  theorem_4_4 : T44
  theorem_4_5 : T45
  theorem_4_6 : T46
  theorem_4_7 : T47
  proposition_4_8 : P48

/-- Use the existing generic theorem rather than restating it as a new axiom. -/
theorem t41_from_frozen : T41 := by
  intro Q xi radius budget start exponent threshold hlocal hdecay hindex
  exact ManuscriptChain.GENERAL_DIOPHANTINE_TRANSFER hlocal hdecay hindex

end PaperBlueprint.Chapters.S04
#print axioms PaperBlueprint.Chapters.S04.t41_from_frozen
