import PaperBlueprint.S05

/-!
# CHAPTER 5 -- six numbered two-variable / pole-system targets

Finite identities and infinite convergence are not conflated. All full
analytic and local valuation statements are explicit OPEN targets.
-/
noncomputable section
namespace PaperBlueprint.Chapters.S05

/-- Theorem 5.1: exact moment evaluations of the actual Beukers density. -/
def KernelPositive7 : Prop :=
  ∀ x y : ℝ, 0 < x → x < 1 → 0 < y → y < 1 →
    0 < PaperBlueprint.S05.beukersKernel7 x y

def T51 : Prop :=
  KernelPositive7 ∧ PaperBlueprint.S05.ExactBeukersMoments7

/-- Theorem 5.2(1): the true rational polynomial slope equals C C^T. -/
def DualSlopeIdentity : Prop :=
  ∀ {h K : ℕ} (C : Fin h → Fin (K+1) → ℚ)
    (i j : Fin h),
    (ManuscriptChain.Real.dualEntry 7 C i j).coeff 1 =
      ∑ r : Fin (K+1), C i r * C j r

/-- Theorem 5.2(1)-(3): positive slope, infinite signed Krein modes,
then genuine rational polynomial cones. -/
def T52 : Prop :=
  DualSlopeIdentity ∧
  PaperBlueprint.S05.InfiniteKreinDecomposition ∧
  PaperBlueprint.S05.OppositePolynomialCones

/-- Proposition 5.3: alternating beta(4) two-variable moments. -/
def P53 : Prop := PaperBlueprint.S05.ExactBeukersMomentsBeta4

/-- Theorem 5.4: no higher odd zeta value survives an even pole pair. -/
def T54 : Prop := PaperBlueprint.S05.EvenPoleCancellation

/-- Theorem 5.6: exact outer prime integral, inner tail, and pole-order
refinement must all be proved, not just the 11 rational affine areas. -/
def T56 : Prop :=
  PaperBlueprint.S05.ExactOuterPrimeSum ∧
  Nonempty PaperBlueprint.S05.InnerPrimeTail

/-- Theorem 5.7: real double-pole determinant and actual p-adic valuations. -/
def T57 : Prop := Nonempty PaperBlueprint.S05.DoublePoleValuation

structure Complete where
  theorem_5_1 : T51
  theorem_5_2 : T52
  proposition_5_3 : P53
  theorem_5_4 : T54
  theorem_5_6 : T56
  theorem_5_7 : T57

end PaperBlueprint.Chapters.S05
