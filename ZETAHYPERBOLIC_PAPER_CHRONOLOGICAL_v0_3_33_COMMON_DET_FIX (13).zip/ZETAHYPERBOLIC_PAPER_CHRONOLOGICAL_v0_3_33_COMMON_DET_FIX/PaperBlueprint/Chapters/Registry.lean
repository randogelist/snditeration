import PaperBlueprint.Chapters.S02
import PaperBlueprint.Chapters.S03
import PaperBlueprint.Chapters.S04
import PaperBlueprint.Chapters.S05
import PaperBlueprint.Chapters.S06

/-!
# Chronological theorem registry, all 47 numbered manuscript items
Each target is a concrete type (or a precisely labelled outstanding bridge).
The compiler verifying this FILE DOES NOT establish all these propositions.
Conjecture 4.11 is intentionally EXCLUDED from `AllRequired`.
-/

noncomputable section
namespace PaperBlueprint.Chapters

inductive Item where
  -- S02
  | definition_2_1
  | lemma_2_2
  | lemma_2_3
  | theorem_2_4
  | theorem_2_5
  -- S03
  | theorem_3_1
  | proposition_3_2
  | theorem_3_3
  | theorem_3_4
  | corollary_3_5_corrected
  | corollary_3_6_corrected
  | theorem_3_7
  | theorem_3_8
  | theorem_3_9
  -- S04
  | theorem_4_1
  | proposition_4_2
  | proposition_4_3
  | theorem_4_4
  | theorem_4_5
  | theorem_4_6
  | theorem_4_7
  | proposition_4_8
  | conjecture_4_11
  -- S05
  | theorem_5_1
  | theorem_5_2
  | proposition_5_3
  | theorem_5_4
  | theorem_5_6
  | theorem_5_7
  -- S06
  | theorem_6_1
  | theorem_6_2
  | theorem_6_3
  | theorem_6_4
  | theorem_6_5
  | theorem_6_6
  | theorem_6_7
  | corollary_6_8
  | theorem_6_9
  | theorem_6_10
  | theorem_6_11
  | theorem_6_12
  | theorem_6_13
  | theorem_6_14
  | theorem_6_15
  | theorem_6_16
  | theorem_6_17
  | theorem_6_18
  deriving DecidableEq, Repr

def Target : Item → Prop
  | .definition_2_1 => S02.D21
  | .lemma_2_2 => S02.L22
  | .lemma_2_3 => S02.L23
  | .theorem_2_4 => S02.T24
  | .theorem_2_5 => S02.T25
  | .theorem_3_1 => S03.T31
  | .proposition_3_2 => S03.P32
  | .theorem_3_3 => S03.T33
  | .theorem_3_4 => S03.T34
  | .corollary_3_5_corrected => S03.C35
  | .corollary_3_6_corrected => S03.C36
  | .theorem_3_7 => S03.T37
  | .theorem_3_8 => S03.T38
  | .theorem_3_9 => S03.T39
  | .theorem_4_1 => S04.T41
  | .proposition_4_2 => S04.P42
  | .proposition_4_3 => S04.P43
  | .theorem_4_4 => S04.T44
  | .theorem_4_5 => S04.T45
  | .theorem_4_6 => S04.T46
  | .theorem_4_7 => S04.T47
  | .proposition_4_8 => S04.P48
  | .conjecture_4_11 => ∃ data : PaperBlueprint.S04.VariationalConjectureData, PaperBlueprint.S04.VariationalConjecture data
  | .theorem_5_1 => S05.T51
  | .theorem_5_2 => S05.T52
  | .proposition_5_3 => S05.P53
  | .theorem_5_4 => S05.T54
  | .theorem_5_6 => S05.T56
  | .theorem_5_7 => S05.T57
  | .theorem_6_1 => S06.T61
  | .theorem_6_2 => S06.T62
  | .theorem_6_3 => S06.T63
  | .theorem_6_4 => S06.T64
  | .theorem_6_5 => S06.T65
  | .theorem_6_6 => S06.T66
  | .theorem_6_7 => S06.T67
  | .corollary_6_8 => S06.C68
  | .theorem_6_9 => S06.T69
  | .theorem_6_10 => S06.T610
  | .theorem_6_11 => S06.T611
  | .theorem_6_12 => S06.T612
  | .theorem_6_13 => S06.T613
  | .theorem_6_14 => S06.T614
  | .theorem_6_15 => S06.T615
  | .theorem_6_16 => S06.T616
  | .theorem_6_17 => S06.T617
  | .theorem_6_18 => S06.T618

/-- The required 46 mathematical/deﬁnitional items. Conjecture 4.11 is not required. -/
def RequiredItem (i : Item) : Prop := i ≠ .conjecture_4_11

/-- Single, explicit FULL-PAPER goal (currently unproved). -/
def FullPaperTarget : Prop := ∀ i : Item, RequiredItem i → Target i

/-- Chapterwise goal, NOT an asserted proof. -/
def ChapterTargets : Prop :=
  S02.D21 ∧ S02.L22 ∧ S02.L23 ∧ S02.T24 ∧ S02.T25 ∧
  Nonempty S03.Complete ∧ Nonempty S04.Complete ∧
  Nonempty S05.Complete ∧ Nonempty S06.Complete

/-- Existing algebraic Chapter 2 certificates are reused directly. -/
theorem chapter2_certified :
    S02.D21 ∧ S02.L22 ∧ S02.L23 ∧ S02.T24 ∧ S02.T25 := by
  exact ⟨S02.d21_from_frozen, S02.l22_from_frozen,
    S02.l23_from_frozen, S02.t24_from_frozen, S02.t25_from_frozen⟩

/-- A whole-paper record is an explicit *dependency blueprint*, not a
proof of existence. All still-open fields are displayed by their types. -/
structure BlueprintEvidence where
  section3 : S03.Complete
  section4 : S04.Complete
  section5 : S05.Complete
  section6 : S06.Complete

def BlueprintExists : Prop := Nonempty BlueprintEvidence

end PaperBlueprint.Chapters

#print axioms PaperBlueprint.Chapters.chapter2_certified
#check PaperBlueprint.Chapters.FullPaperTarget
#check PaperBlueprint.Chapters.BlueprintEvidence
