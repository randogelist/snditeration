import PaperBlueprint.S03
import PaperBlueprint.Chapters.S02
import MAIN_CHAIN_NO_OPEN_INPUTS
import Mathlib.MeasureTheory.Integral.SetIntegral

/-!
# CHAPTER 3 -- all nine spectral targets

3.1 is linked to the previously proved actual odd-zeta pencil.
3.2 through 3.9 are open mathematical PROPOSITIONS, including independent
analytic bridges not yet represented in S03.Hypotheses.
The printed 3.5 / 3.6 are corrected, not silently assumed.
-/
noncomputable section
open MeasureTheory
namespace PaperBlueprint.Chapters.S03

/-- Theorem 3.1: actual admissible odd-weight spectral theorem. -/
def T31 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p

/-- Proposition 3.2: normalized continuous extension at every real s>1. -/
def P32 : Prop := Nonempty PaperBlueprint.S03.ContinuousPencilExtension

/-- The missing measure-identification from moments to a positive density. -/
def ContinuousMomentRealization : Prop :=
  ∀ p : PaperBlueprint.Parameters,
    ManuscriptChain.Real.Admissible p →
      ∃ density : ℝ → ℝ,
        (∀ t : ℝ, 0 < t → 0 < density t) ∧
        (∀ r : ℕ,
          PaperBlueprint.actualMoment p r =
            ∫ t in Set.Ioi (0 : ℝ), t^r * density t)

/-- General sign count, beyond the special weight-five family. -/
def GeneralInertiaCount : Prop :=
  ∀ p : PaperBlueprint.Parameters,
    ManuscriptChain.Real.Admissible p →
      ∃ f : PaperBlueprint.RootSpectrum p,
        ∃ positive : Finset (Fin p.h),
          (∀ i : Fin p.h, i ∈ positive ↔ 0 < f.beta i) ∧
          positive.card =
            (Finset.univ.filter (fun i : Fin p.h =>
              Even (p.N + i.val + 1))).card

/-- Theorem 3.3 in full: analytic realization, Carleman, all mixed minors,
coefficient parity, and exact spectral inertia. -/
def T33 : Prop :=
  ContinuousMomentRealization ∧
  PaperBlueprint.S03.CarlemanDivergence ∧
  PaperBlueprint.S03.ContinuousTotalPositivity ∧
  PaperBlueprint.S03.WeightFiveLeadingSign ∧
  PaperBlueprint.S03.WeightFiveSignature ∧
  GeneralInertiaCount

/-- The fully quantified Desnanot-Jacobi identity in size n+2.
The central minor takes rows/columns 1,...,n; the four flanking
(n+1)-minors take the top/bottom rows and columns. This identity has
NO nonzero-minor side condition, because it uses multiplication only. -/
def DodgsonCondensation : Prop :=
  ∀ (n : ℕ) (A : Matrix (Fin (n+2)) (Fin (n+2)) ℝ),
    A.det *
      (A.submatrix
        (fun i : Fin n => Fin.succ (Fin.castSucc i))
        (fun j : Fin n => Fin.succ (Fin.castSucc j))).det =
      (A.submatrix Fin.castSucc Fin.castSucc).det *
        (A.submatrix Fin.succ Fin.succ).det -
      (A.submatrix Fin.castSucc Fin.succ).det *
        (A.submatrix Fin.succ Fin.castSucc).det

/-- Theorem 3.4: actual leading-minor interlacing and the full universal
Dodgson identity, not merely the already proved 3x3 case. -/
def T34 : Prop :=
  PaperBlueprint.S03.LeadingMinorInterlacing ∧
  DodgsonCondensation

/-- Corrected Corollary 3.5: true Schur fraction plus Lanczos nonbreakdown. -/
def C35 : Prop :=
  PaperBlueprint.S03.CorrectedJFraction ∧
  (∀ p : PaperBlueprint.Parameters,
    ManuscriptChain.Real.Admissible p →
      ∃ offdiag : Fin p.h → ℝ,
        ∀ i : Fin p.h, i.val + 1 < p.h → 0 < offdiag i)

/-- Corrected Corollary 3.6: finite discrete rank (large minors vanish). -/
def C36 : Prop := PaperBlueprint.S03.CorrectedFiniteRank

/-- Theorem 3.7: Newton inequalities on the actual primitive-equivalent
polynomial; the printed blanket strictness is not silently assumed. -/
def T37 : Prop := PaperBlueprint.S03.NewtonLogConcavity

/-- Independent Jacobi trace formula for a differentiable invertible
matrix family. Its application to a deformed Beukers integral is separate. -/
def JacobiDerivative : Prop :=
  ∀ (n : ℕ) (A : ℝ → Matrix (Fin n) (Fin n) ℝ) (t : ℝ),
    (∀ i j, DifferentiableAt ℝ (fun x => A x i j) t) →
    (A t).det ≠ 0 →
      deriv (fun x => Real.log |(A x).det|) t =
        ∑ i : Fin n, ∑ j : Fin n,
          ((A t)⁻¹) j i * deriv (fun x => A x i j) t

/-- The actual scaled Bose / hyperbolic density from Section 3,
with Laplace scale tau and integer weight parameter k. -/
def scaledDensity (k : ℕ) (tau y : ℝ) : ℝ :=
  (2 * (2 * Real.pi)^(2*k) / (Nat.factorial (2*k) : ℝ)) *
    y^(2*k+1) *
    ∑' n : ℕ,
      ((n+1 : ℕ) : ℝ)^(2*k) *
        Real.exp (-(2*Real.pi*tau*y*((n+1 : ℕ) : ℝ)))

/-- D_N(y²) as the ACTUAL product of positive-square factors. -/
def realDenominator (n : ℕ) (y : ℝ) : ℝ :=
  (ManuscriptChain.Real.realPolynomial
    (ManuscriptChain.Real.D n)).eval (y^2)

/-- The deformed actual Gram integral, not a freely chosen smooth matrix. -/
def deformedGram (p : PaperBlueprint.Parameters) (tau : ℝ) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  fun i j =>
    ∫ y in Set.Ioi (0 : ℝ),
      realDenominator p.N y ^ (2*p.m) /
        realDenominator p.K y *
        y^(2*(i.val+j.val)) * scaledDensity p.k tau y

/-- Theorem 3.8(2): exact weighted integral version of Jacobi's identity,
including the missing differentiating-under-the-integral-sign argument. -/
def WeightedJacobiDeformation : Prop :=
  ∀ p : PaperBlueprint.Parameters,
    ManuscriptChain.Real.Admissible p →
      deformedGram p 1 = PaperBlueprint.actualGram p ∧
      ∀ tau : ℝ, 0 < tau →
        (deformedGram p tau).det ≠ 0 ∧
        deriv (fun t => Real.log |(deformedGram p t).det|) tau =
          ∫ y in Set.Ioi (0 : ℝ),
            (∑ i : Fin p.h, ∑ j : Fin p.h,
              ((deformedGram p tau)⁻¹) j i *
                (realDenominator p.N y ^ (2*p.m) /
                  realDenominator p.K y) *
                y^(2*(i.val+j.val)) *
                deriv (fun t => scaledDensity p.k t y) tau)

/-- Theorem 3.8: true pole kernel, generic Jacobi and the concrete
Laplace-weighted integral differentiation. -/
def T38 : Prop :=
  PaperBlueprint.S03.PoleKernelSpectrum ∧
  JacobiDerivative ∧ WeightedJacobiDeformation

/-- Theorem 3.9: actual shifted-square and character Hankel pencils. -/
def T39 : Prop := PaperBlueprint.S03.HurwitzDirichletExtension

/-- Unconstructed record of all remaining Chapter-3 proof obligations. -/
structure Complete where
  prop_3_2 : P32
  theorem_3_3 : T33
  theorem_3_4 : T34
  corrected_3_5 : C35
  corrected_3_6 : C36
  theorem_3_7 : T37
  theorem_3_8 : T38
  theorem_3_9 : T39

/-- The only universally proved spectral endpoint is not a blueprint field. -/
theorem t31_from_frozen : T31 := by
  intro p hp
  exact PaperNoOpenInputs.THEOREM_3_1 p hp

end PaperBlueprint.Chapters.S03
#print axioms PaperBlueprint.Chapters.S03.t31_from_frozen
