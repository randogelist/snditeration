import PaperBlueprint.Common

/-!
# Section 3 blueprint — corrected structural targets

The declarations below are *unproved hypotheses*. Each is an explicit
mathematical statement or a certificate interface, not a claimed theorem.
The actual polynomial and Gram matrix from Section 2 are used throughout.

WARNING: the literal printed Corollaries 3.5 and 3.6 require correction.
-/

noncomputable section
open scoped BigOperators
namespace PaperBlueprint.S03

/-- Proposition 3.2: a continuous symmetric affine-pencil extension which
specializes exactly to the odd-weight matrices. The odd specialization
must use the corrected normalization of the weight. -/
structure ContinuousPencilExtension where
  base : ℝ → Parameters → (p : Parameters) → Matrix (Fin p.h) (Fin p.h) ℝ
  direction : ℝ → (p : Parameters) → Matrix (Fin p.h) (Fin p.h) ℝ
  positive : ∀ (s : ℝ) (p : Parameters), 1 < s →
    (base s p p).PosDef
  direction_nonsingular : ∀ (s : ℝ) (p : Parameters), 1 < s →
    (direction s p).det ≠ 0
  specialization : ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    base (p.weight : ℝ) p p = actualGram p ∧
      direction (p.weight : ℝ) p =
        ManuscriptChain.Real.derivativeMatrix p

/-- Theorem 3.3(1): Carleman divergence for the actual moment functional,
with the moment-to-measure identification to be formalized separately. -/
def CarlemanDivergence : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    2*p.m*p.N ≤ p.K →
    (∀ n, 0 < actualMoment p n) ∧
    ¬ Summable (fun n : ℕ =>
      (actualMoment p (n+1)) ^ (-(1 : ℝ) / (2 * (n+1) : ℝ)))

/-- Theorem 3.3(1): strict positivity of every mixed minor, not only
principal 2x2 and 3x3 atomic minors. -/
def ContinuousTotalPositivity : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    StrictTotalPositivity p

/-- Theorem 3.3(2): exact weight-five sign for the primitive polynomial.
Positive normalization leaves the sign of delta unchanged. -/
def WeightFiveLeadingSign : Prop :=
  ∀ n : ℕ, 0 < n →
    let p := weightFive n
    0 < (ManuscriptChain.Real.delta p).coeff p.h *
      (-1 : ℚ) ^ (n*(n-1)/2)

/-- Theorem 3.3(3): the spectral roots exist by Theorem 3.1; the desired
count is encoded by an exact set of positive eigenvalues. -/
def WeightFiveSignature : Prop :=
  ∀ n : ℕ, 0 < n →
    let p := weightFive n
    ∃ f : RootSpectrum p,
      ∃ positive : Finset (Fin p.h),
        positive.card = p.h / 2 ∧
        (∀ i : Fin p.h, i ∈ positive → 0 < f.beta i) ∧
        (∀ i : Fin p.h, i ∉ positive → f.beta i < 0)

/-- Theorem 3.4: full leading-principal-minor interlacing. The
`Fin.castSucc` and `Fin.succ` indices are exactly Cauchy interlacing. -/
def LeadingMinorInterlacing : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    ∀ (r : ℕ) (hr : r+1 ≤ p.h),
      ∃ (lower : Fin r → ℝ) (upper : Fin (r+1) → ℝ),
        (∀ i : Fin r,
          upper (Fin.castSucc i) ≤ lower i ∧
          lower i ≤ upper (Fin.succ i)) ∧
        (∀ x : ℝ,
          leadingMinor p r (Nat.le_trans (Nat.le_succ r) hr) x = 0 ↔
            ∃ i : Fin r, lower i = x) ∧
        (∀ x : ℝ,
          leadingMinor p (r+1) hr x = 0 ↔
            ∃ i : Fin (r+1), upper i = x)

/-- Corrected 3.5: nonzero normalization and an exact rational Schur
recursion are both required. A future revision must match the normalized
resolvent entry, not the misprinted unit-slope formula. -/
def CorrectedJFraction : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    ∃ (scale : ℝ) (diag slope offsq : ℕ → ℝ)
        (tail : ℕ → ℝ → ℝ),
      scale ≠ 0 ∧
      (∀ i, i+1 < p.h → 0 < offsq i) ∧
      (∀ x : ℝ, (∀ r, r+1 < p.h →
        (diag r + (x - ManuscriptChain.Real.zeta p.weight) * slope r -
          offsq r * tail (r+1) x) * tail r x = 1)) ∧
      (∀ x : ℝ,
        leadingMinor p p.h (Nat.le_refl _) x ≠ 0 →
          leadingMinor p (p.h-1) (Nat.sub_le _ _) x =
            scale * (leadingMinor p p.h (Nat.le_refl _) x) * tail 0 x)

/-- Corrected 3.6: the positive discrete measure has finite rank.
All sufficiently large Hankel determinants therefore VANISH. -/
def ReciprocalMoment (n : ℕ) (roots : Fin n → ℝ)
    (q : ℝ) (r : ℕ) : ℝ :=
  ∑ i : Fin n, (1 / ((roots i - q)^2)) ^ r

def CorrectedFiniteRank : Prop :=
  ∀ n : ℕ, ∀ roots : Fin n → ℝ, ∀ q : ℝ,
    (∀ i, roots i ≠ q) →
    ∀ r : ℕ, n < r →
      (fun i j : Fin r =>
        ReciprocalMoment n roots q (i.val+j.val) :
        Matrix (Fin r) (Fin r) ℝ).det = 0

/-- Theorem 3.7: Newton log-concavity of the *actual* polynomial's
normalized coefficients. The printed universal strictness is not assumed. -/
def NormalizedCoefficient (p : Parameters) (r : ℕ) : ℝ :=
  ((ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.delta p)).coeff r) /
    (Nat.choose p.h r : ℝ)

def NewtonLogConcavity : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    ∀ r : ℕ, 1 ≤ r → r+1 < p.h →
      NormalizedCoefficient p (r-1) *
        NormalizedCoefficient p (r+1) ≤
      (NormalizedCoefficient p r)^2

/-- Theorem 3.8: the actual pole-kernel matrix is the V^T G^-1 V
matrix; spectral equivalence and analytic Jacobi deformation remain open. -/
def PoleKernel (p : Parameters) (i j : Fin p.h) : ℝ :=
  let node (a : Fin p.h) : ℝ :=
    -(((p.N + a.val + 1 : ℕ) : ℝ)^2)
  ∑ a : Fin p.h, ∑ b : Fin p.h,
    (node i)^a.val * (actualGram p)⁻¹ a b * (node j)^b.val

def PoleKernelSpectrum : Prop :=
  ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
    ∃ f : RootSpectrum p,
      (∀ i : Fin p.h,
        ((ManuscriptChain.Real.derivativeMatrix p).det ≠ 0) ∧
        f.beta i ≠ 0) ∧
      (∃ K : Matrix (Fin p.h) (Fin p.h) ℝ,
        (∀ i j, K i j = PoleKernel p i j) ∧ K.IsSymm)

/-- Theorem 3.9: nonzero shifted-square pole derivative and positive
moment realization for rational Hurwitz shifts and the listed characters. -/
def HurwitzDirichletExtension : Prop :=
  ∀ (theta : ℚ), 0 < theta → theta ≤ 1 →
    ∀ (p : Parameters), ManuscriptChain.Real.Admissible p →
      ∃ (base slope : Matrix (Fin p.h) (Fin p.h) ℝ),
        base.PosDef ∧ slope.IsSymm ∧ slope.det ≠ 0

/-- Bundle of explicit hypotheses for the *unfinished* Section 3 items. -/
structure Hypotheses where
  proposition_3_2 : ContinuousPencilExtension
  theorem_3_3_carleman : CarlemanDivergence
  theorem_3_3_total_positive : ContinuousTotalPositivity
  theorem_3_3_leading_sign : WeightFiveLeadingSign
  theorem_3_3_signature : WeightFiveSignature
  theorem_3_4_interlacing : LeadingMinorInterlacing
  corollary_3_5_corrected : CorrectedJFraction
  corollary_3_6_corrected : CorrectedFiniteRank
  theorem_3_7_newton : NewtonLogConcavity
  theorem_3_8_pole_kernel : PoleKernelSpectrum
  theorem_3_9_extended_pencils : HurwitzDirichletExtension

end PaperBlueprint.S03
