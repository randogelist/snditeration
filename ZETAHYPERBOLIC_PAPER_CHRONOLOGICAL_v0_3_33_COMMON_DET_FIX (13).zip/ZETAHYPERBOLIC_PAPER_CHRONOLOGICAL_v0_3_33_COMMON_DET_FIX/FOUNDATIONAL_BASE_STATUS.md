# Foundational Lean base v0.3.12 — SOURCE-ONLY / UNCOMPILED

## Verified inherited checkpoint
The latest compiler log supplied by the user predates v0.3.10 and v0.3.11.
The successful modules in that earlier log remain frozen when source/import/environment hashes match.
No compiler test was performed while assembling v0.3.12.

## New genuine algebraic theorem families

- **S03_Theorem_3_3_ThreeAtomMoment**: exact two- and three-atom Hankel determinants,
  positive 2×2 and 3×3 minors under explicit weight/distinct-node assumptions.
- **S03_Theorem_3_3_ArbitraryFiniteGram**: all-dimensional determinant factorization
  `det(V diag(w) Vᵀ) = det(V)² ∏wᵢ`; strict positivity and nonvanishing conditions.
- **S03_Theorem_3_3_RootSideTransfer**: precise position of an individual root
  `ξ - β⁻¹` on each side of ξ from the sign of β.
- **S04_Theorem_4_1_TransferWindow**: proof of the nonempty choice interval
  `λ/ε < c < μ/ρ`, plus rigorous exponent inequalities `λ/c<ε`, `ρc<μ`.
  Paper's constants give exact margins `1/5627500` and `839/1000`.
- **S05_Theorem_5_2_DualDeterminant**: strict determinant positivity for the
  genuine finite real dual slope matrix from actual independent coefficient rows.
- **S05_Theorem_5_6_OuterPartition**: exact partition endpoint checks and
  rational sum of the eleven printed affine areas (analytic identification remains open).
- **S06_Theorem_6_1_LocalObstruction**: universally valid 2×2 local block
  determinant `-1/36`, and field-theoretic nonvanishing in characteristic not 2 or 3.

## Logic and mathematical proof discipline

1. Proof obligations not discharged by this package are not declared as axioms.
2. Arbitrary-dimensional *finite* Gram claims do not imply strict total positivity
   for the continuous weight in manuscript Theorem 3.3 by themselves.
3. The manuscript's infinite Krein construction (Theorem 5.2) remains separate from
   the true finite-dimensional Gram statements.
4. The standalone quantitative endpoint remains conditional on one `Witness`,
   containing the *uniform eventual* paper estimates. No existence claim for it.
5. A single successful `run.cmd` invocation proves only the named statements
   actually present in the Lean files, not the complete PDF.

## Native Windows user-compiler workflow

Exactly one `run.cmd`. Lean 4.33.0. No Lake invocation, no network, no Python,
no local compilation by assistant. Reuse unchanged passing `.olean` files.
Use `call run.cmd full` only when the user expressly requests full rebuild.

## Early formal certificate
`PaperProofs.FOUNDATIONAL_CERTIFICATE.PAPER_UNCONDITIONAL_FOUNDATIONS` bundles
odd-weight spectral existence, arbitrary finite Hankel-Gram determinants,
correct scaling-window existence, dual-slope positive determinants,
Theorem 5.4 simple-pole cancellation, and the Theorem 6.1 local pole block.
It is scheduled **before** `PAPER_SINGLE_WITNESS_CHAIN` and requires no Witness.

## Standalone proof graph decoupling
Existing unconditional simple-pole cancellation (§5.4), rational outer-area arithmetic (§5.6),
extra-denominator identity (§6.1), and the 2×3 Gram identity (§6.10) now compile before
the optional Witness endpoint. This changes only imports in four modules; previously
verified dependencies remain frozen unless invalidated by the new import graph.

## Further verified source targets (pending the user compiler)
- `S03_Theorem_3_7_ThreeRootNewton`: exact Newton gap formula, inequality,
  and strict inequality for unequal spectral values.
