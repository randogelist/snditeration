# Exact manuscript-to-Lean closure audit — v0.3.28 (2026-10-24)

Source: 52-page `PAPER_SOURCE.pdf`, identical SHA-256 to the 2026-10-24 user-uploaded PDF.
Lean source: v0.3.27 with *zero changes to .lean proofs*; one unchanged FASTCORE runner except its package label.
This is a source-level audit. **No Lean compiler is run** and successful checks are never inferred from uncompiled text.

## Strict theorem-level count

| Type of item | Count | Meaning |
|---|---:|---|
| Package matrix calls formalized | 6 | Five Section 2 items and Theorem 3.1; scope of actual Lean endpoint must be checked against PDF |
| Full closure candidate, user compiler pending | 2 | Proposition 4.3, Theorem 5.4 |
| Partial paper statements | 14 | Genuine proof fragments, including many arbitrary finite-dimensional results |
| Witness-conditional | 1 | Theorem 4.4 (all quantitative premises in one structure), but witness existence NOT proved and endpoint not proven by recent logs |
| Correction-required | 5 | Proposition 3.2, Corollaries 3.5/3.6, Theorems 6.4 and Corollary 6.8 |
| Open | 18 | Missing essential analytic/arithmetic proofs |
| Conjecture | 1 | Conjecture 4.11; not an obligation to be proved as theorem |
| **Tracked** | **47** | Includes Definition 2.1 and Conjecture 4.11; not 47 mathematical theorems |

Strict confirmed baseline from earlier user compiler logs: **6/47 = 12.77%**.
If BOTH candidate full closures compile with clean standard-axiom audit and exact statement scope: **8/47 = 17.02%**.
**Do not promote 8/47 prematurely**. Latest user-provided run reported compilation success through many Section 3 modules and a failure at S04_Proposition_4_3_PadicDisk; the later repair was blocked by a cache lock, and no v0.3.27 PASS log was provided.

## Partition by PDF section

| Section | Formalized | Partial | Full-pending | Witness | Corrections | Open | Conjecture | Tracked |
|---|---:|---:|---:|---:|---:|---:|---:|
| §2 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 5 |
| §3 | 1 | 4 | 0 | 0 | 3 | 1 | 0 | 9 |
| §4 | 0 | 2 | 1 | 1 | 0 | 4 | 1 | 9 |
| §5 | 0 | 2 | 1 | 0 | 0 | 3 | 0 | 6 |
| §6 | 0 | 6 | 0 | 0 | 2 | 10 | 0 | 18 |

## Structural progress — not theorem closure

At least 23/47 items have an unconditional formalized/partial or pending proof body, or a witness-conditional proof route: 6+14+2+1 = **23/47 = 48.9%** of *items touched*, not mathematically proved. Five further correction-required items contain proof/correction infrastructure, putting the broad scope of structurally addressed items at roughly **50–60%**. This is a deliberately approximate breadth indicator, not a formal probability or percent of line-by-line paper proofs.

Verified source inventory: 156 `.lean` files; 13,444 physical Lean source lines; 652 top-level `theorem` declarations; 54 `lemma` declarations; 143 scheduled build checks; and 12 other `.lean` files plus the `lakefile` not directly on the run list. These counts say nothing by themselves about statement equivalence or compilation success. Searches find no `axiom` declaration and the words `sorry`/`admit` only in comments. Frozen PASS stamps must be checked against source, imports, and toolchain.

## Most valuable next full closures

1. **§4 Proposition 4.3:** finish `PaperProofs.S04_Proposition_4_3_PadicDisk` on the real `ℂ_[p]`, then wrapper. No finite ZMod substitution.
2. **§5 Theorem 5.4:** confirm the exact all-odd-weights simple-pole endpoint and audit all imported axioms.
3. **§3 Theorem 3.3:** new residue alternating-sign normal form (`v0.3.27`, FIVE uncompiled modules) plus continuous-measure strict total positivity, signed inertia count, and Carleman determinacy. The first alone does *not* close Theorem 3.3.
4. **§3 Theorem 3.4:** prove all-dimensional leading-principal spectral interlacing, not just 2x2, plus general Jacobi/Dodgson identity.
5. **§5 Theorem 5.2:** finite dual slope / hyperbolicity already substantial; the infinite Krein decomposition and genuine rational-polynomial positive/negative cones remain unproved.

## Single Witness architecture

Theorem 4.4 remains conditional on a record of uniform asymptotic arithmetic and archimedean inequalities, **not** a finite certificate whose existence follows from a finite calculation. This one Witness does not discharge independent theorems across Sections 5–6. A full-paper, one-Witness theorem has not been proved.

## Reproducibility

Exactly one root `run.cmd`. Native Windows Lean 4.33.0, pinned dependencies, frozen hash-cache, `recover` isolation for a busy cache. No local Lean execution. The bundled PDF has not been modified.
