# Audit-only release v0.3.28

Formal Lean files unchanged since v0.3.27. See `THEOREM_CLOSURE_AUDIT_V0328.md` for exact completion boundaries.

# v0.3.12 — Unconditional Formal Foundational Certificate

# ZETAHYPERBOLIC — v0.3.6 — chronological proof advance

Start: `run.cmd` (native Windows CMD, Lean 4.33.0, FASTCORE, single-writer lock).
Optional complete reset: `run.cmd full`.

New source files are in `PaperProofs/`; all previous sources are unchanged.
The native build compiles in PDF order, preserving previously passed `.olean`s
where source/manifest/toolchain and local-import stamps remain valid.

**Trust boundary**: only previously checked statements and new user-compiled
proofs count. Incomplete §3–§6 endpoints remain unproved. See `PROOF_DELTA.md`
and `PROOF_MATRIX.md`. No local Lean build was performed.


## v0.3.7 — Compiler frontier repair
- Theorem 3.3 arithmetic parity lemma rebuilt with explicit `congrArg` identities,
  avoiding rewriting under integer division.
- This is the only modified Lean source; all previously PASSed modules remain byte-identical.
- `#print axioms` added for the four exact arithmetic lemmas.
- The full total-positivity and Sylvester-inertia statements remain open.
- No local Lean compilation performed; only your Windows compiler validates the repair.


## v0.3.8 new chronological statements

- Theorem 3.3: arbitrary mixed 2×2 determinant for a genuine finite two-atom Hankel measure; strict adjacent positivity for two distinct positive nodes.
- Theorem 3.4: exact 2×2 symmetric eigenvalue formulas and 1×1→2×2 interlacing.
- These are unconditional finite cases, **not** claims to finish the infinite/continuous paper theorems.
- Older sources preserved byte-for-byte. First test is on the user's Lean 4.33.0 native compiler only.

- Corollary 3.6: explicit 3×3 Hankel rank obstruction at every shift for a two-atom moment measure.

## v0.3.9

Repair of `PaperProofs.S03_Corollary_3_5_Schur` from the user compiler log.
Run `run.cmd` in this folder. Previously passing modules retain their cache.
No local Lean compilation was carried out when packaging this revision.

## v0.3.11 finite spectral advance

* `PaperProofs.S03_Theorem_3_8_PoleKernel`: exact pole-kernel transpose and symmetry of the C–D pole evaluation matrix.
* `PaperProofs.S05_Theorem_5_2_DualSlope`: coefficient-of-X identity `[X]G_A = C Cᵀ` and diagonal nonnegativity, all finite dimensions.
* Existing modules unchanged; shared FASTCORE frozen cache retained.
* Both new modules compile before the optional `PAPER_SINGLE_WITNESS_CHAIN`, so the user's compiler can certify unconditional results separately.
* This release has not been compiled locally. The 52-page paper remains **partially** formalized.

* `PaperProofs.S05_Theorem_5_2_DualEnergy`: finite real Gram energy is an exact sum of squares; positivity is unconditional.

## New checkpoint
The module `PaperProofs.FOUNDATIONAL_CERTIFICATE` constructs one real proof term for
`UnconditionalPaperCore`, including spectral, finite Gram, transfer, dual slope,
even pole and local arithmetic results. The main witness endpoint remains separate.

## v0.3.15 exact fifth-power finite kernel

See `CHANGELOG_v0_3_15.md` for the added fully quantified algebraic modes, finite geometric identity, and explicit cone energies. They remain native compiler-pending.


See `COVERAGE_NOW.md` for a precise manuscript-level status audit.


## v0.3.22 principal-theorem continuation
See `PRINCIPAL_THEOREMS_V0322.md`; 136 native Lean build modules, frozen FASTCORE cache.

## v0.3.23: two full mathematical closures (compiler-pending)
The PDF §4.3 p-adic and §5.4 even-pole theorems now have exact proof targets, not just partial fragments.
See THEOREM_CLOSURES_V0323.md. Your Lean 4.33 is the sole compiler.


## v0.3.26 lock safety

See `LOCK_SAFE_RECOVERY_v0326.md`. Running `run.cmd recover` uses the previous
certificate cache when safely available; otherwise it selects a persistent
fully isolated cache. No old proof artifact is modified to recover an active lock.

### v0.3.27: Theorem 3.3 alternating sign frontier

Five new, locally uncompiled Lean modules prove the residue product sign and
the actual matrix-inertia normal form. See `PROOF_DELTA_v0_3_27.md`.
Only your Windows Lean compiler determines PASS/FAIL.


## v0.3.30 Open theorem specification
See `HYPOTHESIS_BLUEPRINT_V0330.md` and `PaperBlueprint/FullPaper.lean`. They are **unproved hypotheses**, not theorem certificates.

## v0.3.31 chapter-level blueprint

See `CHAPTER_TARGETS_V0331.md` and `PaperBlueprint/Chapters/Registry.lean`.
All 47 numbered PDF items now have named Lean blueprint entries; some have schematic bridges that still need exact formal statements, and none of the open items is claimed proved.
CRLF native Windows CMD label recovery + Batteries cache validation.

## v0.3.32 paragraph checkpoints

See `PARAGRAPH_CHECKPOINT_REPORT.md` and `PARAGRAPH_CHECKPOINTS.tsv`.
`PaperBlueprint/Chapters/ParagraphCheckpoints.lean` holds typed source goals.
Each compiler PASS / valid FROZEN_PASS emits per-passage checkpoint markers.
Full theorem closure is not implied. Previously passed Lean sources are byte-unchanged.

