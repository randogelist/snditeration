# v0.3.9 Schur repair

- First failed module in user log: `PaperProofs.S03_Corollary_3_5_Schur`.
- Preserved the confirmed passes through `PaperChronology.S03_Corollary_3_5`.
- Replaced a brittle bare `field_simp; ring` sequence by `<;> ring`, which remains valid when `field_simp` closes its goal.
- Added a separately stated exact determinant factorization, and derived nonzero Schur pivot from nonzero determinant.
- No axiom, `sorry`, `admit`, or witness added to the mathematical source.
- Does not claim arbitrary-dimensional Lanczos existence or the PDF's incorrect unit-slope identity.
- No Lean compilation performed; test solely on the user's Lean 4.33 compiler.

## v0.3.12 delta
- 8 newly authored proof modules plus unconditional formal certificate.
- 4 older standalone modules decoupled from late paper wrappers for early checking.
- No compiler run; all new statements require user native Lean 4.33 confirmation.

## v0.3.15 exact fifth-power finite kernel

See `CHANGELOG_v0_3_15.md` for the added fully quantified algebraic modes, finite geometric identity, and explicit cone energies. They remain native compiler-pending.


## v0.3.22 (UNCOMPILED NEW TARGETS)
- Corrected the atomic-energy positive-sum lemma.
- Added unconditional arbitrary-dimensional positive-slope spectral factorization.
- Connected true two-variable dualDelta(7) to symmetric pencil and real roots.
- Linked actual Theorem 3.1 and actual Theorem 5.2(1) in a top-level theorem.
