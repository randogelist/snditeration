import PaperChronology.S06_Theorem_6_18

/-!
# Chronological assembly: all numbered items in the manuscript

Every non-conjectural item is represented by a separate, correctly ordered
module. The early algebra and spectral theorem are unconditional. Some later
items only have proved finite components; the rest are explicit research
frontiers, not hidden hypotheses or admitted theorems. Only the optional
quantitative Section 4.4 endpoint takes the paper's `Witness`.
-/
noncomputable section
namespace PaperChronology

/-- Proven: the manuscript's actual universal odd-weight spectral core. -/
theorem THEOREM_3_1_ALL_ODD_WEIGHTS :
    ∀ p : ManuscriptChain.Real.Parameters,
      ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p := by
  intro p hp
  exact S03_Theorem_3_1.universal_hyperbolicity p hp

/-- The paper's Section 4.4 endpoint, with its one explicit eventual witness. -/
theorem SECTION_4_4_FROM_WITNESS (w : S04_Theorem_4_4.Witness) :
    Irrational (riemannZeta 5).re ∧
    (∃ b₀ : ℕ, ∀ (a : ℤ) (b : ℕ),
      0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|) := by
  exact ⟨S04_Theorem_4_4.irrationality w,
    S04_Theorem_4_4.measure w⟩

end PaperChronology

#print axioms PaperChronology.THEOREM_3_1_ALL_ODD_WEIGHTS
#print axioms PaperChronology.SECTION_4_4_FROM_WITNESS
