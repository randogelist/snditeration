import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Paper Theorem 2.5 — constructor-safe native Lean repair

This module replaces the old `PaperOrder` proof wrapper whose elaboration
failed with `Eq.refl` / `And.intro h.left`.  The underlying Lagrange
pole-diagonalization and determinant-degree lemmas are proved in
`Theorem_2_5_Lagrange_Pole_Diagonalization`.

The conjunction is fully parenthesized; neither theorem is proved by
reconstructing an `Eq` goal with `⟨..., ...⟩` or by assuming a certificate.
No `sorry`, `admit`, `axiom`, or other unproved declaration is introduced.
-/

noncomputable section
open Polynomial

namespace PaperOrder.Section2

/-- Paper Theorem 2.5, diagonal affine decomposition of the original
rational moment-functional pencil, with nonzero diagonal slopes. -/
theorem theorem_2_5_lagrange_evaluation
    (p : ManuscriptChain.Real.Parameters) :
    (∀ (a b : Fin p.h), a ≠ b →
      ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a b =
        C (ManuscriptChain.PoleDiagonalization.poleConstantMatrix p a b)) ∧
    (∀ (a : Fin p.h),
      (ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a a =
        C (ManuscriptChain.PoleDiagonalization.poleWeight p a) *
          (X - C (ManuscriptChain.Real.harmonic p.weight
            (ManuscriptChain.PoleDiagonalization.poleIndex p a))) +
          C (ManuscriptChain.PoleDiagonalization.poleDiagonalRemainder p a)) ∧
      ManuscriptChain.PoleDiagonalization.poleWeight p a ≠ 0) := by
  exact ManuscriptChain.PoleDiagonalization.theorem_2_5_lagrange_pole_diagonalization p

/-- The same fully proven diagonalized-pencil result, together with the
exact Hankel determinant degree `h`.  It requires no extra hypothesis. -/
theorem theorem_2_5_pencil_and_degree
    (p : ManuscriptChain.Real.Parameters) :
    ((∀ (a b : Fin p.h), a ≠ b →
      ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a b =
        C (ManuscriptChain.PoleDiagonalization.poleConstantMatrix p a b)) ∧
     (∀ (a : Fin p.h),
      (ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a a =
        C (ManuscriptChain.PoleDiagonalization.poleWeight p a) *
          (X - C (ManuscriptChain.Real.harmonic p.weight
            (ManuscriptChain.PoleDiagonalization.poleIndex p a))) +
          C (ManuscriptChain.PoleDiagonalization.poleDiagonalRemainder p a)) ∧
      ManuscriptChain.PoleDiagonalization.poleWeight p a ≠ 0)) ∧
    (ManuscriptChain.Real.delta p).natDegree = p.h := by
  exact And.intro (theorem_2_5_lagrange_evaluation p)
    (ManuscriptChain.PoleDiagonalization.delta_natDegree p)

/-- In particular the actual determinant is not the zero polynomial. -/
theorem theorem_2_5_nonzero (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Real.delta p ≠ 0 :=
  ManuscriptChain.PoleDiagonalization.delta_ne_zero p

#print axioms PaperOrder.Section2.theorem_2_5_lagrange_evaluation
#print axioms PaperOrder.Section2.theorem_2_5_pencil_and_degree

end PaperOrder.Section2
