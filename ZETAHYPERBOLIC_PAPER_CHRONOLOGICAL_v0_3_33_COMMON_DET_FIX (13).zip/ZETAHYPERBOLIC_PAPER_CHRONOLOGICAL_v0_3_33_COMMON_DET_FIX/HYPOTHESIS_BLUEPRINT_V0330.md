# ZETAHYPERBOLIC v0.3.30 — hypothesis blueprint

## What this release actually does

This is the exact prior v0.3.29 source tree plus SIX NEW Lean specification modules.
No old mathematical `.lean` source was edited. Existing successful native Lean
`.olean` fingerprints remain reusable by the persistent FASTCORE cache.

A Lean `def ... : Prop` defines a statement; it does **not** prove it. A
`structure Hypotheses` with a field of that type describes the exact
additional mathematical evidence needed before a theorem can be closed.
`#check` and compilation of the structure merely validate syntax/types.

| File | Target |
| --- | --- |
| `PaperBlueprint/Common.lean` | Actual rational Hankel Gram, real zeta, mixed minors, normalization/cone vocabulary |
| `PaperBlueprint/S03.lean` | Real-s continuous extension, Carleman, all mixed minors, inertia, interlacing, corrected J-fraction, finite rank, Newton, pole kernel, Hurwitz/Dirichlet |
| `PaperBlueprint/S04.lean` | Resultants, genuine Cp disk, explicit K=30n polynomial normalization/decay/spectral Witness, mixed zeta forms, determinant limits, root clustering |
| `PaperBlueprint/S05.lean` | Actual two-variable Beukers integrals, infinite signed Krein series and polynomial cones, beta(4), even poles, prime integral, double-pole valuations |
| `PaperBlueprint/S06.lean` | Named typed slots for all 18 numbered theorems, including 2/odd-adic valuations, multiweight zeta-beta, rank-one beta, asymptotic potential gap |
| `PaperBlueprint/FullPaper.lean` | Single **bundle of OPEN hypotheses** and theorem projections; preserves unconditional Theorem 3.1 |

## Main statement boundary

`PaperBlueprint.CompleteBlueprint : Prop := Nonempty PaperBlueprint.Hypotheses`

There is intentionally NO term of this type in the package. In particular,
`Hypotheses` is NOT the finite Witness of the earlier §4.4 conditional
irrationality endpoint: it packages MANY still-open independent claims.
No theorem derives these claims from the §4.4 Witness.

`PaperBlueprint.spectral_core_proved` remains an unconditional reference to the
previously established §3.1 result. The other projection theorems take an
EXPLICIT argument `h : PaperBlueprint.Hypotheses` and simply extract its fields.
They do not establish those fields.

## Mathematical corrections

- 3.2: continuous density normalization must be corrected before proving odd-integer specialization.
- 3.5: the displayed J-fraction lacks correct normalization / affine denominator; the typed target is a corrected Schur recursion **schema** requiring further refinement.
- 3.6: a finite atomic positive measure has zero determinants above the support rank. The corrected rank-zero target is explicit.
- 6.4, 6.8: retain distinct analytic and mixed-weight bridge targets; they are not automatic consequences of an unrelated zeta(5) witness.
- 4.11 is a conjecture; its statement is NOT included among mandatory theorem assumptions.

## Proof development strategy

1. Compile these declarations natively with your pinned Lean 4.33 / Mathlib.
2. For each open field, replace a schematic `Prop` bridge with a precise
   definition tied to the PDF's concrete kernel, valuation or determinant.
3. Prove the field using an imported unconditional theorem or a new lemma.
4. Move proven fields out of the Hypotheses structure into a frozen certified
   module; the full paper's hypothesis bundle should shrink.
5. The only acceptable final finite-witness endpoint is a terminating verifier
   whose acceptance invokes a completely proven downstream chain. That is a
   **future goal**, not claimed by this ZIP.

## Native Windows run

Extract the ZIP in Downloads; use its sole root-level `run.cmd` with `recover`.
No compilation, Mathlib fetch or theorem checking was performed when preparing
this archive. Compilation and axiom audit occur only on the user's machine.
