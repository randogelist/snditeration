# v0.3.27 — exact residue-sign and signed inertia foundations

Target: Theorem 3.3(3). All five new modules are unconditional algebra, and **not locally compiled**. They form a rigorous proof target, not yet a certified result.

1. `SignedResidueProducts`: for each tail pole a, the normalized numerator has sign `(-1)^N` and the denominator has sign `(-1)^(a-N-1)`. No floating-point approximations.
2. `ResidueParityRatio`: the odd `(2m-1)` exponent and positive `a^(2k)` factor yield a strictly positive signed quotient.
3. `AlternatingPoleSign`: `0 < (-1)^(a-1) * gammaWeight(p,k,i)` for every original HankelParams and every finite tail pole.
4. `SignByPoleParity`: odd pole index implies positive actual weight; even pole index implies negative actual weight.
5. `InertiaNormalForm`: the **actual** derivative matrix is congruent to `diagonal (gammaWeight ...)`; each diagonal entry has the proven alternating sign.

These replace neither the missing continuous-measure total-positivity proof nor Sylvester's law/inertia counting theorem. The full Theorem 3.3 is not claimed.

- Only 5 new `.lean` sources; no previously passing source edited.
- Full compiler and axiom verification is exclusively on the user's native Windows Lean 4.33 installation.
- The root `run.cmd` is the sole CMD runner; execute with `recover`.
- Stable FASTCORE primary/isolated cache namespace and frozen PASS stamps preserved.
