import Zetahyperbolic.Foundations
import Zetahyperbolic.CoreLinearAlgebra
import Zetahyperbolic.LagrangeBasis
import Zetahyperbolic.Section2Algebra
import Zetahyperbolic.Section3Elementary
import Zetahyperbolic.Section2Checked
import Zetahyperbolic.ManuscriptCompatibility
import Zetahyperbolic.MainChain
import MAIN_CHAIN_ASSEMBLED
import MAIN_CHAIN_ARITHMETIC

/-!
# Zetahyperbolic: general odd-weight Hankel theorem

`Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL` covers arbitrary admissible k,m,N,K.
The actual positive moment realization and its integral identities are proved.
The endpoint establishes full determinant degree, real roots, spectral
factorization, and a positive zero-free disk. The exact radius is attained
by a root, as stated in `ORIGINAL_EXACT_ZERO_FREE_DISK`.
The general arithmetic implication is exported by MAIN_CHAIN_ARITHMETIC:
normalized quadratic decay and linear degree growth imply irrationality.
The decay estimate remains an explicit hypothesis.
Specialized arithmetic applications remain separate in APPLICATIONS.
-/
namespace Zetahyperbolic

theorem setup_smoke_test : 1 + 1 = 2 := by norm_num

end Zetahyperbolic
