# v0.3.18 — explicit orphan lock recovery

- Native Windows single-writer cache error `CACHE_BUSY_OTHER_BUILD_OR_STALE_LOCK` is not a Lean proof failure.
- `run.cmd` remains the default strict mode. It never removes another owner's lock.
- `run.cmd recover` is the **explicit** recovery path for stale empty lock directories after a prior process exits unexpectedly.
- Recovery uses native `tasklist` to require no visible `lean.exe`/`lake.exe`; process enumeration failures abort. If the lock contains files, recovery also aborts. It preserves all `.olean` files, stamps and dirty flags.
- If an old CMD build is still running between Lean subprocesses, there is no universally reliable owner detection from the legacy empty lock directory. Do not use recovery until all previous builds have truly finished and their consoles are closed.
- Incremental compilation is the default; `run.cmd full` is still available as an explicit full rebuild.
- No changes to any `.lean` source file, no local Lean compilation.
