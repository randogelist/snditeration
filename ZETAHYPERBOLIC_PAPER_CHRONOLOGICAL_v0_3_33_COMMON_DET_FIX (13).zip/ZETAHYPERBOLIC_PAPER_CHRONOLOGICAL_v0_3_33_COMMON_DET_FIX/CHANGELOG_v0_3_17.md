# v0.3.17 - signed feature kernels and failure-resilient cache

- Theorem 5.2: new unconditional finite feature-kernel Gram identity for arbitrary
  numbers of evaluation points and arbitrary numbers of modes; signed
  positive-minus-negative feature energy factorization.
- Theorem 5.2: finite fifth-power Krein quadratic identity in every dimension;
  the printed infinite-dimensional cone construction remains OPEN.
- Direct native FASTCORE runner: on toolchain/Mathlib manifest changes,
  invalidate old success stamps exactly once, before compilation. This fixes
  the previous full-rebuild loop when the build fails before its last module.
- Previously PASSed source files are byte-identical. A failed/retried run
  reuses existing source-matched successful stamps, with existing dependent
  dirty-flag invalidation. Explicit `run.cmd full` still works.
- No local Lean compilation was attempted. New files require the user's compiler.
