import PaperProofs.S05_Theorem_5_2_ExactFifthKernel
import Mathlib.Tactic

/-!
# Theorem 5.2: finite geometric-series kernel and exact signed truncation

The paper's kernel (u+v)^5/(1-uv) is obtained from its finite
geometric sums by a single exact algebraic remainder identity.
This source certifies the finite truncations AND their algebraic
positive-minus-negative Krein splitting in all dimensions M.
It does not assert convergence at the boundary |uv| = 1.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_TruncatedKernel

open PaperProofs.S05_Theorem_5_2_ExactFifthKernel

/-- M-term geometric truncation of the polynomial weight-seven kernel. -/
def truncatedKernel (M : ℕ) (u v : ℝ) : ℝ :=
  ∑ m in Finset.range M, (u * v) ^ m * (u + v) ^ 5

def truncatedPositive (M : ℕ) (u v : ℝ) : ℝ :=
  ∑ m in Finset.range M, positiveMode m u v

def truncatedNegative (M : ℕ) (u v : ℝ) : ℝ :=
  ∑ m in Finset.range M, negativeMode m u v

/-- Arbitrarily many finite Krein modes, with no residue hypotheses. -/
theorem truncated_difference (M : ℕ) (u v : ℝ) :
    truncatedPositive M u v - truncatedNegative M u v =
      2 * truncatedKernel M u v := by
  unfold truncatedPositive truncatedNegative truncatedKernel
  rw [← Finset.sum_sub_distrib, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m _
  exact mode_difference m u v

/-- Exact geometric remainder as a polynomial identity, valid even
when 1-uv=0. -/
theorem geometric_remainder_polynomial (M : ℕ) (u v : ℝ) :
    (1 - u * v) * truncatedKernel M u v =
      (1 - (u * v) ^ M) * (u + v) ^ 5 := by
  induction M with
  | zero => simp [truncatedKernel]
  | succ M ih =>
      have hs : truncatedKernel (M + 1) u v =
          truncatedKernel M u v + (u * v) ^ M * (u + v) ^ 5 := by
        simp [truncatedKernel, Finset.sum_range_succ]
      rw [hs]
      calc
        (1 - u * v) * (truncatedKernel M u v +
            (u * v) ^ M * (u + v) ^ 5) =
          (1 - u * v) * truncatedKernel M u v +
            (1 - u * v) * (u * v) ^ M * (u + v) ^ 5 := by ring
        _ = (1 - (u * v) ^ M) * (u + v) ^ 5 +
            (1 - u * v) * (u * v) ^ M * (u + v) ^ 5 := by rw [ih]
        _ = (1 - (u * v) ^ (M + 1)) * (u + v) ^ 5 := by
          rw [pow_succ]
          ring

/-- Multiplying the exact truncated Krein identity by 1-uv gives
 the finite geometric remainder, which avoids any division by 1-uv. -/
theorem signed_remainder_polynomial (M : ℕ) (u v : ℝ) :
    (1 - u * v) * (truncatedPositive M u v - truncatedNegative M u v) =
      2 * ((1 - (u * v) ^ M) * (u + v) ^ 5) := by
  rw [truncated_difference]
  calc
    (1 - u * v) * (2 * truncatedKernel M u v) =
        2 * ((1 - u * v) * truncatedKernel M u v) := by ring
    _ = 2 * ((1 - (u * v) ^ M) * (u + v) ^ 5) := by
        rw [geometric_remainder_polynomial]

/-- The corresponding EXACT analytic-looking quotient identity on
 the complement of the pole uv=1: no asymptotic limiting argument. -/
theorem exact_tail (M : ℕ) (u v : ℝ) (h : u * v ≠ 1) :
    (u + v) ^ 5 / (1 - u * v) =
      truncatedKernel M u v +
        (u * v) ^ M * (u + v) ^ 5 / (1 - u * v) := by
  have hd : 1 - u * v ≠ 0 := by
    intro h0
    apply h
    linarith
  have he := geometric_remainder_polynomial M u v
  field_simp [hd] <;> nlinarith [he]

end PaperProofs.S05_Theorem_5_2_TruncatedKernel

#print axioms PaperProofs.S05_Theorem_5_2_TruncatedKernel.truncated_difference
#print axioms PaperProofs.S05_Theorem_5_2_TruncatedKernel.geometric_remainder_polynomial
#print axioms PaperProofs.S05_Theorem_5_2_TruncatedKernel.signed_remainder_polynomial
#print axioms PaperProofs.S05_Theorem_5_2_TruncatedKernel.exact_tail
