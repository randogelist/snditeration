import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.LinearAlgebra.Matrix.Polynomial

/-!
# Theorem 3.8: algebraic pole-kernel symmetry

The paper's Christoffel-Darboux matrix is the conjugate Vᵀ G⁻¹ V.
This module proves its transpose law for a general rational matrix G
and specializes the result to symmetric G. Analytic identification with
orthogonal polynomials and Jacobi's parameter derivative remain open.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_8_PoleKernel
open ManuscriptChain

/-- Exact pole-lattice kernel matrix at negative square interpolation nodes. -/
def poleKernel (p : Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ) : Matrix (Fin p.h) (Fin p.h) ℚ :=
  (PoleDiagonalization.poleVandermonde p).transpose * H *
    PoleDiagonalization.poleVandermonde p

/-- Transposition commutes with pole-lattice congruence. -/
theorem poleKernel_transpose (p : Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ) :
    (poleKernel p H).transpose = poleKernel p H.transpose := by
  unfold poleKernel
  simp only [Matrix.transpose_mul, Matrix.transpose_transpose, Matrix.mul_assoc]

/-- A symmetric Gram inverse yields a symmetric Christoffel-Darboux
    evaluation matrix on the actual negative-square pole lattice. -/
theorem poleKernel_symmetric (p : Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hH : H.transpose = H) :
    (poleKernel p H).transpose = poleKernel p H := by
  rw [poleKernel_transpose, hH]

end PaperProofs.S03_Theorem_3_8_PoleKernel

#print axioms PaperProofs.S03_Theorem_3_8_PoleKernel.poleKernel_transpose
#print axioms PaperProofs.S03_Theorem_3_8_PoleKernel.poleKernel_symmetric
