import PaperChronology.S03_Corollary_3_5
import Mathlib.Tactic

/-!
# Paper Corollary 3.5: exact 2 × 2 Schur identity (corrected statement)

The manuscript's unnormalized unit-slope formula is not asserted.
This module proves the rational 2 × 2 Schur identity directly, including
all nonzero denominators. These are exact finite algebraic identities;
they do not assume the existence of an arbitrary-dimensional Lanczos chain.
-/
namespace PaperProofs.S03_Corollary_3_5_Schur

/-- Exact Schur complement cross multiplication for a nonzero pivot. -/
theorem schur_cross_multiplication (a b d : ℝ) (ha : a ≠ 0) :
    (d - b ^ 2 / a) * a = a * d - b ^ 2 := by
  field_simp [ha] <;> ring

/-- The determinant factors through the Schur complement. -/
theorem schur_det_factorization (a b d : ℝ) (ha : a ≠ 0) :
    a * d - b ^ 2 = a * (d - b ^ 2 / a) := by
  calc
    a * d - b ^ 2 = (d - b ^ 2 / a) * a :=
      (schur_cross_multiplication a b d ha).symm
    _ = a * (d - b ^ 2 / a) := mul_comm _ _

/-- Nonsingularity of a 2 × 2 block implies a nonzero Schur complement. -/
theorem schur_ne_zero (a b d : ℝ) (ha : a ≠ 0)
    (hdet : a * d - b ^ 2 ≠ 0) : d - b ^ 2 / a ≠ 0 := by
  intro hz
  apply hdet
  calc
    a * d - b ^ 2 = a * (d - b ^ 2 / a) := schur_det_factorization a b d ha
    _ = 0 := by rw [hz, mul_zero]

/-- Correct two-step reciprocal principal-minor / Schur fraction. -/
theorem two_by_two_fraction (a b d : ℝ) (ha : a ≠ 0)
    (hdet : a * d - b ^ 2 ≠ 0) :
    a / (a * d - b ^ 2) = 1 / (d - b ^ 2 / a) := by
  have hs : d - b ^ 2 / a ≠ 0 := schur_ne_zero a b d ha hdet
  field_simp [ha, hdet, hs] <;> ring

end PaperProofs.S03_Corollary_3_5_Schur

#print axioms PaperProofs.S03_Corollary_3_5_Schur.schur_cross_multiplication
#print axioms PaperProofs.S03_Corollary_3_5_Schur.schur_det_factorization
#print axioms PaperProofs.S03_Corollary_3_5_Schur.schur_ne_zero
#print axioms PaperProofs.S03_Corollary_3_5_Schur.two_by_two_fraction
