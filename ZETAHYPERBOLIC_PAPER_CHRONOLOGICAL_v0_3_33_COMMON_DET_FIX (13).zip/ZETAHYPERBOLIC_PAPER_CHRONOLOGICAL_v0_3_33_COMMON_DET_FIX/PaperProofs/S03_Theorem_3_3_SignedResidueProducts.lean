import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.Tactic

/-!
# Theorem 3.3: sign of the actual residue products

This is the rational finite-product part of the manuscript's Sylvester
inertia computation. The factors are *the pole factors from Theorem 2.5*,
not surrogate eigenvalues. All hypotheses are finite natural inequalities.
This module is independent of the analytic positive-Gram input.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_SignedResidueProducts

private theorem neg_one_pow_square (n : ℕ) :
    ((-1 : ℚ) ^ n) ^ 2 = 1 := by
  rw [← pow_mul, Nat.mul_comm n 2, pow_mul]
  norm_num

private theorem prod_neg_eq {α : Type*} [DecidableEq α]
    (s : Finset α) (f : α → ℚ) :
    (∏ x ∈ s, -f x) = (-1 : ℚ) ^ s.card * ∏ x ∈ s, f x := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert x s hx ih =>
      simp only [Finset.prod_insert hx, Finset.card_insert_of_not_mem hx,
        pow_succ, ih]
      ring

private theorem prod_conditional_sign {α : Type*} [DecidableEq α]
    (s : Finset α) (pred : α → Prop) [DecidablePred pred] :
    (∏ x ∈ s, if pred x then (-1 : ℚ) else 1) =
      (-1 : ℚ) ^ (s.filter pred).card := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert x s hx ih =>
      by_cases h : pred x
      · simp [hx, h, ih, pow_succ, mul_comm]
      · simp [hx, h, ih]

/-- Numerator factors from the original order-s moment pencil. -/
def numeratorProduct (N a : ℕ) : ℚ :=
  ∏ ν ∈ Finset.Icc 1 N, ((ν : ℚ) ^ 2 - (a : ℚ) ^ 2)

/-- Denominator factors from the original Lagrange pole derivative. -/
def denominatorProduct (N K a : ℕ) : ℚ :=
  ∏ b ∈ (Finset.Icc (N + 1) K).erase a,
    ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)

/-- Every denominator factor is normalized to a strictly positive rational. -/
def positiveDenFactor (a b : ℕ) : ℚ :=
  if b < a then (a : ℚ) ^ 2 - (b : ℚ) ^ 2
  else (b : ℚ) ^ 2 - (a : ℚ) ^ 2

/-- The numerator has exactly N negative factors, irrespective of weight. -/
theorem numeratorProduct_signed_pos (N a : ℕ) (ha : N < a) :
    0 < (-1 : ℚ) ^ N * numeratorProduct N a := by
  have hgood : 0 < ∏ ν ∈ Finset.Icc 1 N,
      ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by
    apply Finset.prod_pos
    intro ν hν
    have hνN : ν ≤ N := (Finset.mem_Icc.mp hν).2
    have hνa : ν < a := by omega
    have hc : (ν : ℚ) < (a : ℚ) := by exact_mod_cast hνa
    have hz : (0 : ℚ) < (a : ℚ) := by exact_mod_cast (by omega : 0 < a)
    have hmul : 0 < ((a : ℚ) - (ν : ℚ)) * ((a : ℚ) + (ν : ℚ)) :=
      mul_pos (sub_pos.mpr hc) (add_pos_of_pos_of_nonneg hz (by positivity))
    nlinarith
  have hcard : (Finset.Icc 1 N).card = N := by
    simp [Finset.card_Icc]
  have hprod : numeratorProduct N a =
      (-1 : ℚ) ^ N * ∏ ν ∈ Finset.Icc 1 N,
        ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by
    unfold numeratorProduct
    calc
      (∏ ν ∈ Finset.Icc 1 N, ((ν : ℚ) ^ 2 - (a : ℚ) ^ 2)) =
          ∏ ν ∈ Finset.Icc 1 N,
            -((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by
              apply Finset.prod_congr rfl
              intro ν _
              ring
      _ = (-1 : ℚ) ^ N * ∏ ν ∈ Finset.Icc 1 N,
            ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by
              rw [prod_neg_eq, hcard]
  rw [hprod]
  calc
    (-1 : ℚ) ^ N *
      ((-1 : ℚ) ^ N * ∏ ν ∈ Finset.Icc 1 N,
        ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2)) =
        (((-1 : ℚ) ^ N) ^ 2) *
          ∏ ν ∈ Finset.Icc 1 N, ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by ring
    _ = ∏ ν ∈ Finset.Icc 1 N, ((a : ℚ) ^ 2 - (ν : ℚ) ^ 2) := by
      rw [neg_one_pow_square]
      ring
    _ > 0 := hgood

/-- The denominator has exactly a-N-1 negative factors at pole a.
This positive signed-product statement includes every tail pole. -/
theorem denominatorProduct_signed_pos (N K a : ℕ)
    (hNa : N < a) (haK : a ≤ K) :
    0 < (-1 : ℚ) ^ (a - (N + 1)) * denominatorProduct N K a := by
  classical
  let T : Finset ℕ := (Finset.Icc (N + 1) K).erase a
  have hfilter : T.filter (fun b => b < a) = Finset.Ico (N + 1) a := by
    ext b
    simp only [T, Finset.mem_filter, Finset.mem_erase, Finset.mem_Icc,
      Finset.mem_Ico]
    omega
  have hcard : (T.filter (fun b => b < a)).card = a - (N + 1) := by
    rw [hfilter]
    simp [Finset.card_Ico]
  have hgood : 0 < ∏ b ∈ T, positiveDenFactor a b := by
    apply Finset.prod_pos
    intro b hb
    have hne : b ≠ a := (Finset.mem_erase.mp hb).1
    have ha0 : (0 : ℚ) < (a : ℚ) := by
      exact_mod_cast (by omega : 0 < a)
    by_cases hlt : b < a
    · simp only [positiveDenFactor, if_pos hlt]
      have hq : (b : ℚ) < (a : ℚ) := by exact_mod_cast hlt
      have hmul : 0 < ((a : ℚ) - (b : ℚ)) * ((a : ℚ) + (b : ℚ)) :=
        mul_pos (sub_pos.mpr hq) (add_pos_of_pos_of_nonneg ha0 (by positivity))
      nlinarith
    · have hab : a < b := by omega
      simp only [positiveDenFactor, if_neg hlt]
      have hq : (a : ℚ) < (b : ℚ) := by exact_mod_cast hab
      have hmul : 0 < ((b : ℚ) - (a : ℚ)) * ((b : ℚ) + (a : ℚ)) :=
        mul_pos (sub_pos.mpr hq) (add_pos_of_pos_of_nonneg
          (by exact_mod_cast (by omega : 0 < b)) (by positivity))
      nlinarith
  have hsplit : denominatorProduct N K a =
      (∏ b ∈ T, if b < a then (-1 : ℚ) else 1) *
        ∏ b ∈ T, positiveDenFactor a b := by
    unfold denominatorProduct
    change (∏ b ∈ T, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) = _
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro b hb
    by_cases hlt : b < a
    · simp [positiveDenFactor, hlt]
      ring
    · simp [positiveDenFactor, hlt]
  rw [hsplit, prod_conditional_sign, hcard]
  calc
    (-1 : ℚ) ^ (a - (N + 1)) *
      ((-1 : ℚ) ^ (a - (N + 1)) * ∏ b ∈ T, positiveDenFactor a b) =
        (((-1 : ℚ) ^ (a - (N + 1))) ^ 2) *
          ∏ b ∈ T, positiveDenFactor a b := by ring
    _ = ∏ b ∈ T, positiveDenFactor a b := by
      rw [neg_one_pow_square]
      ring
    _ > 0 := hgood

end PaperProofs.S03_Theorem_3_3_SignedResidueProducts

#print axioms PaperProofs.S03_Theorem_3_3_SignedResidueProducts.numeratorProduct_signed_pos
#print axioms PaperProofs.S03_Theorem_3_3_SignedResidueProducts.denominatorProduct_signed_pos
