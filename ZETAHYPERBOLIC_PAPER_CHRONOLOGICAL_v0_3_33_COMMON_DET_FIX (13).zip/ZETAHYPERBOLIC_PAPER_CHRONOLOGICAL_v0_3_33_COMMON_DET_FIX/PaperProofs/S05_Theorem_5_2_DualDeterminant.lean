import PaperProofs.S05_Theorem_5_2_DualEnergy
import PaperProofs.S05_Theorem_5_2_DualSlope
import Mathlib.Tactic

/-!
# Theorem 5.2(1): positive derivative determinant from polynomial independence

The rational dual pencil has slope C*Cᵀ; the real coefficient Gram is
strictly positive definite exactly when the coefficient rows are linearly
independent. Hence its determinant is strictly positive. This theorem
packages the unconditional FINITE matrix implication, not the infinite
Krein cone or the asserted rational approximation results.
-/

noncomputable section
namespace PaperProofs.S05_Theorem_5_2_DualDeterminant

open PaperProofs.S05_Theorem_5_2_DualEnergy

variable {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ)

/-- Positive determinant of the actual real dual-pencil derivative. -/
theorem real_dual_slope_det_positive
    (hc : FullRowRank c) :
    0 < (realCoefficientGram c).det :=
  (realCoefficientGram_posDef c hc).det_pos

/-- Exact degree of a nondegenerate pencil is a subsequent theorem;
this establishes the independent nonvanishing derivative-determinant
criterion required for that degree calculation. -/
theorem real_dual_slope_det_nonzero
    (hc : FullRowRank c) :
    (realCoefficientGram c).det ≠ 0 :=
  ne_of_gt (real_dual_slope_det_positive c hc)

end PaperProofs.S05_Theorem_5_2_DualDeterminant

#print axioms PaperProofs.S05_Theorem_5_2_DualDeterminant.real_dual_slope_det_positive
#print axioms PaperProofs.S05_Theorem_5_2_DualDeterminant.real_dual_slope_det_nonzero
