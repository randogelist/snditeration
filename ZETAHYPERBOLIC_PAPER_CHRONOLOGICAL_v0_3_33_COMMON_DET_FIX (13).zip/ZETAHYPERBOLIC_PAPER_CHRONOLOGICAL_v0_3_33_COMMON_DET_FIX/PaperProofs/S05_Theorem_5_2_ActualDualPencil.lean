import PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity
import PaperProofs.S05_Theorem_5_2_DualSlope
import PaperProofs.S05_Theorem_5_2_DualEnergy
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Mathlib.Tactic

/-!
# Theorem 5.2(1) — the genuine two-variable zeta-seven pencil

This is the principal finite-dimensional statement for the real polynomial
obtained from the *actual* `dualEntry 7` coefficients. There is no abstract
root-realness premise and no hypothesis about an unspecified matrix pencil.
The only parameter condition is `FullRowRank c`, the exact linear
independence condition imposed on the polynomial rows in the manuscript.

The infinite Krein decomposition in Theorem 5.2(2) and the concrete rational
subspace construction in part (3) are separate; they are not silently
claimed by this module.
-/

noncomputable section
open scoped BigOperators
open Polynomial Matrix
namespace PaperProofs.S05_Theorem_5_2_ActualDualPencil

open ManuscriptChain
open PaperProofs.S05_Theorem_5_2_DualEnergy
open PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity

variable {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ)

/-- Actual constant matrix from Theorem 5.1's divided differences. -/
def actualConstantMatrix : Matrix (Fin h) (Fin h) ℝ :=
  fun i j => ((∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
    c i r * c j t * Real.dualConstant 7 r.val t.val : ℚ) : ℝ)

/-- The divided-difference moment constant is symmetric even at equal
    indices; the zero-denominator case is never cancelled. -/
theorem dualConstant_symmetric (s r t : ℕ) :
    Real.dualConstant s r t = Real.dualConstant s t r := by
  unfold Real.dualConstant
  by_cases hrt : r = t
  · subst t
    rfl
  · have htr : t ≠ r := Ne.symm hrt
    simp only [if_neg hrt, if_neg htr]
    have hn : Real.harmonic (s - 1) r - Real.harmonic (s - 1) t =
        -(Real.harmonic (s - 1) t - Real.harmonic (s - 1) r) := by ring
    have hd : (↑(s - 1) : ℚ) * ((r : ℚ) - (t : ℚ)) =
        -((↑(s - 1) : ℚ) * ((t : ℚ) - (r : ℚ))) := by ring
    rw [hn, hd]
    simp

/-- Symmetry of the true constant matrix, for all polynomial families. -/
theorem actualConstantMatrix_symmetric :
    (actualConstantMatrix c).IsSymm := by
  ext i j
  change
    ((∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
        c j r * c i t * Real.dualConstant 7 r.val t.val : ℚ) : ℝ) =
      ((∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
        c i r * c j t * Real.dualConstant 7 r.val t.val : ℚ) : ℝ)
  congr 1
  calc
    (∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
        c j r * c i t * Real.dualConstant 7 r.val t.val) =
      ∑ t : Fin (K + 1), ∑ r : Fin (K + 1),
        c j r * c i t * Real.dualConstant 7 r.val t.val := Finset.sum_comm
    _ = ∑ t : Fin (K + 1), ∑ r : Fin (K + 1),
        c i t * c j r * Real.dualConstant 7 t.val r.val := by
      apply Finset.sum_congr rfl
      intro t _
      apply Finset.sum_congr rfl
      intro r _
      rw [dualConstant_symmetric]
      ring
    _ = ∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
        c i r * c j t * Real.dualConstant 7 r.val t.val := rfl

/-- Exact identification with the already-defined `dualDelta 7`, with
    NO independent polynomial chosen in place of the paper's. -/
theorem real_dualDelta_eq_affine :
    Real.realPolynomial (Real.dualDelta 7 c) =
      realAffineDet (actualConstantMatrix c) (realCoefficientGram c) := by
  unfold Real.realPolynomial Real.dualDelta realAffineDet
  change (Polynomial.mapRingHom (Rat.castHom ℝ))
    ((fun i j => Real.dualEntry 7 c i j :
      Matrix (Fin h) (Fin h) ℚ[X]).det) = _
  rw [(Polynomial.mapRingHom (Rat.castHom ℝ)).map_det]
  congr 1
  ext i j
  simp only [Matrix.map_apply, Real.dualEntry, Polynomial.map_add,
    Polynomial.map_mul, Polynomial.map_C, Polynomial.map_X]
  change C ((∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
    c i r * c j t * Real.dualConstant 7 r.val t.val : ℚ) : ℝ) +
      C ((∑ r : Fin (K + 1), c i r * c j r : ℚ) : ℝ) * X =
    C (actualConstantMatrix c i j) + X * C (realCoefficientGram c i j)
  have hbase :
      ((∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
        c i r * c j t * Real.dualConstant 7 r.val t.val : ℚ) : ℝ) =
        actualConstantMatrix c i j := rfl
  have hslope :
      ((∑ r : Fin (K + 1), c i r * c j r : ℚ) : ℝ) =
        realCoefficientGram c i j := by
    simp [realCoefficientGram, Rat.cast_sum, Rat.cast_mul]
  rw [hbase, hslope]
  ring

/-- The corrected principal dual theorem: exact degree in all dimensions. -/
theorem actual_dual_degree (hc : FullRowRank c) :
    (Real.realPolynomial (Real.dualDelta 7 c)).natDegree = h := by
  rw [real_dualDelta_eq_affine]
  exact positive_slope_exact_degree
    (actualConstantMatrix c) (realCoefficientGram c)
    (realCoefficientGram_posDef c hc)

/-- The corrected principal dual theorem: every complex root of the
    genuine Beukers determinant polynomial is a real number. -/
theorem actual_dual_all_roots_real (hc : FullRowRank c) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Real.realPolynomial (Real.dualDelta 7 c)) = 0) : z.im = 0 := by
  rw [real_dualDelta_eq_affine] at hz
  exact positive_slope_all_roots_real
    (actualConstantMatrix c) (realCoefficientGram c)
    (actualConstantMatrix_symmetric c)
    (realCoefficientGram_posDef c hc) z hz

/-- Root-factor statement for the actual pencil — no roots are assumed. -/
theorem actual_dual_root_factorization (hc : FullRowRank c) :
    ∃ r : Fin h → ℝ,
      Real.realPolynomial (Real.dualDelta 7 c) =
        C ((realCoefficientGram c).det) * ∏ i, (X - C (r i)) := by
  rw [real_dualDelta_eq_affine]
  exact positive_slope_root_factorization
    (actualConstantMatrix c) (realCoefficientGram c)
    (actualConstantMatrix_symmetric c)
    (realCoefficientGram_posDef c hc)

end PaperProofs.S05_Theorem_5_2_ActualDualPencil

#print axioms PaperProofs.S05_Theorem_5_2_ActualDualPencil.dualConstant_symmetric
#print axioms PaperProofs.S05_Theorem_5_2_ActualDualPencil.actualConstantMatrix_symmetric
#print axioms PaperProofs.S05_Theorem_5_2_ActualDualPencil.actual_dual_degree
#print axioms PaperProofs.S05_Theorem_5_2_ActualDualPencil.actual_dual_all_roots_real
#print axioms PaperProofs.S05_Theorem_5_2_ActualDualPencil.actual_dual_root_factorization
