import PaperChronology.S03_Corollary_3_6
import Mathlib.Tactic

/-! Corrected finite-support Stieltjes geometry: positive semidefiniteness
rather than strict positivity beyond the support rank. -/
namespace PaperProofs.S03_Corollary_3_6_FiniteAtoms

/-- A single Dirac atom yields zero 2x2 Hankel determinant. -/
theorem one_atom_singular (u : ℝ) :
    (1:ℝ) * u^2 - u*u = 0 := by ring

/-- For two unit-mass atoms, the 2x2 determinant is their squared gap. -/
theorem two_atom_determinant (u v : ℝ) :
    (2:ℝ)*(u^2+v^2) - (u+v)^2 = (u-v)^2 := by ring

theorem two_atom_nonnegative (u v : ℝ) :
    0 ≤ (2:ℝ)*(u^2+v^2) - (u+v)^2 := by
  rw [two_atom_determinant]
  positivity

/-- Strict positivity holds for two distinct atoms (but not for larger
Hankel determinants without enough distinct support points). -/
theorem two_atom_positive {u v : ℝ} (huv : u ≠ v) :
    0 < (2:ℝ)*(u^2+v^2) - (u+v)^2 := by
  rw [two_atom_determinant]
  exact sq_pos_of_ne_zero (sub_ne_zero.mpr huv)

end PaperProofs.S03_Corollary_3_6_FiniteAtoms
#print axioms PaperProofs.S03_Corollary_3_6_FiniteAtoms.two_atom_determinant
