import Mathlib.Tactic

/-!
# Theorem 5.2(2): universal finite Krein square decomposition

The infinite rank signed-cone identity in Theorem 5.2 begins with the
finite algebraic decomposition 4ab = (a+b)^2 - (a-b)^2.
This module proves the identity for arbitrary finite families and weights,
including positivity of each cone when the coefficients are nonnegative.
No claim is made about the infinite tail or the existence of universal
rational polynomial subspaces.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_FiniteKreinSplit

variable {m : ℕ}

/-- The two positive/negative square branches of a finite signed
bilinear form. -/
def plusEnergy (w a b : Fin m → ℝ) : ℝ :=
  ∑ i : Fin m, w i * (a i + b i) ^ 2

def minusEnergy (w a b : Fin m → ℝ) : ℝ :=
  ∑ i : Fin m, w i * (a i - b i) ^ 2

def crossEnergy (w a b : Fin m → ℝ) : ℝ :=
  ∑ i : Fin m, w i * a i * b i

/-- Full finite weighted signed-square identity for an arbitrary
number of modes. It is the finite truncation of the paper's Krein
representation, not an assumption on the analytic remainder. -/
theorem finite_krein_split (w a b : Fin m → ℝ) :
    plusEnergy w a b - minusEnergy w a b = 4 * crossEnergy w a b := by
  classical
  unfold plusEnergy minusEnergy crossEnergy
  rw [← Finset.sum_sub_distrib, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- Every finite positive branch is nonnegative for nonnegative weights. -/
theorem plusEnergy_nonnegative (w a b : Fin m → ℝ)
    (hw : ∀ i, 0 ≤ w i) :
    0 ≤ plusEnergy w a b := by
  unfold plusEnergy
  exact Finset.sum_nonneg (fun i _ => mul_nonneg (hw i) (sq_nonneg _))

/-- Every finite negative branch also has a nonnegative squared norm. -/
theorem minusEnergy_nonnegative (w a b : Fin m → ℝ)
    (hw : ∀ i, 0 ≤ w i) :
    0 ≤ minusEnergy w a b := by
  unfold minusEnergy
  exact Finset.sum_nonneg (fun i _ => mul_nonneg (hw i) (sq_nonneg _))

/-- A one-sided estimate for the mixed form obtained from the finite
square decomposition. -/
theorem crossEnergy_upper (w a b : Fin m → ℝ)
    (hw : ∀ i, 0 ≤ w i) :
    4 * crossEnergy w a b ≤ plusEnergy w a b := by
  have hid := finite_krein_split w a b
  have hminus := minusEnergy_nonnegative w a b hw
  linarith

/-- The complementary lower estimate. -/
theorem crossEnergy_lower (w a b : Fin m → ℝ)
    (hw : ∀ i, 0 ≤ w i) :
    -minusEnergy w a b ≤ 4 * crossEnergy w a b := by
  have hid := finite_krein_split w a b
  have hplus := plusEnergy_nonnegative w a b hw
  linarith

end PaperProofs.S05_Theorem_5_2_FiniteKreinSplit

#print axioms PaperProofs.S05_Theorem_5_2_FiniteKreinSplit.finite_krein_split
#print axioms PaperProofs.S05_Theorem_5_2_FiniteKreinSplit.plusEnergy_nonnegative
#print axioms PaperProofs.S05_Theorem_5_2_FiniteKreinSplit.minusEnergy_nonnegative
#print axioms PaperProofs.S05_Theorem_5_2_FiniteKreinSplit.crossEnergy_upper
#print axioms PaperProofs.S05_Theorem_5_2_FiniteKreinSplit.crossEnergy_lower
