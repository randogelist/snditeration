import PaperChronology.S04_Proposition_4_3
import Mathlib.Tactic

/-! Finite residue analogue of Proposition 4.3. The full p-adic disk
criterion requires a non-archimedean norm argument; it is NOT asserted here. -/
namespace PaperProofs.S04_Proposition_4_3_ResidueDisk

/-- Integral-polynomial evaluation is unchanged modulo p when the input
residue class is unchanged. This finite formulation uses a universal polynomial
and does not assume its degree or any root information. -/
theorem residue_polynomial_eval_congr (p : ℕ) (Q : Polynomial ℤ)
    (x y : ℤ) (h : (x : ZMod p) = (y : ZMod p)) :
    Q.eval₂ (Int.castRingHom (ZMod p)) (x : ZMod p) =
      Q.eval₂ (Int.castRingHom (ZMod p)) (y : ZMod p) := by
  rw [h]

/-- A nonzero polynomial value in a residue disk cannot acquire a zero
at another representative of the same disk. -/
theorem finite_zero_exclusion (p : ℕ) (Q : Polynomial ℤ)
    (x y : ℤ) (h : (x : ZMod p) = (y : ZMod p))
    (hx : Q.eval₂ (Int.castRingHom (ZMod p)) (x : ZMod p) ≠ 0) :
    Q.eval₂ (Int.castRingHom (ZMod p)) (y : ZMod p) ≠ 0 := by
  rw [← h]
  exact hx

end PaperProofs.S04_Proposition_4_3_ResidueDisk
#print axioms PaperProofs.S04_Proposition_4_3_ResidueDisk.finite_zero_exclusion
