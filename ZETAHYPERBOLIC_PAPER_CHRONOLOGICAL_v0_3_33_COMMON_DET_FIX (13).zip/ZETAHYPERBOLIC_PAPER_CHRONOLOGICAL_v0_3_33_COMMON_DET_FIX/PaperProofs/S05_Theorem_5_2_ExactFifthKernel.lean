import Mathlib.Tactic

/-!
# Theorem 5.2: exact fifth-power Krein decomposition, every finite mode

This is the polynomial algebra behind the manuscript's two-variable
weight-seven Beukers kernel. Unlike a generic signed-square template,
the three coefficients are the exact binomial coefficients 1, 5, 10.
For every mode m and x,y, the difference between the two explicit
rank-three kernels is exactly twice (xy)^m (x+y)^5.

No infinite-series convergence or approximation hypotheses are used.
-/

noncomputable section
namespace PaperProofs.S05_Theorem_5_2_ExactFifthKernel

/-- Explicit positive/negative logarithmic-polynomial mode functions,
with the logarithms replaced by algebraic arguments u, v. -/
def plus0 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (1 + u ^ 5)
def minus0 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (1 - u ^ 5)
def plus1 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (u + u ^ 4)
def minus1 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (u - u ^ 4)
def plus2 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (u ^ 2 + u ^ 3)
def minus2 (m : ℕ) (u : ℝ) : ℝ := u ^ m * (u ^ 2 - u ^ 3)

/-- The rank-three positive branch for a single geometric-series mode. -/
def positiveMode (m : ℕ) (u v : ℝ) : ℝ :=
  plus0 m u * plus0 m v +
  5 * (plus1 m u * plus1 m v) +
  10 * (plus2 m u * plus2 m v)

/-- The rank-three negative branch for the same mode. -/
def negativeMode (m : ℕ) (u v : ℝ) : ℝ :=
  minus0 m u * minus0 m v +
  5 * (minus1 m u * minus1 m v) +
  10 * (minus2 m u * minus2 m v)

/-- The complete finite-mode kernel decomposition, with precisely
 2 K_m(u,v) = K_m⁺(u,v) - K_m⁻(u,v). -/
theorem mode_difference (m : ℕ) (u v : ℝ) :
    positiveMode m u v - negativeMode m u v =
      2 * ((u * v) ^ m * (u + v) ^ 5) := by
  unfold positiveMode negativeMode
    plus0 minus0 plus1 minus1 plus2 minus2
  rw [mul_pow]
  ring

/-- The printed 1/720 and 1/1440 constants in the Beukers/Krein
 representation are exact and require no analytic assumptions. -/
theorem normalized_weight_seven_kernel (u v : ℝ) :
    (u + v) ^ 5 / 720 =
      (positiveMode 0 u v - negativeMode 0 u v) / 1440 := by
  unfold positiveMode negativeMode
    plus0 minus0 plus1 minus1 plus2 minus2
  simp only [pow_zero, one_mul]
  ring

/-- Symmetry of both exact finite-rank kernels. -/
theorem positiveMode_symmetric (m : ℕ) (u v : ℝ) :
    positiveMode m u v = positiveMode m v u := by
  unfold positiveMode
  ring

theorem negativeMode_symmetric (m : ℕ) (u v : ℝ) :
    negativeMode m u v = negativeMode m v u := by
  unfold negativeMode
  ring

end PaperProofs.S05_Theorem_5_2_ExactFifthKernel

#print axioms PaperProofs.S05_Theorem_5_2_ExactFifthKernel.mode_difference
#print axioms PaperProofs.S05_Theorem_5_2_ExactFifthKernel.normalized_weight_seven_kernel
#print axioms PaperProofs.S05_Theorem_5_2_ExactFifthKernel.positiveMode_symmetric
#print axioms PaperProofs.S05_Theorem_5_2_ExactFifthKernel.negativeMode_symmetric
