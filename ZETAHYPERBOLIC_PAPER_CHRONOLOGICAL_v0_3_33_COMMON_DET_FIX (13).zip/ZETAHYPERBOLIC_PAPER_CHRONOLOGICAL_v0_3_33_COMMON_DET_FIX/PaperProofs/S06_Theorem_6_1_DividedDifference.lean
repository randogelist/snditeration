import Mathlib.Tactic

/-! Theorem 6.1, elementary p-denominator bridge. This proves how
an order-six pole of a harmonic jump acquires a seventh denominator power
after division by p. Exact valuations of the complete moment matrix remain open. -/
namespace PaperProofs.S06_Theorem_6_1_DividedDifference

/-- Dividing a pole contribution by one additional p gives order s+1. -/
theorem extra_denominator_power (s p : ℕ) (hp : 0 < p) :
    (((p : ℚ)^s)⁻¹) / (p : ℚ) = ((p : ℚ)^(s+1))⁻¹ := by
  have h : (p : ℚ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hp)
  rw [pow_succ]
  field_simp [h, pow_ne_zero _ h]

/-- The weight-seven divided-difference pole has denominator p^7. -/
theorem sixth_to_seventh (p : ℕ) (hp : 0 < p) :
    ((1 : ℚ) / (p : ℚ)^6) / (p : ℚ) =
      (1 : ℚ) / (p : ℚ)^7 := by
  simpa [one_div] using extra_denominator_power 6 p hp

end PaperProofs.S06_Theorem_6_1_DividedDifference
#print axioms PaperProofs.S06_Theorem_6_1_DividedDifference.sixth_to_seventh
