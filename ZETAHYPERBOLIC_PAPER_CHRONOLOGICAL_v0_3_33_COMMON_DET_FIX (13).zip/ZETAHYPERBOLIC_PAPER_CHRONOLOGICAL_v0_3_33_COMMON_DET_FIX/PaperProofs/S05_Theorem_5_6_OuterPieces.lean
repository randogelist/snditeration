import Mathlib.Tactic

/-! Theorem 5.6(1): EXACT RATIONAL 11-PIECE INTEGRAL ARITHMETIC.
The analytic identification of the piecewise formula with the original floor/
max/min integrand is still separate. It is NOT supplied by this module. -/
namespace PaperProofs.S05_Theorem_5_6_OuterPieces

/-- Rational affine area: ∫_l^r (b+c*y) dy in elementary closed form. -/
def affineArea (l r b c : ℚ) : ℚ :=
  b*(r-l) + c*(r^2-l^2)/2

theorem piece_01 : affineArea (1/3) (43/120) (51/8) (-5) = 223/1920 := by norm_num [affineArea]
theorem piece_02 : affineArea (43/120) (29/80) (513/40) (-23) = 2177/115200 := by norm_num [affineArea]
theorem piece_03 : affineArea (29/80) (37/100) (571/40) (-27) = 10527/320000 := by norm_num [affineArea]
theorem piece_04 : affineArea (37/100) (37/80) (497/40) (-22) = 48359/160000 := by norm_num [affineArea]
theorem piece_05 : affineArea (37/80) (29/60) (41/10) (-4) = 53/1152 := by norm_num [affineArea]
theorem piece_06 : affineArea (29/60) (1/2) (53/20) (-1) = 259/7200 := by norm_num [affineArea]
theorem piece_07 : affineArea (1/2) (43/80) (7/2) 1 = 1929/12800 := by norm_num [affineArea]
theorem piece_08 : affineArea (43/80) (37/60) (121/10) (-15) = 10469/38400 := by norm_num [affineArea]
theorem piece_09 : affineArea (37/60) (37/40) (41/4) (-12) = 37/120 := by norm_num [affineArea]
theorem piece_10 : affineArea (37/40) 1 1 (-2) = -111/1600 := by norm_num [affineArea]
theorem piece_11 : affineArea 1 (37/20) (37/20) (-1) = 289/800 := by norm_num [affineArea]

/-- Exact arithmetic total in equation (5.6), using ALL eleven PDF intervals. -/
theorem all_eleven_areas :
    affineArea (1/3) (43/120) (51/8) (-5) +
    affineArea (43/120) (29/80) (513/40) (-23) +
    affineArea (29/80) (37/100) (571/40) (-27) +
    affineArea (37/100) (37/80) (497/40) (-22) +
    affineArea (37/80) (29/60) (41/10) (-4) +
    affineArea (29/60) (1/2) (53/20) (-1) +
    affineArea (1/2) (43/80) (7/2) 1 +
    affineArea (43/80) (37/60) (121/10) (-15) +
    affineArea (37/60) (37/40) (41/4) (-12) +
    affineArea (37/40) 1 1 (-2) +
    affineArea 1 (37/20) (37/20) (-1) =
      (453803 : ℚ) / 288000 := by
  rw [piece_01, piece_02, piece_03, piece_04,
      piece_05, piece_06, piece_07, piece_08,
      piece_09, piece_10, piece_11]
  norm_num

/-- Exact rational total from the printed table. -/
theorem sum_of_printed_piece_values :
    (223 : ℚ)/1920 + 2177/115200 + 10527/320000 + 48359/160000 +
      53/1152 + 259/7200 + 1929/12800 + 10469/38400 +
      37/120 - 111/1600 + 289/800 = 453803/288000 := by
  norm_num

end PaperProofs.S05_Theorem_5_6_OuterPieces
#print axioms PaperProofs.S05_Theorem_5_6_OuterPieces.all_eleven_areas
