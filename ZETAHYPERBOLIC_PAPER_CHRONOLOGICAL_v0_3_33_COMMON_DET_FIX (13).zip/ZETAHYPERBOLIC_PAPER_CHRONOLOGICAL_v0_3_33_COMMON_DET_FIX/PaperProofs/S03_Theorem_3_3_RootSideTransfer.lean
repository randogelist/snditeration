import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Mathlib.Tactic

/-!
# Theorem 3.3: exact spectral-side sign transfer

Once the universal positive-Gram pencil is factored, the location of
an individual real root relative to ζ(s) is determined by the sign of
its nonzero generalized eigenvalue. This does NOT assert eigenvalue
inertia, which must be proved independently for the manuscript family.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_3_RootSideTransfer
open ManuscriptChain.Spectral

variable {n : ℕ} {p : SymmetricAffinePencil n}

/-- The map β ↦ center − β⁻¹ sends positive eigenvalues strictly left. -/
theorem root_below_center_iff (c : RootFactorization p) (i : Fin n) :
    c.root i < p.center ↔ 0 < c.beta i := by
  change p.center - (c.beta i)⁻¹ < p.center ↔ 0 < c.beta i
  constructor
  · intro h
    have hi : 0 < (c.beta i)⁻¹ := by linarith
    exact (inv_pos).mp hi
  · intro h
    have hi : 0 < (c.beta i)⁻¹ := (inv_pos).mpr h
    linarith

/-- Negative generalized eigenvalues produce roots strictly to the
right of the center. -/
theorem root_above_center_iff (c : RootFactorization p) (i : Fin n) :
    p.center < c.root i ↔ c.beta i < 0 := by
  change p.center < p.center - (c.beta i)⁻¹ ↔ c.beta i < 0
  constructor
  · intro h
    have hi : (c.beta i)⁻¹ < 0 := by linarith
    exact (inv_lt_zero).mp hi
  · intro h
    have hi : (c.beta i)⁻¹ < 0 := (inv_lt_zero).mpr h
    linarith

/-- The root cannot coincide with the distinguished zeta center,
independently of a quantitative zero-free disk. -/
theorem root_avoids_center (c : RootFactorization p) (i : Fin n) :
    c.root i ≠ p.center := by
  exact c.root_ne_center i

end PaperProofs.S03_Theorem_3_3_RootSideTransfer

#print axioms PaperProofs.S03_Theorem_3_3_RootSideTransfer.root_below_center_iff
#print axioms PaperProofs.S03_Theorem_3_3_RootSideTransfer.root_above_center_iff
#print axioms PaperProofs.S03_Theorem_3_3_RootSideTransfer.root_avoids_center
