import PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram
import PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy
import Mathlib.Tactic

/-!
# Theorem 3.3: the atomic moment-to-Vandermonde determinant bridge

The earlier development had independent theorems about arbitrary finite
atomic Hankel quadratic forms and Vandermonde-diagonal Gram determinants.
Here they are identified for the *same* moment family and all dimensions.
The determinant formula and strict positivity therefore apply directly to
the actual atomic moment matrix, rather than to an unrelated Gram matrix.

This is the finite-atomic theorem, not a proof of continuous-measure total
positivity of every mixed minor in the manuscript.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge

open PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram
open PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy

variable {n : ℕ}

/-- The coefficient-wise moment Hankel matrix equals the square atomic
Vandermonde/diagonal Gram matrix for *every* finite size. -/
theorem atomicHankel_eq_finiteAtomGram (nodes weights : Fin n → ℝ) :
    atomicHankel nodes weights n = finiteAtomGram nodes weights := by
  classical
  ext i j
  change (∑ a : Fin n, weights a * nodes a ^ ((i : ℕ) + (j : ℕ))) =
    (∑ b : Fin n,
      (∑ a : Fin n, nodes a ^ (i : ℕ) * (Matrix.diagonal weights) a b) *
        nodes b ^ (j : ℕ))
  have hinner (b : Fin n) :
      (∑ a : Fin n, nodes a ^ (i : ℕ) * (Matrix.diagonal weights) a b) =
        nodes b ^ (i : ℕ) * weights b := by
    simp [Matrix.diagonal_apply]
  calc
    (∑ a : Fin n, weights a * nodes a ^ ((i : ℕ) + (j : ℕ))) =
        ∑ b : Fin n, (nodes b ^ (i : ℕ) * weights b) * nodes b ^ (j : ℕ) := by
          apply Finset.sum_congr rfl
          intro b _
          rw [pow_add]
          ring
    _ = ∑ b : Fin n,
          (∑ a : Fin n, nodes a ^ (i : ℕ) * (Matrix.diagonal weights) a b) *
            nodes b ^ (j : ℕ) := by
          apply Finset.sum_congr rfl
          intro b _
          rw [hinner]

/-- Exact determinant of a true finite atomic Hankel moment matrix. -/
theorem atomicHankel_det (nodes weights : Fin n → ℝ) :
    (atomicHankel nodes weights n).det =
      ((atomVandermonde nodes).det) ^ 2 * ∏ a, weights a := by
  rw [atomicHankel_eq_finiteAtomGram]
  exact finiteAtomGram_det nodes weights

/-- Strictly positive determinant for nondegenerate finite atomic moments.
The Vandermonde condition is explicit and algebraically checkable. -/
theorem atomicHankel_det_pos
    (nodes weights : Fin n → ℝ)
    (hV : (atomVandermonde nodes).det ≠ 0)
    (hw : ∀ a, 0 < weights a) :
    0 < (atomicHankel nodes weights n).det := by
  rw [atomicHankel_eq_finiteAtomGram]
  exact finiteAtomGram_det_pos nodes weights hV hw

/-- The same bridge gives determinant nonvanishing over signed atoms,
provided no weight vanishes and the Vandermonde is invertible. -/
theorem atomicHankel_det_ne_zero
    (nodes weights : Fin n → ℝ)
    (hV : IsUnit (atomVandermonde nodes).det)
    (hw : ∀ a, weights a ≠ 0) :
    (atomicHankel nodes weights n).det ≠ 0 := by
  rw [atomicHankel_eq_finiteAtomGram]
  exact finiteAtomGram_det_ne_zero nodes weights hV hw

end PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge

#print axioms PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge.atomicHankel_eq_finiteAtomGram
#print axioms PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge.atomicHankel_det
#print axioms PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge.atomicHankel_det_pos
#print axioms PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge.atomicHankel_det_ne_zero
