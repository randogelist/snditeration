import MAIN_CHAIN_NO_OPEN_INPUTS
import PaperProofs.S05_Theorem_5_2_ActualDualPencil
import PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge
import Mathlib.Tactic

/-!
# Principal theorem chain — genuine manuscript objects

Theorem 3.1: unconditional spectral hyperbolicity for all admissible
odd-weight rational Hankel pencils (imported proved theorem).
Theorem 3.3: all-dimensional finite atomic Hankel determinant positivity,
under the explicit finite Vandermonde nonsingularity criterion.
Theorem 5.2(1): degree and complex-root reality of the genuine rational
two-variable zeta-seven dual determinant, for polynomial-linearly
independent coefficient rows.

The non-finite analytic parts of 3.3 and 5.2 are NOT included in this
statement. Only the manuscript's separate quantitative witness is allowed
at its corresponding §4 theorem, not asserted here.
-/

noncomputable section
namespace PaperProofs.PRINCIPAL_THEOREMS_BRIDGE

open ManuscriptChain
open PaperProofs.S05_Theorem_5_2_ActualDualPencil
open PaperProofs.S05_Theorem_5_2_DualEnergy
open PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge
open PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram

/-- Actual general odd-weight pencil and the true zeta-seven dual pencil
    can be certified together without any analytic Witness. -/
theorem principal_pencils
    (p : Real.Parameters) (hp : Real.Admissible p)
    {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (hc : FullRowRank c) :
    General.GeneralStatement p ∧
    (Real.realPolynomial (Real.dualDelta 7 c)).natDegree = h ∧
    (∀ z : ℂ,
      Polynomial.eval₂ (algebraMap ℝ ℂ) z
        (Real.realPolynomial (Real.dualDelta 7 c)) = 0 → z.im = 0) := by
  exact ⟨PaperNoOpenInputs.THEOREM_3_1 p hp,
    actual_dual_degree c hc,
    actual_dual_all_roots_real c hc⟩

/-- Full-size finite atomic Gram determinant, rather than a fixed-size
    illustrative instance; strictness follows from a proved formula. -/
theorem arbitrary_finite_positive_hankel
    {n : ℕ} (nodes weights : Fin n → ℝ)
    (hV : (atomVandermonde nodes).det ≠ 0)
    (hw : ∀ a, 0 < weights a) :
    0 < (PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy.atomicHankel
      nodes weights n).det :=
  atomicHankel_det_pos nodes weights hV hw

end PaperProofs.PRINCIPAL_THEOREMS_BRIDGE

#print axioms PaperProofs.PRINCIPAL_THEOREMS_BRIDGE.principal_pencils
#print axioms PaperProofs.PRINCIPAL_THEOREMS_BRIDGE.arbitrary_finite_positive_hankel
