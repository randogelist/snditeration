import PaperProofs.S03_Theorem_3_3_AlternatingPoleSign
import Mathlib.Tactic

/-!
# Theorem 3.3(3): sign of each original residue weight by pole parity

This removes the ambiguous `(-1)^(a-1)` notation from the final
statement: poles of odd index carry a positive weight, while poles of
even index carry a negative weight. No spectral or analytic hypothesis.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_3_SignByPoleParity

/-- Every actual odd-indexed tail pole has positive Lagrange residue. -/
theorem odd_pole_weight_pos
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h)
    (hodd : Odd (Zetahyperbolic.poleNat p i)) :
    0 < Zetahyperbolic.gammaWeight p k i := by
  obtain ⟨t, ht⟩ := hodd
  have hexp : Zetahyperbolic.poleNat p i - 1 = 2 * t := by omega
  have hsign : (-1 : ℚ) ^ (2 * t) = 1 := by
    rw [pow_mul]
    norm_num
  have h :=
    PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.gammaWeight_alternating p k i
  rw [hexp, hsign, one_mul] at h
  exact h

/-- Every actual even-indexed tail pole has negative Lagrange residue. -/
theorem even_pole_weight_neg
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h)
    (heven : Even (Zetahyperbolic.poleNat p i)) :
    Zetahyperbolic.gammaWeight p k i < 0 := by
  obtain ⟨t, ht⟩ := heven
  have ha : 0 < Zetahyperbolic.poleNat p i := by
    dsimp [Zetahyperbolic.poleNat]
    omega
  have htpos : 0 < t := by omega
  have hexp : Zetahyperbolic.poleNat p i - 1 =
      2 * (t - 1) + 1 := by omega
  have hsign : (-1 : ℚ) ^ (2 * (t - 1) + 1) = -1 := by
    rw [pow_add, pow_mul]
    norm_num
  have h :=
    PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.gammaWeight_alternating p k i
  rw [hexp, hsign] at h
  nlinarith

end PaperProofs.S03_Theorem_3_3_SignByPoleParity

#print axioms PaperProofs.S03_Theorem_3_3_SignByPoleParity.odd_pole_weight_pos
#print axioms PaperProofs.S03_Theorem_3_3_SignByPoleParity.even_pole_weight_neg
