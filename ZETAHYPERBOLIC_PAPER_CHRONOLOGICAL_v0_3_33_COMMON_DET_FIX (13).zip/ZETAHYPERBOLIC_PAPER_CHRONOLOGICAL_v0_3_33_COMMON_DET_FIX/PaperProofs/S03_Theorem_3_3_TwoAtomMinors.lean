import PaperChronology.S03_Theorem_3_3
import Mathlib.Tactic

/-!
# Theorem 3.3: explicit strict 2 × 2 total-positivity witness

The general paper claim concerns the positive continuous Hankel measure and
minors of arbitrary size. This module proves a genuine finite-atom case:
for two positive atoms the mixed 2 × 2 determinant factors as a product
of two Vandermonde determinants. In particular all adjacent Hankel
2 × 2 minors are strictly positive when the nodes are distinct and positive.
This is *not* a proof of total positivity of the whole continuous family.
-/

namespace PaperProofs.S03_Theorem_3_3_TwoAtomMinors

/-- The moment of two weighted atoms. -/
def moment (w₀ w₁ u v : ℝ) (r : ℕ) : ℝ :=
  w₀ * u ^ r + w₁ * v ^ r

/-- Exact two-atom 2 × 2 Cauchy-Binet formula, for arbitrary row and
column exponent indices. This is the mixed-minor algebra of Theorem 3.3. -/
theorem mixed_two_by_two_factor
    (w₀ w₁ u v : ℝ) (i j r s : ℕ) :
    moment w₀ w₁ u v (i + r) * moment w₀ w₁ u v (j + s) -
      moment w₀ w₁ u v (i + s) * moment w₀ w₁ u v (j + r) =
      w₀ * w₁ * (u ^ i * v ^ j - v ^ i * u ^ j) *
        (u ^ r * v ^ s - v ^ r * u ^ s) := by
  simp only [moment, pow_add]
  ring

/-- Every shifted adjacent 2 × 2 Hankel determinant equals a positive
mass factor times the square of the node separation. -/
theorem adjacent_minor_factor
    (w₀ w₁ u v : ℝ) (r : ℕ) :
    moment w₀ w₁ u v r * moment w₀ w₁ u v (r + 2) -
      (moment w₀ w₁ u v (r + 1)) ^ 2 =
      w₀ * w₁ * (u * v) ^ r * (v - u) ^ 2 := by
  simp only [moment, pow_add, pow_one, mul_pow]
  ring

/-- Strict positivity of the adjacent minors for any two distinct
positive nodes and any two positive atom masses. -/
theorem adjacent_minor_strict
    (w₀ w₁ u v : ℝ) (r : ℕ)
    (hw₀ : 0 < w₀) (hw₁ : 0 < w₁)
    (hu : 0 < u) (hv : 0 < v) (huv : u ≠ v) :
    0 < moment w₀ w₁ u v r * moment w₀ w₁ u v (r + 2) -
      (moment w₀ w₁ u v (r + 1)) ^ 2 := by
  rw [adjacent_minor_factor]
  have hmass : 0 < w₀ * w₁ := mul_pos hw₀ hw₁
  have hnodes : 0 < (u * v) ^ r := pow_pos (mul_pos hu hv) r
  have hgap : 0 < (v - u) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv.symm)
  exact mul_pos (mul_pos hmass hnodes) hgap

/-- If the two nodes coincide, the rank-one moment determinant vanishes. -/
theorem adjacent_minor_zero_same_node
    (w₀ w₁ u : ℝ) (r : ℕ) :
    moment w₀ w₁ u u r * moment w₀ w₁ u u (r + 2) -
      (moment w₀ w₁ u u (r + 1)) ^ 2 = 0 := by
  rw [adjacent_minor_factor]
  ring

end PaperProofs.S03_Theorem_3_3_TwoAtomMinors

#print axioms PaperProofs.S03_Theorem_3_3_TwoAtomMinors.mixed_two_by_two_factor
#print axioms PaperProofs.S03_Theorem_3_3_TwoAtomMinors.adjacent_minor_factor
#print axioms PaperProofs.S03_Theorem_3_3_TwoAtomMinors.adjacent_minor_strict
#print axioms PaperProofs.S03_Theorem_3_3_TwoAtomMinors.adjacent_minor_zero_same_node
