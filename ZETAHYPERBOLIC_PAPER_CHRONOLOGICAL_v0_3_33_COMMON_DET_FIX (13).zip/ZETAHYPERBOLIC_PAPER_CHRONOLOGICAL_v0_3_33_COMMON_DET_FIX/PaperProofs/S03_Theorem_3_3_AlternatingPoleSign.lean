import PaperProofs.S03_Theorem_3_3_ResidueParityRatio
import Mathlib.Tactic

/-!
# Theorem 3.3(3) — exact alternating signs of actual pole weights

For every admissible original Section 2 Hankel pencil and every pole
index `a = N+1+i`, the residue-weight sign is `(-1)^(a-1)`. This is
the missing finite sign calculation needed before transferring Sylvester's
law of inertia to the real symmetric spectral pencil.

This module does not silently assert the spectral inertia theorem: that
is a separate bridge from diagonal congruence and positive Gram input.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_3_AlternatingPoleSign
open PaperProofs.S03_Theorem_3_3_SignedResidueProducts
open PaperProofs.S03_Theorem_3_3_ResidueParityRatio

/-- Normalize a fraction by sign multipliers of square one. This is
valid for arbitrary rational numerator and nonzero denominator. -/
theorem signed_ratio_transfer (A D s t : ℚ)
    (hD : D ≠ 0) (ht : t * t = 1) :
    (s * A) / (t * D) = (s * t) * (A / D) := by
  have htne : t ≠ 0 := by
    intro hzero
    rw [hzero] at ht
    norm_num at ht
  apply (div_eq_iff (mul_ne_zero htne hD)).2
  have hcross : ((s * t) * (A / D)) * (t * D) =
      (s * (t * t)) * A := by
    field_simp [hD]
    ring
  rw [hcross, ht]
  ring

/-- The manuscript's explicit residue weights alternate in sign at
every tail pole, uniformly in N,K,m and in odd zeta weight 2k+1. -/
theorem gammaWeight_alternating
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (Zetahyperbolic.poleNat p i - 1) *
      Zetahyperbolic.gammaWeight p k i := by
  let a := Zetahyperbolic.poleNat p i
  let P := numeratorProduct p.N a
  let D := denominatorProduct p.N p.K a
  let A : ℚ := (a : ℚ) ^ (2 * k) * P ^ (2 * p.m - 1)
  let s : ℚ := (-1) ^ p.N
  let t : ℚ := (-1) ^ i.val
  have hamem := Zetahyperbolic.poleNat_mem_tail p i
  have haN : p.N < a := by
    have h := (Finset.mem_Icc.mp hamem).1
    dsimp [a]
    omega
  have haK : a ≤ p.K := (Finset.mem_Icc.mp hamem).2
  have hDpos : 0 < (-1 : ℚ) ^ (a - (p.N + 1)) * D :=
    denominatorProduct_signed_pos p.N p.K a haN haK
  have hDnz : D ≠ 0 := by
    intro hz
    rw [hz] at hDpos
    simp at hDpos
  have htsq : t * t = 1 := by
    dsimp [t]
    rw [← pow_two, ← pow_mul, Nat.mul_comm i.val 2, pow_mul]
    norm_num
  have hratio : 0 < (s * A) / (t * D) := by
    simpa only [s, A, t, P, D, a] using
      (exact_signed_residue_ratio_pos p k i)
  have hratio' : 0 < (s * t) * (A / D) := by
    rw [← signed_ratio_transfer A D s t hDnz htsq]
    exact hratio
  have hgamma : Zetahyperbolic.gammaWeight p k i = A / D := rfl
  have hexp : a - 1 = p.N + i.val := by
    dsimp [a, Zetahyperbolic.poleNat]
    omega
  rw [hgamma, show Zetahyperbolic.poleNat p i - 1 = p.N + i.val
      from hexp, pow_add]
  exact hratio'

/-- The pole weights cannot vanish, now also a consequence of their
strictly signed positivity rather than an independent denominator check. -/
theorem gammaWeight_nonzero_from_sign
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h) :
    Zetahyperbolic.gammaWeight p k i ≠ 0 := by
  intro hz
  have hp := gammaWeight_alternating p k i
  rw [hz] at hp
  simp at hp

end PaperProofs.S03_Theorem_3_3_AlternatingPoleSign

#print axioms PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.signed_ratio_transfer
#print axioms PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.gammaWeight_alternating
#print axioms PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.gammaWeight_nonzero_from_sign
