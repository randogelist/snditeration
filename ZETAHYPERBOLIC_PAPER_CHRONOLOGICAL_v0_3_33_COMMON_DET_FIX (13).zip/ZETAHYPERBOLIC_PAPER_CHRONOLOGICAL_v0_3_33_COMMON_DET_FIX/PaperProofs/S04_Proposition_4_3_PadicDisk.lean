import Mathlib.NumberTheory.Padics.Complex
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Analysis.Normed.Ring.Ultra
import Mathlib.Tactic

/-!
# Proposition 4.3: genuine ultrametric zero-free disk over C_p

This closes the exact p-adic conclusion in the paper: for an INTEGER
polynomial Q and a p-adic-integer center xi, every alpha in the open
p-adic disk of radius norm(Q(xi)) has the SAME nonzero polynomial norm.

No auxiliary analytic or finite-residue approximation is postulated.
The integer coefficient bound and polynomial Lipschitz inequality are
proved from the nonarchimedean norm on `PadicComplex p`.

If the pinned Mathlib interface differs, the user's compiler is the only
authority; this new module has NOT been compiled locally.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperProofs.S04_Proposition_4_3_PadicDisk

variable (p : ℕ) [Fact (Nat.Prime p)]

/-- Actual evaluation of an integer polynomial in the p-adic complex field. -/
def evalIntegral (Q : Polynomial ℤ) (x : ℂ_[p]) : ℂ_[p] :=
  Q.eval₂ (Int.castRingHom (ℂ_[p])) x

/-- The norm of an integer coefficient in C_p is at most one. -/
private theorem int_norm_le_one (z : ℤ) :
    ‖(z : ℂ_[p])‖ ≤ 1 := by
  exact IsUltrametricDist.norm_intCast_le_one (ℂ_[p]) z

/-- Every natural power of an element of the valuation ring remains there. -/
private theorem power_norm_le_one {x : ℂ_[p]} (hx : ‖x‖ ≤ 1) :
    ∀ n : ℕ, ‖x ^ n‖ ≤ 1 := by
  intro n
  induction n with
  | zero => simp
  | succ n ih =>
    calc
      ‖x ^ (n + 1)‖ = ‖x ^ n‖ * ‖x‖ := by rw [pow_succ, norm_mul]
      _ ≤ 1 * 1 := mul_le_mul ih hx (norm_nonneg _) (by norm_num)
      _ = 1 := by ring

/-- The nonarchimedean power-difference estimate on the closed unit disk. -/
private theorem power_diff_norm_le {x y : ℂ_[p]}
    (hx : ‖x‖ ≤ 1) (hy : ‖y‖ ≤ 1) :
    ∀ n : ℕ, ‖x ^ n - y ^ n‖ ≤ ‖x - y‖ := by
  intro n
  induction n with
  | zero => simp
  | succ n ih =>
    have hident : x ^ (n + 1) - y ^ (n + 1) =
        (x ^ n - y ^ n) * x + y ^ n * (x - y) := by
      calc
        x ^ (n + 1) - y ^ (n + 1) = x ^ n * x - y ^ n * y := by
          rw [pow_succ, pow_succ]
        _ = (x ^ n - y ^ n) * x + y ^ n * (x - y) := by ring
    rw [hident]
    calc
      ‖(x ^ n - y ^ n) * x + y ^ n * (x - y)‖ ≤
          max (‖(x ^ n - y ^ n) * x‖) (‖y ^ n * (x - y)‖) :=
        (PadicComplex.isNonarchimedean p) _ _
      _ ≤ ‖x - y‖ := by
        apply max_le
        · rw [norm_mul]
          calc
            ‖x ^ n - y ^ n‖ * ‖x‖ ≤ ‖x - y‖ * 1 :=
              mul_le_mul ih hx (norm_nonneg _) (norm_nonneg _)
            _ = ‖x - y‖ := mul_one _
        · rw [norm_mul]
          calc
            ‖y ^ n‖ * ‖x - y‖ ≤ 1 * ‖x - y‖ :=
              mul_le_mul_of_nonneg_right (power_norm_le_one p hy n)
                (norm_nonneg _)
            _ = ‖x - y‖ := one_mul _

/-- A finite sum of uniformly bounded terms in C_p has the same bound. -/
private theorem norm_sum_le
    (f : ℕ → ℂ_[p]) (B : ℝ) (hB : 0 ≤ B)
    (hf : ∀ i, ‖f i‖ ≤ B) (s : Finset ℕ) :
    ‖∑ i ∈ s, f i‖ ≤ B := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using hB
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi]
    calc
      ‖f i + ∑ j ∈ s, f j‖ ≤
          max (‖f i‖) (‖∑ j ∈ s, f j‖) :=
        (PadicComplex.isNonarchimedean p) _ _
      _ ≤ B := max_le (hf i) ih

/-- A finite integer polynomial evaluated in C_p has norm ≤1 on the
valuation ring. No hypothesis on degree or leading coefficient. -/
theorem norm_eval_le_one (Q : Polynomial ℤ) (x : ℂ_[p])
    (hx : ‖x‖ ≤ 1) : ‖evalIntegral p Q x‖ ≤ 1 := by
  have hterms : ∀ i : ℕ, ‖(Q.coeff i : ℂ_[p]) * x ^ i‖ ≤ 1 := by
    intro i
    rw [norm_mul]
    calc
      ‖(Q.coeff i : ℂ_[p])‖ * ‖x ^ i‖ ≤ 1 * 1 :=
        mul_le_mul (int_norm_le_one p (Q.coeff i))
          (power_norm_le_one p hx i) (norm_nonneg _) (by norm_num)
      _ = 1 := by ring
  have hsum := norm_sum_le p
    (fun i => (Q.coeff i : ℂ_[p]) * x ^ i)
    1 (by norm_num) hterms (Finset.range (Q.natDegree + 1))
  have heval : evalIntegral p Q x =
      ∑ i ∈ Finset.range (Q.natDegree + 1),
        (Q.coeff i : ℂ_[p]) * x ^ i := by
    unfold evalIntegral
    simpa using (Polynomial.eval₂_eq_sum_range
      (Int.castRingHom (ℂ_[p])) x (p := Q))
  rw [heval]
  exact hsum

/-- The complete p-adic 1-Lipschitz bound for integer polynomials on the
closed unit disk, including all degrees and all p-adic complex inputs. -/
theorem norm_eval_sub_le (Q : Polynomial ℤ) (x y : ℂ_[p])
    (hx : ‖x‖ ≤ 1) (hy : ‖y‖ ≤ 1) :
    ‖evalIntegral p Q x - evalIntegral p Q y‖ ≤ ‖x - y‖ := by
  have heval : ∀ z : ℂ_[p], evalIntegral p Q z =
      ∑ i ∈ Finset.range (Q.natDegree + 1),
        (Q.coeff i : ℂ_[p]) * z ^ i := by
    intro z
    unfold evalIntegral
    simpa using (Polynomial.eval₂_eq_sum_range
      (Int.castRingHom (ℂ_[p])) z (p := Q))
  have hdiff : evalIntegral p Q x - evalIntegral p Q y =
      ∑ i ∈ Finset.range (Q.natDegree + 1),
        (Q.coeff i : ℂ_[p]) * (x ^ i - y ^ i) := by
    calc
      evalIntegral p Q x - evalIntegral p Q y =
          (∑ i ∈ Finset.range (Q.natDegree + 1),
            (Q.coeff i : ℂ_[p]) * x ^ i) -
          (∑ i ∈ Finset.range (Q.natDegree + 1),
            (Q.coeff i : ℂ_[p]) * y ^ i) := by rw [heval x, heval y]
      _ = ∑ i ∈ Finset.range (Q.natDegree + 1),
          ((Q.coeff i : ℂ_[p]) * x ^ i - (Q.coeff i : ℂ_[p]) * y ^ i) := by
            rw [← Finset.sum_sub_distrib]
      _ = ∑ i ∈ Finset.range (Q.natDegree + 1),
          (Q.coeff i : ℂ_[p]) * (x ^ i - y ^ i) := by
            apply Finset.sum_congr rfl
            intro i _
            ring
  have hterms : ∀ i : ℕ,
      ‖(Q.coeff i : ℂ_[p]) * (x ^ i - y ^ i)‖ ≤ ‖x - y‖ := by
    intro i
    rw [norm_mul]
    calc
      ‖(Q.coeff i : ℂ_[p])‖ * ‖x ^ i - y ^ i‖ ≤ 1 * ‖x - y‖ :=
        mul_le_mul (int_norm_le_one p (Q.coeff i))
          (power_diff_norm_le p hx hy i) (norm_nonneg _) (by norm_num)
      _ = ‖x - y‖ := one_mul _
  rw [hdiff]
  exact norm_sum_le p _ _ (norm_nonneg _) hterms _

/-- Full Proposition 4.3 (not merely a finite ZMod analogue): the norm
of Q is constant and NONZERO on its sharp open p-adic disk about xi. -/
theorem ultrametric_zero_free_disk
    (Q : Polynomial ℤ) (xi alpha : ℂ_[p])
    (hxi : ‖xi‖ ≤ 1)
    (hQ : evalIntegral p Q xi ≠ 0)
    (hnear : ‖alpha - xi‖ < ‖evalIntegral p Q xi‖) :
    ‖evalIntegral p Q alpha‖ = ‖evalIntegral p Q xi‖ ∧
      evalIntegral p Q alpha ≠ 0 := by
  have hQone : ‖evalIntegral p Q xi‖ ≤ 1 :=
    norm_eval_le_one p Q xi hxi
  have halpha : ‖alpha‖ ≤ 1 := by
    calc
      ‖alpha‖ = ‖(alpha - xi) + xi‖ := by congr 1 <;> ring
      _ ≤ max ‖alpha - xi‖ ‖xi‖ :=
        (PadicComplex.isNonarchimedean p) _ _
      _ ≤ 1 := max_le (le_of_lt (lt_of_lt_of_le hnear hQone)) hxi
  have hsmall :
      ‖evalIntegral p Q alpha - evalIntegral p Q xi‖ <
        ‖evalIntegral p Q xi‖ :=
    lt_of_le_of_lt (norm_eval_sub_le p Q alpha xi halpha hxi) hnear
  have heq : ‖evalIntegral p Q alpha‖ = ‖evalIntegral p Q xi‖ := by
    have hupper : ‖evalIntegral p Q alpha‖ ≤ ‖evalIntegral p Q xi‖ := by
      calc
        ‖evalIntegral p Q alpha‖ =
            ‖(evalIntegral p Q alpha - evalIntegral p Q xi) +
              evalIntegral p Q xi‖ := by congr 1 <;> ring
        _ ≤ max ‖evalIntegral p Q alpha - evalIntegral p Q xi‖
                 ‖evalIntegral p Q xi‖ :=
              (PadicComplex.isNonarchimedean p) _ _
        _ = ‖evalIntegral p Q xi‖ := max_eq_right (le_of_lt hsmall)
    have hlower : ‖evalIntegral p Q xi‖ ≤ ‖evalIntegral p Q alpha‖ := by
      by_contra hnot
      have hlt : ‖evalIntegral p Q alpha‖ < ‖evalIntegral p Q xi‖ :=
        lt_of_not_ge hnot
      have hbound :
          ‖evalIntegral p Q xi‖ ≤
            max ‖evalIntegral p Q alpha - evalIntegral p Q xi‖
                ‖evalIntegral p Q alpha‖ := by
        calc
          ‖evalIntegral p Q xi‖ =
              ‖(evalIntegral p Q xi - evalIntegral p Q alpha) +
                evalIntegral p Q alpha‖ := by congr 1 <;> ring
          _ ≤ max ‖evalIntegral p Q xi - evalIntegral p Q alpha‖
                   ‖evalIntegral p Q alpha‖ :=
                (PadicComplex.isNonarchimedean p) _ _
          _ = max ‖evalIntegral p Q alpha - evalIntegral p Q xi‖
                    ‖evalIntegral p Q alpha‖ := by rw [norm_sub_rev]
      have hstrict :
          max ‖evalIntegral p Q alpha - evalIntegral p Q xi‖
              ‖evalIntegral p Q alpha‖ < ‖evalIntegral p Q xi‖ :=
        max_lt hsmall hlt
      exact (not_lt_of_ge hbound) hstrict
    exact le_antisymm hupper hlower
  refine ⟨heq, ?_⟩
  intro hz
  apply hQ
  apply norm_eq_zero.mp
  rw [← heq, hz, norm_zero]

end PaperProofs.S04_Proposition_4_3_PadicDisk

#print axioms PaperProofs.S04_Proposition_4_3_PadicDisk.norm_eval_le_one
#print axioms PaperProofs.S04_Proposition_4_3_PadicDisk.norm_eval_sub_le
#print axioms PaperProofs.S04_Proposition_4_3_PadicDisk.ultrametric_zero_free_disk
