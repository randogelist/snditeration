import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil
import Mathlib.Tactic

/-!
# Theorem 5.2, unconditional finite algebra of the genuine dual pencil

This module uses the actual `Real.dualEntry` coefficients from Theorem 5.1.
It proves that their degree-one coefficient matrix is C*Cᵀ, the part of
Theorem 5.2(1) independent of the analytic double integral and of any
Krein-tail hypothesis. It does not assert polynomial subspace existence.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperProofs.S05_Theorem_5_2_DualSlope

open ManuscriptChain

variable {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ)

/-- The exact coefficient matrix of the rational-polynomial dual pencil. -/
def coefficientMatrix : Matrix (Fin h) (Fin (K + 1)) ℚ := c

def slopeMatrix : Matrix (Fin h) (Fin h) ℚ :=
  fun i j => (Real.dualEntry 7 c i j).coeff 1

/-- Every polynomial entry has exactly the coefficient of X prescribed by
    the two-variable moment construction. -/
theorem entry_slope (i j : Fin h) :
    (Real.dualEntry 7 c i j).coeff 1 = ∑ r, c i r * c j r := by
  unfold Real.dualEntry
  rw [Polynomial.coeff_add, Polynomial.coeff_C_mul]
  simp

/-- The paper's precise matrix identity M_A = C Cᵀ, in arbitrary dimensions. -/
theorem slope_eq_coeff_gram :
    slopeMatrix c = coefficientMatrix c * (coefficientMatrix c).transpose := by
  classical
  ext i j
  change (Real.dualEntry 7 c i j).coeff 1 = _
  rw [entry_slope]
  simp [coefficientMatrix, Matrix.mul_apply, dotProduct,
    Matrix.transpose_apply]

/-- The degree-one coefficient matrix is symmetric, without a witness. -/
theorem slope_transpose_eq :
    (slopeMatrix c).transpose = slopeMatrix c := by
  rw [slope_eq_coeff_gram]
  simp only [Matrix.transpose_mul, Matrix.transpose_transpose]

/-- Nonnegative diagonal entries of the actual X-slope. -/
theorem slope_diagonal_nonnegative (i : Fin h) :
    0 ≤ slopeMatrix c i i := by
  change 0 ≤ (Real.dualEntry 7 c i i).coeff 1
  rw [entry_slope]
  have hsum : 0 ≤ ∑ r : Fin (K + 1), (c i r) ^ 2 :=
    Finset.sum_nonneg (fun r _ => sq_nonneg (c i r))
  simpa only [pow_two] using hsum

end PaperProofs.S05_Theorem_5_2_DualSlope

#print axioms PaperProofs.S05_Theorem_5_2_DualSlope.entry_slope
#print axioms PaperProofs.S05_Theorem_5_2_DualSlope.slope_eq_coeff_gram
#print axioms PaperProofs.S05_Theorem_5_2_DualSlope.slope_transpose_eq
#print axioms PaperProofs.S05_Theorem_5_2_DualSlope.slope_diagonal_nonnegative
