import PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy
import Mathlib.Tactic

/-!
# Corollary 3.6: unconditional finite reciprocal-root moments

If `roots` is a finite real spectrum and `q` is a rational evaluation
point different from the roots, then u_j=(roots_j-q)^(-2)>0 and
S_(2k)(q)=sum_j u_j^k. Every finite Hankel form built from this sequence
is positive semidefinite. Strict positivity beyond the support size is
not asserted (and is false in the literal manuscript).
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Corollary_3_6_ReciprocalRoots

open PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy

variable {m n : ℕ}

/-- Positive reciprocal squared distances from the evaluation point. -/
def reciprocalNodes (roots : Fin m → ℝ) (q : ℝ) : Fin m → ℝ :=
  fun a => ((roots a - q)⁻¹) ^ 2

/-- Positive reciprocal squared distance whenever q is not a root. -/
theorem reciprocalNodes_pos
    (roots : Fin m → ℝ) (q : ℝ)
    (hq : ∀ a, roots a ≠ q) (a : Fin m) :
    0 < reciprocalNodes roots q a := by
  unfold reciprocalNodes
  apply sq_pos_of_ne_zero
  apply inv_ne_zero
  exact sub_ne_zero.mpr (hq a)

/-- The finite reciprocal-root power sums are atomic moments. -/
def evenReciprocalMoment (roots : Fin m → ℝ) (q : ℝ) (k : ℕ) : ℝ :=
  ∑ a : Fin m, (reciprocalNodes roots q a) ^ k

/-- A definitional bridge to the general atomic Hankel moment. -/
theorem evenReciprocalMoment_eq_atomic
    (roots : Fin m → ℝ) (q : ℝ) (k : ℕ) :
    evenReciprocalMoment roots q k =
      atomicMoment (reciprocalNodes roots q) (fun _ => 1) k := by
  simp [evenReciprocalMoment, atomicMoment]

/-- Corrected universal finite-support Stieltjes positivity in all
    dimensions; after more rows than support points only semidefinite. -/
theorem evenReciprocalMoment_semidefinite
    (roots : Fin m → ℝ) (q : ℝ) (v : Fin n → ℝ) :
    0 ≤ ∑ i : Fin n, ∑ j : Fin n,
       v i * evenReciprocalMoment roots q ((i : ℕ) + (j : ℕ)) * v j := by
  have h := atomicHankel_nonnegative
      (reciprocalNodes roots q) (fun _ : Fin m => (1 : ℝ))
      (fun _ => by norm_num) v
  simpa only [atomicHankel, evenReciprocalMoment_eq_atomic] using h

end PaperProofs.S03_Corollary_3_6_ReciprocalRoots

#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalRoots.reciprocalNodes_pos
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalRoots.evenReciprocalMoment_eq_atomic
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalRoots.evenReciprocalMoment_semidefinite
