import Mathlib.Tactic

/-!
# Theorem 3.3 / Corollary 3.6: arbitrary finite atomic moment energy

For arbitrary real nodes, nonnegative masses, and arbitrary polynomial
coefficients, the associated Hankel quadratic form is a weighted sum of
squares. This is valid in every finite dimension, even for repeated nodes.

Consequences:
* positivity in the semidefinite sense without a support-rank condition;
* strict positivity of an individual quadratic form if at least one
  positive-weight atom detects its polynomial;
* an exact bridge from the moment formula M_(i+j) to the Gram form.

The infinite continuous-measure total-positivity theorem in the PDF is
NOT claimed by this finite-support lemma.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy

variable {m n : ℕ}

/-- Real discrete moment of degree `k` with finitely many atoms. -/
def atomicMoment (nodes weights : Fin m → ℝ) (k : ℕ) : ℝ :=
  ∑ a : Fin m, weights a * nodes a ^ k

/-- Arbitrary rectangular truncation of the infinite atomic Hankel form. -/
def atomicHankel (nodes weights : Fin m → ℝ) (n : ℕ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => atomicMoment nodes weights (i.val + j.val)

/-- Exact finite weighted-sum-of-squares identity. -/
private theorem double_sum_weighted_square
    {ι : Type*} [Fintype ι] (w : ℝ) (u : ι → ℝ) :
    (∑ i : ι, ∑ j : ι, w * (u i * u j)) =
      w * (∑ i : ι, u i) ^ 2 := by
  classical
  -- Expand the sums in the same order.  A blind double `simp` can
  -- interchange the two binders and leave a residual `sum_comm` goal.
  have hsquare :
      (∑ i : ι, ∑ j : ι, u i * u j) = (∑ i : ι, u i) ^ 2 := by
    calc
      (∑ i : ι, ∑ j : ι, u i * u j) =
          ∑ i : ι, u i * (∑ j : ι, u j) := by
            simp only [Finset.mul_sum]
      _ = (∑ i : ι, u i) * (∑ j : ι, u j) := by
            simp only [Finset.sum_mul]
      _ = (∑ i : ι, u i) ^ 2 := by ring
  calc
    (∑ i : ι, ∑ j : ι, w * (u i * u j)) =
        w * (∑ i : ι, ∑ j : ι, u i * u j) := by
          simp only [Finset.mul_sum]
    _ = w * (∑ i : ι, u i) ^ 2 := by
          rw [hsquare]

/-- The full discrete Hankel energy equals a weighted sum of squares,
    without restricting the number of rows or support points. -/
theorem atomicHankel_energy
    (nodes weights : Fin m → ℝ) (v : Fin n → ℝ) :
    (∑ i : Fin n, ∑ j : Fin n,
      v i * atomicHankel nodes weights n i j * v j) =
      ∑ a : Fin m, weights a *
        (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ^ 2 := by
  classical
  dsimp only [atomicHankel, atomicMoment]
  calc
    (∑ i : Fin n, ∑ j : Fin n,
        v i * (∑ a : Fin m, weights a * nodes a ^ ((i : ℕ) + (j : ℕ))) * v j) =
        ∑ i : Fin n, ∑ j : Fin n, ∑ a : Fin m,
          weights a * ((v i * nodes a ^ (i : ℕ)) * (v j * nodes a ^ (j : ℕ))) := by
            apply Finset.sum_congr rfl
            intro i _
            apply Finset.sum_congr rfl
            intro j _
            rw [Finset.mul_sum, Finset.sum_mul]
            apply Finset.sum_congr rfl
            intro a _
            rw [pow_add]
            ring
    _ = ∑ a : Fin m, ∑ i : Fin n, ∑ j : Fin n,
          weights a * ((v i * nodes a ^ (i : ℕ)) * (v j * nodes a ^ (j : ℕ))) := by
            calc
              (∑ i : Fin n, ∑ j : Fin n, ∑ a : Fin m,
                  weights a * ((v i * nodes a ^ (i : ℕ)) * (v j * nodes a ^ (j : ℕ)))) =
                  ∑ i : Fin n, ∑ a : Fin m, ∑ j : Fin n,
                    weights a * ((v i * nodes a ^ (i : ℕ)) * (v j * nodes a ^ (j : ℕ))) := by
                      apply Finset.sum_congr rfl
                      intro i _
                      exact Finset.sum_comm
              _ = ∑ a : Fin m, ∑ i : Fin n, ∑ j : Fin n,
                  weights a * ((v i * nodes a ^ (i : ℕ)) * (v j * nodes a ^ (j : ℕ))) := by
                    exact Finset.sum_comm
    _ = ∑ a : Fin m, weights a *
          (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ^ 2 := by
            apply Finset.sum_congr rfl
            intro a _
            exact double_sum_weighted_square (weights a)
              (fun i : Fin n => v i * nodes a ^ (i : ℕ))

/-- The atomic Hankel form is positive semidefinite when its masses
    are nonnegative. There is no false claim of full rank. -/
theorem atomicHankel_nonnegative
    (nodes weights : Fin m → ℝ)
    (hw : ∀ a, 0 ≤ weights a) (v : Fin n → ℝ) :
    0 ≤ ∑ i : Fin n, ∑ j : Fin n,
      v i * atomicHankel nodes weights n i j * v j := by
  rw [atomicHankel_energy]
  exact Finset.sum_nonneg (fun a _ =>
    mul_nonneg (hw a) (sq_nonneg _))

/-- If a polynomial vector evaluates nontrivially at a positive-mass
    support point, then its Hankel energy is strictly positive. -/
theorem atomicHankel_positive_of_detected
    (nodes weights : Fin m → ℝ)
    (hw : ∀ a, 0 < weights a)
    (v : Fin n → ℝ)
    (hdetect : ∃ a : Fin m,
      (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ≠ 0) :
    0 < ∑ i : Fin n, ∑ j : Fin n,
      v i * atomicHankel nodes weights n i j * v j := by
  obtain ⟨a, ha⟩ := hdetect
  rw [atomicHankel_energy]
  -- The positive detected atom is a lower bound for the whole sum.
  -- This explicit argument avoids relying on version-sensitive
  -- `Finset.sum_pos'` elaboration at the final term.
  have hnonneg (b : Fin m) :
      0 ≤ weights b *
        (∑ i : Fin n, v i * nodes b ^ (i : ℕ)) ^ 2 :=
    mul_nonneg (le_of_lt (hw b)) (sq_nonneg _)
  have hdetected :
      0 < weights a *
        (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ^ 2 :=
    mul_pos (hw a) (sq_pos_of_ne_zero ha)
  have hle :
      weights a * (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ^ 2 ≤
        ∑ b : Fin m, weights b *
          (∑ i : Fin n, v i * nodes b ^ (i : ℕ)) ^ 2 := by
    exact Finset.single_le_sum
      (fun b _ => hnonneg b) (Finset.mem_univ a)
  exact lt_of_lt_of_le hdetected hle

/-- The moment matrix is symmetric in all finite dimensions. -/
theorem atomicHankel_transpose (nodes weights : Fin m → ℝ) :
    (atomicHankel nodes weights n).transpose =
      atomicHankel nodes weights n := by
  ext i j
  simp only [Matrix.transpose_apply, atomicHankel, Nat.add_comm]

end PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy

#print axioms PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy.atomicHankel_energy
#print axioms PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy.atomicHankel_nonnegative
#print axioms PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy.atomicHankel_positive_of_detected
#print axioms PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy.atomicHankel_transpose
