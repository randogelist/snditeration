import PaperProofs.S05_Theorem_5_2_DualDeterminant
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Mathlib.Analysis.Matrix.Order
import Mathlib.LinearAlgebra.Matrix.Polynomial
import Mathlib.Tactic

/-!
# Theorem 5.2(1): principal hyperbolicity with positive pencil slope

Unlike Theorem 3.1, whose *base* is positive definite, the dual Beukers
pencil has a positive definite *slope*. The following is the complete
finite-dimensional spectral theorem for this dual situation in EVERY
matrix dimension, including singular or indefinite constant matrices.

Input is only symmetry of the constant matrix and positive definiteness
of the derivative. Neither its determinant nor a root-separation bound
is assumed, and no analytic or arithmetic witness is introduced.

The remaining infinite-dimensional Krein-space and rational-subspace
parts of PDF Theorem 5.2 are separate mathematical theorems.
-/

noncomputable section
open scoped BigOperators MatrixOrder
open Matrix Polynomial

namespace PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity

variable {n : ℕ}

/-- Determinant of the affine pencil with its positive direction as slope. -/
def realAffineDet (A M : Matrix (Fin n) (Fin n) ℝ) : ℝ[X] :=
  (fun i j => C (A i j) + X * C (M i j)).det

/-- The actual polynomial evaluates to the actual matrix determinant. -/
theorem realAffineDet_eval (A M : Matrix (Fin n) (Fin n) ℝ) (x : ℝ) :
    (realAffineDet A M).eval x = (A + x • M).det := by
  unfold realAffineDet
  change (Polynomial.evalRingHom x)
    ((fun i j => C (A i j) + X * C (M i j) :
      Matrix (Fin n) (Fin n) ℝ[X]).det) = _
  rw [(Polynomial.evalRingHom x).map_det]
  congr 1
  ext i j
  simp [Matrix.add_apply, Matrix.smul_apply, smul_eq_mul]
  ring

/-- A Hermitian matrix plus a real scalar identity has the indicated
    eigenvalue-product determinant, without an invertibility assumption. -/
theorem det_add_scalar_one_of_hermitian
    (B : Matrix (Fin n) (Fin n) ℝ) (hB : B.IsHermitian) (x : ℝ) :
    (B + x • (1 : Matrix (Fin n) (Fin n) ℝ)).det =
      ∏ i, (hB.eigenvalues i + x) := by
  let e := Unitary.conjStarAlgAut ℝ _ hB.eigenvectorUnitary
  have he : B = e (diagonal hB.eigenvalues) := by
    simpa [e, Function.comp_def] using hB.spectral_theorem
  have hmap : B + x • (1 : Matrix (Fin n) (Fin n) ℝ) =
      e (diagonal hB.eigenvalues + x • 1) := by
    simp only [map_add, map_one, map_smul, ← he]
  rw [hmap]
  change Matrix.det (e (diagonal hB.eigenvalues + x • 1)) = _
  dsimp only [e]
  rw [Unitary.conjStarAlgAut_apply, Matrix.det_mul_comm, ← Matrix.mul_assoc]
  simp only [Unitary.coe_star_mul_self, Matrix.one_mul]
  have hd : diagonal hB.eigenvalues + x • (1 : Matrix (Fin n) (Fin n) ℝ) =
      diagonal (fun i => hB.eigenvalues i + x) := by
    ext i j
    by_cases hij : i = j <;> simp [hij, Matrix.diagonal]
  rw [hd, Matrix.det_diagonal]

/-- Complete spectral factorization of a symmetric affine pencil whose
    direction matrix is positive definite; unlike the base-positive case,
    the constant matrix may be singular or indefinite. -/
theorem positive_slope_root_factorization
    (A M : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsSymm) (hM : M.PosDef) :
    ∃ r : Fin n → ℝ,
      realAffineDet A M = C M.det * ∏ i, (X - C (r i)) := by
  let S := CFC.sqrt M
  have hSsq : S * S = M := by
    simpa [S, sq] using CFC.sq_sqrt M hM.posSemidef.nonneg
  have hShermitian : S.IsHermitian :=
    (CFC.sqrt_nonneg M).posSemidef.isHermitian
  have hMdet : M.det ≠ 0 := ne_of_gt hM.det_pos
  have hSdet : S.det ≠ 0 := by
    intro hz
    have hd := congrArg Matrix.det hSsq
    rw [Matrix.det_mul, hz, zero_mul] at hd
    exact hMdet hd.symm
  have hSunit : IsUnit S.det := isUnit_iff_ne_zero.mpr hSdet
  let B := S⁻¹ * A * S⁻¹
  have hB : B.IsHermitian := by
    have h := Matrix.isHermitian_conjTranspose_mul_mul (S⁻¹)
      (Matrix.isHermitian_iff_isSymm.mpr hA)
    simpa only [hShermitian.inv.eq] using h
  have hconj : S * B * S = A := by
    dsimp only [B]
    calc
      S * (S⁻¹ * A * S⁻¹) * S =
          (S * S⁻¹) * A * (S⁻¹ * S) := by
            simp only [Matrix.mul_assoc]
      _ = A := by
        rw [Matrix.mul_nonsing_inv S hSunit,
          Matrix.nonsing_inv_mul S hSunit]
        simp
  have hpencil (x : ℝ) :
      A + x • M = S * (B + x • 1) * S := by
    calc
      A + x • M = S * B * S + x • (S * S) := by
        rw [hconj, hSsq]
      _ = S * (B + x • 1) * S := by
        simp [Matrix.mul_add, Matrix.add_mul]
  have hdetS : S.det * S.det = M.det := by
    rw [← Matrix.det_mul, hSsq]
  have hdet (x : ℝ) :
      (A + x • M).det = M.det * ∏ i, (hB.eigenvalues i + x) := by
    rw [hpencil, Matrix.det_mul, Matrix.det_mul,
      det_add_scalar_one_of_hermitian B hB]
    calc
      S.det * (∏ i, (hB.eigenvalues i + x)) * S.det =
          (S.det * S.det) * ∏ i, (hB.eigenvalues i + x) := by ring
      _ = M.det * ∏ i, (hB.eigenvalues i + x) := by rw [hdetS]
  refine ⟨fun i => -(hB.eigenvalues i), ?_⟩
  apply Polynomial.funext
  intro x
  rw [realAffineDet_eval, hdet]
  simp only [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_prod,
    Polynomial.eval_sub, Polynomial.eval_X]
  congr 1
  apply Finset.prod_congr rfl
  intro i _
  ring

/-- Principal Theorem 5.2(1): all complex roots are real, with no
    assumption that the constant matrix is positive or nonsingular. -/
theorem positive_slope_all_roots_real
    (A M : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsSymm) (hM : M.PosDef) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z (realAffineDet A M) = 0) :
    z.im = 0 := by
  obtain ⟨r, hr⟩ := positive_slope_root_factorization A M hA hM
  have heval :
      Polynomial.eval₂ (algebraMap ℝ ℂ) z (realAffineDet A M) =
        (M.det : ℂ) * ∏ i, (z - (r i : ℂ)) := by
    rw [hr]
    simp [Polynomial.eval₂_finsetProd]
  have hd : (M.det : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (ne_of_gt hM.det_pos)
  have hp : (∏ i, (z - (r i : ℂ))) = 0 :=
    (mul_eq_zero.mp (heval ▸ hz)).resolve_left hd
  obtain ⟨i, _, hi⟩ := Finset.prod_eq_zero_iff.mp hp
  have hzreal : z = (r i : ℂ) := sub_eq_zero.mp hi
  rw [hzreal]
  rfl

/-- Exact degree, not merely a bound, for every positive-slope pencil. -/
theorem positive_slope_exact_degree
    (A M : Matrix (Fin n) (Fin n) ℝ) (hM : M.PosDef) :
    (realAffineDet A M).natDegree = n := by
  have heq : realAffineDet A M =
      ((X : ℝ[X]) • M.map C + A.map C).det := by
    unfold realAffineDet
    congr 1
    ext i j
    simp [Matrix.smul_apply, Matrix.add_apply, Matrix.map_apply,
      smul_eq_mul]
    ring
  rw [heq]
  apply Nat.le_antisymm
  · simpa only [Fintype.card_fin] using
      Polynomial.natDegree_det_X_add_C_le M A
  · apply Polynomial.le_natDegree_of_ne_zero
    rw [show (((X : ℝ[X]) • M.map C + A.map C).det).coeff n = M.det by
      simpa only [Fintype.card_fin] using
        Polynomial.coeff_det_X_add_C_card M A]
    exact ne_of_gt hM.det_pos

end PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity

#print axioms PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity.positive_slope_root_factorization
#print axioms PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity.positive_slope_all_roots_real
#print axioms PaperProofs.S05_Theorem_5_2_PrincipalHyperbolicity.positive_slope_exact_degree
