import Mathlib.Tactic

/-! Theorem 6.10(2), explicit two-row finite derivative Gram identity.
This is exact polynomial algebra, without any limiting potential theory. -/
namespace PaperProofs.S06_Theorem_6_10_GramDet

/-- The 2x2 Gram determinant of two vectors in R^3 is the sum of squares
of their three 2x2 minors. -/
theorem two_row_cauchy_binet
    (a b c d e f : ℝ) :
    (a^2+b^2+c^2)*(d^2+e^2+f^2) - (a*d+b*e+c*f)^2 =
       (a*e-b*d)^2 + (a*f-c*d)^2 + (b*f-c*e)^2 := by
  ring

theorem two_row_gram_det_nonnegative (a b c d e f : ℝ) :
    0 ≤ (a^2+b^2+c^2)*(d^2+e^2+f^2) - (a*d+b*e+c*f)^2 := by
  rw [two_row_cauchy_binet]
  positivity

end PaperProofs.S06_Theorem_6_10_GramDet
#print axioms PaperProofs.S06_Theorem_6_10_GramDet.two_row_gram_det_nonnegative
