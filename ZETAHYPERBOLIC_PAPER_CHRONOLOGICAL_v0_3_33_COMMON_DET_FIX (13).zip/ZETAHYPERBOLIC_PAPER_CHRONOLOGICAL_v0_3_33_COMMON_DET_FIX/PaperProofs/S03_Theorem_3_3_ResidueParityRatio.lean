import PaperProofs.S03_Theorem_3_3_SignedResidueProducts
import Zetahyperbolic.Section2Checked
import Mathlib.Tactic

/-!
# Theorem 3.3 — positivity of the exact signed Lagrange residue ratio

The numerator of gamma_a has N negative pole factors, raised to an odd
power. The denominator has exactly a-N-1 negative factors. This module
handles the exponent and combines the two strictly positive normalized
products, for the *actual* gammaWeight defined in Section 2.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_ResidueParityRatio
open PaperProofs.S03_Theorem_3_3_SignedResidueProducts

/-- An explicitly positive quotient built from the same products used in
Zetahyperbolic.gammaWeight. No extra spectral or analytic assumptions. -/
theorem exact_signed_residue_ratio_pos
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h) :
    let a := Zetahyperbolic.poleNat p i
    0 < ((-1 : ℚ) ^ p.N *
        ((a : ℚ) ^ (2 * k) * (numeratorProduct p.N a) ^ (2 * p.m - 1))) /
      ((-1 : ℚ) ^ i.val * denominatorProduct p.N p.K a) := by
  dsimp
  let a := Zetahyperbolic.poleNat p i
  let P := numeratorProduct p.N a
  let D := denominatorProduct p.N p.K a
  have hamem := Zetahyperbolic.poleNat_mem_tail p i
  have haN : p.N < a := by
    have h := (Finset.mem_Icc.mp hamem).1
    dsimp [a]
    omega
  have haK : a ≤ p.K := (Finset.mem_Icc.mp hamem).2
  have hP : 0 < (-1 : ℚ) ^ p.N * P :=
    numeratorProduct_signed_pos p.N a haN
  have hDzero : 0 < (-1 : ℚ) ^ (a - (p.N + 1)) * D :=
    denominatorProduct_signed_pos p.N p.K a haN haK
  have hindex : a - (p.N + 1) = i.val := by
    dsimp [a, Zetahyperbolic.poleNat]
    omega
  have hD : 0 < (-1 : ℚ) ^ i.val * D := by
    simpa only [hindex] using hDzero
  have hPnz : P ≠ 0 := by
    intro hz
    rw [hz] at hP
    simp at hP
  have hA : 0 < (a : ℚ) := by
    exact_mod_cast (by omega : 0 < a)
  have hm : 2 * p.m - 1 = 2 * (p.m - 1) + 1 := by
    have hmp := p.hm
    omega
  have hEven : 0 < P ^ (2 * (p.m - 1)) := by
    rw [pow_mul]
    exact pow_pos (sq_pos_of_ne_zero hPnz) _
  have hNum : 0 < (-1 : ℚ) ^ p.N *
      ((a : ℚ) ^ (2 * k) * P ^ (2 * p.m - 1)) := by
    rw [hm, pow_add, pow_one]
    calc
      (-1 : ℚ) ^ p.N * ((a : ℚ) ^ (2 * k) *
            (P ^ (2 * (p.m - 1)) * P)) =
          (a : ℚ) ^ (2 * k) * P ^ (2 * (p.m - 1)) *
            ((-1 : ℚ) ^ p.N * P) := by ring
      _ > 0 := mul_pos (mul_pos (pow_pos hA _) hEven) hP
  exact div_pos hNum hD

end PaperProofs.S03_Theorem_3_3_ResidueParityRatio

#print axioms PaperProofs.S03_Theorem_3_3_ResidueParityRatio.exact_signed_residue_ratio_pos
