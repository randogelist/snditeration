import PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge
import Mathlib.Tactic

/-!
# Theorem 3.3 — all-dimensional shifted atomic Hankel determinants

For n finite atoms and any shift k, the shifted moment matrix is exactly
V diag(w_a x_a^k) Vᵀ. Therefore its determinant is the squared Vandermonde
determinant multiplied by the shifted atomic masses.

All shifts and all dimensions are quantified. Positivity for positive
atoms and weights is a *mathematical proof* at finite support; no
continuous-measure theorem or unproved analytic hypothesis is imported.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant

open PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy
open PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram
open PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge

variable {n : ℕ}

/-- The actual degree-shifted Hankel matrix, not a separately defined Gram. -/
def shiftedAtomicHankel (nodes weights : Fin n → ℝ) (shift : ℕ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => atomicMoment nodes weights (shift + ((i : ℕ) + (j : ℕ)))

/-- Exact identification with the unshifted moment matrix at reweighted atoms. -/
theorem shiftedAtomicHankel_eq_atomic
    (nodes weights : Fin n → ℝ) (shift : ℕ) :
    shiftedAtomicHankel nodes weights shift =
      atomicHankel nodes (fun a => weights a * nodes a ^ shift) n := by
  classical
  ext i j
  change
    (∑ a : Fin n, weights a * nodes a ^ (shift + ((i : ℕ) + (j : ℕ)))) =
      ∑ a : Fin n, (weights a * nodes a ^ shift) *
        nodes a ^ ((i : ℕ) + (j : ℕ))
  apply Finset.sum_congr rfl
  intro a _
  rw [pow_add]
  ring

/-- Exact determinant for every nonnegative integer shift, without
nonvanishing assumptions. In particular it also covers singular matrices. -/
theorem shiftedAtomicHankel_det
    (nodes weights : Fin n → ℝ) (shift : ℕ) :
    (shiftedAtomicHankel nodes weights shift).det =
      ((atomVandermonde nodes).det) ^ 2 *
        (∏ a : Fin n, weights a * nodes a ^ shift) := by
  rw [shiftedAtomicHankel_eq_atomic]
  exact atomicHankel_det nodes (fun a => weights a * nodes a ^ shift)

/-- Every positive-node shifted Hankel determinant is strictly positive
if the finite Vandermonde is nonsingular and all masses are positive. -/
theorem shiftedAtomicHankel_det_pos
    (nodes weights : Fin n → ℝ) (shift : ℕ)
    (hV : (atomVandermonde nodes).det ≠ 0)
    (hw : ∀ a, 0 < weights a)
    (hn : ∀ a, 0 < nodes a) :
    0 < (shiftedAtomicHankel nodes weights shift).det := by
  rw [shiftedAtomicHankel_eq_atomic]
  apply atomicHankel_det_pos nodes
    (fun a => weights a * nodes a ^ shift) hV
  intro a
  exact mul_pos (hw a) (pow_pos (hn a) shift)

/-- Full quadratic-energy factorization for the shifted moments. -/
theorem shiftedAtomicHankel_energy
    (nodes weights : Fin n → ℝ) (shift : ℕ) (v : Fin n → ℝ) :
    (∑ i : Fin n, ∑ j : Fin n,
      v i * shiftedAtomicHankel nodes weights shift i j * v j) =
      ∑ a : Fin n, (weights a * nodes a ^ shift) *
        (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ^ 2 := by
  rw [shiftedAtomicHankel_eq_atomic]
  exact atomicHankel_energy nodes
    (fun a => weights a * nodes a ^ shift) v

/-- The shifted quadratic form is nonnegative even when the atoms are
repeated; strictness is a separate support-nondegeneracy question. -/
theorem shiftedAtomicHankel_nonnegative
    (nodes weights : Fin n → ℝ) (shift : ℕ)
    (hw : ∀ a, 0 ≤ weights a)
    (hn : ∀ a, 0 ≤ nodes a) (v : Fin n → ℝ) :
    0 ≤ ∑ i : Fin n, ∑ j : Fin n,
      v i * shiftedAtomicHankel nodes weights shift i j * v j := by
  rw [shiftedAtomicHankel_eq_atomic]
  exact atomicHankel_nonnegative nodes
    (fun a => weights a * nodes a ^ shift)
    (fun a => mul_nonneg (hw a) (pow_nonneg (hn a) shift)) v

/-- A single detecting atom makes the shifted quadratic form strictly
positive when the nodes and masses are all positive. -/
theorem shiftedAtomicHankel_positive_of_detected
    (nodes weights : Fin n → ℝ) (shift : ℕ)
    (hw : ∀ a, 0 < weights a)
    (hn : ∀ a, 0 < nodes a)
    (v : Fin n → ℝ)
    (hdetect : ∃ a : Fin n,
      (∑ i : Fin n, v i * nodes a ^ (i : ℕ)) ≠ 0) :
    0 < ∑ i : Fin n, ∑ j : Fin n,
      v i * shiftedAtomicHankel nodes weights shift i j * v j := by
  rw [shiftedAtomicHankel_eq_atomic]
  exact atomicHankel_positive_of_detected nodes
    (fun a => weights a * nodes a ^ shift)
    (fun a => mul_pos (hw a) (pow_pos (hn a) shift)) v hdetect

end PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant

#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_eq_atomic
#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_det
#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_det_pos
#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_energy
#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_nonnegative
#print axioms PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant.shiftedAtomicHankel_positive_of_detected
