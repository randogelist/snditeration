import PaperProofs.S05_Theorem_5_2_DualSlope
import Mathlib.Tactic

/-!
# Theorem 5.2: finite real Gram energy, without Krein or analytic assumptions

All dimensions, actual rational coefficient rows. The energy identity is the
basic algebra needed to deduce M_A >= 0 (and M_A > 0 after a proof of full
row rank). It does not establish the infinite signed Gram-cone construction.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_DualEnergy
open ManuscriptChain

variable {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ)

/-- The real Gram of the same rows used in Theorem 5.2. -/
def realCoefficientGram : Matrix (Fin h) (Fin h) ℝ :=
  fun i j => ∑ r : Fin (K + 1), (c i r : ℝ) * (c j r : ℝ)

/-- Gram quadratic form equals a sum of squares, in every finite dimension. -/
theorem realCoefficientGram_energy (v : Fin h → ℝ) :
    Extensions.qform (realCoefficientGram c) v =
      ∑ r : Fin (K + 1),
        (∑ i : Fin h, v i * (c i r : ℝ)) ^ 2 := by
  classical
  unfold Extensions.qform realCoefficientGram
  calc
    (∑ i : Fin h, ∑ j : Fin h,
        v i * (∑ r : Fin (K + 1), (c i r : ℝ) * (c j r : ℝ)) * v j) =
        ∑ i : Fin h, ∑ j : Fin h, ∑ r : Fin (K + 1),
          (v i * (c i r : ℝ)) * (v j * (c j r : ℝ)) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          rw [Finset.mul_sum, Finset.sum_mul]
          apply Finset.sum_congr rfl
          intro r _
          ring
    _ = ∑ i : Fin h, ∑ r : Fin (K + 1), ∑ j : Fin h,
          (v i * (c i r : ℝ)) * (v j * (c j r : ℝ)) := by
          apply Finset.sum_congr rfl
          intro i _
          exact Finset.sum_comm
    _ = ∑ r : Fin (K + 1), ∑ i : Fin h, ∑ j : Fin h,
          (v i * (c i r : ℝ)) * (v j * (c j r : ℝ)) := by
          exact Finset.sum_comm
    _ = ∑ r : Fin (K + 1),
          (∑ i : Fin h, v i * (c i r : ℝ)) ^ 2 := by
          apply Finset.sum_congr rfl
          intro r _
          simp only [pow_two, Finset.sum_mul, Finset.mul_sum]

/-- Finite Gram positivity is unconditional for every coefficient family. -/
theorem realCoefficientGram_nonnegative (v : Fin h → ℝ) :
    0 ≤ Extensions.qform (realCoefficientGram c) v := by
  rw [realCoefficientGram_energy]
  exact Finset.sum_nonneg (fun r _ => sq_nonneg _)


/-- Full row rank, stated as injectivity of the real coefficient evaluation map.
    For the manuscript this is precisely linear independence of the chosen
    rational polynomial rows, not a new analytic or Diophantine witness. -/
def FullRowRank : Prop :=
  ∀ v : Fin h → ℝ,
    (∀ r : Fin (K + 1), ∑ i : Fin h, v i * (c i r : ℝ) = 0) → v = 0

/-- Strict positivity of C Cᵀ when the coefficient rows have full rank. -/
theorem realCoefficientGram_strictly_positive (hc : FullRowRank c) :
    Extensions.PositiveQForm (realCoefficientGram c) := by
  intro v hv
  have hex : ∃ r : Fin (K + 1),
      ∑ i : Fin h, v i * (c i r : ℝ) ≠ 0 := by
    by_contra h
    push_neg at h
    exact hv (hc v h)
  obtain ⟨r, hr⟩ := hex
  rw [realCoefficientGram_energy]
  have hpos : 0 < (∑ i : Fin h, v i * (c i r : ℝ)) ^ 2 :=
    sq_pos_of_ne_zero hr
  have hle :
      (∑ i : Fin h, v i * (c i r : ℝ)) ^ 2 ≤
        ∑ t : Fin (K + 1),
          (∑ i : Fin h, v i * (c i t : ℝ)) ^ 2 :=
    Finset.single_le_sum (fun t _ => sq_nonneg _) (Finset.mem_univ r)
  exact lt_of_lt_of_le hpos hle

/-- The rational-coefficient Gram becomes a symmetric real matrix. -/
theorem realCoefficientGram_symmetric :
    (realCoefficientGram c).IsSymm := by
  change (realCoefficientGram c).transpose = realCoefficientGram c
  ext i j
  simp only [Matrix.transpose_apply, realCoefficientGram]
  exact Finset.sum_congr rfl (fun r _ => mul_comm _ _)

/-- The positive-derivative part of Theorem 5.2(1) for any full-row-rank C. -/
theorem realCoefficientGram_posDef (hc : FullRowRank c) :
    (realCoefficientGram c).PosDef :=
  Extensions.posDef_of_symmetric_positive_qform _
    (realCoefficientGram_symmetric c)
    (realCoefficientGram_strictly_positive c hc)

end PaperProofs.S05_Theorem_5_2_DualEnergy

#print axioms PaperProofs.S05_Theorem_5_2_DualEnergy.realCoefficientGram_energy
#print axioms PaperProofs.S05_Theorem_5_2_DualEnergy.realCoefficientGram_nonnegative

#print axioms PaperProofs.S05_Theorem_5_2_DualEnergy.realCoefficientGram_strictly_positive
#print axioms PaperProofs.S05_Theorem_5_2_DualEnergy.realCoefficientGram_posDef
