import PaperProofs.S03_Theorem_3_3_AlternatingPoleSign
import Zetahyperbolic.Section2Checked
import Mathlib.Tactic

/-!
# Theorem 3.3 — exact signed inertia normal form of the actual pencil

The derivative of the Section 2 rational Hankel pencil, not a fabricated
matrix, is congruent to its Lagrange diagonal. Combining its proven
Vandermonde invertibility with the newly proven residue-sign formula
gives a concrete, dimension-uniform signed normal form.

This is the arithmetic/inertia *input* to Sylvester's law. The additional
analytic strict-total-positivity claim for the continuous measure is not
asserted or assumed here.
-/

noncomputable section
open Matrix
namespace PaperProofs.S03_Theorem_3_3_InertiaNormalForm

/-- Unconditional congruence of the ACTUAL derivative matrix to its
residue diagonal, in every finite Hankel dimension. -/
theorem actual_derivative_congruent_diagonal
    (p : Zetahyperbolic.HankelParams) (k : ℕ) :
    (Zetahyperbolic.V_pole p)⁻¹ * Zetahyperbolic.M_deriv p k *
        ((Zetahyperbolic.V_pole p)⁻¹).transpose =
      Matrix.diagonal (Zetahyperbolic.gammaWeight p k) := by
  let V := Zetahyperbolic.V_pole p
  have hunit : IsUnit V.det :=
    isUnit_iff_ne_zero.mpr (Zetahyperbolic.V_pole_det_ne_zero p)
  have hright : V.transpose * (V⁻¹).transpose = 1 := by
    rw [← Matrix.transpose_mul, Matrix.nonsing_inv_mul V hunit,
      Matrix.transpose_one]
  rw [Zetahyperbolic.M_deriv_factorization]
  change V⁻¹ * (V * Matrix.diagonal (Zetahyperbolic.gammaWeight p k) *
      V.transpose) * (V⁻¹).transpose = _
  calc
    V⁻¹ * (V * Matrix.diagonal (Zetahyperbolic.gammaWeight p k) *
        V.transpose) * (V⁻¹).transpose =
      (V⁻¹ * V) * Matrix.diagonal (Zetahyperbolic.gammaWeight p k) *
        (V.transpose * (V⁻¹).transpose) := by
          simp only [Matrix.mul_assoc]
    _ = Matrix.diagonal (Zetahyperbolic.gammaWeight p k) := by
      rw [Matrix.nonsing_inv_mul V hunit, hright]
      simp

/-- The diagonal entry of the normalized original derivative has the
strict sign stipulated by Theorem 3.3(3), at every pole. -/
theorem signed_inertia_normal_form_entry
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (Zetahyperbolic.poleNat p i - 1) *
      ((Zetahyperbolic.V_pole p)⁻¹ * Zetahyperbolic.M_deriv p k *
        ((Zetahyperbolic.V_pole p)⁻¹).transpose) i i := by
  rw [actual_derivative_congruent_diagonal]
  simpa using
    (PaperProofs.S03_Theorem_3_3_AlternatingPoleSign.gammaWeight_alternating p k i)

/-- The signed normal form is nonsingular. This is not inferred from
an assumed spectrum; it follows from the derivative determinant proof. -/
theorem derivative_nonsingular_from_pole_data
    (p : Zetahyperbolic.HankelParams) (k : ℕ) :
    (Zetahyperbolic.M_deriv p k).det ≠ 0 :=
  Zetahyperbolic.M_deriv_det_ne_zero p k

end PaperProofs.S03_Theorem_3_3_InertiaNormalForm

#print axioms PaperProofs.S03_Theorem_3_3_InertiaNormalForm.actual_derivative_congruent_diagonal
#print axioms PaperProofs.S03_Theorem_3_3_InertiaNormalForm.signed_inertia_normal_form_entry
#print axioms PaperProofs.S03_Theorem_3_3_InertiaNormalForm.derivative_nonsingular_from_pole_data
