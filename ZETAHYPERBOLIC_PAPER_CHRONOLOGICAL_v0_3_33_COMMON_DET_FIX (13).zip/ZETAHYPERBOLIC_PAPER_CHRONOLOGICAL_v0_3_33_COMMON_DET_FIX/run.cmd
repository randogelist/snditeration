@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 exit /b 2
set "PROJECT=%CD%"
set "LOG=%PROJECT%\PAPER_CHRONOLOGY_BUILD.log"
set "LEAN_JOBS=16"
set "LEAN_NUM_THREADS=16"
set "LEAN_THREADS=16"
set "LEAN_ABORT_ON_PANIC=1"
set "FROZEN_HITS=0"
set "COMPILED_NOW=0"
set "PARAGRAPH_CHECKPOINTS_REACHED=0"
set "PARAGRAPH_BLUEPRINTS_REACHED=0"
set "MODE=INCREMENTAL"
set "FORCE=0"
if /I "%~1"=="full" set "FORCE=1"
if /I "%~1"=="full" set "MODE=FULL"
rem Recover is EXPLICIT: isolate when Lean/Lake is active;
rem never delete a potentially active shared cache or its proof artifacts.
set "RECOVER=0"
if /I "%~1"=="recover" set "RECOVER=1"
if not defined FASTCORE_CACHE_ROOT set "FASTCORE_CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if not defined FASTCORE_PROJECT_CACHE set "FASTCORE_PROJECT_CACHE=%USERPROFILE%\lean-native\zetahyperbolic_paper_chronological_fastcore"
set "CACHE_ROOT=%FASTCORE_CACHE_ROOT%"
set "BUILD_CACHE=%FASTCORE_PROJECT_CACHE%"
set "PRIMARY_BUILD_CACHE=%BUILD_CACHE%"
set "CACHE_ISOLATED=0"
set "OUT_ROOT=%BUILD_CACHE%\olean"
set "STAMP_ROOT=%BUILD_CACHE%\stamps"
set "DIRTY_ROOT=%BUILD_CACHE%\dirty"
set "CACHE_KEY=%BUILD_CACHE%\cache_key"
set "LOCKDIR=%BUILD_CACHE%\single_writer_lock"
set "LOCK_ACQUIRED=0"
rem Single writer for the selected cache.  With explicit recover:
rem   - reuse PRIMARY only when its orphan lock can be safely removed;
rem   - when another Lean/Lake is active, do NOT touch the primary lock;
rem     compile into a separate, persistently named isolated cache instead.
rem The isolated cache NEVER reads/writes the locked project's oleans/stamps.
if "%RECOVER%"=="1" if exist "%LOCKDIR%" (
  call :RECOVER_OR_ISOLATE
  if errorlevel 1 exit /b 3
)
rem Acquire cache writer ownership BEFORE opening the shared log file.
if not exist "%BUILD_CACHE%" mkdir "%BUILD_CACHE%"
2>nul mkdir "%LOCKDIR%"
if errorlevel 1 (
  echo ERROR=CACHE_BUSY_OTHER_BUILD_OR_STALE_LOCK
  echo LOCKDIR=%LOCKDIR%
  exit /b 3
)
set "LOCK_ACQUIRED=1"

>"%LOG%" echo BUILD=START
>>"%LOG%" echo PACKAGE=ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_33_COMMON_DET_FIX
>>"%LOG%" echo STARTUP=FASTCORE
>>"%LOG%" echo LAKE=NOT_USED
>>"%LOG%" echo CACHE_ISOLATED=%CACHE_ISOLATED%
>>"%LOG%" echo PRIMARY_CACHE=%PRIMARY_BUILD_CACHE%
>>"%LOG%" echo SELECTED_CACHE=%BUILD_CACHE%
>>"%LOG%" echo NETWORK=NOT_USED
>>"%LOG%" echo PYTHON=NOT_USED
>>"%LOG%" echo POWERSHELL=NOT_USED
>>"%LOG%" echo WSL=NOT_USED
>>"%LOG%" echo LEAN_JOBS=%LEAN_JOBS%
>>"%LOG%" echo PAPER_MODULES=157
>>"%LOG%" echo FILE_TREE=PaperChronology
>>"%LOG%" echo CACHE_POLICY=FROZEN_PASS_ONLY_WITH_SOURCE_STAMP_AND_OLEAN
>>"%LOG%" echo FAILED_REBUILD=INVALIDATES_STAMP_BEFORE_COMPILE

echo ================================================
echo ZETAHYPERBOLIC - NATIVE FASTCORE CHRONOLOGY
echo PACKAGE=ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_33_COMMON_DET_FIX
echo PAPER_MODULES=157
echo ================================================
echo LEAN_JOBS=%LEAN_JOBS%
echo CACHE_ISOLATED=%CACHE_ISOLATED%
echo SELECTED_CACHE=%BUILD_CACHE%
echo LAKE=NOT_USED
echo NETWORK=NOT_USED
echo FROZEN_POLICY=SKIP_PREVIOUSLY_CHECKED_UNCHANGED_SOURCES

if not exist "FASTCORE_BUILD_ORDER.txt" goto :NO_ORDER
if not exist "PARAGRAPH_CHECKPOINTS.tsv" goto :NO_ORDER
if not exist "CHRONOLOGY.txt" goto :NO_ORDER
if not exist "lean-toolchain" goto :NO_TOOLCHAIN
if not exist "lake-manifest.json" goto :NO_TOOLCHAIN

set "LEAN_EXE=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"
if not exist "%LEAN_EXE%" (
  set "LEAN_EXE=lean.exe"
  where lean.exe >nul 2>nul
  if errorlevel 1 goto :NO_LEAN
)
"%LEAN_EXE%" --version >>"%LOG%" 2>&1
if errorlevel 1 goto :NO_LEAN
findstr /C:"4.33.0" "%LOG%" >nul 2>nul
if errorlevel 1 goto :WRONG_VERSION

set "LEAN_PREFIX="
for /f "delims=" %%P in ('"%LEAN_EXE%" --print-prefix') do set "LEAN_PREFIX=%%P"
if not defined LEAN_PREFIX goto :NO_PREFIX
if not exist "%LEAN_PREFIX%\lib\lean" goto :NO_PREFIX
if not exist "%CACHE_ROOT%" goto :NO_MATHLIB

if not exist "%BUILD_CACHE%" mkdir "%BUILD_CACHE%"
if not exist "%OUT_ROOT%" mkdir "%OUT_ROOT%"
if not exist "%STAMP_ROOT%" mkdir "%STAMP_ROOT%"
if not exist "%DIRTY_ROOT%" mkdir "%DIRTY_ROOT%"
if not exist "%CACHE_KEY%" mkdir "%CACHE_KEY%"

rem On a changed toolchain/manifest, invalidate ALL old success stamps ONCE.
rem Publish the new environment key before processing sources: a failed run
rem must not force a full rebuild of modules it has already passed.
set "ENV_STALE=0"
if exist "%CACHE_KEY%\lean-toolchain" (
  fc /b "lean-toolchain" "%CACHE_KEY%\lean-toolchain" >nul 2>nul
  if errorlevel 1 set "ENV_STALE=1"
) else (
  set "ENV_STALE=1"
)
if exist "%CACHE_KEY%\lake-manifest.json" (
  fc /b "lake-manifest.json" "%CACHE_KEY%\lake-manifest.json" >nul 2>nul
  if errorlevel 1 set "ENV_STALE=1"
) else (
  set "ENV_STALE=1"
)
if "%ENV_STALE%"=="1" (
  if exist "%STAMP_ROOT%" rd /s /q "%STAMP_ROOT%"
  if exist "%STAMP_ROOT%" goto :STAMP_INVALIDATION_FAILED
  mkdir "%STAMP_ROOT%"
  if errorlevel 1 goto :STAMP_INVALIDATION_FAILED
  copy /y "lean-toolchain" "%CACHE_KEY%\lean-toolchain" >nul
  if errorlevel 1 goto :STAMP_INVALIDATION_FAILED
  copy /y "lake-manifest.json" "%CACHE_KEY%\lake-manifest.json" >nul
  if errorlevel 1 goto :STAMP_INVALIDATION_FAILED
  set "MODE=ENVIRONMENT_CHANGED"
)
if "%FORCE%"=="1" set "MODE=FULL"

rem CRLF batch file: essential for CALL :ADD_CACHE label visibility in CMD.exe.
rem Local project .oleans take precedence over older cached project versions.
rem All Mathlib and dependency imports come from the existing native .olean cache.
set "LEAN_PATH=%LEAN_PREFIX%\lib\lean;%OUT_ROOT%"
set "PACKAGE_ROOT_COUNT=0"
set "MATHLIB_READY=0"
set "BATTERIES_READY=0"
call :ADD_CACHE "%CACHE_ROOT%\.lake\build\lib\lean"
call :ADD_CACHE "%CACHE_ROOT%\.lake\packages\mathlib\.lake\build\lib\lean"
call :ADD_CACHE "%CACHE_ROOT%\.lake\packages\batteries\.lake\build\lib\lean"
for /D %%P in ("%CACHE_ROOT%\.lake\packages\*") do call :ADD_CACHE "%%~fP\.lake\build\lib\lean"
call :ADD_CACHE "%CACHE_ROOT%\build\lib\lean"
if not "%MATHLIB_READY%"=="1" goto :NO_MATHLIB
if not "%BATTERIES_READY%"=="1" goto :NO_BATTERIES

set "IMPORTGRAPH_READY=0"
if exist "%CACHE_ROOT%\.lake\packages\importGraph\.lake\build\lib\lean" set "IMPORTGRAPH_READY=1"

echo NATIVE_LEAN_PATH=READY
echo MATHLIB_CACHE=READY
echo BATTERIES_CACHE=READY
echo IMPORTGRAPH_CACHE=%IMPORTGRAPH_READY%
echo MODE=%MODE%
echo LOCAL_OLEAN_CACHE=%BUILD_CACHE%
echo LEAN_THREADS=%LEAN_JOBS%
>>"%LOG%" echo NATIVE_LEAN_PATH=READY
>>"%LOG%" echo MATHLIB_CACHE=READY
>>"%LOG%" echo BATTERIES_CACHE=READY
>>"%LOG%" echo IMPORTGRAPH_CACHE=%IMPORTGRAPH_READY%
>>"%LOG%" echo MODE=%MODE%
>>"%LOG%" echo LOCAL_OLEAN_CACHE=%BUILD_CACHE%
>>"%LOG%" echo LEAN_PATH_PACKAGE_ROOT_COUNT=%PACKAGE_ROOT_COUNT%

rem Source order is dependency-sorted while keeping all 48 PDF milestones in order.
for /f "usebackq eol=# tokens=1,* delims=|" %%M in ("FASTCORE_BUILD_ORDER.txt") do (
  call :COMPILE "%%M" "%%N"
  if errorlevel 1 goto :FAILED
)

rem Trust audit: any #print axioms output containing sorryAx is a hard failure.
findstr /C:"sorryAx" "%LOG%" >nul 2>nul
if not errorlevel 1 goto :SORRY_AX_FOUND
>>"%LOG%" echo AXIOM_AUDIT=PASS
echo AXIOM_AUDIT=PASS

rem Only a complete successful run clears pending downstream-rebuild markers.
if exist "%DIRTY_ROOT%" rd /s /q "%DIRTY_ROOT%"
mkdir "%DIRTY_ROOT%"
if errorlevel 1 goto :FAILED
>>"%LOG%" echo FROZEN_PASSES=%FROZEN_HITS%
>>"%LOG%" echo NEWLY_COMPILED=%COMPILED_NOW%
>>"%LOG%" echo PARAGRAPH_CHECKPOINTS_REACHED=%PARAGRAPH_CHECKPOINTS_REACHED%
>>"%LOG%" echo PARAGRAPH_BLUEPRINTS_REACHED=%PARAGRAPH_BLUEPRINTS_REACHED%
>>"%LOG%" echo BUILD=PASS
if "%LOCK_ACQUIRED%"=="1" rd "%LOCKDIR%" >nul 2>nul
echo.
echo FROZEN_PASSES=%FROZEN_HITS%
echo NEWLY_COMPILED=%COMPILED_NOW%
echo PARAGRAPH_CHECKPOINTS_REACHED=%PARAGRAPH_CHECKPOINTS_REACHED%
echo PARAGRAPH_BLUEPRINTS_REACHED=%PARAGRAPH_BLUEPRINTS_REACHED%
echo BUILD=PASS
echo LOG=%LOG%
exit /b 0


:RECOVER_OR_ISOLATE
rem NEVER remove a lock while any Lean or Lake process may own it.
rem (cmd tasklist does not expose command lines or reliable lock ownership.)
rem If the legacy lock is orphaned and EMPTY, recover on an explicit request.
rem Otherwise enter a completely isolated output/cache namespace.
if not exist "%LOCKDIR%" exit /b 0
if not defined TEMP goto :ISOLATE_CACHE
set "SCAN=%TEMP%\zeta_lock_scan_%RANDOM%_%RANDOM%.txt"
tasklist /FO CSV /NH >"%SCAN%" 2>nul
if errorlevel 1 (
  if exist "%SCAN%" del /q "%SCAN%" >nul 2>nul
  goto :ISOLATE_CACHE
)
findstr /I /C:"lean.exe" /C:"lake.exe" "%SCAN%" >nul 2>nul
if not errorlevel 1 (
  del /q "%SCAN%" >nul 2>nul
  goto :ISOLATE_CACHE
)
del /q "%SCAN%" >nul 2>nul
rem No Lean/Lake was enumerated. The legacy lock may still belong to a
rem CMD process between jobs; only remove an EMPTY lock directory, never
rem delete files from it. The caller opted in by passing recover.
rd "%LOCKDIR%" >nul 2>nul
if not exist "%LOCKDIR%" (
  echo CACHE_RECOVERY=EMPTY_ORPHAN_LOCK_CLEARED
  exit /b 0
)
:ISOLATE_CACHE
rem The primary lock and all its certificates are left COMPLETELY intact.
rem Use this persistent alternate namespace across retries/releases until
rem the primary writer is no longer active. The only safe alternative when
rem its ownership is unknown is a one-time isolated build, not cache theft.
set "CACHE_ISOLATED=1"
set "BUILD_CACHE=%PRIMARY_BUILD_CACHE%_isolated_326"
set "OUT_ROOT=%BUILD_CACHE%\olean"
set "STAMP_ROOT=%BUILD_CACHE%\stamps"
set "DIRTY_ROOT=%BUILD_CACHE%\dirty"
set "CACHE_KEY=%BUILD_CACHE%\cache_key"
set "LOCKDIR=%BUILD_CACHE%\single_writer_lock"
set "MODE=ISOLATED_SAFE_RECOVERY"
echo CACHE_RECOVERY=ISOLATED_SAFE_CACHE
 echo PRIMARY_CACHE_LOCK_PRESERVED=%PRIMARY_BUILD_CACHE%\single_writer_lock
 echo ISOLATED_CACHE=%BUILD_CACHE%
rem If another writer is already using our isolated namespace, refuse.
if exist "%LOCKDIR%" (
  echo ERROR=ISOLATED_CACHE_ALREADY_LOCKED
  echo LOCKDIR=%LOCKDIR%
  exit /b 1
)
exit /b 0


:REPORT_PARAGRAPHS
rem Emit a passage checkpoint only AFTER its exact associated Lean module
rem produced a valid OLEAN and success stamp, or a frozen cache hit.
rem Merely indexed/schematic targets are not counted as integrated.
for /f "usebackq eol=# tokens=1-5 delims=|" %%A in ("%PROJECT%\PARAGRAPH_CHECKPOINTS.tsv") do (
  if /I "%%A"=="%~1" (
    if /I "%%E"=="SCAFFOLD" (
      echo PARAGRAPH_BLUEPRINT=%%B STAGE=SCHEMATIC PAGE=%%C
      >>"%LOG%" echo PARAGRAPH_BLUEPRINT=%%B STAGE=SCHEMATIC PAGE=%%C
      set /a PARAGRAPH_BLUEPRINTS_REACHED+=1 >nul
    ) else if /I "%%E"=="CONJECTURE" (
      echo PARAGRAPH_BLUEPRINT=%%B STAGE=CONJECTURE PAGE=%%C
      >>"%LOG%" echo PARAGRAPH_BLUEPRINT=%%B STAGE=CONJECTURE PAGE=%%C
      set /a PARAGRAPH_BLUEPRINTS_REACHED+=1 >nul
    ) else (
      echo PARAGRAPH_CHECKPOINT=INTEGRATED ID=%%B STAGE=%%E PAGE=%%C
      >>"%LOG%" echo PARAGRAPH_CHECKPOINT=INTEGRATED ID=%%B STAGE=%%E PAGE=%%C MODULE=%%A
      set /a PARAGRAPH_CHECKPOINTS_REACHED+=1 >nul
    )
  )
)
exit /b 0

:ADD_CACHE
if not exist "%~1" exit /b 0
set "LEAN_PATH=%LEAN_PATH%;%~1"
set /a PACKAGE_ROOT_COUNT+=1 >nul
if exist "%~1\Mathlib.olean" set "MATHLIB_READY=1"
if exist "%~1\Mathlib\Tactic.olean" set "MATHLIB_READY=1"
if exist "%~1\Mathlib\NumberTheory\LSeries\RiemannZeta.olean" set "MATHLIB_READY=1"
if exist "%~1\Batteries.olean" set "BATTERIES_READY=1"
if exist "%~1\Batteries\Data\List\Basic.olean" set "BATTERIES_READY=1"
exit /b 0

:COMPILE
set "MOD=%~1"
set "DEPENDS=%~2"
set "MOD_REL=%MOD:.=\%"
set "SRC=%PROJECT%\%MOD_REL%.lean"
set "OUT=%OUT_ROOT%\%MOD_REL%.olean"
set "STAMP=%STAMP_ROOT%\%MOD_REL%.lean"
set "DIRTY=0"
if not exist "%SRC%" (
  echo ERROR=MISSING_SOURCE %MOD%
  >>"%LOG%" echo ERROR=MISSING_SOURCE %MOD%
  exit /b 1
)
rem A module is frozen only if its matching .olean AND byte-identical
rem successfully compiled source stamp both exist. The manifest and Lean
rem toolchain are checked before entering this subroutine.
if "%FORCE%"=="1" set "DIRTY=1"
if not exist "%OUT%" set "DIRTY=1"
if not exist "%STAMP%" set "DIRTY=1"
if "%DIRTY%"=="0" (
  fc /b "%SRC%" "%STAMP%" >nul 2>nul
  if errorlevel 1 set "DIRTY=1"
)
rem Dependency markers persist across interrupted or failed runs. Each
rem direct local import is recorded in FASTCORE_BUILD_ORDER.txt.
for %%D in (%DEPENDS%) do (
  if exist "%DIRTY_ROOT%\%%D.flag" set "DIRTY=1"
)
if "%DIRTY%"=="0" (
  set /a FROZEN_HITS+=1 >nul
  echo FROZEN_PASS=%MOD%
  >>"%LOG%" echo FROZEN_PASS=%MOD%
  call :REPORT_PARAGRAPHS "%MOD%"
  exit /b 0
)
for %%F in ("%OUT%") do if not exist "%%~dpF" mkdir "%%~dpF"
for %%F in ("%STAMP%") do if not exist "%%~dpF" mkdir "%%~dpF"
rem Crash safety: publish the changed-module marker BEFORE Lean runs;
rem delete any previously successful stamp and stale compiled artifact.
rem If Lean or CMD aborts, downstream dependents remain invalidated on retry.
>"%DIRTY_ROOT%\%MOD%.flag" echo REBUILD_PENDING
if errorlevel 1 (
  echo ERROR=DIRTY_FLAG_FAILED %MOD%
  >>"%LOG%" echo ERROR=DIRTY_FLAG_FAILED %MOD%
  exit /b 1
)
if exist "%STAMP%" del /q "%STAMP%" >nul 2>nul
if exist "%OUT%" del /q "%OUT%" >nul 2>nul
if exist "%OUT%" (
  echo ERROR=STALE_OLEAN_COULD_NOT_BE_DELETED %MOD%
  >>"%LOG%" echo ERROR=STALE_OLEAN_COULD_NOT_BE_DELETED %MOD%
  exit /b 1
)
echo CHECK=%MOD%
>>"%LOG%" echo CHECK=%MOD%
"%LEAN_EXE%" -j %LEAN_JOBS% -o "%OUT%" "%SRC%" >>"%LOG%" 2>&1
if errorlevel 1 (
  if exist "%OUT%" del /q "%OUT%" >nul 2>nul
  echo FAILED_MODULE=%MOD%
  >>"%LOG%" echo FAILED_MODULE=%MOD%
  echo ==== FIRST COMPILER ERRORS ====
  findstr /N /C:": error:" /C:"error(lean." /C:"error:" "%LOG%"
  echo ==== END COMPILER ERRORS ====
  exit /b 1
)
if not exist "%OUT%" (
  echo ERROR=OLEAN_NOT_WRITTEN %MOD%
  >>"%LOG%" echo ERROR=OLEAN_NOT_WRITTEN %MOD%
  exit /b 1
)
copy /y "%SRC%" "%STAMP%" >nul
if errorlevel 1 (
  echo ERROR=STAMP_FAILED %MOD%
  >>"%LOG%" echo ERROR=STAMP_FAILED %MOD%
  exit /b 1
)
>"%DIRTY_ROOT%\%MOD%.flag" echo REBUILT_PASS
set /a COMPILED_NOW+=1 >nul
>>"%LOG%" echo PASS=%MOD%
echo PASS=%MOD%
call :REPORT_PARAGRAPHS "%MOD%"
exit /b 0

:: Cache stamp purge must succeed before using any existing .olean.
:STAMP_INVALIDATION_FAILED
echo ERROR=ENVIRONMENT_STAMP_INVALIDATION_FAILED
>>"%LOG%" echo ERROR=ENVIRONMENT_STAMP_INVALIDATION_FAILED
goto :FAILED
:NO_ORDER
echo ERROR=MISSING_BUILD_ORDER_OR_CHRONOLOGY
>>"%LOG%" echo ERROR=MISSING_BUILD_ORDER_OR_CHRONOLOGY
goto :FAILED
:NO_TOOLCHAIN
echo ERROR=MISSING_LEAN_TOOLCHAIN_OR_MANIFEST
>>"%LOG%" echo ERROR=MISSING_LEAN_TOOLCHAIN_OR_MANIFEST
goto :FAILED
:NO_LEAN
echo ERROR=LEAN_4_33_NOT_FOUND
>>"%LOG%" echo ERROR=LEAN_4_33_NOT_FOUND
goto :FAILED
:WRONG_VERSION
echo ERROR=LEAN_VERSION_NOT_4_33_0
>>"%LOG%" echo ERROR=LEAN_VERSION_NOT_4_33_0
goto :FAILED
:NO_PREFIX
echo ERROR=LEAN_STDLIB_PREFIX_NOT_FOUND
>>"%LOG%" echo ERROR=LEAN_STDLIB_PREFIX_NOT_FOUND
goto :FAILED
:NO_MATHLIB
echo ERROR=MATHLIB_PREBUILT_OLEAN_CACHE_NOT_FOUND
echo CACHE_ROOT=%CACHE_ROOT%
>>"%LOG%" echo ERROR=MATHLIB_PREBUILT_OLEAN_CACHE_NOT_FOUND
>>"%LOG%" echo CACHE_ROOT=%CACHE_ROOT%
goto :FAILED
:NO_BATTERIES
echo ERROR=BATTERIES_PRECOMPILED_OLEAN_CACHE_NOT_FOUND
echo CACHE_ROOT=%CACHE_ROOT%
>>"%LOG%" echo ERROR=BATTERIES_PRECOMPILED_OLEAN_CACHE_NOT_FOUND
>>"%LOG%" echo CACHE_ROOT=%CACHE_ROOT%
goto :FAILED
:SORRY_AX_FOUND
echo ERROR=SORRY_AX_REPORTED_IN_AXIOM_AUDIT
>>"%LOG%" echo ERROR=SORRY_AX_REPORTED_IN_AXIOM_AUDIT
goto :FAILED
:FAILED
if "%LOCK_ACQUIRED%"=="1" rd "%LOCKDIR%" >nul 2>nul
>>"%LOG%" echo BUILD=FAIL
echo BUILD=FAIL
echo LOG=%LOG%
exit /b 1
