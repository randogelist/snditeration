# v0.3.15 — Exact fifth-power Beukers/Krein kernel (native Lean sources)

New additive formal proof sources, not yet compiled by the user's Lean 4.33.0:

1. `S05_Theorem_5_2_ExactFifthKernel`: algebraic fifth-power identity with exact binomial coefficients 1,5,10 and the source paper's normalization 1/720 vs 1/1440; for every geometric mode `m` and all real arguments.
2. `S05_Theorem_5_2_TruncatedKernel`: unconditional all-`M` finite Krein decomposition, exact geometric polynomial remainder `(1-uv)K_M=(1-(uv)^M)(u+v)^5`, and exact rational tail off the pole `uv=1`.
3. `S05_Theorem_5_2_ExactConeEnergy`: arbitrary-dimensional finite positive and negative square energies and their exact one-sided order bounds.

These are the polynomial and finite-series parts of Theorem 5.2(2), not yet the analytic infinite-series interchange, complete Krein-space decomposition, or polynomial cone-construction of Theorem 5.2(3). No assumption has been added; there are no `sorry`, `admit` or custom `axiom` declarations in the three new modules.

Cache: all previously passed Lean sources are byte-for-byte unchanged. Exactly one top-level `run.cmd`, no local Lean compilation, offline pinned Lean 4.33 direct FASTCORE startup. `run.cmd full` remains available for user-triggered full rebuild.
