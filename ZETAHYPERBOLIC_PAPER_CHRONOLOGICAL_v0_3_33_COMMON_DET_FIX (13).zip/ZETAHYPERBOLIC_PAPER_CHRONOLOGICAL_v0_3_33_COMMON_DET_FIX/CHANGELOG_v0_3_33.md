# v0.3.33 — Common matrix determinant typing repair

## Native compiler checkpoint

- Last user log: `PaperBlueprint.Common` failed with `lean.invalidField` at lines 43 and 50.
- Cause: the elaborator interpreted `(fun i j => ... : Matrix ...).det` as a function projection and looked for `Function.det`.
- Fix: both `mixedMinor` and `leadingMinor` now use `Matrix.det (fun i j : Fin r => ...)` with the matrix type supplied by the function's expected argument.
- No other Lean sources have been modified; the frozen proof cache remains valid for unchanged modules.
- No Lean compilation was performed while preparing this package.
- The new module still requires the user's native Lean 4.33.0 verification.

## Closure counts are unchanged

- The 47-item manuscript checklist continues to record 6 complete, 14 partial, 2 compiler-pending full closures, 1 witness-conditional, 5 correction-required, 18 open, 1 conjecture.
- The 212 paragraph entries are an *integration registry* and are NOT 212 proved paragraphs.
- This release does not promote any mathematical theorem to complete.

## Strict boundary

An arbitrary `Prop` field or an uninhabited structure of hypotheses is a specification, never proof of the specified theorem. A compiler-PASS for the blueprint checks its well-typed declarations, not their truth. Paragraph `INTEGRATED` means the mapped module has passed; it does not imply theorem-level closure.
