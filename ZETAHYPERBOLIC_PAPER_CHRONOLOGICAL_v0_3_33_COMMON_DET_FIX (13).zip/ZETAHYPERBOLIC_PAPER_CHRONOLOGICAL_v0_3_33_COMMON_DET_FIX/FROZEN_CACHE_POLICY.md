# FROZEN CACHE POLICY — Lean 4.33.0 native

Only the single top-level `run.cmd` is executable. No Lake, internet,
PowerShell, Python, WSL or local compilation is part of this package run.

1. The cached output must be a real `.olean` emitted on a successful run.
2. The last passing source copy must exactly match the current `.lean` bytes.
3. The pinned toolchain and Mathlib manifest must match the retained build key.
4. Every source-local import is listed in the dependency-sorted build graph;
   a changed prerequisite invalidates each dependent even if it was unchanged.
5. On any required compile, a persistent dirty flag is written BEFORE Lean starts;
   the success stamp and `.olean` are removed BEFORE Lean starts.
6. A failed/interrupted compilation preserves the dirty markers, and does
   not mark a module passed. All markers clear only after the entire run passes.
7. A fresh extracted ZIP reuses the same `%FASTCORE_PROJECT_CACHE%` path as
   v0.3.2 and v0.3.3, unless you explicitly override that environment variable.
8. `run.cmd full` is available for explicit complete rebuilding.

**Observed earlier user log:** 9 prior cache hits in a PaperOrder-based build,
followed by a missing theorem identifier at item 10. That log does NOT
certify the present PaperChronology modules. This package will only reuse
previously checked `.olean` files when the names, source stamps, toolchain
and dependencies match.

**Proof status:** Theorem 3.3 partial, current additions not compiler-tested.
The package is not presented as a proof of every PDF theorem.

### v0.3.5

The original Theorem 2.5 proof file is byte-for-byte unchanged. Only the new `PaperOrder` compatibility module and the revised `PaperChronology` wrapper need recompilation, except for downstream dependent modules marked dirty by the cache. The build stops on any failure.
