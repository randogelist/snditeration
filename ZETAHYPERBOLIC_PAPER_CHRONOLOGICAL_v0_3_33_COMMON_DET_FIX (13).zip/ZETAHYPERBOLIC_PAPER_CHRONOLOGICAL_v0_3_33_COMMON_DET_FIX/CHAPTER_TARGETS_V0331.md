# Chapter-by-chapter Lean blueprint -- v0.3.31

Every one of the 47 numbered manuscript items has a Lean target slot. Some Section 6 bridge fields are still schematic and require replacement with actual equality/valuation propositions. This is a blueprint, NOT full formal statement fidelity or 47 formal proofs.

No `sorry`, custom `axiom`, or `opaque` declaration is added by this release. No Lean compilation performed locally.

## Chronological registry (47 items)

| PDF item | Typed Lean goal | Proof status |
|---|---|---|
| `definition_2_1` | `PaperBlueprint.Chapters.Target .definition_2_1` | Existing foundational certificate; verify frozen axiom audit |
| `lemma_2_2` | `PaperBlueprint.Chapters.Target .lemma_2_2` | Existing foundational certificate; verify frozen axiom audit |
| `lemma_2_3` | `PaperBlueprint.Chapters.Target .lemma_2_3` | Existing foundational certificate; verify frozen axiom audit |
| `theorem_2_4` | `PaperBlueprint.Chapters.Target .theorem_2_4` | Existing foundational certificate; verify frozen axiom audit |
| `theorem_2_5` | `PaperBlueprint.Chapters.Target .theorem_2_5` | Existing foundational certificate; verify frozen axiom audit |
| `theorem_3_1` | `PaperBlueprint.Chapters.Target .theorem_3_1` | Existing unconditional core |
| `proposition_3_2` | `PaperBlueprint.Chapters.Target .proposition_3_2` | Open / partial, requires proof |
| `theorem_3_3` | `PaperBlueprint.Chapters.Target .theorem_3_3` | Open / partial, requires proof |
| `theorem_3_4` | `PaperBlueprint.Chapters.Target .theorem_3_4` | Open / partial, requires proof |
| `corollary_3_5_corrected` | `PaperBlueprint.Chapters.Target .corollary_3_5_corrected` | Open / partial, requires proof |
| `corollary_3_6_corrected` | `PaperBlueprint.Chapters.Target .corollary_3_6_corrected` | Open / partial, requires proof |
| `theorem_3_7` | `PaperBlueprint.Chapters.Target .theorem_3_7` | Open / partial, requires proof |
| `theorem_3_8` | `PaperBlueprint.Chapters.Target .theorem_3_8` | Open / partial, requires proof |
| `theorem_3_9` | `PaperBlueprint.Chapters.Target .theorem_3_9` | Open / partial, requires proof |
| `theorem_4_1` | `PaperBlueprint.Chapters.Target .theorem_4_1` | Open / partial, requires proof |
| `proposition_4_2` | `PaperBlueprint.Chapters.Target .proposition_4_2` | Open / partial, requires proof |
| `proposition_4_3` | `PaperBlueprint.Chapters.Target .proposition_4_3` | Open / partial, requires proof |
| `theorem_4_4` | `PaperBlueprint.Chapters.Target .theorem_4_4` | Open / partial, requires proof |
| `theorem_4_5` | `PaperBlueprint.Chapters.Target .theorem_4_5` | Open / partial, requires proof |
| `theorem_4_6` | `PaperBlueprint.Chapters.Target .theorem_4_6` | Open / partial, requires proof |
| `theorem_4_7` | `PaperBlueprint.Chapters.Target .theorem_4_7` | Open / partial, requires proof |
| `proposition_4_8` | `PaperBlueprint.Chapters.Target .proposition_4_8` | Open / partial, requires proof |
| `conjecture_4_11` | `PaperBlueprint.Chapters.Target .conjecture_4_11` | Conjecture, excluded from mandatory closure |
| `theorem_5_1` | `PaperBlueprint.Chapters.Target .theorem_5_1` | Open / partial, requires proof |
| `theorem_5_2` | `PaperBlueprint.Chapters.Target .theorem_5_2` | Open / partial, requires proof |
| `proposition_5_3` | `PaperBlueprint.Chapters.Target .proposition_5_3` | Open / partial, requires proof |
| `theorem_5_4` | `PaperBlueprint.Chapters.Target .theorem_5_4` | Open / partial, requires proof |
| `theorem_5_6` | `PaperBlueprint.Chapters.Target .theorem_5_6` | Open / partial, requires proof |
| `theorem_5_7` | `PaperBlueprint.Chapters.Target .theorem_5_7` | Open / partial, requires proof |
| `theorem_6_1` | `PaperBlueprint.Chapters.Target .theorem_6_1` | Open / partial, requires proof |
| `theorem_6_2` | `PaperBlueprint.Chapters.Target .theorem_6_2` | Open / partial, requires proof |
| `theorem_6_3` | `PaperBlueprint.Chapters.Target .theorem_6_3` | Open / partial, requires proof |
| `theorem_6_4` | `PaperBlueprint.Chapters.Target .theorem_6_4` | Open / partial, requires proof |
| `theorem_6_5` | `PaperBlueprint.Chapters.Target .theorem_6_5` | Open / partial, requires proof |
| `theorem_6_6` | `PaperBlueprint.Chapters.Target .theorem_6_6` | Open / partial, requires proof |
| `theorem_6_7` | `PaperBlueprint.Chapters.Target .theorem_6_7` | Open / partial, requires proof |
| `corollary_6_8` | `PaperBlueprint.Chapters.Target .corollary_6_8` | Open / partial, requires proof |
| `theorem_6_9` | `PaperBlueprint.Chapters.Target .theorem_6_9` | Open / partial, requires proof |
| `theorem_6_10` | `PaperBlueprint.Chapters.Target .theorem_6_10` | Open / partial, requires proof |
| `theorem_6_11` | `PaperBlueprint.Chapters.Target .theorem_6_11` | Open / partial, requires proof |
| `theorem_6_12` | `PaperBlueprint.Chapters.Target .theorem_6_12` | Open / partial, requires proof |
| `theorem_6_13` | `PaperBlueprint.Chapters.Target .theorem_6_13` | Open / partial, requires proof |
| `theorem_6_14` | `PaperBlueprint.Chapters.Target .theorem_6_14` | Open / partial, requires proof |
| `theorem_6_15` | `PaperBlueprint.Chapters.Target .theorem_6_15` | Open / partial, requires proof |
| `theorem_6_16` | `PaperBlueprint.Chapters.Target .theorem_6_16` | Open / partial, requires proof |
| `theorem_6_17` | `PaperBlueprint.Chapters.Target .theorem_6_17` | Open / partial, requires proof |
| `theorem_6_18` | `PaperBlueprint.Chapters.Target .theorem_6_18` | Open / partial, requires proof |

## Semantic boundaries

* §2 contains five previously constructed logical endpoints; these are preserved, not rewritten.
* §3 includes a new explicit positive-measure representation and arbitrary-weight inertia target. Parts 3.5/3.6 target corrected statements because their printed forms require repair.
* §4 keeps the genuine `ℂ_[p]` disk and the exact `K = 30n` rational determinant witness; quantitative convergence, heights and separation remain separate.
* §5 binds the target to the exact two-variable Beukers kernel, infinite signed features, rational polynomial cones, prime integrals, and local determinant valuations.
* §6 enumerates all 18 numbered results. Several earlier S06 structures still hold unbound `Prop` fields: an arbitrary such field is NOT evidence. These must be strengthened to concrete fixed formulas before counting those items as formally specified or proved.
* `BlueprintExists` and `FullPaperTarget` are unproved. A record named `Hypotheses` is a conjunction of open mathematical obligations, not a finite terminating certificate.

## Build fix

* `run.cmd` is written with DOS CRLF line endings. The previous v0.3.30 shipped LF and Windows reported `Das Sprungziel - ADD_CACHE wurde nicht gefunden`.
* Mathlib and Batteries roots are discovered explicitly, and their `.olean` files are required before source compilation.
* Seven new chapter files are scheduled just after the existing `PaperBlueprint.FullPaper` dependency boundary, before incomplete §3.3–§6 proof modules.
* Cached previously compiler-passed modules are reused; `recover` never steals an active writer lock.
* Compilation authority: user native Windows Lean 4.33.0 exclusively.
