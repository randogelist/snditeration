import PaperChronology.S03_Theorem_3_4

/-!
# Corollary 3.5: Stieltjes J-fraction from interlacing roots
PDF pp. 10–11. Status: correction-required.
Prior checked basis / current support: printed one-pole unit-slope denominator inconsistent.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Corollary_3_5

/-- A proved one-dimensional obstruction to the uncorrected J-fraction. -/
theorem unit_slope_is_wrong (a xi : ℝ) :
    ¬ (∀ X : ℝ, 29 / 2 - 12 * X = a + (X - xi)) :=
  PaperSection3Corrections.no_unit_slope_fraction_denominator a xi

-- Open: corrected, normalized J-fraction for the principal-minor sequence.

end PaperChronology.S03_Corollary_3_5
