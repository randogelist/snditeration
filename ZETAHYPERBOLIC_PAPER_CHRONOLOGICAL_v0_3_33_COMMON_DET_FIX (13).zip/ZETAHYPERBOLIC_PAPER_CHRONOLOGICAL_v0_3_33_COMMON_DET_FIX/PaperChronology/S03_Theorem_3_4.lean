import PaperChronology.S03_Theorem_3_3

/-!
# Theorem 3.4: Root interlacing and Dodgson condensation
PDF pp. 9–10. Status: open.
Prior checked basis / current support: no complete principal-minor interlacing proof.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Theorem_3_4

#check ManuscriptChain.Real.pencil
#check ManuscriptChain.Real.delta
-- Open: principal-minor interlacing and the exact Dodgson identity as printed.

end PaperChronology.S03_Theorem_3_4
