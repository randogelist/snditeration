import PaperChronology.S04_Theorem_4_4

/-!
# Theorem 4.5: Irrationality and measure for b*zeta(5)+a*zeta(3)
PDF pp. 18–19. Status: open.
Prior checked basis / current support: mixed-weight primitive normalization and prime valuations pending.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S04_Theorem_4_5

#check ManuscriptChain.Real.zeta_eq_riemannZeta_re
-- Open: the mixed zeta(5)/zeta(3) primitive arithmetic and uniform prime bounds.

end PaperChronology.S04_Theorem_4_5
