import PaperChronology.S04_Proposition_4_3
import PAPER_SINGLE_WITNESS_CHAIN

/-!
# Theorem 4.4: Sharpened spectral bound and effective measure for zeta(5)
PDF pp. 16–18. Status: witness-conditional.
Prior checked basis / current support: PaperSingleWitness.Witness contains all eventual quantitative estimates.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S04_Theorem_4_4

/-- The only explicit conditional input of the terminal quantitative application. -/
abbrev Witness : Prop := PaperSingleWitness.Witness

theorem irrationality (witness : Witness) :
    Irrational (riemannZeta 5).re :=
  PaperSingleWitness.THEOREM_4_4_IRRATIONALITY witness

theorem measure (witness : Witness) :
    ∃ b₀ : ℕ, ∀ (a : ℤ) (b : ℕ),
      0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| :=
  PaperSingleWitness.THEOREM_4_4_MEASURE witness

end PaperChronology.S04_Theorem_4_4
