import PaperChronology.S02_Lemma_2_3
import Theorem_2_4_Canonical_Basis_Invariance

/-!
# Theorem 2.4: Canonical basis invariance
PDF pp. 6. Status: formalized.
Prior checked basis / current support: BasisInvariance.primitive_normalization theorem.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S02_Theorem_2_4

open Polynomial
/-- Determinant covariance under rational basis changes. -/
theorem determinant_covariance {h : ℕ}
    (G : Matrix (Fin h) (Fin h) ℚ[X])
    (A B : Matrix (Fin h) (Fin h) ℚ) :
    Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil G A B) =
      C (Matrix.det A * Matrix.det B) * Matrix.det G :=
  ManuscriptChain.BasisInvariance.det_changeBasisPencil G A B

/-- The paper's *constructed* primitive normalization result, formulated at its
proper chronological stage.  The only premise here is nonvanishing of the
Hankel determinant; Theorem 2.5 proves this premise for the actual pencil.

The stronger unconditional alias `theorem_2_4_constructed_for_manuscript`
is defined only in `Theorem_2_5_Lagrange_Pole_Diagonalization`.  In particular,
it must NOT be referenced here before importing Theorem 2.5. -/
theorem primitive_invariance_if_nonzero
    (p : ManuscriptChain.Real.Parameters)
    (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0)
    (hdelta : ManuscriptChain.Real.delta p ≠ 0) :
    let n₀ := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p) hdelta
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
        (ManuscriptChain.Real.pencil p) A B hA hB).mpr hdelta)
    nAB.polynomial = n₀.polynomial ∨ nAB.polynomial = -n₀.polynomial :=
  ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance
    p A B hA hB hdelta

#check ManuscriptChain.BasisInvariance.theorem_2_4_canonical_basis_invariance
#check ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance
#check Zetahyperbolic.canonical_primitive_content_invariance

end PaperChronology.S02_Theorem_2_4
