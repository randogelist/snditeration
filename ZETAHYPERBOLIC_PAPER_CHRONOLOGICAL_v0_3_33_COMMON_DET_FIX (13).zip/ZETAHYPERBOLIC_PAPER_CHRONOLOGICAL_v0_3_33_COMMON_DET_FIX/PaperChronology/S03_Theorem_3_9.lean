import PaperChronology.S03_Theorem_3_8
import Zetahyperbolic.Section3Elementary

/-!
# Theorem 3.9: Hyperbolicity for Hurwitz and Dirichlet determinants
PDF pp. 13–14. Status: partial.
Prior checked basis / current support: five explicit Fekete factor inequalities proved.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Theorem_3_9

/-- All five character Fekete factors are strictly positive on (0,1). -/
theorem character_factors_positive {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1) :
    0 < z * (1 - z) ∧
    0 < z * (1 - z ^ 2) ∧
    0 < z * (1 - z) ^ 2 * (1 + z) ∧
    0 < z * (1 - z ^ 2) * (1 - z ^ 4) ∧
    0 < z * (1 + z ^ 2) * (1 - z ^ 4) :=
  Zetahyperbolic.fekete_polynomial_positivity_basic hz0 hz1

-- Open: integral identification and hyperbolicity of the actual twisted pencils.

end PaperChronology.S03_Theorem_3_9
