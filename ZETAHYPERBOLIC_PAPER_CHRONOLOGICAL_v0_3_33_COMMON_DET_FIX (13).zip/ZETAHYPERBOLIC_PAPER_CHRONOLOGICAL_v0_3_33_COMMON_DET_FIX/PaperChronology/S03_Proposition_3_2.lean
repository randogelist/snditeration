import PaperChronology.S03_Theorem_3_1
import PAPER_SECTION3_CORRECTIONS

/-!
# Proposition 3.2: Continuous hyperbolic pencil for all real s > 1
PDF pp. 8. Status: correction-required.
Prior checked basis / current support: correct continuous weight prefactor; no complete analytic equality.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Proposition_3_2

/-- Certified correction: the printed continuous prefactor differs by pi/2. -/
theorem printed_vs_odd (k : ℕ) :
    (2 * Real.pi) ^ (2 * k + 1) /
        (2 * (Nat.factorial (2 * k) : ℝ)) =
    (Real.pi / 2) *
      (2 * (2 * Real.pi) ^ (2 * k) /
        (Nat.factorial (2 * k) : ℝ)) :=
  PaperSection3Corrections.printed_prefactor_scale k

-- Remaining goal: rebuild the normalized continuous family for all real s>1.

end PaperChronology.S03_Proposition_3_2
