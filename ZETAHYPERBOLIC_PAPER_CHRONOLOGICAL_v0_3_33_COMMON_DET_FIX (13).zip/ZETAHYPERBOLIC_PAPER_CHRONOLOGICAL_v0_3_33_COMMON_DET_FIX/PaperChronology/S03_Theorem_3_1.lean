import PaperChronology.S02_Theorem_2_5
import MAIN_CHAIN_ASSEMBLED

/-!
# Theorem 3.1: Universal hyperbolicity and zero-free disk
PDF pp. 7–8. Status: formalized.
Prior checked basis / current support: ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Theorem_3_1

open ManuscriptChain
/-- For every odd weight and admissible finite pencil, the actual spectral conclusion. -/
theorem universal_hyperbolicity (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Exact radius with complex-root exclusion and a root on the boundary. -/
theorem exact_zero_free_disk (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
        ¬ ManuscriptChain.General.ComplexRoot p z) ∧
      (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
        ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

end PaperChronology.S03_Theorem_3_1
