import PaperChronology.S05_Proposition_5_3
import PaperProofs.S05_Theorem_5_4_EvenPole

/-!
# Theorem 5.4: Cancellation of all higher zeta variables on even pole pairs

FULL STATEMENT of the paper on the *stated simple-pole domain*, all odd
weights s = 2k+1 and all j >= 1. The genuine Definition 2.1 auxiliary
functional is represented by `tauPolePoly` as a polynomial in X.

The difference `tau((x-j)^(-1)) - tau((x+j)^(-1))` is CONSTANT and equals
j^(-(2k+1)). No hypothesis, witness, sorry, or new axiom appears here.
No claim is made for higher-order poles beyond the paper's stated scope.
-/

noncomputable section
namespace PaperChronology.S05_Theorem_5_4

open Polynomial

/-- Complete theorem 5.4 as printed (simple-pole domain). -/
theorem even_pole_cancellation_all_odd_weights
    (k j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (((j : ℚ) ^ (2 * k + 1))⁻¹) :=
  PaperProofs.S05_Theorem_5_4_EvenPole.tau_even_pole_pair k j hj

/-- Exact constancy of the even-pole difference for any X evaluation. -/
theorem independent_of_X
    (k j : ℕ) (hj : 1 ≤ j) (X Y : ℚ) :
    (Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ))).eval X =
    (Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ))).eval Y := by
  rw [even_pole_cancellation_all_odd_weights k j hj]
  simp

end PaperChronology.S05_Theorem_5_4

#print axioms PaperChronology.S05_Theorem_5_4.even_pole_cancellation_all_odd_weights
#print axioms PaperChronology.S05_Theorem_5_4.independent_of_X
