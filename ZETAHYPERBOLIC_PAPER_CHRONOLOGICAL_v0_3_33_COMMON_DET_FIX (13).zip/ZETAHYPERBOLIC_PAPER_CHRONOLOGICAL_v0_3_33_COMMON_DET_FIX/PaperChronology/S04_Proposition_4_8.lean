import PaperChronology.S04_Theorem_4_7

/-!
# Proposition 4.8: Rational root exclusion and cluster factor degrees
PDF pp. 21–22. Status: open.
Prior checked basis / current support: requires published quantitative estimates and additional bounds.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S04_Proposition_4_8

#check ManuscriptChain.RealTransfer.RationalMeasure
-- Open: factor-height and root-denominator consequences with precise rates.

end PaperChronology.S04_Proposition_4_8
