# v0.3.10 – isolated witness endpoint

- New `PAPER_WITNESS_GRAM.lean`: unconditional admissibility and positivity, compiled first.
- Simplified `PAPER_SINGLE_WITNESS_CHAIN.lean`: uses the already proved Gram result and exactly one witness predicate (three eventual estimates).
- Keeps all previously passed theorem modules byte-identical; FASTCORE persistent stamps and `.olean` remain reusable.
- `run.cmd` now prints compiler error lines in addition to recording the full log.
- No `sorry`, `admit`, or custom axiom introduced. No mathematical witness was constructed.
- This is a source repair; the sole compiler remains the user's native Lean 4.33.0.
