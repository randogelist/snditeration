# v0.3.26 — safe lock recovery, no cache races

The v0.3.25 runner refused `recover` because **some** `lean.exe` or
`lake.exe` was running, even if it belonged to another project. That
is a cache/runner lock, not an error in the paper theorem.

One top-level `run.cmd`. Run with `recover`:

- **Primary cache not locked:** ordinary pass-once incremental build.
- **Primary lock exists, no Lean/Lake and empty directory:** explicitly clear
  that empty orphan lock and reuse all matching previously compiled proofs.
- **Primary lock exists and any Lean/Lake is running, scan unavailable,
  or directory nonempty:** do not remove the lock. Use the independent
  persistent cache `%FASTCORE_PROJECT_CACHE%_isolated_326`.
- **Alternate cache already locked:** abort rather than overwrite a writer.
- **Original cache is never imported while potentially being written.**
  Consequently the first isolated build can recompile unchanged modules once;
  subsequent isolated builds reuse their verified .oleans and source stamps.
  This is necessary to avoid accepting half-written or mismatched certificates.

Do not manually force-delete an active lock. Do not kill Lean or Lake
processes to make the package run. The selected cache and mode are printed.

No Lean was compiled in the package creation environment. The repaired
Proposition 4.3 Lean file from v0.3.25 is unchanged and remains unverified.
