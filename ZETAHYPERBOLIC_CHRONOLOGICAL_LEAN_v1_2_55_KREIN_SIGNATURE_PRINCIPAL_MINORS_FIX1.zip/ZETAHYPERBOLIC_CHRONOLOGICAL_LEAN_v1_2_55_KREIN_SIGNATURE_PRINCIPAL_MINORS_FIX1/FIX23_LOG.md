# v1.2.33 — actual roots explicit Matrix.map FIX4

The user's last reported log had the failure at line 107, corresponding
exactly to the v1.2.31 source, not the v1.2.32 source (where that
statement moved to lines 113–115). This release is a defensive update.

`Matrix.map` is now called by its fully-qualified name, applied to the
actual polynomial matrix and a polynomial ring homomorphism. This
avoids Lean's field-notation resolution of `.map` as `Function.map`
when `Matrix` is definitionally a binary function, irrespective of
whether it was named via an auxiliary Matrix-typed definition.

No other Lean sources are changed. Only the edited module and its one
chronological transitive importer have their proof-cache closure
fingerprints invalidated. The run output includes
`ACTUAL_ROOTS_COMPILER_SOURCE=V1233_EXPLICIT_MATRIX_MAP_FIX4` to
help separate current build logs from earlier versions.

No local Lean compilation was performed; native Windows Lean 4.33.0
remains the sole compilation authority. `FULL_PAPER=NOT_PROVED`.
