# v1.2.21 — Jacobi matrix evaluation proof FIX6

Input: Native Windows Lean 4.33.0 reported 119/129 checks completed; `ProofAdvances/Theorem_3_8_Jacobi.lean:54:62` had one unresolved matrix-entry goal:

`eval t (1 i j) + A i j * t = 1 i j + t * A i j`.

Fix: In `unitDetPoly_eval`, split matrix indices by `i = j`; unfold `Matrix.one_apply`, simplify `Polynomial.evalRingHom`, and close any remaining commutative scalar equation with `ring`. No theorem statement or earlier passing module was changed. The only new source proof was in the failed Jacobi module. Jacobi's downstream dependency keys are invalidated; all other SHA-verified modules remain eligible for frozen reuse.

Source-only/static packaging validation, NOT locally Lean-compiled. The final paper and infinite-integral bridge remain open.
