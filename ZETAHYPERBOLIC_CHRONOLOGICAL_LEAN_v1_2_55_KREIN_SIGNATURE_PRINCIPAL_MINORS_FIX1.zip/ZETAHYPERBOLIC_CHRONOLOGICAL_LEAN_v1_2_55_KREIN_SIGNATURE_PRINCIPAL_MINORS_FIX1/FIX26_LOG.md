# v1.2.43 — Principal p-adic wrapper, explicit coercion fix

- User's native Lean 4.33.0 verdict for v1.2.42: `LEAN_CHECKS=143/144`, only `PAPER_PRINCIPAL_PADIC_DISK.lean` fails at lines 28 and 31.
- Cause: annotating the evaluation of `Q.map (Int.castRingHom (ℤ_[p]))` as `ℚ_[p]` does not coerce it. The polynomial is in `ℤ_[p][X]` and `eval ξ` is in `ℤ_[p]`; a type annotation is not a coercion.
- Fix: explicit two-stage typing `(((Q.map ...).eval ξ : ℤ_[p]) : ℚ_[p])` at both sites.
- Proof remains an exact application of the previously compiler-PASSed `PROPOSITION_4_3_INTEGER_QPADIC`.
- All 143 passed Lean sources, their manifest records and transitive fingerprints remain byte-identical. Only the one failed wrapper receives a new source and closure fingerprint.
- 144 total build targets. `FULL_PAPER=NOT_PROVED`. No local Lean run.
