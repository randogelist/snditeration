# v1.2.17 — Jacobi HasDerivAt / polynomial-evaluation repair

Previous native Windows Lean 4.33.0 user log: BUILD=FAIL, FROZEN_PASS=119, REUSED_OLEAN=119, LEAN_CHECKS=119/129. The Jacobi module is the first pending target. Do not promote it or its descendants to PASS before native compilation and axiom audit.

This release edits only `ProofAdvances/Theorem_3_8_Jacobi.lean` and runner/manifest metadata. The v1.2.16 source for every other Lean module is byte-identical. The polynomial derivative proof uses Mathlib's `Matrix.derivative_det_one_add_X_smul`. Evaluation of the matrix polynomial at a real number is established via `Polynomial.evalRingHom` and `RingHom.map_det`; the `HasDerivAt` goal is transported from `Polynomial.hasDerivAt`. The logarithmic quotient uses `field_simp` without a redundant second tactic. The actual odd-zeta endpoint reuses verified `Theorem_3_8_Actual` trace identity and Gram determinant positivity.

This is a source-only repair: NO Lean compiler was run by the authoring system. The full paper is NOT proved, and Theorem 3.8(2) still lacks the Laplace integral interchange proof.
