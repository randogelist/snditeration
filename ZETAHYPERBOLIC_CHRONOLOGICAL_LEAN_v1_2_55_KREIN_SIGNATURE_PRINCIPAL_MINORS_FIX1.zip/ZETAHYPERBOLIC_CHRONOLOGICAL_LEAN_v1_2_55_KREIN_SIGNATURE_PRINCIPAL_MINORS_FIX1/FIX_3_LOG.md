# Corollary 3.5 — tactic-sequence fix (v1.2.6)

User native Windows Lean 4.33.0 compiler reported:

```
Paper\Corollary_3_5.lean:27:4: error: No goals to be solved
LEAN_CHECKS=73/114
FROZEN_PASS=59
REUSED_OLEAN=59
NEW_COMPILED=14
```

The subgoal establishing the algebraic factorization is fully closed by
`field_simp [hg]`; the following `ring` was redundant and caused Lean to reject
the module. Exactly that trailing `ring` line was removed. The `ring` after
`rw [hfactor, mul_inv_rev]` remains: it commutes the two inverse factors.

No theorem type was changed. No other Lean file was modified. The inherited
59 reusable and 14 newly passing module results remain eligible in persistent
FASTCORE CAS, if the user has the corresponding PASS artifacts with matching
source, dependency-closure, Lean binary, and Mathlib fingerprints. The failed
Corollary 3.5 is not cached as PASS.

At startup `run.cmd` verifies the SHA256 of the repaired source and prints
`COROLLARY35_SOURCE=FIX1_CONFIRMED`. If missing, verify the new package is
extracted and the proper CMD command is used.

The theorem provided is only the corrected **scalar resolvent identity**,
not the full PDF Corollary 3.5. The printed continued-fraction formula is
not claimed proven.

**Local Lean compilation was deliberately not performed.**
