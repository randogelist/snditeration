import PAPER_CHAPTER_ADVANCES_V1254
import ProofAdvances.Corollary_3_6_AllPrincipalMinors
import ProofAdvances.Theorem_5_2_FiniteSignature
import Mathlib.Tactic

/-!
# v1.2.55: chapter-level certified bridges

Section 3: the complete positive-semidefinite principal-minor hierarchy
for nonnegative finite atomic weights, including every truncation size;
strict positivity for injectively selected principal minors below support.
Section 5: explicit six-dimensional quintic (3,3) Krein sectors with
orthogonality, strict signs, and spanning. This is NOT the infinite
Krein-space/integral theorem; the manuscript remains incompletely proved.
-/

noncomputable section

namespace ZetaHyperbolicPaper.ChapterAdvancesV1255

open PaperAdvances.Corollary3_6_WeightedCorrected
open PaperAdvances.Corollary3_6_AllPrincipalMinors
open PaperAdvances.Theorem5_2_FiniteKreinPolarization
open PaperAdvances.Theorem5_2_FiniteSignature

/-- Section 3, valid for all orders: every principal minor is nonnegative. -/
theorem COROLLARY_3_6_ALL_PRINCIPAL_MINORS
    {h n m : ℕ} (u w : Fin h → ℝ)
    (hw : ∀ k, 0 ≤ w k) (e : Fin m → Fin n) :
    0 ≤ ((weightedHankel u w n).submatrix e e).det := by
  exact weighted_all_principal_minors_nonnegative u w hw e

/-- Section 3, strictly positive minors below the finite support rank. -/
theorem COROLLARY_3_6_STRICT_PRINCIPAL_MINORS
    {h n m : ℕ} (u w : Fin h → ℝ)
    (hu : Function.Injective u) (hw : ∀ k, 0 < w k)
    (hn : n ≤ h) (e : Fin m → Fin n) (he : Function.Injective e) :
    0 < ((weightedHankel u w n).submatrix e e).det := by
  exact weighted_all_principal_minors_positive u w hu hw hn e he

/-- Section 5: exact orthogonality of the finite positive and negative
three-dimensional channels in the manuscript's quintic kernel. -/
theorem THEOREM_5_2_FINITE_KREIN_ORTHOGONALITY
    (x y z u v w : ℝ) :
    quinticBilinear (symmetricTuple x y z) (antisymmetricTuple u v w) = 0 := by
  exact mixed_polarization_zero x y z u v w

/-- Section 5: every six-channel vector has the finite signed decomposition. -/
theorem THEOREM_5_2_FINITE_KREIN_SPANNING (a : Fin 6 → ℝ) :
    ∃ x y z u v w : ℝ,
      a = fun i => symmetricTuple x y z i + antisymmetricTuple u v w i := by
  exact symmetric_antisymmetric_span_all a

end ZetaHyperbolicPaper.ChapterAdvancesV1255

#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1255.COROLLARY_3_6_ALL_PRINCIPAL_MINORS
#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1255.COROLLARY_3_6_STRICT_PRINCIPAL_MINORS
#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1255.THEOREM_5_2_FINITE_KREIN_ORTHOGONALITY
#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1255.THEOREM_5_2_FINITE_KREIN_SPANNING
