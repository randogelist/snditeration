# Principal theorem endpoint – v1.2.34

`PAPER_PRINCIPAL_THEOREM.lean` introduces an explicit `PrincipalTheoremStatement`
with three parts: (1) general odd-weight spectral hyperbolicity, (2) the exact
nearest-zero disk, (3) effective irrationality measure 25687 plus irrationality
of ζ(5). The first two are proved unconditionally. The third is obtained from
**only** the existing `ZetaHyperbolicPaper.Witness`.

The principal effective-measure claim is written with an existential
threshold and a literal quantified rational inequality. The theorem
`THEOREM_4_4_EXPLICIT_INEQUALITY` exposes the denominator bound directly.

The companion printed Theorem 4.5 is defined separately as
`Theorem45LinearFormsTarget`; its combined zeta(5)/zeta(3) claim is not proven
by the ζ(5)-only Witness. `FullPrincipalSection4Target` remains open. The
`Witness` has two *infinite quantified estimates*, not a finite certificate.
No claim that a finite input invokes the full 52-page downstream theorem is
made. No new custom axioms or `sorry` are introduced.

The added module imports only the known Sections 2–4 chain and is intentionally
scheduled **before** the pending Theorem 5.2 ActualRoots module, so even if
that independent frontier fails, the principal endpoint can be independently
compiler-tested and persisted in the frozen cache. Previously compiled/verified
modules are unchanged and retain their exact cache fingerprints.

Compiler verification of the new module is pending the user's Windows Lean
4.33.0. The runner continues to report `FULL_PAPER=NOT_PROVED`.
