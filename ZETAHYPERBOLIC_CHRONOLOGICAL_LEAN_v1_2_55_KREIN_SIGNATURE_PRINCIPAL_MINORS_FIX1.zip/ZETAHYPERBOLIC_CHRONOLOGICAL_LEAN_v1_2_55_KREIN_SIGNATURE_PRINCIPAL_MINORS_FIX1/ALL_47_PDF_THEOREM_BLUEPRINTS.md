# 47-entry theorem blueprint audit — ZETAHYPERBOLIC

**Source:** supplied 52-page Zetahyperbolic PDF (21 October 2026).
**Lean baseline compiler-confirmed:** v1.2.43 144/144 PASS. v1.2.44 four modules not yet confirmed.
**New package:** 7 chapter-blueprint modules plus the same 4 pending v1.2.44 proof modules.
**Meaning:** a blueprint is a typed statement or a named proof-obligation interface, *not* its proof.
**Never infer full PDF theorem coverage from successful build; `FULL_PAPER=NOT_PROVED`.

## Chapter dependencies

- §2: exact rational-function semantic bridge for pullback/reflection; basis invariance/diagonalization cores.
- §3: ordered Gram minors and signature → interlacing and repaired J-fractions → Newton/all-order Turan → CD/Jacobi & Hurwitz.
- §4: full C_p disk + resultant transfer; W1 (uniform normalized determinant decay) + W2 (uniform spectral norm) → Theorem 4.4; independent mixed-weight analogue → Theorem 4.5.
- §5: Beukers double integral → finite dual hyperbolicity → infinite Krein and rational subspaces; beta moments; pole cancellations and prime valuations.
- §6: Mellin/valuation → q-adic nonvanishing → multiweight positive cone → infinite Krein → height and irrationality endpoints.

## Precise theorem-completeness policy

1. `Proof` requires actual declaration `theorem ... : ExactPDFStatement := ...` with axiom audit; importing a file and `#check` does not suffice.
2. `Modeled` means all PDF subclauses are typed, not merely summarized by `Prop` parameters. Parameterized `FullChapter` interfaces are planning contracts and do not count as fully modeled.
3. New theorem fully covered only after all subclauses discharge from kernel-proven lemmas without `sorryAx` or additional conjectural axioms.
4. Correct Corollary 3.5 scalar normalization and Corollary 3.6 finite-atomic rank obstruction explicitly. As printed, 3.6 all-orders strict positivity is false.
5. 4.11 is a CONJECTURE, not a theorem. §2 Definition 2.1 is definitional, not a proof obligation.
6. Quantified `Witness` is not a finite checkable witness, and passing Lean files that *use* it does not prove that it exists.

## Every original numbered item

| PDF number | Short title | Stage from chronological audit | Live proof obligation |
|---|---|---|---|
| Definition 2.1 | Order-s rational moment functional | FOUNDATION | Definition_2_1_Order_s_Rational_Moment_Functional.lean |
| Lemma 2.2 | Pullback identity | PROVED_GENERATORS | Finite normal-form pullback passed; extend exact identity to every rational function in manuscript domain. |
| Lemma 2.3 | Reflection and difference identities for tau_X | PROVED_GENERATORS | Finite-span reflection passed; verify full difference-domain and rational-function equivalence. |
| Theorem 2.4 | Canonical basis invariance | PROVED_CORE | Theorem_2_4_Canonical_Basis_Invariance.lean |
| Theorem 2.5 | Lagrange pole diagonalization | PROVED_CORE | Theorem_2_5_Lagrange_Pole_Diagonalization.lean |
| Theorem 3.1 | Universal hyperbolicity and zero-free disk | PROVED | PAPER_02_03_UNCONDITIONAL.lean |
| Proposition 3.2 | Continuous hyperbolic pencil for all real s > 1 | PARTIAL_ADVANCED | New real-exponent pole weights, strict positivity of their scaling, exact signed slope determinant, nonsingularity, and generic spectral factorization (ProofAdvances/Proposition_3_2.lean). Explicit continuous w_s integral and base Gram positivity remain open. |
| Theorem 3.3 | Total positivity, leading sign, and universal signature | PARTIAL_ADVANCED | Actual odd-weight Gram determinant > 0, exact leading-coefficient pole product, real-exponent positive/negative pole-index sets constant, finite parity identity (ProofAdvances/Theorem_3_3.lean). All non-principal minors and exact inertia counts remain open. |
| Theorem 3.4 | Root interlacing and Dodgson condensation for principal minors | PARTIAL_ADVANCED | Exact symmetric 3×3 Dodgson identity and sign at a vanishing leading minor proved in ProofAdvances/Theorem_3_4. General r and interlacing remain open. |
| Corollary 3.5 | Stieltjes J-fraction from interlacing roots | CORRECTION | As printed (3.6) misses Gram normalization and misuses the spectral parameter. Correct scalar resolvent lemma included. |
| Corollary 3.6 | Stieltjes reciprocal-root power sums | CORRECTION_ADVANCED | General finite-atomic Hankel = Vandermonde Gram factorization and two-atom rank-two obstruction proved in ProofAdvances/Corollary_3_6; printed strict all-orders assertion is false. |
| Theorem 3.7 | Turanian non-negativity and Newton log-concavity | PARTIAL_ADVANCED | Full finite-degree first Turan/strict-offroot passed; higher derivatives and Newton/equality-case specifications remain. |
| Theorem 3.8 | Christoffel-Darboux pole representation and Jacobi derivative identity | PARTIAL_ADVANCED | Full characteristic-polynomial and trace correspondence between actual relative Hankel matrix and pole kernel in all finite dimensions (ProofAdvances/Theorem_3_8_Actual.lean); symmetric-root and differentiated-integral components remain. |
| Theorem 3.9 | Hyperbolicity for Hurwitz and Dirichlet Hankel determinants | PARTIAL | Fekete polynomial positivity formally proved; complete shifted integral/character moment identities are not. |
| Theorem 4.1 | Spectral irrationality measure criterion | PROVED_CORE | Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean |
| Proposition 4.2 | Transfer criterion for algebraic approximations of degree d >= 1 | OPEN | Requires formal resultant, height and conjugate factor estimates. |
| Proposition 4.3 | Ultrametric zero-free disk over Q_p | OPEN | Q_p disk passed; full C_p statement in v1.2.44 awaits native Lean certification. |
| Theorem 4.4 | Sharpened spectral bound and effective irrationality measure for zeta(5) | CONDITIONAL | Printed 0.0004 normalized decay and 11.411 bound are supplied by the single Witness, not proved. |
| Theorem 4.5 | Irrationality and effective measure for b zeta(5) + a zeta(3) | OPEN | Separate combined-weight positivity and uniform p-adic normalization beyond single zeta(5) Witness. |
| Theorem 4.6 | Two-sided determinant bounds and coefficient heights | OPEN | Euler-Maclaurin determinant asymptotics and lower Gram Jensen bound. |
| Theorem 4.7 | Macroscopic exponential root collapse and root separation | OPEN | Depends on 4.4 and 4.6, plus quantitative factor height. |
| Proposition 4.8 | Rational root exclusion and degree bounds for cluster factors | OPEN | Depends on repaired 4.4–4.7. |
| Conjecture 4.11 | Variational limit of spectral norm exponent | CONJECTURE | A conjecture in the PDF; not treated as theorem. |
| Theorem 5.1 | Two-variable Beukers measure for zeta(7) | PARTIAL | Finite rational dual coefficient identities exist; double-integral identity is not proved. |
| Theorem 5.2 | Dual hyperbolicity and Krein-space decomposition of the two-variable zeta(7) pencil | PARTIAL | Finite positive/negative certificate implications proved; infinite mode tails not controlled. |
| Proposition 5.3 | Two-variable Beukers measure and dual pencil for beta(4) | OPEN | Beta integral moments and rational off-diagonal moments need proof. |
| Theorem 5.4 | Cancellation of higher zeta values on even pole pairs | PARTIAL | Finite-pole cancellation passed; match full original tauX simple-pole formulation. |
| Theorem 5.6 | Weight-seven prime-sum evaluation and pole-ordered refinement | OPEN | 11 rational affine intervals, tail integral and local p-adic unimodular argument. |
| Theorem 5.7 | Simultaneous double-pole Hankel determinant for 1, zeta(5), zeta(6) | PARTIAL | Hermite and local block algebra available; q-adic nonvanishing and valuation not closed. |
| Theorem 6.1 | Divided-difference p-adic valuation law and intrinsic p^-6 barrier | OPEN | Exact local valuations and fiber Mellin integral. |
| Theorem 6.2 | Simultaneous weight-(6,7) Beukers functional with zero denominator overhead | OPEN | Asymmetric Beukers moments and denominator-free arithmetic. |
| Theorem 6.3 | Unconditional q-adic non-vanishing and explicit positive-cone approximations for G_A(7) | PARTIAL | Source has certificate implication; existence of tail estimates and bases unproved. |
| Theorem 6.4 | Character-Vandermonde sign cancellation and unconditional hyperbolicity for beta(4) | PARTIAL | Auxiliary beta moment model interfaces, not complete PDF beta(4) weight identity. |
| Theorem 6.5 | Unconditional q-adic non-vanishing for Delta_K(0) | OPEN | Prime congruence and determinant valuation for beta pencil. |
| Theorem 6.6 | Generalized multi-weight positive-definite pencil | OPEN | Finite-dimensional cone and Turan proved; analytic combined-weight and uniform p-adic bounds open. |
| Theorem 6.7 | Universal multi-weight two-variable Beukers Krein decomposition | OPEN | General multi-index integral and infinite-mode Krein decomposition. |
| Corollary 6.8 | Unconditional three-term linear independence cone for 1,zeta(3),zeta(5) | OPEN | Full combined normalized determinant arithmetic, not implied by spectral 3.1. |
| Theorem 6.9 | Triple-pole and multi-weight Hankel determinants | PARTIAL | Finite Hermite interpolation/local block identity proved in imported module. |
| Theorem 6.10 | Universal potential-gap identity and vanishing of quadratic derivative growth in two variables | PARTIAL | Finite determinant identity proved; full asymptotic potential conservation not. |
| Theorem 6.11 | p^-(2k-1) distribution growth law and 2-adic polynomial-quotient obstruction | OPEN | Prime-adic distribution and quotient valuation bounds. |
| Theorem 6.12 | Full-dimension sign-flip restoration of positive definiteness and q-adic non-vanishing for pure beta(4) | OPEN | Signed beta weight moment correction, full positivity and q-adic certificate. |
| Theorem 6.13 | Central-factorial secant differential identity, Laplace mode annihilation, and consequences | OPEN | Exact differential polynomial and annihilation identity. |
| Theorem 6.14 | Even-pole scaling via cosh(2pi v) and coupled positive-definite pencils | OPEN | Even-pole functional and positive weight realization. |
| Theorem 6.15 | Arithmetic transcendence, strictly positive one-variable measure, and rank-one obstruction | OPEN | Transcendence, positivity, and rank-one endpoint each need standalone proof. |
| Theorem 6.16 | Generalized multi-weight Zeta-Beta positive-definite pencil | PARTIAL | Auxiliary compact-ratio positivity lemmas present; full multi-weight pencil absent. |
| Theorem 6.17 | Universal two-variable Beukers Zeta-Beta pencil, Krein decomposition, and extensions | PARTIAL | Finite harmonic-window/index lemmas available, not universal analytic theorem. |
| Theorem 6.18 | Principal-minor 2-adic integrality law, dyadic height bounds for Zeta-Beta pencils | PARTIAL | Finite boundary-degree lemma exists; full dyadic height result remains. |

## Suggested proof attack order

**First closure targets:** (1) exact §2 domain ↔ finite normal form; (2) §3 full Newton and ordered-minor positivity; (3) §4 C_p full p-adic disk (v1.2.44 candidate), (4) §5 exact two-variable Beukers moments, (5) §6 isolated local valuation or finite proof that can be closed from existing Hermite lemmas.
**Longest quantitative frontier:** 4.4 W1 decay; next W2 spectral bound. These cannot be certified by a finite numerical computation without an independent universal transfer.
**No local Lean compilation performed.** Only user Windows Lean 4.33.0/Mathlib compiler is authoritative.
