import ProofAdvances.Theorem_5_2_DualDerivative
import ProofAdvances.Theorem_5_1_DualSymmetric
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic

/-!
# Theorem 5.2 -- actual rational dual pencil derivative

At every finite dimension, the coefficient of X in the manuscript's
rational two-variable Beukers pencil is the Gram matrix C C^T. The
basis coefficients are actual rational numbers rather than symbolic
matrices. A full-row-rank coefficient matrix therefore gives a positive
definite derivative, strictly positive determinant and symmetry.

This is the complete finite algebra behind Theorem 5.2(1). Evaluation
of the two-variable integral at zeta(7), as well as Krein-space signs,
remains analytically separate.
-/

noncomputable section
open Matrix Polynomial
namespace PaperAdvances.Theorem5_2_ActualDual

open ManuscriptChain
open PaperAdvances.Theorem5_2_DualDerivative

/-- The true real coefficient matrix of the rational dual pencil. -/
def actualSlope {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => ((Real.dualEntry s c i j).coeff 1 : ℝ)

/-- Identification of the actual rational-pole derivative with C C^T. -/
theorem actualSlope_eq_gram {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    actualSlope s c = dualSlope (coefficientMatrix c) := by
  exact dualEntry_slope_eq_gram s c

/-- Full-rank rational coefficient rows yield a positive derivative. -/
theorem actualSlope_posDef {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective (coefficientMatrix c).vecMul) :
    (actualSlope s c).PosDef := by
  rw [actualSlope_eq_gram]
  exact dualSlope_posDef (coefficientMatrix c) hc

/-- Consequently the full-size actual derivative has positive determinant. -/
theorem actualSlope_det_pos {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective (coefficientMatrix c).vecMul) :
    0 < (actualSlope s c).det :=
  (actualSlope_posDef s c hc).det_pos


end PaperAdvances.Theorem5_2_ActualDual

#print axioms PaperAdvances.Theorem5_2_ActualDual.actualSlope_eq_gram
#print axioms PaperAdvances.Theorem5_2_ActualDual.actualSlope_posDef
#print axioms PaperAdvances.Theorem5_2_ActualDual.actualSlope_det_pos
