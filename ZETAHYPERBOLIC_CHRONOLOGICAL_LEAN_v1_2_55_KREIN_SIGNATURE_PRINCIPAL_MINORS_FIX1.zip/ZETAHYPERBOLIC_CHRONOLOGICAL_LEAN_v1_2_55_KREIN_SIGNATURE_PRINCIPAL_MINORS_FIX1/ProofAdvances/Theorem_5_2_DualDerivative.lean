import ProofAdvances.Theorem_5_1_DualSymmetric
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic

/-!
# Theorem 5.2(1) -- positive definite full-rank dual derivative

The X-derivative of the dual Beukers polynomial matrix is the coefficient
Gram C*C^T. This is positive definite for **every finite dimension**,\
provided the coefficient rows are linearly independent, as prescribed in
the manuscript. This is a completely finite algebraic result: the distinct
analytic problem of evaluating the double integral at X=zeta(7) remains.
-/

noncomputable section
open Matrix Polynomial
namespace PaperAdvances.Theorem5_2_DualDerivative

/-- A real coefficient matrix gives an h-by-h Gram slope. -/
def dualSlope {h K : ℕ} (C : Matrix (Fin h) (Fin (K + 1)) ℝ) :
    Matrix (Fin h) (Fin h) ℝ := C * C.transpose

/-- Full-rank coefficient rows imply a strictly positive derivative Gram. -/
theorem dualSlope_posDef {h K : ℕ}
    (C : Matrix (Fin h) (Fin (K + 1)) ℝ)
    (hC : Function.Injective C.vecMul) :
    (dualSlope C).PosDef := by
  have hh := Matrix.PosDef.mul_conjTranspose_self C hC
  simpa only [dualSlope, Matrix.conjTranspose_eq_transpose_of_trivial] using hh

/-- In particular the dual slope has strictly positive determinant. -/
theorem dualSlope_det_pos {h K : ℕ}
    (C : Matrix (Fin h) (Fin (K + 1)) ℝ)
    (hC : Function.Injective C.vecMul) :
    0 < (dualSlope C).det := (dualSlope_posDef C hC).det_pos

/-- Exact real coefficient matrix of a rational polynomial basis. -/
def coefficientMatrix {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin (K + 1)) ℝ :=
  fun i r => (c i r : ℝ)

/-- The X coefficient of the actual rational dual pencil is C*C^T,
    not an assumed positive definite matrix. -/
theorem dualEntry_slope_eq_gram {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    (fun i j : Fin h =>
        ((ManuscriptChain.Real.dualEntry s c i j).coeff 1 : ℝ)) =
      dualSlope (coefficientMatrix c) := by
  ext i j
  rw [Theorem5_1_DualSymmetric.dual_entry_linear_coefficient]
  simp [dualSlope, coefficientMatrix, Matrix.mul_apply, Matrix.transpose_apply]

end PaperAdvances.Theorem5_2_DualDerivative

#print axioms PaperAdvances.Theorem5_2_DualDerivative.dualSlope_posDef
#print axioms PaperAdvances.Theorem5_2_DualDerivative.dualEntry_slope_eq_gram
