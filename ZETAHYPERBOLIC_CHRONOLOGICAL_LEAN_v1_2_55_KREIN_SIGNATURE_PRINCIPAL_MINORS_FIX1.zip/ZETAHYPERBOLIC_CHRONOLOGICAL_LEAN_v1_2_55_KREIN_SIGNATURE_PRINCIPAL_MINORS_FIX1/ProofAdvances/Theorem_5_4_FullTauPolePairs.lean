import ProofAdvances.Theorem_5_4_FiniteCancellation
import ProofAdvances.Lemma_2_3_FullNormalForm
import Mathlib.Tactic

/-!
# Theorem 5.4 — direct tau_X simple-pole evaluation, all odd weights

The PDF's equation (5.5) is a statement about its auxiliary tau_X
functional on x-even pole pairs. This module proves that very equation
in the existing, explicit polynomial-valued tau pole generator model,
for every odd weight 2k+1 and every positive integer j, including j=1.
The result also extends to every finite rational linear combination
of such pairs by exact linearity, without any analytic or number-
theoretic premise.

It does not claim to prove the PDF's higher-order pole or infinite
dimensional analytic identities, which are different statements.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperAdvances.Theorem5_4_FullTauPolePairs

/-- Equation (5.5) in the paper's exact tau pole-action model:
`tau_X ((x-j)⁻¹ - (x+j)⁻¹) = j^-(2k+1)` for all j>=1. -/
theorem tau_even_pole_pair_exact (k j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (1 / ((j : ℚ) ^ (2 * k + 1))) := by
  have hdpos : Zetahyperbolic.dIndex (j : ℤ) = j := by
    simp [Zetahyperbolic.dIndex,
      Int.toNat_of_nonneg (by omega : (0 : ℤ) ≤ (j : ℤ))]
  have hdneg : Zetahyperbolic.dIndex (-(j : ℤ)) = j - 1 := by
    have hneg : ¬ (0 : ℤ) ≤ -(j : ℤ) := by omega
    unfold Zetahyperbolic.dIndex
    rw [if_neg hneg]
    have hcast : -(-(j : ℤ)) - 1 = ((j - 1 : ℕ) : ℤ) := by omega
    rw [hcast]
    simp
  have hjrec : j - 1 + 1 = j := by omega
  have hrec := Zetahyperbolic.harmonicWeight_succ (2 * k + 1) (j - 1)
  rw [hjrec] at hrec
  unfold Zetahyperbolic.tauPolePoly
  rw [hdpos, hdneg, hrec]
  simp only [Polynomial.C_add, Polynomial.C_sub, one_div]
  ring

/-- Rational weighted sums of pole pairs inherit exact cancellation of
all X-dependence, including the previously excluded endpoint j=1. -/
theorem tau_even_pole_pairs_finite (k : ℕ) (J : Finset ℕ)
    (c : ℕ → ℚ) (hJ : ∀ j ∈ J, 1 ≤ j) :
    (∑ j ∈ J, Polynomial.C (c j) *
      (Zetahyperbolic.tauPolePoly k (j : ℤ) -
       Zetahyperbolic.tauPolePoly k (-(j : ℤ)))) =
      Polynomial.C (∑ j ∈ J, c j / ((j : ℚ) ^ (2 * k + 1))) := by
  calc
    _ = ∑ j ∈ J, Polynomial.C (c j / ((j : ℚ) ^ (2 * k + 1))) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [tau_even_pole_pair_exact k j (hJ j hj)]
      rw [← Polynomial.C_mul]
      simp only [div_eq_mul_inv, one_div, one_mul]
    _ = Polynomial.C (∑ j ∈ J, c j / ((j : ℚ) ^ (2 * k + 1))) := by
      simp only [map_sum]

end PaperAdvances.Theorem5_4_FullTauPolePairs

#print axioms PaperAdvances.Theorem5_4_FullTauPolePairs.tau_even_pole_pair_exact
#print axioms PaperAdvances.Theorem5_4_FullTauPolePairs.tau_even_pole_pairs_finite
