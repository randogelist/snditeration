import ProofAdvances.Theorem_5_2_FiniteKreinPolarization
import Mathlib.Data.Fin.VecNotation
import Mathlib.Tactic

/-!
# Theorem 5.2(2): exact finite Witt/Krein signature of the quintic form

The six-dimensional quintic pairing decomposes explicitly into three
symmetric (+) and three antisymmetric (-) coordinates.  We prove the
orthogonality, the strict sign of every nonzero pure vector in each
three-dimensional sector, and the fact that these sectors span EVERY
six-tuple.  This constitutes an exact finite (3,3) signature certificate
for the algebraic kernel, not the missing infinite Krein decomposition,
analytic integration, or rational polynomial subspaces of the PDF.
-/

noncomputable section

namespace PaperAdvances.Theorem5_2_FiniteSignature

open PaperAdvances.Theorem5_2_FiniteKreinPolarization

/-- The three-dimensional positive sector. -/
def symmetricTuple (x y z : ℝ) : Fin 6 → ℝ := ![x, y, z, z, y, x]

/-- The three-dimensional negative sector. -/
def antisymmetricTuple (x y z : ℝ) : Fin 6 → ℝ := ![x, y, z, -z, -y, -x]

/-- The symmetric sector has diagonal weights 2, 10, 20. -/
theorem symmetric_quadratic (x y z : ℝ) :
    quinticBilinear (symmetricTuple x y z) (symmetricTuple x y z) =
      2 * x ^ 2 + 10 * y ^ 2 + 20 * z ^ 2 := by
  simp [quinticBilinear, symmetricTuple] <;> ring

/-- The antisymmetric sector has the negatives of the same weights. -/
theorem antisymmetric_quadratic (x y z : ℝ) :
    quinticBilinear (antisymmetricTuple x y z) (antisymmetricTuple x y z) =
      -(2 * x ^ 2 + 10 * y ^ 2 + 20 * z ^ 2) := by
  simp [quinticBilinear, antisymmetricTuple] <;> ring

/-- The positive and negative three-dimensional sectors are orthogonal
for the original signed quintic bilinear pairing. -/
theorem mixed_polarization_zero (x y z u v w : ℝ) :
    quinticBilinear (symmetricTuple x y z) (antisymmetricTuple u v w) = 0 := by
  simp [quinticBilinear, symmetricTuple, antisymmetricTuple] <;> ring

/-- The positive sector is STRICTLY positive on every nonzero triple. -/
theorem symmetric_strict_positive (x y z : ℝ)
    (hne : x ≠ 0 ∨ y ≠ 0 ∨ z ≠ 0) :
    0 < quinticBilinear (symmetricTuple x y z) (symmetricTuple x y z) := by
  rw [symmetric_quadratic]
  rcases hne with hx | hy | hz
  · have hx2 : 0 < x ^ 2 := sq_pos_of_ne_zero hx
    nlinarith [sq_nonneg y, sq_nonneg z]
  · have hy2 : 0 < y ^ 2 := sq_pos_of_ne_zero hy
    nlinarith [sq_nonneg x, sq_nonneg z]
  · have hz2 : 0 < z ^ 2 := sq_pos_of_ne_zero hz
    nlinarith [sq_nonneg x, sq_nonneg y]

/-- The negative sector is STRICTLY negative on every nonzero triple. -/
theorem antisymmetric_strict_negative (x y z : ℝ)
    (hne : x ≠ 0 ∨ y ≠ 0 ∨ z ≠ 0) :
    quinticBilinear (antisymmetricTuple x y z) (antisymmetricTuple x y z) < 0 := by
  rw [antisymmetric_quadratic]
  rcases hne with hx | hy | hz
  · have hx2 : 0 < x ^ 2 := sq_pos_of_ne_zero hx
    nlinarith [sq_nonneg y, sq_nonneg z]
  · have hy2 : 0 < y ^ 2 := sq_pos_of_ne_zero hy
    nlinarith [sq_nonneg x, sq_nonneg z]
  · have hz2 : 0 < z ^ 2 := sq_pos_of_ne_zero hz
    nlinarith [sq_nonneg x, sq_nonneg y]

/-- The two signed sectors span the complete original six-channel space.
Together with the strict forms and orthogonality above, this establishes
finite signature (3,3), not merely two example directions. -/
theorem symmetric_antisymmetric_span_all (a : Fin 6 → ℝ) :
    ∃ x y z u v w : ℝ,
      a = fun i => symmetricTuple x y z i + antisymmetricTuple u v w i := by
  refine ⟨(a 0 + a 5) / 2, (a 1 + a 4) / 2, (a 2 + a 3) / 2,
    (a 0 - a 5) / 2, (a 1 - a 4) / 2, (a 2 - a 3) / 2, ?_⟩
  funext i
  fin_cases i <;> simp [symmetricTuple, antisymmetricTuple] <;> ring

end PaperAdvances.Theorem5_2_FiniteSignature

#print axioms PaperAdvances.Theorem5_2_FiniteSignature.symmetric_quadratic
#print axioms PaperAdvances.Theorem5_2_FiniteSignature.antisymmetric_quadratic
#print axioms PaperAdvances.Theorem5_2_FiniteSignature.mixed_polarization_zero
#print axioms PaperAdvances.Theorem5_2_FiniteSignature.symmetric_strict_positive
#print axioms PaperAdvances.Theorem5_2_FiniteSignature.antisymmetric_strict_negative
#print axioms PaperAdvances.Theorem5_2_FiniteSignature.symmetric_antisymmetric_span_all
