import ProofAdvances.Lemma_2_2_FullNormalForm
import Paper.Lemma_2_3
import Mathlib.Tactic

/-!
# Lemma 2.3: full finite-span reflection and pole-difference identities

Exact reflection for EVERY finite linear combination of polynomial
monomials and integer simple poles, plus the difference identity for
EVERY finite linear combination of admissible poles r != 0,1.
The two generator families are separately combined by Q-linearity.
No assertion about a larger domain of poles or invalid evaluation at
r=0,1 is introduced.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperAdvances.Lemma2_3_FullNormalForm

/-- Action of the auxiliary tau functional on arbitrary finite
linear combinations of monomial and simple-pole generators. -/
def tauFiniteSpan (k : ℕ) (es : Finset ℕ) (u : ℕ → ℚ)
    (rs : Finset ℤ) (v : ℤ → ℚ) : ℚ[X] :=
  (∑ d ∈ es, C (u d * Zetahyperbolic.tauMonomial k d)) +
  ∑ r ∈ rs, C (v r) * Zetahyperbolic.tauPolePoly k r

/-- Tau applied to the pullback of each generator under x ↦ -1-x.
The monomial pullback uses the exact binomial expansion. -/
def tauReflectedFiniteSpan (k : ℕ) (es : Finset ℕ) (u : ℕ → ℚ)
    (rs : Finset ℤ) (v : ℤ → ℚ) : ℚ[X] :=
  (∑ d ∈ es, C (u d *
    ((-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i)))) +
  ∑ r ∈ rs, C (v r) *
    (-Zetahyperbolic.tauPolePoly k (-1 - r))

/-- Monomial sector of Lemma 2.3: reflected finite sums have
exactly the negative moment value. -/
theorem monomial_reflection_finite (k : ℕ) (hk : 1 ≤ k)
    (es : Finset ℕ) (u : ℕ → ℚ) :
    (∑ d ∈ es, C (u d *
      ((-1 : ℚ) ^ d *
        (∑ i ∈ Finset.range (d + 1),
          (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i)))) =
      -(∑ d ∈ es, C (u d * Zetahyperbolic.tauMonomial k d)) := by
  calc
    _ = ∑ d ∈ es, -(C (u d * Zetahyperbolic.tauMonomial k d)) := by
      apply Finset.sum_congr rfl
      intro d hd
      rw [Zetahyperbolic.tau_reflection_monomial k d hk]
      simp only [mul_neg, Polynomial.C_neg]
    _ = -(∑ d ∈ es, C (u d * Zetahyperbolic.tauMonomial k d)) := by
      rw [Finset.sum_neg_distrib]

/-- Pole sector of Lemma 2.3: reflected finite sums are negated. -/
theorem pole_reflection_finite (k : ℕ)
    (rs : Finset ℤ) (v : ℤ → ℚ) :
    (∑ r ∈ rs, C (v r) *
      (-Zetahyperbolic.tauPolePoly k (-1 - r))) =
      -(∑ r ∈ rs, C (v r) * Zetahyperbolic.tauPolePoly k r) := by
  calc
    _ = ∑ r ∈ rs, -(C (v r) * Zetahyperbolic.tauPolePoly k r) := by
      apply Finset.sum_congr rfl
      intro r hr
      rw [Zetahyperbolic.tauPolePoly_reflect k r]
      ring
    _ = -(∑ r ∈ rs, C (v r) * Zetahyperbolic.tauPolePoly k r) := by
      rw [Finset.sum_neg_distrib]

/-- Lemma 2.3 (2.6), fully assembled over arbitrary finite spans
of both types of generators. -/
theorem FULL_REFLECTION_ALL_FINITE_SPANS
    (k : ℕ) (hk : 1 ≤ k)
    (es : Finset ℕ) (u : ℕ → ℚ)
    (rs : Finset ℤ) (v : ℤ → ℚ) :
    tauReflectedFiniteSpan k es u rs v = -tauFiniteSpan k es u rs v := by
  unfold tauReflectedFiniteSpan tauFiniteSpan
  rw [monomial_reflection_finite k hk es u,
    pole_reflection_finite k rs v]
  ring

/-- Lemma 2.3 (2.7), fully assembled over arbitrary finite
linear combinations of poles with permissible labels. -/
theorem FULL_DIFFERENCE_ALL_FINITE_POLES (k : ℕ)
    (rs : Finset ℤ) (v : ℤ → ℚ)
    (hr : ∀ r ∈ rs, r ≠ 0 ∧ r ≠ 1) :
    (∑ r ∈ rs, C (v r) *
      (Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r)) =
      ∑ r ∈ rs, C (v r *
        (-((r : ℚ) ^ (2 * k + 1))⁻¹)) := by
  apply Finset.sum_congr rfl
  intro r hrs
  have h := hr r hrs
  rw [Zetahyperbolic.tau_difference_pole k r h.1 h.2]
  rw [← Polynomial.C_mul]

end PaperAdvances.Lemma2_3_FullNormalForm

#print axioms PaperAdvances.Lemma2_3_FullNormalForm.FULL_REFLECTION_ALL_FINITE_SPANS
#print axioms PaperAdvances.Lemma2_3_FullNormalForm.FULL_DIFFERENCE_ALL_FINITE_POLES
