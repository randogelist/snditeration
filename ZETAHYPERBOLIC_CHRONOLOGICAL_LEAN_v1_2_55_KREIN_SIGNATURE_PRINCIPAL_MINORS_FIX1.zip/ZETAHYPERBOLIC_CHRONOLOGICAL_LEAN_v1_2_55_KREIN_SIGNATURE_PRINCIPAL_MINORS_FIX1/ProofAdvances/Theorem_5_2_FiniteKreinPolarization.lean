import ProofAdvances.Theorem_5_2_ActualRoots
import Mathlib.Tactic

/-!
# Theorem 5.2(2): exact FINITE quintic Krein polarization identity

The analytic two-variable kernel has a quintic logarithmic numerator.
Its 6 binomial terms (1,5,10,10,5,1) pair by ν ↔ 5-ν into a
sum of three positive-square and negative-square channels.  The finite
bilinear identity, its exact 1/720 versus 1/1440 normalization, and
finite positive/negative cones are proved here for arbitrary real inputs.

This DOES NOT prove the infinite m-sum, exchange of integrals, existence
of rational polynomial positive/negative subspaces, or the full PDF 5.2.
-/

noncomputable section
open scoped BigOperators

namespace PaperAdvances.Theorem5_2_FiniteKreinPolarization

/-- The binomial-paired quintic signed kernel for two arbitrary six-tuples.
The six terms have coefficients 1,5,10,10,5,1. -/
def quinticBilinear (a b : Fin 6 → ℝ) : ℝ :=
  (a 0 * b 5 + a 5 * b 0) +
    5 * (a 1 * b 4 + a 4 * b 1) +
    10 * (a 2 * b 3 + a 3 * b 2)

/-- The positive Krein pairing of the three symmetric channels. -/
def kreinPlus (a b : Fin 6 → ℝ) : ℝ :=
  (a 0 + a 5) * (b 0 + b 5) +
    5 * (a 1 + a 4) * (b 1 + b 4) +
    10 * (a 2 + a 3) * (b 2 + b 3)

/-- The negative Krein pairing of the three antisymmetric channels. -/
def kreinMinus (a b : Fin 6 → ℝ) : ℝ :=
  (a 0 - a 5) * (b 0 - b 5) +
    5 * (a 1 - a 4) * (b 1 - b 4) +
    10 * (a 2 - a 3) * (b 2 - b 3)

/-- Exact 1/720 - 1/1440 identity that underlies equation (5.4).
This is the pointwise algebra, not a theorem about the integral. -/
theorem quintic_polarization (a b : Fin 6 → ℝ) :
    quinticBilinear a b / 720 =
      (kreinPlus a b - kreinMinus a b) / 1440 := by
  unfold quinticBilinear kreinPlus kreinMinus
  ring

/-- An exact identity for arbitrary FINITE sums of quintic channels.
This is valid without moment or integrability assumptions. -/
theorem finite_quintic_polarization {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (a b : ι → Fin 6 → ℝ) :
    (∑ i ∈ s, quinticBilinear (a i) (b i)) / 720 =
    ((∑ i ∈ s, kreinPlus (a i) (b i)) -
      (∑ i ∈ s, kreinMinus (a i) (b i))) / 1440 := by
  calc
    _ = ∑ i ∈ s, quinticBilinear (a i) (b i) / 720 := by
      rw [Finset.sum_div]
    _ = ∑ i ∈ s, (kreinPlus (a i) (b i) - kreinMinus (a i) (b i)) / 1440 := by
      apply Finset.sum_congr rfl
      intro i hi
      exact quintic_polarization (a i) (b i)
    _ = ((∑ i ∈ s, kreinPlus (a i) (b i)) -
          (∑ i ∈ s, kreinMinus (a i) (b i))) / 1440 := by
      rw [← Finset.sum_sub_distrib, Finset.sum_div]

/-- Positive semidefinite square-channel form, pointwise. -/
theorem kreinPlus_nonneg (a : Fin 6 → ℝ) : 0 ≤ kreinPlus a a := by
  unfold kreinPlus
  nlinarith [sq_nonneg (a 0 + a 5),
    sq_nonneg (a 1 + a 4), sq_nonneg (a 2 + a 3)]

/-- Negative-channel quadratic form is itself nonnegative; it enters
with a minus sign in the signed Beukers kernel. -/
theorem kreinMinus_nonneg (a : Fin 6 → ℝ) : 0 ≤ kreinMinus a a := by
  unfold kreinMinus
  nlinarith [sq_nonneg (a 0 - a 5),
    sq_nonneg (a 1 - a 4), sq_nonneg (a 2 - a 3)]

/-- If all antisymmetric channels vanish, a finite kernel truncation is
nonnegative, with no hypotheses beyond the explicit finite constraints. -/
theorem finite_plus_cone_nonnegative {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (a : ι → Fin 6 → ℝ)
    (hminus : ∀ i ∈ s, kreinMinus (a i) (a i) = 0) :
    0 ≤ (∑ i ∈ s, quinticBilinear (a i) (a i)) / 720 := by
  rw [Finset.sum_div]
  apply Finset.sum_nonneg
  intro i hi
  rw [quintic_polarization, hminus i hi, sub_zero]
  exact div_nonneg (kreinPlus_nonneg (a i)) (by norm_num)

/-- Exchanging + and - forces a nonpositive signed kernel truncation. -/
theorem finite_minus_cone_nonpositive {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (a : ι → Fin 6 → ℝ)
    (hplus : ∀ i ∈ s, kreinPlus (a i) (a i) = 0) :
    (∑ i ∈ s, quinticBilinear (a i) (a i)) / 720 ≤ 0 := by
  rw [Finset.sum_div]
  apply Finset.sum_nonpos
  intro i hi
  rw [quintic_polarization, hplus i hi, zero_sub]
  exact div_nonpos_of_nonpos_of_nonneg
    (neg_nonpos.mpr (kreinMinus_nonneg (a i))) (by norm_num)

end PaperAdvances.Theorem5_2_FiniteKreinPolarization

#print axioms PaperAdvances.Theorem5_2_FiniteKreinPolarization.quintic_polarization
#print axioms PaperAdvances.Theorem5_2_FiniteKreinPolarization.finite_quintic_polarization
#print axioms PaperAdvances.Theorem5_2_FiniteKreinPolarization.finite_plus_cone_nonnegative
#print axioms PaperAdvances.Theorem5_2_FiniteKreinPolarization.finite_minus_cone_nonpositive
