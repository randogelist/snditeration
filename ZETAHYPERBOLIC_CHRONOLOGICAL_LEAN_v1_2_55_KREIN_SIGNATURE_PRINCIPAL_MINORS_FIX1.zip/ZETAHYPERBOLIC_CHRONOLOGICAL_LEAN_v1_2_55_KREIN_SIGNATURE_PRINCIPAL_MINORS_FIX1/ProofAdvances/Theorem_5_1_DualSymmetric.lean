import Paper.Theorem_5_1
import Mathlib.Tactic

/-!
# Theorem 5.1 -- structural symmetry of the exact rational divided differences

The manuscript's two-variable moment matrix has one unknown zeta-value
on the diagonal and finite rational divided differences off the diagonal.
These theorems formalize symmetry for that rational skeleton and identify
the coefficient of X in its matrix-pencil entries.

They do not pretend that the Beukers two-dimensional integral has been
formally integrated.  The integral-moment identity is a separate target.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperAdvances.Theorem5_1_DualSymmetric

open ManuscriptChain

/-- The divided-difference rational constant is symmetric in its two indices. -/
theorem dual_constant_symmetric (s r t : ℕ) :
    Real.dualConstant s r t = Real.dualConstant s t r := by
  by_cases h : r = t
  · subst t
    rfl
  · have h' : t ≠ r := Ne.symm h
    unfold Real.dualConstant
    rw [if_neg h, if_neg h']
    have hnum : Real.harmonic (s - 1) t - Real.harmonic (s - 1) r =
        -(Real.harmonic (s - 1) r - Real.harmonic (s - 1) t) := by ring
    have hden : (t : ℚ) - (r : ℚ) = -((r : ℚ) - (t : ℚ)) := by ring
    rw [hnum, hden]
    simp only [mul_neg, div_neg, neg_div, neg_neg]

/-- The unknown scalar X has the concrete Gram-type coefficient C C^T. -/
theorem dual_entry_linear_coefficient
    {h K : ℕ} (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (i j : Fin h) :
    (Real.dualEntry s c i j).coeff 1 = ∑ r, c i r * c j r := by
  simp [Real.dualEntry]

/-- At X=0 the dual matrix entry is a completely rational finite sum. -/
theorem dual_entry_zero_value
    {h K : ℕ} (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (i j : Fin h) :
    (Real.dualEntry s c i j).eval 0 =
      ∑ r, ∑ t, c i r * c j t * Real.dualConstant s r.val t.val := by
  -- Unfold only the outer pencil definition.  In particular, do NOT
  -- distribute `C` over either finite sum; their evaluations are opaque.
  unfold Real.dualEntry
  simp only [Polynomial.eval_add, Polynomial.eval_mul,
    Polynomial.eval_C, Polynomial.eval_X, mul_zero, add_zero]

/-- The rational kernel is symmetric even before the analytic integral bridge. -/
theorem dual_entry_symmetric
    {h K : ℕ} (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (i j : Fin h) :
    Real.dualEntry s c i j = Real.dualEntry s c j i := by
  have hs :
      (∑ r, ∑ t, c i r * c j t * Real.dualConstant s r.val t.val) =
      (∑ r, ∑ t, c j r * c i t * Real.dualConstant s r.val t.val) := by
    calc
      (∑ r, ∑ t, c i r * c j t * Real.dualConstant s r.val t.val) =
          ∑ t, ∑ r, c i r * c j t * Real.dualConstant s r.val t.val := by
            rw [Finset.sum_comm]
      _ = ∑ t, ∑ r, c j t * c i r * Real.dualConstant s t.val r.val := by
        apply Finset.sum_congr rfl
        intro t _
        apply Finset.sum_congr rfl
        intro r _
        rw [dual_constant_symmetric]
        ring
      _ = (∑ r, ∑ t, c j r * c i t * Real.dualConstant s r.val t.val) := rfl
  have hd : (∑ r, c i r * c j r) = (∑ r, c j r * c i r) := by
    apply Finset.sum_congr rfl
    intro r _
    ring
  simp only [Real.dualEntry, hs, hd]

end PaperAdvances.Theorem5_1_DualSymmetric

#print axioms PaperAdvances.Theorem5_1_DualSymmetric.dual_constant_symmetric
#print axioms PaperAdvances.Theorem5_1_DualSymmetric.dual_entry_linear_coefficient
#print axioms PaperAdvances.Theorem5_1_DualSymmetric.dual_entry_symmetric
