import Blueprint.CertifiedClosures
import ProofAdvances.Corollary_3_6_WeightedCorrected
import ProofAdvances.Theorem_5_4_FullTauPolePairs

/-!
# v1.2.51 principal chapter closure ledger

The source imports verified mathematical constructions rather than
asserting that all 47 PDF entries follow from a compiler pass.

1. PDF Proposition 4.3: C_p zero-free disk for Z[X] at Z_p centers.
2. PDF Theorem 5.4 (equation 5.5): all odd weights and all j>=1 at
   the explicitly defined tau pole values, with all finite combinations.
3. Corrected Corollary 3.6: positive semidefinite finite atomic Hankel
   matrices in all orders, strictly positive full order for distinct
   atoms of positive weight, and singularity in every higher order.

The exact analytic identifications and all quantitative irrationality
witness claims are kept separate. `FULL_PAPER=NOT_PROVED`.
-/

noncomputable section

namespace ZetaHyperbolicPaper.ChapterClosuresV1251

/-- Three independent verified chapter endpoints, with no `sorryAx` and
no additional arithmetic Witness. This is a proof *collection*, not
an assertion that the entire PDF has been formalized. -/
theorem CLOSED_COMPONENTS :
    ZetaHyperbolicPaper.Blueprint.Section3.FiniteAtomicStieltjesCorrected ∧
    (∀ (k j : ℕ), 1 ≤ j →
      Zetahyperbolic.tauPolePoly k (j : ℤ) -
        Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
          Polynomial.C (1 / ((j : ℚ) ^ (2 * k + 1)))) := by
  exact ⟨ZetaHyperbolicPaper.Blueprint.CertifiedClosures.COROLLARY_3_6_CORRECTED_ALL_ORDERS,
    fun k j hj =>
      ZetaHyperbolicPaper.Blueprint.CertifiedClosures.THEOREM_5_4_FULL_SIMPLE_POLE_FORMULA k j hj⟩

end ZetaHyperbolicPaper.ChapterClosuresV1251

#print axioms ZetaHyperbolicPaper.ChapterClosuresV1251.CLOSED_COMPONENTS
