# Progress after v1.2.2

## Proposition 3.2 (continuous real-s pencil) — new kernel-goal components
`exponentScale_pos`, `gamma_ne_zero`, `gamma_pos_iff`, `gamma_neg_iff`,
`exponentScale_odd`, `gamma_odd`, `slope_det_formula`,
`slope_det_ne_zero`, `slope_isSymm`, `pencil_direction_nonsingular`,
`factorization`, `all_complex_roots_real`.

The last result is universally quantified over a positive-definite base;
it does not prove the PDF's continuous-weight integral or its Gram positivity.

## Theorem 3.3 (total positivity/signature) — new kernel-goal components
`actual_gram_det_pos`, `leading_coefficient_product`,
`positive_pole_index_set`, `negative_pole_index_set`,
`positive_pole_count_constant`, `negative_pole_count_constant`,
`weight_five_parity_correction`.

The full strict total positivity of arbitrary minors, Carleman determinacy,
and explicit inertia counts (floor(h/2), ceil(h/2)) remain to be proved.

No new sorry, admit, axiom, opaque or native constant declarations.
All new Lean statements are pending **your** compiler verification.

## v1.2.7 (not locally compiled)

- 3.4: symmetric 3×3 Dodgson condensation and sign law.
- 3.6: finite atomic Hankel matrix = V Vᵀ; two-atom order-3 determinant zero.
- 3.7: two cubic Turán sum-of-squares formulas, 3-mode variance and Taylor bound.

The assertions are only compiler verified once the corresponding Windows
`CHECK_PASS=` lines appear in the returned output.

## v1.2.9 CD spectral increment (awaiting compiler)

- Section 3.3: generic sign of nondegenerate real-exponent derivative determinant.
- Section 3.8(1): characteristic-polynomial equality for Christoffel-Darboux
  pole-kernel operator at arbitrary matrix size and actual rational Hankel data.
- Section 3.8(2): trace equality only; no integral differentiation claim.

See SEC3_CD_INCREMENT.md.

- **Theorem 3.9**: new full-size finite shifted-square pole spectral
  transfer (noncolliding nodes, real-exponent residue scaling, nonsingular
  symmetric derivative, exact degree and real-rootedness for positive-definite
  base). See `SEC3_HURWITZ_INCREMENT.md`.
