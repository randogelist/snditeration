# Source provenance

The native Lean source roots come from the project archives:

- `Zetahyperbolic-general-assembled-lean433 (2).zip`, integrated as the prior corrected core.
- `ZETAHYPERBOLIC_PAPER_CORRECTED_CORE_v1_0_0.zip`, preserving manuscript corrections and conditional/unconditional theorem distinctions.

Examined but not pulled wholesale into the main proof graph:

- `ODD_ZETA_3X3_MERGED_v0_3_0.zip`: 3×3 rational transfer constructions and separate denominator-normalized witness frontier.
- `WITNESS_FRONTIER_HANDOFF_20261022.zip`: ζ(7) finite rational witness interface whose analytic remainder is not a native result in that archive.
- `zeta5-spectral-lean (1).zip`, `MAIN_CHAIN_LEAN_ONLY (4).zip`, Chebyshev-Mastertier, and other supplied source archives: useful partial/alternative proof inputs, but they do not prove W1 and W2 for the *same* manuscript primitive ζ(5) determinant family.

A separate irrationality proof of ζ(5) would not automatically imply this paper's exponent-25687 measure or all of its Sections 5–6 statements. No independent irrationality axiom is imported.
