# v1.2.18 — Jacobi direct lemma FIX3

The user compiler stopped with sorryAx in Theorem3_8_Jacobi.unitDetPoly_derivative and its dependents (BUILD=FAIL; 119/129 checks passed).

This patch **only changes** ProofAdvances/Theorem_3_8_Jacobi.lean and cache fingerprints of its dependents.

* `unitDetPoly_derivative`: use an explicit typed `change` followed by the exact pinned Mathlib theorem `Matrix.derivative_det_one_add_X_smul`.
* `unitDet_hasDerivAt`: use the polynomial derivative theorem directly, `rw` the exact derivative coefficient, and transport along `unitDetPoly_eval`.
* No new axiom, sorry, `admit`, or conditional input is introduced.
* Previously verified modules preserved. Jacobi and its dependents are invalidated.
* Lean compilation is reserved for the user's native Windows Lean 4.33.0.

The endpoint of the actual Laplace-weight analytic Jacobi theorem remains OPEN.
