# v1.2.39 — Direct Proposition 4.3, genuine Q_p zero-free disk

User compiler checkpoint: v1.2.38 `BUILD=PASS`, `LEAN_CHECKS=137/137`, `FROZEN_PASS=135`, `REUSED_OLEAN=135`, `NEW_COMPILED=2`.
The 137 previously passed Lean sources remain byte-identical and frozen; only 2 new modules are added.

New proof targets:
1. Finite ultrametric sums of strictly norm-dominated terms, including the empty case.
2. Exact constant-coefficient norm preservation for a finite polynomial.
3. Unit-coefficient ultrametric zero-free disk, with explicit `eval != 0`.
4. Proposition 4.3 for ANY polynomial over `Z_p`, at a Z_p center and an arbitrary point of Q_p; translation preserves integral coefficients, so no extra coefficient hypothesis is needed.
5. Integer `Z[X]` specialization with natural embeddings, connecting to the original printed proposition.
6. Named principal theorem endpoint for the printed integer-polynomial case.

Precise limitation: The manuscript quantifies over alpha in C_p, whereas this round proves alpha in Q_p. A formal C_p extension is outstanding. This does not establish any irrationality/transcendence result; `FULL_PAPER=NOT_PROVED`. Neither `sorry` nor custom axioms were introduced, and only the user's native Windows Lean 4.33.0 compiler decides PASS.
