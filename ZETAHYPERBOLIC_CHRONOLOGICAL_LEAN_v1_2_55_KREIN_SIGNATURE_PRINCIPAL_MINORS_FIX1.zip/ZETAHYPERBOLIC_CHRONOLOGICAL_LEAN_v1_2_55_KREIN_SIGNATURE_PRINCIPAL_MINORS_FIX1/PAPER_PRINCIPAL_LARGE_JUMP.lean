import PAPER_PRINCIPAL_STRICT_ROLLE
import ProofAdvances.Lemma_2_2_FullNormalForm
import ProofAdvances.Lemma_2_3_FullNormalForm
import ProofAdvances.Theorem_5_4_FiniteCancellation
import ProofAdvances.Theorem_6_6_FiniteMultiweightCone

/-!
# Principal cross-section assembly: large jump

This module combines all newly proposed unconditional finite-span and
finite-dimensional conclusions. It does NOT change or close the printed
analytic and Diophantine gaps; in particular it does not produce the
one finite arithmetic witness or prove unconditional zeta(5)/zeta(7)
irrationality. The existing passed endpoint remains untouched.
-/

noncomputable section
open scoped BigOperators

namespace ZetaHyperbolicPaper.PrincipalLargeJump

/-- Complete finite normal-form pullback for every admissible k. -/
def PullbackFiniteSpan : Prop :=
  ∀ (k : ℕ), 1 ≤ k → ∀ (R : Zetahyperbolic.RatMomentElem),
    Zetahyperbolic.muFunctionalPoly k R =
      PaperAdvances.Lemma2_2_FullNormalForm.tauPulledbackNormalForm k R

/-- Finite-span Bernoulli reflection for polynomial + pole generators. -/
def ReflectionFiniteSpan : Prop :=
  ∀ (k : ℕ), 1 ≤ k → ∀ (es : Finset ℕ) (u : ℕ → ℚ)
    (rs : Finset ℤ) (v : ℤ → ℚ),
    PaperAdvances.Lemma2_3_FullNormalForm.tauReflectedFiniteSpan k es u rs v =
      -PaperAdvances.Lemma2_3_FullNormalForm.tauFiniteSpan k es u rs v

/-- Full family of finite linear combinations of pole-pair identities. -/
def PolePairCancellationFinite : Prop :=
  ∀ (s : ℕ) (J : Finset ℕ) (c : ℕ → ℚ) (X : ℚ),
    (∑ n ∈ J, c n *
      ((ManuscriptChain.Real.harmonic s (n + 1) - X) -
       (ManuscriptChain.Real.harmonic s n - X))) =
    ∑ n ∈ J, c n / (((n + 1 : ℕ) : ℚ) ^ s)

/-- These three new finite identities are mathematically unconditional. -/
theorem PRINCIPAL_FINITE_SPAN_THEOREMS_UNCONDITIONAL :
    PullbackFiniteSpan ∧ ReflectionFiniteSpan ∧ PolePairCancellationFinite := by
  refine ⟨?_, ?_, ?_⟩
  · intro k hk R
    exact PaperAdvances.Lemma2_2_FullNormalForm.FULL_PULLBACK_ALL_NORMAL_FORMS k hk R
  · intro k hk es u rs v
    exact PaperAdvances.Lemma2_3_FullNormalForm.FULL_REFLECTION_ALL_FINITE_SPANS
      k hk es u rs v
  · intro s J c X
    exact PaperAdvances.Theorem5_4_FiniteCancellation.FINITE_POLE_PAIR_CANCELLATION
      s J c X

end ZetaHyperbolicPaper.PrincipalLargeJump

#print axioms ZetaHyperbolicPaper.PrincipalLargeJump.PRINCIPAL_FINITE_SPAN_THEOREMS_UNCONDITIONAL
