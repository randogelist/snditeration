# v1.2.51 — substantial chapter statement closures

**Last actual user compiler checkpoint:** native Lean 4.33.0 `BUILD=PASS`, `LEAN_CHECKS=155/155`, v1.2.50. All those 155 module files (source and transitive closure fingerprints) are preserved exactly byte-for-byte; none is recompiled unless cache invalidation makes it necessary. Four new target modules are uncompiled.

## New formal mathematical statements

1. **Corrected Corollary 3.6:** for any finite weighted atomic measure, a nonnegative weight function gives positive semidefinite moment Hankel matrices of arbitrary order; for strictly positive weights and distinct atoms the full square matrix is positive definite; every square Hankel determinant at order `n > h` vanishes exactly. This formally demonstrates the printed all-orders-strict-positivity assertion is impossible.
2. **Theorem 5.4 (5.5):** exact `τ_X^{(2k+1)}((x-j)^-1-(x+j)^-1)=j^-(2k+1)` for every `k`, every `j≥1` (including j=1) on the original polynomial-valued `τ` pole generators; arbitrary finite rational linear combinations also proved. No new hypotheses.
3. **Proposition 4.3:** exports the already compiler-confirmed full `ℂ_p` open-disk preservation theorem for integer polynomials and `ℤ_p` centers as a distinct chapter theorem.
4. **Chapter closure interface:** formal corrected Stieltjes target of `Blueprint.Section3` is discharged, and scope separation is preserved.

## Explicit outstanding gates

Theorem 4.4 normalized determinant decay W1, spectral norm W2, numerical irrationality measure, infinite Krein theorem, arbitrary-order ordered Gram minors, and the rest of the manuscript remain open. No finite universally transferable witness has been constructed; no irrationality claim is being made. `FULL_PAPER=NOT_PROVED`. No Lean was compiled in the packaging environment.
