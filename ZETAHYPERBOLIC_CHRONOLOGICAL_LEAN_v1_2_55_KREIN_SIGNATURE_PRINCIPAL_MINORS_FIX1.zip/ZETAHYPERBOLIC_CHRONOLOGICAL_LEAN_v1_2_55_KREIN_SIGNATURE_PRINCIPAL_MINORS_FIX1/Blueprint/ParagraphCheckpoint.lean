import Blueprint.Master
import PAPER_PRINCIPAL_COMPLEX_PADIC_AND_CONE
import ProofAdvances.Corollary_3_6_FullGram
import ProofAdvances.Theorem_3_3
import ProofAdvances.Theorem_3_4
import ProofAdvances.Theorem_3_8_Actual
import ProofAdvances.Theorem_3_9_CharacterPositive
import ProofAdvances.Theorem_5_2_ActualDual
import ProofAdvances.Theorem_6_6_AnchoredSemidefiniteCone

/-!
# PDF paragraph checkpoint — indexed source versus mathematical Lean content

This stage tracks the statement/proof paragraphs attached to the 47 numbered
items, not all narrative/equation paragraphs in the 52-page PDF.
`numberedParagraphs` is a source locator. It is not itself a proof.
`CHAPTER_PARAGRAPH_PROOF_ANCHORS` is an actual conjunction proved from
existing compiler-verified theorems in every chapter (2-6).
No full-paper paragraph-coverage or arithmetic witness is asserted.
`FULL_PAPER=NOT_PROVED` until every literal mathematical theorem is discharged.
-/

namespace ZetaHyperbolicPaper.Blueprint.ParagraphCheckpoint

/-- An integration stage for a PDF numbered statement paragraph; stage names
carry no formal proof by themselves. See the actual theorem below. -/
inductive Stage where
  | indexed         -- merely source-indexed in the manuscript
  | modeled         -- some typed mathematical object exists
  | component       -- nontrivial substatement has been proved
  | corrected       -- a mathematically valid corrected statement is proved
  | literalFull     -- previous literal-scope theorem audit passed
  deriving Repr, DecidableEq

structure ParagraphEvidence where
  reference : String
  page : Nat
  chapter : Nat
  stage : Stage
  deriving Repr

/-- Exactly 47 numbered statement anchor locations in the supplied PDF.
This is not a count of every prose paragraph. -/
def numberedParagraphs : List ParagraphEvidence := [
  ⟨"Definition 2.1", 3, 2, .modeled⟩,
  ⟨"Lemma 2.2", 4, 2, .component⟩,
  ⟨"Lemma 2.3", 5, 2, .component⟩,
  ⟨"Theorem 2.4", 6, 2, .component⟩,
  ⟨"Theorem 2.5", 6, 2, .component⟩,
  ⟨"Theorem 3.1", 7, 3, .literalFull⟩,
  ⟨"Proposition 3.2", 8, 3, .component⟩,
  ⟨"Theorem 3.3", 8, 3, .component⟩,
  ⟨"Theorem 3.4", 9, 3, .component⟩,
  ⟨"Corollary 3.5", 10, 3, .modeled⟩,
  ⟨"Corollary 3.6", 11, 3, .corrected⟩,
  ⟨"Theorem 3.7", 11, 3, .component⟩,
  ⟨"Theorem 3.8", 12, 3, .component⟩,
  ⟨"Theorem 3.9", 13, 3, .component⟩,
  ⟨"Theorem 4.1", 14, 4, .component⟩,
  ⟨"Proposition 4.2", 15, 4, .indexed⟩,
  ⟨"Proposition 4.3", 15, 4, .literalFull⟩,
  ⟨"Theorem 4.4", 16, 4, .modeled⟩,
  ⟨"Theorem 4.5", 18, 4, .indexed⟩,
  ⟨"Theorem 4.6", 19, 4, .indexed⟩,
  ⟨"Theorem 4.7", 21, 4, .indexed⟩,
  ⟨"Proposition 4.8", 21, 4, .indexed⟩,
  ⟨"Conjecture 4.11", 22, 4, .indexed⟩,
  ⟨"Theorem 5.1", 22, 5, .component⟩,
  ⟨"Theorem 5.2", 23, 5, .component⟩,
  ⟨"Proposition 5.3", 24, 5, .indexed⟩,
  ⟨"Theorem 5.4", 25, 5, .component⟩,
  ⟨"Theorem 5.6", 26, 5, .indexed⟩,
  ⟨"Theorem 5.7", 28, 5, .component⟩,
  ⟨"Theorem 6.1", 29, 6, .indexed⟩,
  ⟨"Theorem 6.2", 31, 6, .indexed⟩,
  ⟨"Theorem 6.3", 32, 6, .component⟩,
  ⟨"Theorem 6.4", 33, 6, .component⟩,
  ⟨"Theorem 6.5", 34, 6, .indexed⟩,
  ⟨"Theorem 6.6", 35, 6, .component⟩,
  ⟨"Theorem 6.7", 37, 6, .indexed⟩,
  ⟨"Corollary 6.8", 38, 6, .modeled⟩,
  ⟨"Theorem 6.9", 38, 6, .component⟩,
  ⟨"Theorem 6.10", 39, 6, .component⟩,
  ⟨"Theorem 6.11", 40, 6, .indexed⟩,
  ⟨"Theorem 6.12", 42, 6, .indexed⟩,
  ⟨"Theorem 6.13", 43, 6, .indexed⟩,
  ⟨"Theorem 6.14", 45, 6, .indexed⟩,
  ⟨"Theorem 6.15", 46, 6, .indexed⟩,
  ⟨"Theorem 6.16", 47, 6, .component⟩,
  ⟨"Theorem 6.17", 48, 6, .component⟩,
  ⟨"Theorem 6.18", 49, 6, .component⟩
]

theorem NUMBERED_PDF_PARAGRAPHS_INDEXED : numberedParagraphs.length = 47 := by
  decide

/-- The nontrivial mathematical anchors for text in all five PDF chapters;
this does not imply any entire `FullChapter` proposition. -/
theorem CHAPTER_PARAGRAPH_PROOF_ANCHORS :
    ZetaHyperbolicPaper.Blueprint.Section2.PullbackFinite ∧
    ZetaHyperbolicPaper.Blueprint.Section2.ReflectionFinite ∧
    ZetaHyperbolicPaper.Blueprint.Section3.UniversalSpectralAndDisk ∧
    ZetaHyperbolicPaper.Blueprint.Section3.FiniteAtomicStieltjesCorrected ∧
    ZetaHyperbolicPaper.Blueprint.Section4.IntegralQpadicDisk ∧
    ZetaHyperbolicPaper.Blueprint.Section5.AllFinitePolePairs ∧
    ZetaHyperbolicPaper.Blueprint.Section6.FiniteMultiweightEvidence := by
  refine ⟨ZetaHyperbolicPaper.Blueprint.Section2.finite_pullback_and_reflection.1,
    ZetaHyperbolicPaper.Blueprint.Section2.finite_pullback_and_reflection.2,
    ZetaHyperbolicPaper.Blueprint.Section3.spectral_and_disk_complete,
    ?_,
    ZetaHyperbolicPaper.Blueprint.Section4.qpadic_disk_certified,
    ZetaHyperbolicPaper.Blueprint.Section5.finite_pole_cancellation_proved,
    ZetaHyperbolicPaper.Blueprint.Section6.finite_multiweight_cancellation_proved⟩
  intro h u n
  exact PaperAdvances.Corollary3_6_FullGram.finite_hankel_posSemidef u n

end ZetaHyperbolicPaper.Blueprint.ParagraphCheckpoint

/-! Proof constants checked below anchor further mathematical paragraphs in the
PDF. They were already compiler-confirmed in v1.2.50; listing them does not
promote the remainder of their printed theorem statements to proven. -/
-- Theorem 2.4: basis determinant algebra
#check ZetaHyperbolicPaper.Blueprint.Section2.basis_determinant_identity
-- Theorem 2.5: pole-derivative nonsingularity
#check ZetaHyperbolicPaper.Blueprint.Section2.exact_pole_slope
-- Theorem 3.1: spectral theorem and disk
#check ZetaHyperbolicPaper.Blueprint.Section3.spectral_and_disk_complete
-- Theorem 3.3: actual Gram determinant positivity
#check PaperAdvances.Theorem3_3.actual_gram_det_pos
-- Theorem 3.4: 3-by-3 condensation
#check PaperAdvances.Theorem3_4.symmetric_3x3_dodgson
-- Corollary 3.6: finite atomic PSD; correction required
#check PaperAdvances.Corollary3_6_FullGram.finite_hankel_posSemidef
-- Theorem 3.7: first Turan inequality
#check ZetaHyperbolicPaper.Blueprint.Section3.first_turan_complete
-- Theorem 3.8: finite spectrum transfer
#check PaperAdvances.Theorem3_8_Actual.actual_relative_charpoly_eq_pole
-- Theorem 3.9: character numerator positivity
#check PaperAdvances.Theorem3_9_CharacterPositive.all_fekete_numerators_pos
-- Proposition 4.3: full p-adic complex disk
#check ZetaHyperbolicPaper.PrincipalComplexPadicAndCone.PRINCIPAL_PROPOSITION_4_3_COMPLEX_PADIC
-- Theorem 5.2: finite dual slope positivity
#check PaperAdvances.Theorem5_2_ActualDual.actualSlope_posDef
-- Theorem 5.4: finite pole-pair cancellation
#check ZetaHyperbolicPaper.Blueprint.Section5.finite_pole_cancellation_proved
-- Theorem 6.6: finite multiweight identity
#check ZetaHyperbolicPaper.Blueprint.Section6.finite_multiweight_cancellation_proved
-- Theorem 6.6: finite anchored cone
#check PaperAdvances.Theorem6_6_AnchoredSemidefiniteCone.ANCHORED_FINITE_CONE_POSDEF

#print axioms ZetaHyperbolicPaper.Blueprint.ParagraphCheckpoint.NUMBERED_PDF_PARAGRAPHS_INDEXED
#print axioms ZetaHyperbolicPaper.Blueprint.ParagraphCheckpoint.CHAPTER_PARAGRAPH_PROOF_ANCHORS
