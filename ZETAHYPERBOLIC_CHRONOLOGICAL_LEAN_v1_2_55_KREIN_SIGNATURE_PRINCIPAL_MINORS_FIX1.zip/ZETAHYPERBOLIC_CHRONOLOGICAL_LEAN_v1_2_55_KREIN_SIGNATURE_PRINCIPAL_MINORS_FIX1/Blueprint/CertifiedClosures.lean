import Blueprint.Master
import ProofAdvances.Corollary_3_6_WeightedCorrected
import ProofAdvances.Theorem_5_4_FullTauPolePairs
import PAPER_PRINCIPAL_COMPLEX_PADIC_AND_CONE
import Mathlib.Tactic

/-!
# Chapter closure index v1.2.51 — distinct from the open master blueprint

The completed endpoints named here are actual Lean-proved propositions,
not instances of the open `FullChapter` proof-contract structures.
* Chapter 3: a corrected finite-atomic Stieltjes hierarchy; all orders
  PSD and exact determinant vanishing above finite support size.
* Chapter 4: the full integer-coefficient C_p version of Proposition 4.3.
* Chapter 5: every simple even-pole pair in the explicit tau_X action,
  including the j=1 exception, and all their finite linear combinations.

Theorem 4.4's uniform normalized determinant decay and spectral norm
witnesses remain OPEN. The entire original PDF remains NOT proved.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ZetaHyperbolicPaper.Blueprint.CertifiedClosures

/-- Completes the repaired (mathematically valid) positive semidefinite
Stieltjes-moment clause in the section-3 blueprint. -/
theorem COROLLARY_3_6_CORRECTED_ALL_ORDERS :
    ZetaHyperbolicPaper.Blueprint.Section3.FiniteAtomicStieltjesCorrected := by
  intro h u n
  exact PaperAdvances.Corollary3_6_FullGram.finite_hankel_posSemidef u n

/-- Explicit rank limitation of the same corrected hierarchy. -/
theorem COROLLARY_3_6_ZERO_ABOVE_SUPPORT (h n : ℕ) (hn : h < n)
    (u : Fin h → ℝ) :
    (PaperAdvances.Corollary3_6.finiteHankel u n).det = 0 := by
  exact PaperAdvances.Corollary3_6_WeightedCorrected.finite_hankel_det_zero_above_support
    u n hn

/-- The PDF Proposition 4.3: the full C_p zero-exclusion conclusion is
already compiler-confirmed and imported; this theorem exports it as a
standalone chapter-level end product. -/
theorem PROPOSITION_4_3_FULL_COMPLEX_PADIC
    {p : ℕ} [Fact p.Prime]
    (Q : ℤ[X]) (ξ : ℤ_[p]) (α : ℂ_[p])
    (hQ : (Q.map (Int.castRingHom (ℤ_[p]))).eval ξ ≠ 0)
    (hα : ‖α - ((ξ : ℚ_[p]) : ℂ_[p])‖ <
      ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖) :
    ‖(((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).map
      (algebraMap ℚ_[p] ℂ_[p])).eval α‖ =
      ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖ ∧
    (((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).map
      (algebraMap ℚ_[p] ℂ_[p])).eval α ≠ 0 := by
  exact ZetaHyperbolicPaper.PrincipalComplexPadicAndCone.PRINCIPAL_PROPOSITION_4_3_COMPLEX_PADIC
    Q ξ α hQ hα

/-- Exact printed Theorem 5.4 pole-pair generator formula, not just a
conditional reference to auxiliary reflection/difference identities. -/
theorem THEOREM_5_4_FULL_SIMPLE_POLE_FORMULA
    (k j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (1 / ((j : ℚ) ^ (2 * k + 1))) := by
  exact PaperAdvances.Theorem5_4_FullTauPolePairs.tau_even_pole_pair_exact k j hj

end ZetaHyperbolicPaper.Blueprint.CertifiedClosures

#print axioms ZetaHyperbolicPaper.Blueprint.CertifiedClosures.COROLLARY_3_6_CORRECTED_ALL_ORDERS
#print axioms ZetaHyperbolicPaper.Blueprint.CertifiedClosures.COROLLARY_3_6_ZERO_ABOVE_SUPPORT
#print axioms ZetaHyperbolicPaper.Blueprint.CertifiedClosures.PROPOSITION_4_3_FULL_COMPLEX_PADIC
#print axioms ZetaHyperbolicPaper.Blueprint.CertifiedClosures.THEOREM_5_4_FULL_SIMPLE_POLE_FORMULA
