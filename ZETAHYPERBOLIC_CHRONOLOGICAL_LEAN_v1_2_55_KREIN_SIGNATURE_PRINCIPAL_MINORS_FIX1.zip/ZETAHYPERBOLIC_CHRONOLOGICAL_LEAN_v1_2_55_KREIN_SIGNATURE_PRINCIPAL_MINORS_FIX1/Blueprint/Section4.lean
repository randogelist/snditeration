import Blueprint.Section3
import PAPER_PRINCIPAL_PADIC_DISK
import PAPER_04_WITNESS
import Mathlib.Tactic

/-!
# PDF section 4 (nine numbered entries, one is Conjecture 4.11)

Theorem 4.1 transfer is proved as a conditional transfer criterion.
Proposition 4.2 needs resultant/height/conjugate estimates.
Proposition 4.3 is proved over Q_p; full C_p extension is in pending v1.2.44.
Theorem 4.4 needs both quantitatively specified eventual estimates W1/W2
from the actual normalized determinant family: the `Witness` is NOT known.
Theorem 4.5 requires a separately constructed mixed ζ(3)/ζ(5) family.
Theorems 4.6/4.7 and Proposition 4.8 depend on new asymptotics and heights.
Conjecture 4.11 is *not* misreported as a theorem to prove.
-/

noncomputable section
open Polynomial

namespace ZetaHyperbolicPaper.Blueprint.Section4

/-- The actual Section-4 remaining quantified arithmetic data.
`Nonempty Witness` is an OPEN proposition; the constructor has not
been supplied by a finite accepted certificate. -/
def QuantitativeZeta5WitnessExists : Prop :=
  Nonempty ZetaHyperbolicPaper.Witness

/-- Exact original rational irrationality-measure conclusion. -/
def EffectiveZeta5Statement : Prop :=
  ZetaHyperbolicPaper.Principal.Theorem44ArithmeticStatement

/-- Printed Theorem 4.5 independent linear-form objective. -/
def CombinedWeight35Statement : Prop :=
  ZetaHyperbolicPaper.Principal.Theorem45LinearFormsTarget

/-- Native Q_p version of the printed ultrametric conclusion. -/
def IntegralQpadicDisk : Prop :=
  ∀ {p : ℕ} [Fact p.Prime],
    ∀ (Q : ℤ[X]) (ξ : ℤ_[p]) (α : ℚ_[p]),
      (Q.map (Int.castRingHom (ℤ_[p]))).eval ξ ≠ 0 →
      ‖α - (ξ : ℚ_[p])‖ <
        ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖ →
      ‖((Q.map (Int.castRingHom (ℤ_[p]))).map
        (PadicInt.Coe.ringHom)).eval α‖ =
        ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖ ∧
      ((Q.map (Int.castRingHom (ℤ_[p]))).map
        (PadicInt.Coe.ringHom)).eval α ≠ 0

theorem qpadic_disk_certified : IntegralQpadicDisk := by
  intro p hp Q ξ α hQ hα
  exact ZetaHyperbolicPaper.PrincipalPadicDisk.PRINCIPAL_THEOREM_4_3_INTEGER_ZERO_FREE_QPADIC
    Q ξ α hQ hα

/-- This closes the actual ζ(5) statement, BUT ONLY given the missing W1/W2. -/
theorem zeta5_irrationality_if_quantitative_witness
    (h : QuantitativeZeta5WitnessExists) : EffectiveZeta5Statement := by
  obtain ⟨w⟩ := h
  exact ZetaHyperbolicPaper.Principal.THEOREM_4_4_ARITHMETIC_FROM_WITNESS w

/-- Chapter-4 specification boundary: no actual Witness instance,
no unearned extension of Theorem 4.1 to arbitrary algebraic numbers. -/
structure FullChapter
    (AlgebraicResultantHeights FullComplexPadicDisk : Prop)
    (GramAndHeightAsymptotics MacroscopicCollapse RootFactorExclusion : Prop) : Prop where
  theorem_4_1_transfer :
    ∀ _w : ZetaHyperbolicPaper.Witness,
      ZetaHyperbolicPaper.Principal.Theorem44ArithmeticStatement
  proposition_4_2 : AlgebraicResultantHeights
  proposition_4_3_qpadic : IntegralQpadicDisk
  proposition_4_3_complex_padic : FullComplexPadicDisk
  theorem_4_4_witness : QuantitativeZeta5WitnessExists
  theorem_4_5_mixed : CombinedWeight35Statement
  theorem_4_6 : GramAndHeightAsymptotics
  theorem_4_7 : MacroscopicCollapse
  proposition_4_8 : RootFactorExclusion

/- The last PDF item Conjecture 4.11 is kept in the inventory as a
CONJECTURE rather than forced as an axiom or disguised as a theorem. -/

end ZetaHyperbolicPaper.Blueprint.Section4

#print axioms ZetaHyperbolicPaper.Blueprint.Section4.qpadic_disk_certified
#print axioms ZetaHyperbolicPaper.Blueprint.Section4.zeta5_irrationality_if_quantitative_witness
