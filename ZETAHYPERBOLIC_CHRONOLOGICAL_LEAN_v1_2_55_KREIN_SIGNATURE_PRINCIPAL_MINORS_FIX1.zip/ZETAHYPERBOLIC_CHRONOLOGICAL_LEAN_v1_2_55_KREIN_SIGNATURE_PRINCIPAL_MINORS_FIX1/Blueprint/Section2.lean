import Blueprint.Inventory
import PAPER_PRINCIPAL_LARGE_JUMP
import PAPER_02_03_UNCONDITIONAL
import Mathlib.Tactic

/-!
# PDF section 2 (five entries): statement and evidence contracts

Definition 2.1: functional domain. Lemma 2.2: rational pullback.
Lemma 2.3: reflection / difference. Theorem 2.4: basis invariance.
Theorem 2.5: Lagrange pole diagonalization.

The finite-normal-form and determinant statements below are actual proved
facts, not substitutes for every rational-function identity in the PDF.
`FullRationalFunctionModel` remains a genuinely OPEN specification input.
-/

noncomputable section
open scoped BigOperators
open Matrix

namespace ZetaHyperbolicPaper.Blueprint.Section2

/-- PDF Lemma 2.2, represented on every finite rational normal form. -/
def PullbackFinite : Prop :=
  ZetaHyperbolicPaper.PrincipalLargeJump.PullbackFiniteSpan

/-- PDF Lemma 2.3, reflection on every finite polynomial/simple-pole span. -/
def ReflectionFinite : Prop :=
  ZetaHyperbolicPaper.PrincipalLargeJump.ReflectionFiniteSpan

/-- A proved auxiliary to Theorem 2.4: arbitrary invertible bases multiply
all Gram determinants only by the two basis determinants. -/
def GenericBasisDeterminant : Prop :=
  ∀ (h : ℕ) (A B G : Matrix (Fin h) (Fin h) ℚ),
    (A * G * B.transpose).det = A.det * G.det * B.det

/-- An actual Theorem 2.5 consequence for all paper parameters. -/
def ExactPoleSlope : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    (ManuscriptChain.Real.derivativeMatrix p).det ≠ 0

/-- Compiled unconditional core evidence. -/
theorem finite_pullback_and_reflection : PullbackFinite ∧ ReflectionFinite := by
  exact ⟨ZetaHyperbolicPaper.PrincipalLargeJump.PRINCIPAL_FINITE_SPAN_THEOREMS_UNCONDITIONAL.1,
    ZetaHyperbolicPaper.PrincipalLargeJump.PRINCIPAL_FINITE_SPAN_THEOREMS_UNCONDITIONAL.2.1⟩

theorem basis_determinant_identity : GenericBasisDeterminant := by
  intro h A B G
  simp [Matrix.det_mul, Matrix.det_transpose, mul_assoc]

theorem exact_pole_slope : ExactPoleSlope := by
  intro p
  exact ZetaHyperbolicPaper.CHAPTER_2_DERIVATIVE p

/-- The five numbered section-2 entries are FULL only after the unrestricted
functional domain and its compatibility with finite normal forms are proved.
Supplying a proof of the separate `FullRationalFunctionModel` is NOT automated. -/
structure FullChapter (FullRationalFunctionModel : Prop) : Prop where
  definition_2_1_complete : FullRationalFunctionModel
  lemma_2_2_finite : PullbackFinite
  lemma_2_3_finite : ReflectionFinite
  theorem_2_4_basis : GenericBasisDeterminant
  theorem_2_5_slope : ExactPoleSlope

/-- A transparent closure rule with the missing domain premise visible. -/
theorem chapter2_from_domain (fullDomain : Prop) (h : fullDomain) :
    FullChapter fullDomain := by
  exact ⟨h, finite_pullback_and_reflection.1,
    finite_pullback_and_reflection.2, basis_determinant_identity,
    exact_pole_slope⟩

end ZetaHyperbolicPaper.Blueprint.Section2

#print axioms ZetaHyperbolicPaper.Blueprint.Section2.finite_pullback_and_reflection
#print axioms ZetaHyperbolicPaper.Blueprint.Section2.basis_determinant_identity
#print axioms ZetaHyperbolicPaper.Blueprint.Section2.chapter2_from_domain
