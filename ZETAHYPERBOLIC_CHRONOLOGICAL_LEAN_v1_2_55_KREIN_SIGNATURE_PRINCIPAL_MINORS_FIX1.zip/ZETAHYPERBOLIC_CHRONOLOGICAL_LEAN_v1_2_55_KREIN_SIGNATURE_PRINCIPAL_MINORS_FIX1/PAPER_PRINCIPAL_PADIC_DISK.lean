import PAPER_PRINCIPAL_STRICT_ROLLE
import ProofAdvances.Proposition_4_3_PadicDisk

/-!
# Principal endpoint extended into the arithmetic (p-adic) sector

This module imports the independently proved all-degree Turan strictness,
its equality cases, and the Q_p zero-free-disk theorem for integral polynomials.
It introduces NO witness axiom and makes NO assertion of a full irrationality
or transcendence theorem. The paper's C_p-valued Proposition 4.3 is not
claimed until the field-extension argument is formalized.
-/

noncomputable section

namespace ZetaHyperbolicPaper.PrincipalPadicDisk

open Polynomial
open PaperAdvances.Proposition4_3_PadicDisk

/-- Direct theorem 4.3 endpoint, on the original integer-polynomial
coefficients and a genuinely p-adic center. -/
theorem PRINCIPAL_THEOREM_4_3_INTEGER_ZERO_FREE_QPADIC
    {p : ℕ} [Fact p.Prime]
    (Q : ℤ[X]) (ξ : ℤ_[p]) (α : ℚ_[p])
    (hQ : (Q.map (Int.castRingHom (ℤ_[p]))).eval ξ ≠ 0)
    (hα : ‖α - (ξ : ℚ_[p])‖ <
        ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖) :
    ‖((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).eval α‖ =
      ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖ ∧
    ((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).eval α ≠ 0 := by
  exact PROPOSITION_4_3_INTEGER_QPADIC Q ξ α hQ hα

end ZetaHyperbolicPaper.PrincipalPadicDisk

#print axioms ZetaHyperbolicPaper.PrincipalPadicDisk.PRINCIPAL_THEOREM_4_3_INTEGER_ZERO_FREE_QPADIC
