import PAPER_PRINCIPAL_THEOREM
import ProofAdvances.Theorem_5_2_ActualRoots
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic

/-!
# Principal endpoint extension: Section 5 finite dual pencil and Section 4 arithmetic

All previously verified Sections 2–4 theorems are imported unchanged.

* The actual rational dual two-variable determinant of the paper has full
  degree and only real complex roots whenever its rational coefficient
  matrix has independent rows.  This is the unconditional **finite algebra**
  of Theorem 5.2, *not* the unproved analytic Beukers integral or infinite
  Krein decomposition.
* The same Section-4 Witness proves irrationality of nonzero integer and
  rational multiples of zeta(5), including the a=0 slice of printed 4.5.
* The rational approximation estimate survives integer scaling with the
  mathematically correct coefficient q/(q*d)^25687.  It is NOT presented
  as the paper's unproved unit-coefficient bound for arbitrary zeta(3)
  linear forms.

This module contains no assertion that a finite numerical certificate
proves the quantified Witness, or that the whole manuscript is complete.
-/

noncomputable section

namespace ZetaHyperbolicPaper.PrincipalExtension

open ZetaHyperbolicPaper.Principal
open PaperAdvances.Theorem5_2_ActualRoots
open PaperAdvances.Theorem5_2_ActualDual
open ManuscriptChain
open Polynomial

/-- Exact, concrete rational-moment Section 5.2 finite-dimensional theorem.
    It needs only full row rank of the coefficient matrix, and is completely
    independent of the Section 4 analytic Witness. -/
def FiniteDualSpectralStatement : Prop :=
  ∀ (h K s : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
    Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul →
      (Real.realPolynomial (Real.dualDelta s c)).natDegree = h ∧
      (∀ z : ℂ,
        Polynomial.eval₂ (algebraMap ℝ ℂ) z
          (Real.realPolynomial (Real.dualDelta s c)) = 0 →
        z.im = 0)

/-- Theorem 5.2(1), all finite dimensions; no analytic Witness input. -/
theorem FINITE_DUAL_SPECTRAL_UNCONDITIONAL :
    FiniteDualSpectralStatement := by
  intro h K s c hc
  constructor
  · exact actualDualDelta_natDegree s c hc
  · intro z hz
    exact actualDualDelta_complex_roots_real s c hc z hz

/-- Actual rational Beukers polynomial factorization, at the same scope. -/
theorem FINITE_DUAL_FACTORIZATION_UNCONDITIONAL
    {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul) :
    ∃ beta : Fin h → ℝ,
      Real.realPolynomial (Real.dualDelta s c) =
        Polynomial.C ((actualSlope s c).det) *
          ∏ i, ((Polynomial.X : ℝ[X]) +
            Polynomial.C (beta i - Real.zeta s)) := by
  obtain ⟨beta, hfactor⟩ :=
    PaperAdvances.Theorem5_2_RealRoots.positive_slope_factorization
      (actualPencil s c) (actualSlope_posDef s c hc)
  refine ⟨beta, ?_⟩
  rw [← actualPencil_detPolynomial]
  exact hfactor

/-- Rational-affine closure of witness-dependent zeta(5) irrationality.
    This does not assert independence of zeta(5) and zeta(3). -/
theorem RATIONAL_AFFINE_ZETA5_IRRATIONAL
    (w : ZetaHyperbolicPaper.Witness) (q r : ℚ) (hq : q ≠ 0) :
    Irrational ((q : ℝ) * (riemannZeta 5).re + (r : ℝ)) := by
  have hqz : Irrational ((q : ℝ) * (riemannZeta 5).re) :=
    irrational_ratCast_mul_iff.mpr
      ⟨hq, ZetaHyperbolicPaper.WITNESS_IMPLIES_IRRATIONAL_ZETA5 w⟩
  exact irrational_add_ratCast_iff.mpr hqz

/-- Integer multiples of zeta(5) are irrational from the SAME Witness. -/
theorem INTEGER_MULTIPLE_ZETA5_IRRATIONAL
    (w : ZetaHyperbolicPaper.Witness) (b : ℤ) (hb : b ≠ 0) :
    Irrational ((b : ℝ) * (riemannZeta 5).re) := by
  exact irrational_intCast_mul_iff.mpr
    ⟨hb, ZetaHyperbolicPaper.WITNESS_IMPLIES_IRRATIONAL_ZETA5 w⟩

/-- Proven a=0 part of the irrationality component of printed Theorem 4.5.
    The general a*zeta(3) addition and the printed quantitative exponent
    for that combination remain OPEN. -/
theorem THEOREM_4_5_A_ZERO_IRRATIONAL
    (w : ZetaHyperbolicPaper.Witness) (b : ℤ) (hb : 0 < b) :
    Irrational ((b : ℝ) * (riemannZeta 5).re +
      (0 : ℝ) * (riemannZeta 3).re) := by
  have h := INTEGER_MULTIPLE_ZETA5_IRRATIONAL w b (ne_of_gt hb)
  simpa only [zero_mul, add_zero] using h

/-- Exact, correctly rescaled effective lower bound for any positive
    integer multiple of zeta(5).  Original measure exponent is unchanged,
    but the prefactor is q/(q*d)^25687, NOT d^-25687.
    This is a nontrivial quantitative branch of the paper's linear forms. -/
theorem SCALED_ZETA5_EXPLICIT_MEASURE
    (w : ZetaHyperbolicPaper.Witness)
    (q : ℕ) (hq : 0 < q) (a : ℤ) (d : ℕ) (hd : 0 < d)
    (hlarge : ManuscriptChain.MainChain.indexDenominatorThreshold
      (w.start + 1) ≤ q * d) :
    (q : ℝ) / (((q * d : ℕ) : ℝ) ^ 25687) <
      |(q : ℝ) * (riemannZeta 5).re - (a : ℝ) / (d : ℝ)| := by
  have hqR : 0 < (q : ℝ) := by exact_mod_cast hq
  have hq0 : (q : ℝ) ≠ 0 := ne_of_gt hqR
  have hd0 : (d : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hd)
  have hratio :
      (q : ℝ) * ((a : ℝ) / (((q * d : ℕ) : ℝ))) =
        (a : ℝ) / (d : ℝ) := by
    simp only [Nat.cast_mul]
    field_simp [hq0, hd0] <;> ring
  have hnorm :
      |(q : ℝ) * (riemannZeta 5).re - (a : ℝ) / (d : ℝ)| =
        (q : ℝ) *
          |(riemannZeta 5).re - (a : ℝ) / (((q * d : ℕ) : ℝ))| := by
    calc
      |(q : ℝ) * (riemannZeta 5).re - (a : ℝ) / (d : ℝ)| =
          |(q : ℝ) * ((riemannZeta 5).re -
            (a : ℝ) / (((q * d : ℕ) : ℝ)))| := by
            congr 1
            rw [mul_sub, hratio]
      _ = (q : ℝ) *
            |(riemannZeta 5).re - (a : ℝ) / (((q * d : ℕ) : ℝ))| := by
            rw [abs_mul, abs_of_pos hqR]
  have hmeasure :=
    ZetaHyperbolicPaper.Principal.THEOREM_4_4_EXPLICIT_INEQUALITY
      w a (q * d) (Nat.mul_pos hq hd) hlarge
  calc
    (q : ℝ) / (((q * d : ℕ) : ℝ) ^ 25687) =
        (q : ℝ) * (1 / (((q * d : ℕ) : ℝ) ^ 25687)) := by
          simp only [div_eq_mul_inv, one_mul]
    _ < (q : ℝ) *
          |(riemannZeta 5).re - (a : ℝ) / (((q * d : ℕ) : ℝ))| :=
            mul_lt_mul_of_pos_left hmeasure hqR
    _ = |(q : ℝ) * (riemannZeta 5).re -
          (a : ℝ) / (d : ℝ)| := hnorm.symm

/-- Both previously separate sections now share one named endpoint. -/
def PrincipalWithFiniteDualStatement : Prop :=
  PrincipalTheoremStatement ∧ FiniteDualSpectralStatement ∧
    (∀ b : ℤ, b ≠ 0 →
      Irrational ((b : ℝ) * (riemannZeta 5).re))

/-- Extended finite spectral-plus-arithmetic theorem: the only analytic
    input remains exactly the prior Section-4 Witness. -/
theorem PRINCIPAL_WITH_FINITE_DUAL_FROM_WITNESS
    (w : ZetaHyperbolicPaper.Witness) :
    PrincipalWithFiniteDualStatement := by
  exact ⟨PAPER_PRINCIPAL_THEOREM_FROM_WITNESS w,
    FINITE_DUAL_SPECTRAL_UNCONDITIONAL,
    INTEGER_MULTIPLE_ZETA5_IRRATIONAL w⟩

end ZetaHyperbolicPaper.PrincipalExtension

#check ZetaHyperbolicPaper.PrincipalExtension.FINITE_DUAL_SPECTRAL_UNCONDITIONAL
#check ZetaHyperbolicPaper.PrincipalExtension.FINITE_DUAL_FACTORIZATION_UNCONDITIONAL
#check ZetaHyperbolicPaper.PrincipalExtension.THEOREM_4_5_A_ZERO_IRRATIONAL
#check ZetaHyperbolicPaper.PrincipalExtension.SCALED_ZETA5_EXPLICIT_MEASURE
#check ZetaHyperbolicPaper.PrincipalExtension.PRINCIPAL_WITH_FINITE_DUAL_FROM_WITNESS

#print axioms ZetaHyperbolicPaper.PrincipalExtension.FINITE_DUAL_SPECTRAL_UNCONDITIONAL
#print axioms ZetaHyperbolicPaper.PrincipalExtension.FINITE_DUAL_FACTORIZATION_UNCONDITIONAL
#print axioms ZetaHyperbolicPaper.PrincipalExtension.THEOREM_4_5_A_ZERO_IRRATIONAL
#print axioms ZetaHyperbolicPaper.PrincipalExtension.SCALED_ZETA5_EXPLICIT_MEASURE
#print axioms ZetaHyperbolicPaper.PrincipalExtension.PRINCIPAL_WITH_FINITE_DUAL_FROM_WITNESS
