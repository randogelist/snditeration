# v1.2.31 — dual actual roots fix2

Input: native Lean 4.33.0 checkpoint `BUILD=FAIL`, `LEAN_CHECKS=129/131`,
first failing module `ProofAdvances/Theorem_5_2_ActualRoots.lean`.

The previous version's affine evaluation tactic did not close a goal at line 73.
This version isolates rational entries `a`, `b`, proves evaluation of the
concrete affine polynomial explicitly, and applies the already checked
`dual_entry_linear_coefficient` theorem. The matrix of rational polynomials
is explicitly annotated as `Matrix (Fin h) (Fin h) ℚ[X]` before `.map`,
removing the invalid projection from a bare function. The polynomial matrix
identity is proved via `Polynomial.funext` and the pointwise matrix identity.
The determinant transport uses the resulting well-typed matrix and
`RingHom.map_det` as in the previously checked manuscript pencil theorem.

Only `Theorem_5_2_ActualRoots.lean` is edited. Its unproved chronological
consumer has its dependency key invalidated. Every other already-passed
module is frozen and source-identical. No Lean compilation performed locally.
The user's native Windows compiler is the sole acceptance authority.
`FULL_PAPER=NOT_PROVED` remains.
