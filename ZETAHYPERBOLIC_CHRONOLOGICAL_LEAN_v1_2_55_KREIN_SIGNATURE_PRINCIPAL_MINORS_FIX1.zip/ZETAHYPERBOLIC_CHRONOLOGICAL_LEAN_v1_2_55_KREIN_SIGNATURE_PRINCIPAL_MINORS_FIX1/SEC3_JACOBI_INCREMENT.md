# v1.2.13 — corrected finite Jacobi proof path

Target: `ProofAdvances.Theorem_3_8_Jacobi.lean` and the downstream
`PAPER_CHRONOLOGICAL_CHAIN.lean` (unchanged source, changed dependency).

Exact unconditional assertions:
- polynomial trace coefficient for `det (I+X A)`;
- real analytic derivative `HasDerivAt (fun t => det (I+t A)) (trace A) 0`;
- pointwise nonsingular affine determinant factorization;
- real affine determinant and log-determinant derivatives;
- actual odd-zeta Gram affine log derivative equals the CD pole trace.

These are finite matrix results; the paper's separate Laplace-tau integral
identity remains an open analytic bridge. No witness is introduced.

The prior v1.2.12 Jacobi source did not compile and contained `sorryAx`
dependencies; its four failed proof terms were not saved as a frozen pass.
The v1.2.13 module is a candidate awaiting the user's compiler.
