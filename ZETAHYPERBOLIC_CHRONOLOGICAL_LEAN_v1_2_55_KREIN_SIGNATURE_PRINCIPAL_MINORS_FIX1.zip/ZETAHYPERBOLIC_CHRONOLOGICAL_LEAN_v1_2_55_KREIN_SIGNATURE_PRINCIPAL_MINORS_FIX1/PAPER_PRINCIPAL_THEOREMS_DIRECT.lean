import PAPER_PRINCIPAL_THEOREM_EXTENDED
import ProofAdvances.Theorem_3_7_AllDegrees

/-!
# Principal theorem advance: direct theorem proof, not an interface-only wrapper

The Section 3.7 first-derivative Turan/Laguerre inequality is proved
for every actual rational odd-zeta Hankel determinant (all finite sizes),
and the Section 5.2 analogous theorem for every full-rank finite dual
Beukers determinant. Neither conclusion assumes the Section-4 Witness.

The old principal theorem remains a separate, explicitly
Witness-conditional Section-4 arithmetic endpoint. This module combines
that endpoint with the NEW unconditional theorem-level inequalities.
No finite Witness or full 52-page theorem is asserted.
-/

noncomputable section

namespace ZetaHyperbolicPaper.DirectPrincipal

open PaperAdvances.Theorem3_7_AllDegrees

/-- The principal proved part of Theorem 3.7, entirely on the actual
odd-zeta determinant and quantified over every admissible size. -/
def OddZetaGlobalTuran : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p → ∀ x : ℝ,
      0 ≤ turan (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.delta p)) x

/-- Finite Section 5.2 dual analogue, with only the already-motivated
full-row-rank condition on its coefficient basis. -/
def DualBeukersGlobalTuran : Prop :=
  ∀ (h K s : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
    Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul →
      ∀ x : ℝ,
        0 ≤ turan (ManuscriptChain.Real.realPolynomial
          (ManuscriptChain.Real.dualDelta s c)) x

/-- Both new mathematical theorem branches have unconditional proofs. -/
theorem PRINCIPAL_TURAN_THEOREMS_UNCONDITIONAL :
    OddZetaGlobalTuran ∧ DualBeukersGlobalTuran := by
  constructor
  · intro p hp x
    exact THEOREM_3_7_ACTUAL_ALL_DEGREES p hp x
  · intro h K s c hc x
    exact THEOREM_5_2_ACTUAL_DUAL_TURAN s c hc x

/-- This assembled endpoint extends the already existing Witness-conditional
arithmetic theorem with TWO new unconditional all-degree inequalities. -/
def PrincipalWithTuran (w : ZetaHyperbolicPaper.Witness) : Prop :=
  ZetaHyperbolicPaper.PrincipalExtension.PrincipalWithFiniteDualStatement ∧
    OddZetaGlobalTuran ∧ DualBeukersGlobalTuran

theorem PRINCIPAL_WITH_TURAN_FROM_WITNESS
    (w : ZetaHyperbolicPaper.Witness) : PrincipalWithTuran w := by
  exact ⟨ZetaHyperbolicPaper.PrincipalExtension.PRINCIPAL_WITH_FINITE_DUAL_FROM_WITNESS w,
    PRINCIPAL_TURAN_THEOREMS_UNCONDITIONAL.1,
    PRINCIPAL_TURAN_THEOREMS_UNCONDITIONAL.2⟩

end ZetaHyperbolicPaper.DirectPrincipal

#print axioms ZetaHyperbolicPaper.DirectPrincipal.PRINCIPAL_TURAN_THEOREMS_UNCONDITIONAL
#print axioms ZetaHyperbolicPaper.DirectPrincipal.PRINCIPAL_WITH_TURAN_FROM_WITNESS
