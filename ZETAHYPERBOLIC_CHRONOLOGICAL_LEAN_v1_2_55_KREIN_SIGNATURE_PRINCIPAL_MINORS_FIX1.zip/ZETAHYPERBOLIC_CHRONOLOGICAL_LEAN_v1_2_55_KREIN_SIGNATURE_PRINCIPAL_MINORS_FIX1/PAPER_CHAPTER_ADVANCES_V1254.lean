import Blueprint.ParagraphCheckpointV1254
import ProofAdvances.Corollary_3_6_PowerSumExtrema
import ProofAdvances.Theorem_5_2_FiniteKreinPolarization
import Blueprint.CertifiedClosures
import Mathlib.Tactic

/-!
# v1.2.54 — proof progress beyond the frozen chapter/paragraph checkpoint

The exact weighted finite-support determinant criterion is closed in
Section 3, the sharp finite moment max bounds are closed in Section 3,
and the exact quintic finite Krein polarization is closed in Section 5.
This does not import an infinite Beukers integral or solve Theorem 4.4.
The chapter status of the 47 PDF items is not inflated by these results.
-/

noncomputable section
open scoped BigOperators

namespace ZetaHyperbolicPaper.ChapterAdvancesV1254

/-- Section 3: the complete strict/zero determinant support boundary. -/
theorem COROLLARY_3_6_EXACT_SUPPORT_THRESHOLD
    {h : ℕ} (u w : Fin h → ℝ)
    (hu : Function.Injective u) (hw : ∀ i, 0 < w i) (n : ℕ) :
    0 < (PaperAdvances.Corollary3_6_WeightedCorrected.weightedHankel u w n).det ↔
      n ≤ h := by
  exact PaperAdvances.Corollary3_6_ExactFiniteRank.weighted_det_pos_iff_order_le_support
    u w hu hw n

/-- Section 5: finite binomial-index sum identity from equation (5.4). -/
theorem THEOREM_5_2_FINITE_KREIN_IDENTITY (a b : Fin 6 → ℝ) :
    PaperAdvances.Theorem5_2_FiniteKreinPolarization.quinticBilinear a b / 720 =
      (PaperAdvances.Theorem5_2_FiniteKreinPolarization.kreinPlus a b -
       PaperAdvances.Theorem5_2_FiniteKreinPolarization.kreinMinus a b) / 1440 := by
  exact PaperAdvances.Theorem5_2_FiniteKreinPolarization.quintic_polarization a b

end ZetaHyperbolicPaper.ChapterAdvancesV1254

#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1254.COROLLARY_3_6_EXACT_SUPPORT_THRESHOLD
#print axioms ZetaHyperbolicPaper.ChapterAdvancesV1254.THEOREM_5_2_FINITE_KREIN_IDENTITY
