# Verification ledger at release

- **Compiler-verified checkpoint supplied by user:** v1.2.11, 120/120 PASS, no sorryAx on reported endpoints.
- **Pending compiler validation:** v1.2.13 Jacobi trace proof; v1.2.14 shifted-pole proof; v1.2.15 five new theorem modules and modified main chain.
- **Previously passing Lean source files changed:** 0.
- **Existing chronological main source changed:** 1 (requires recompile).
- **New source files:** 5.
- **Total imported Lean compilation targets:** 127.
- **Native compiler:** user-controlled Lean 4.33.0 on Windows.
- **Local Lean compilation:** intentionally NOT performed.
- **Claims not proved:** Full paper; Laplace Gram integral derivative; Hurwitz/Dirichlet actual integral evaluation; two-variable Beukers integral; infinite tails and general p-adic estimates; existence of a finite witness that implies all of these.

The first 120 targets are eligible for source/dependency-verified frozen artifact reuse, not automatically accepted merely because a manifest contains their names. Full compilation and axiom audits are the user's compiler's responsibility.
