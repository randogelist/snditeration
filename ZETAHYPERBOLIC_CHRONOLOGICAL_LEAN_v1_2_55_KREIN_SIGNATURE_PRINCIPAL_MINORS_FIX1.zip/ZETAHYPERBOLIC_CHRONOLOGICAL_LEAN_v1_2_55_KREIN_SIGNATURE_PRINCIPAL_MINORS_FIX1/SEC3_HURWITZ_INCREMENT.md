# v1.2.14 — Theorem 3.9 finite shifted-pole transfer

New file: `ProofAdvances/Theorem_3_9_ShiftedPole.lean`.

New explicit proof terms (pending user compiler):
- `poleV_det_ne_zero`, using Vandermonde interpolation for injective nodes;
- `poleM_det_formula` and `poleM_det_ne_zero`, for all finite matrix sizes;
- `poleM_isSymm` and symmetric affine-pencils;
- `polePencil_degree`, `polePencil_center_ne_zero`, and `polePencil_complex_roots_real`;
- `shiftedSquareNode_injective`: negative-square poles at N+a+theta are distinct for theta>0;
- `shiftedGamma_ne_zero`: real-exponent scaling preserves nonzero residues;
- `hurwitz_slope_nonsingular` and `hurwitz_complex_roots_real`.

**Not proved by this module:** the paper's analytic Hurwitz moment identity,
positivity of its actual shifted Gram integral, or a complete Dirichlet
character integral realization. The generic `G.PosDef` argument is a domain
condition of an all-matrices theorem, not an extra input added to Witness.

The v1.2.13 Jacobi file has not yet received a compiler PASS from the user.
The previous verified frozen baseline is 120/120 (v1.2.11). If the pending
Jacobi source fails, report the exact error and do not freeze it.

One ZIP, one `run.cmd`, native Windows Lean 4.33.0, no local compilation.
