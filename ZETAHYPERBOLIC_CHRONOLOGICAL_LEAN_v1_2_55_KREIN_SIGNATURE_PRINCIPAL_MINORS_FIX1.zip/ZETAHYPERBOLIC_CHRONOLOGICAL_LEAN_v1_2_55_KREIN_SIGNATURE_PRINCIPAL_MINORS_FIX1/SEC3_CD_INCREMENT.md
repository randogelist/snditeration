# Section 3 continuation — v1.2.9

**Previous compiler baseline:** native Windows Lean 4.33.0 `117/117 PASS` as
reported by the user on 2026-10-24. These 117 modules retain their source SHA
and CAS import-closure keys except the changed main entry point.

**New Lean modules awaiting user's compiler (3):**

1. `ProofAdvances/Theorem_3_3_Sign.lean`: full-size determinant-sign equivalence
   for the continuous real-exponent slope, using its *strictly positive*
   Vandermonde squared factor. This is not the paper's explicit inertia count.
2. `ProofAdvances/Theorem_3_8_Kernel.lean`: arbitrary-size AB/BA characteristic
   polynomial identity identifying the relative operator and its
   Christoffel–Darboux pole-kernel operator; also the trace identity and kernel
   matrix entry formula.
3. `ProofAdvances/Theorem_3_8_Actual.lean`: connects the generic identity
   to the manuscript's **actual rational derivative matrix and odd-zeta Gram**;
   recovers pole residues at `s = 2*k+1` and proves the exact characteristic
   polynomial and trace equality for those matrices.

`PAPER_CHRONOLOGICAL_CHAIN.lean` now exposes all three developments in order.

## What is NOT claimed

- No construction of the explicit real-s continuous Gram integral, or its
  positivity, beyond the previous source.
- No proof of all mixed Hankel minors or explicit Sylvester inertia counts.
- No arbitrary-size root interlacing or corrected full J-fraction yet.
- No identification of the symmetric `G^-1/2 M G^-1/2` spectrum or the
  **differentiation under the integral sign** in the paper's Theorem 3.8(2).
- No new odd-zeta irrationality theorem; the Section-4 single Witness is
  preserved and not asserted to exist.

No sorry, admit or custom axiom was introduced in the new sources.

## Runtime

`run.cmd` compiles the three new modules and the updated entry point; verified
unchanged `.olean` files are reused by source hash, complete import-closure key,
and compiler/Mathlib fingerprint. Static checks only were run during packaging.
