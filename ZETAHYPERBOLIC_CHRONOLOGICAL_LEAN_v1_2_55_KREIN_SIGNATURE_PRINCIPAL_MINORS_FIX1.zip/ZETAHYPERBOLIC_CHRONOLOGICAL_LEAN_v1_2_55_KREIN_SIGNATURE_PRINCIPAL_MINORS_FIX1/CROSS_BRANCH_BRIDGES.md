# Candidate branch connections (without claiming new theorems)

## GP KQ BKQR XY / IMPACTG 3x3

`ODD_ZETA_3X3_MERGED_v0_3_0.zip` includes valid finite matrix/eta
identifications and a `ThreeByThreeFrontier` conditional theorem. The finite
ratios `R35*R57` do NOT directly imply irrationality of the separate
zeta values, much less the exponential primitive Hankel determinant decay
needed by the manuscript. The missing link is an actual family of polynomial
witnesses with denominator-normalized error tending to zero and an explicit
identification of that family with the paper's `P_{k,n}` (or a separate
integer linear form yielding irrationality).

## Chebyshev–Mastertier ζ(7)

The uploaded native branch has exact rational series and Chebyshev
identities. Its own checkpoint says several native endpoint modules were
not compiled. Even an independent irrationality witness for ζ(7) would not
establish Theorems 5.2, 5.6, 6.1 etc. of this paper.

## Zeta(5) external Lean completion

The public `mo271/Zeta5` repository (https://github.com/mo271/Zeta5)
reports a self-contained Lean 4.34.0-rc1 proof of irrationality of ζ(5)
with only Lean's three usual logical axioms. This is a separate completion
of Fauzan's proof, NOT a proof of the entire Prince Anand manuscript and
NOT an effective measure 25687 certificate. Its toolchain and mathlib pins
are different from this 4.33 source. In particular, no direct imported
`Apery` theorem is silently assumed by this package.

The `danromik/zeta5-irrationality` formalization
(https://github.com/danromik/zeta5-irrationality) uses an external PNT
axiom according to its README. It is not a zero-custom-axiom endpoint.

## How to bridge correctly

A theorem that genuinely discharges the manuscript's remaining direct
irrationality premise must prove the normalized decay for the SAME
primitive determinant family. That is stronger than merely importing the
truth of `Irrational (riemannZeta 5).re`.

The final quantitative route also must prove the `11.411 K` norm bound
and normalize the integer polynomial family, rather than using a
syntactically discharged but unsupported comparison predicate.
