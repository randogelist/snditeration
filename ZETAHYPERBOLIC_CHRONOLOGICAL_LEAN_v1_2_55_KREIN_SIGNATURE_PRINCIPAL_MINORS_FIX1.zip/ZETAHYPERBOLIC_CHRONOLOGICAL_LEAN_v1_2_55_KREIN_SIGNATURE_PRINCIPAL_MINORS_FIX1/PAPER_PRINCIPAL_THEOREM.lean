import PAPER_MAIN_CHAIN

/-!
# Principal mathematical theorem endpoint for the ZETAHYPERBOLIC manuscript

This file states the principal results at the level of the original mathematical
objects, not just a list of compiled modules. It cleanly separates:

1. **UNCONDITIONAL** general odd-weight spectral hyperbolicity and exact zero-free disks;
2. **WITNESS-CONDITIONAL** effective irrationality measure 25687 and irrationality of ζ(5);
3. **OPEN** the separate printed Theorem 4.5 on b ζ(5) + a ζ(3).

The Section-4 `Witness` is the actual two-bound quantified infinite-family
hypothesis of PAPER_04_WITNESS.  No theorem in this file asserts that such a
witness exists, nor that it can currently be checked from finite data.

Theorems below use only existing proved implications. Axiom audit must be
limited to standard axioms: propext, Classical.choice, Quot.sound. No sorry.
-/

noncomputable section

namespace ZetaHyperbolicPaper.Principal

/-- Theorem 3.1: actual odd-weight primitive Hankel determinants have full
spectral factorization, degree, center, real roots, and a positive gap. -/
def UniversalSpectralStatement : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p

/-- Stronger exact nearest-root zero-free disk in the complex plane. -/
def ExactZeroFreeDiskStatement : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ∃ radius : ℝ, 0 < radius ∧
        (∀ z : ℂ,
          ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
            ¬ ManuscriptChain.General.ComplexRoot p z) ∧
        (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
          ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius)

/-- Theorem 4.4's precise arithmetic conclusion: eventual irrationality
measure |ζ(5)-a/b| > b⁻²⁵⁶⁸⁷, with some denominator cutoff. -/
def EffectiveZeta5MeasureStatement : Prop :=
  ∃ b₀ : ℕ,
    ManuscriptChain.RealTransfer.RationalMeasure
      (riemannZeta 5).re 25687 b₀

/-- Section-4 principal arithmetic endpoint, including strict irrationality. -/
def Theorem44ArithmeticStatement : Prop :=
  EffectiveZeta5MeasureStatement ∧ Irrational (riemannZeta 5).re

/-- This is the precise, audit-ready principal endpoint reached by the
currently proved Section-2/3 and single-Witness Section-4 implications. -/
def PrincipalTheoremStatement : Prop :=
  UniversalSpectralStatement ∧
  ExactZeroFreeDiskStatement ∧
  Theorem44ArithmeticStatement

/-- The genuine unconditional part of the principal theorem. -/
theorem UNIVERSAL_SPECTRAL_UNCONDITIONAL : UniversalSpectralStatement := by
  intro p hp
  exact ZetaHyperbolicPaper.CHAPTER_3_SPECTRAL p hp

/-- The exact zero-free radius is unconditional for each admissible family. -/
theorem EXACT_DISKS_UNCONDITIONAL : ExactZeroFreeDiskStatement := by
  intro p hp
  exact ZetaHyperbolicPaper.CHAPTER_3_EXACT_DISK p hp

/-- The displayed numerical power bound is a theorem *given* the actual
uniform decay/spectral Witness. The cutoff is explicitly specified. -/
theorem ZETA5_EFFECTIVE_MEASURE_FROM_WITNESS
    (w : ZetaHyperbolicPaper.Witness) :
    EffectiveZeta5MeasureStatement := by
  exact ⟨ManuscriptChain.MainChain.indexDenominatorThreshold (w.start + 1),
    ZetaHyperbolicPaper.WITNESS_IMPLIES_EFFECTIVE_MEASURE w⟩

/-- Exact inequality in manuscript Theorem 4.4, including a and b. -/
theorem THEOREM_4_4_EXPLICIT_INEQUALITY
    (w : ZetaHyperbolicPaper.Witness) (a : ℤ) (b : ℕ)
    (hb : 0 < b)
    (hlarge : ManuscriptChain.MainChain.indexDenominatorThreshold
      (w.start + 1) ≤ b) :
    1 / (b : ℝ) ^ 25687 <
      |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  exact ZetaHyperbolicPaper.WITNESS_IMPLIES_EFFECTIVE_MEASURE
    w a b hb hlarge

/-- All the currently justified principal arithmetic assertions from
only one explicitly described Witness, without extra side assumptions. -/
theorem THEOREM_4_4_ARITHMETIC_FROM_WITNESS
    (w : ZetaHyperbolicPaper.Witness) :
    Theorem44ArithmeticStatement := by
  exact ⟨ZETA5_EFFECTIVE_MEASURE_FROM_WITNESS w,
    ZetaHyperbolicPaper.WITNESS_IMPLIES_IRRATIONAL_ZETA5 w⟩

/-- Named principal theorem endpoint: ONE quantified analytic Witness is the
only external hypothesis; Sections 2–3 are discharged unconditionally. -/
theorem PAPER_PRINCIPAL_THEOREM_FROM_WITNESS
    (w : ZetaHyperbolicPaper.Witness) :
    PrincipalTheoremStatement := by
  exact ⟨UNIVERSAL_SPECTRAL_UNCONDITIONAL,
    EXACT_DISKS_UNCONDITIONAL,
    THEOREM_4_4_ARITHMETIC_FROM_WITNESS w⟩

/-- The exact remaining existence question for this scoped endpoint.
This implication is NOT a theorem establishing existence of a Witness. -/
theorem PAPER_PRINCIPAL_THEOREM_IF_WITNESS_EXISTS
    (hw : Nonempty ZetaHyperbolicPaper.Witness) :
    PrincipalTheoremStatement := by
  obtain ⟨w⟩ := hw
  exact PAPER_PRINCIPAL_THEOREM_FROM_WITNESS w

/-- Printed Theorem 4.5 is a separate currently OPEN target: combined
ζ(5) and ζ(3) irrationality and the SAME effective exponent. -/
def Theorem45LinearFormsTarget : Prop :=
  ∀ a b : ℤ, 0 < b →
    (a : ℝ) < (Real.pi ^ 2 / 3) * (b : ℝ) →
      Irrational ((b : ℝ) * (riemannZeta 5).re +
        (a : ℝ) * (riemannZeta 3).re) ∧
      (∃ q₀ : ℕ,
        ManuscriptChain.RealTransfer.RationalMeasure
          ((b : ℝ) * (riemannZeta 5).re +
            (a : ℝ) * (riemannZeta 3).re) 25687 q₀)

/-- Full main Section-4 target is deliberately NOT claimed from the
existing ζ(5)-only Witness. Theorem 4.5 requires separate analytic work. -/
def FullPrincipalSection4Target : Prop :=
  PrincipalTheoremStatement ∧ Theorem45LinearFormsTarget

end ZetaHyperbolicPaper.Principal

#check ZetaHyperbolicPaper.Principal.PrincipalTheoremStatement
#check ZetaHyperbolicPaper.Principal.PAPER_PRINCIPAL_THEOREM_FROM_WITNESS
#check ZetaHyperbolicPaper.Principal.PAPER_PRINCIPAL_THEOREM_IF_WITNESS_EXISTS
#check ZetaHyperbolicPaper.Principal.FullPrincipalSection4Target

#print axioms ZetaHyperbolicPaper.Principal.UNIVERSAL_SPECTRAL_UNCONDITIONAL
#print axioms ZetaHyperbolicPaper.Principal.EXACT_DISKS_UNCONDITIONAL
#print axioms ZetaHyperbolicPaper.Principal.THEOREM_4_4_EXPLICIT_INEQUALITY
#print axioms ZetaHyperbolicPaper.Principal.PAPER_PRINCIPAL_THEOREM_FROM_WITNESS
#print axioms ZetaHyperbolicPaper.Principal.PAPER_PRINCIPAL_THEOREM_IF_WITNESS_EXISTS
