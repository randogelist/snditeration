import PAPER_02_03_UNCONDITIONAL
import ZETA5_DIRECT_IRRATIONALITY

/-!
# Paper Section 4 — single explicit Witness interface

ONLY the `Witness` argument remains open in the main endpoint.
The witness is NOT known to exist. It contains TWO independent quantified
quantitative assertions on the paper's actual primitive ζ(5) determinant:
(1) eventual normalized quadratic value decay; (2) the printed uniform
11.411 spectral factor bound. Neither is proved by merely exhibiting a
finite rational polynomial. All analytic Gram positivity, primitive
normalization, determinant degree, and denominator-index selection are
already proved by the imported native Lean modules.

Packaging two substantive inequalities in one structure is syntactically
one hypothesis, NOT a proof that those estimates are equivalent or that the
paper supplies an independently verified finite witness.
-/

noncomputable section

namespace ZetaHyperbolicPaper

/-- The Gram positivity theorem is already available without a witness. -/
def gramFamily (start : ℕ) :
    ∀ n : ℕ, start + 1 ≤ n →
      (ManuscriptChain.Real.gram
        (ManuscriptChain.Real.mainParameters n)
        (ManuscriptChain.Real.zeta 5)).PosDef := by
  intro n hn
  exact ManuscriptChain.MainChain.main_gram_posDef n (by omega)

/-- A single conditional argument for the Section-4 effective measure.
    Both obligations refer to the *same* actual primitive Hankel family.
    The root factorization is constructed from the proved Gram positivity. -/
structure Witness where
  start : ℕ
  normalized_decay :
    ∀ n : ℕ, start + 1 ≤ n →
      |ManuscriptChain.RealTransfer.evalReal
        ((ManuscriptChain.MainChain.primitiveMainNormalization start).Q n)
        ManuscriptChain.MainChain.zeta5| ≤
        ManuscriptChain.MainChain.decayBudget n
  spectral_bound :
    ∀ n : ℕ, ∀ hn : start + 1 ≤ n,
      ∀ i : Fin ((ManuscriptChain.Real.mainParameters n).h),
        |(ManuscriptChain.MainChain.mainRootFactorization
          (start + 1) (gramFamily start) n hn).beta i| ≤
          Real.exp ((ManuscriptChain.Real.rhoPrinted : ℝ) *
            ManuscriptChain.MainChain.mainK n)

/-- Witness value input plus *proved* positivity gives the full Decay
    interface. There is no nonvanishing hypothesis in Witness. -/
def witnessDecay (w : Witness) :
    ManuscriptChain.RealTransfer.Decay
      (ManuscriptChain.MainChain.primitiveMainNormalization w.start).Q
      ManuscriptChain.MainChain.zeta5
      ManuscriptChain.MainChain.decayBudget
      (w.start + 1) := by
  refine ⟨?_, w.normalized_decay⟩
  intro n hn
  exact ne_of_gt
    (ManuscriptChain.MainChain.normalized_value_pos
      (ManuscriptChain.MainChain.primitiveMainNormalization w.start)
      (ManuscriptChain.MainChain.main_baseValuePositive (w.start + 1)
        (by omega)) n hn)

/-- Factorization is constructed, not provided by the witness. -/
def witnessSpectralData (w : Witness) :
    ManuscriptChain.MainChain.MainSpectralData (w.start + 1) :=
  ManuscriptChain.MainChain.mainSpectralDataOfGram
    (w.start + 1) (gramFamily w.start) w.spectral_bound

/-- The root-gap and value bounds imply the printed quantitative measure.
    The index budget, comparison lemma and integer squeeze are native proofs. -/
theorem WITNESS_IMPLIES_EFFECTIVE_MEASURE (w : Witness) :
    ManuscriptChain.RealTransfer.RationalMeasure
      (riemannZeta 5).re 25687
      (ManuscriptChain.MainChain.indexDenominatorThreshold (w.start + 1)) := by
  have h : ManuscriptChain.RealTransfer.RationalMeasure
      ManuscriptChain.MainChain.zeta5 25687
      (ManuscriptChain.MainChain.indexDenominatorThreshold (w.start + 1)) :=
    ManuscriptChain.RealTransfer.conditional_measure
      (ManuscriptChain.MainChain.main_localComparison
        (ManuscriptChain.MainChain.primitiveMainNormalization w.start)
        (witnessSpectralData w))
      (witnessDecay w)
      (ManuscriptChain.MainChain.main_indexBudget
        (ManuscriptChain.MainChain.primitiveMainNormalization w.start))
  simpa only [ManuscriptChain.MainChain.zeta5,
    ManuscriptChain.Real.zeta_five_eq_riemannZeta_re] using h

/-- Direct irrationality requires only the VALUE component of the witness;
    the quantitative spectral bound is needed for the paper's measure. -/
theorem WITNESS_IMPLIES_IRRATIONAL_ZETA5 (w : Witness) :
    Irrational (riemannZeta 5).re :=
  ManuscriptChain.ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY
    w.start w.normalized_decay

end ZetaHyperbolicPaper

#print axioms ZetaHyperbolicPaper.gramFamily
#print axioms ZetaHyperbolicPaper.witnessDecay
#print axioms ZetaHyperbolicPaper.WITNESS_IMPLIES_EFFECTIVE_MEASURE
#print axioms ZetaHyperbolicPaper.WITNESS_IMPLIES_IRRATIONAL_ZETA5
