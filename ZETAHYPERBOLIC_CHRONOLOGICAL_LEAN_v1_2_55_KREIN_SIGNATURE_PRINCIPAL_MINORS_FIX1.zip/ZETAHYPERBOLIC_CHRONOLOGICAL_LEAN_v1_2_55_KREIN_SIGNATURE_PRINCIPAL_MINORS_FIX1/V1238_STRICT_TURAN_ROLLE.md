# v1.2.38 — Principal Theorem 3.7 strictness and equality / Rolle

Compiler baseline reported by user: `BUILD=PASS`, `LEAN_CHECKS=135/135`, `FROZEN_PASS=133`, `REUSED_OLEAN=133`, `NEW_COMPILED=2` for v1.2.37. All 135 Lean modules are byte-identical and retained; new modules are not pre-marked compiled.

New direct theorems target:
- Explicit affine finite-product strict Laguerre--Turan positivity at non-roots when at least one linear factor is nonconstant.
- Propagation under nonzero scalar scaling.
- Actual odd-zeta rational Hankel determinant strict positivity for all admissible dimensions.
- Actual full-rank finite rational Beukers determinant strict positivity for every positive dimension.
- Exact equality classification: `T(P,x)=0` iff `P(x)=P'(x)=0` (multiple real zero), for both actual families.
- Actual Rolle derivative-critical-point separation between any two distinct real roots; **not** claimed as successive principal-minor interlacing.
- A direct principal endpoint combining the strict/equality results, independently of the Section 4 arithmetic Witness.

NEW Lean files: `ProofAdvances/Theorem_3_7_StrictRolle.lean` and `PAPER_PRINCIPAL_STRICT_ROLLE.lean`.

This package has NOT been locally Lean-compiled (user's native Windows Lean 4.33.0 is sole authority). No `sorry`, `admit`, or custom axioms introduced. `FULL_PAPER=NOT_PROVED`.
