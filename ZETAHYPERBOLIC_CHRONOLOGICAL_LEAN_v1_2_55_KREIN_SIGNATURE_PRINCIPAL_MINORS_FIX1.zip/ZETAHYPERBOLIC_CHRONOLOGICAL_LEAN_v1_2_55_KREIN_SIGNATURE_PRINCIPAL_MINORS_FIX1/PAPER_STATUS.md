# All 47 numbered entries in strict PDF order

**Source:** Zetahyperbolic (3) (1)(6).pdf, 52 pages.

Statuses are mathematical audit classifications, not compiler output. A module for an OPEN claim may contain only an explicit frontier comment; it is not a fabricated proof.

| Order | PDF | Paper module | Status | Exact gap / checked import |
|---:|---|---|---|---|
| 1 | Definition 2.1: Order-s rational moment functional | `Paper.Definition_2_1` | **FOUNDATION** | Definition_2_1_Order_s_Rational_Moment_Functional.lean |
| 2 | Lemma 2.2: Pullback identity | `Paper.Lemma_2_2` | **PROVED_GENERATORS** | Monomial and simple-pole generator identities are kernel proved in Zetahyperbolic.Section2Checked; assemble the whole functional by Q-linearity. |
| 3 | Lemma 2.3: Reflection and difference identities for tau_X | `Paper.Lemma_2_3` | **PROVED_GENERATORS** | Monomial and simple-pole generator identities are kernel proved in Zetahyperbolic.Section2Checked; assemble the whole functional by Q-linearity. |
| 4 | Theorem 2.4: Canonical basis invariance | `Paper.Theorem_2_4` | **PROVED_CORE** | Theorem_2_4_Canonical_Basis_Invariance.lean |
| 5 | Theorem 2.5: Lagrange pole diagonalization | `Paper.Theorem_2_5` | **PROVED_CORE** | Theorem_2_5_Lagrange_Pole_Diagonalization.lean |
| 6 | Theorem 3.1: Universal hyperbolicity and zero-free disk | `Paper.Theorem_3_1` | **PROVED** | PAPER_02_03_UNCONDITIONAL.lean |
| 7 | Proposition 3.2: Continuous hyperbolic pencil for all real s > 1 | `Paper.Proposition_3_2` | **PARTIAL_ADVANCED** | New real-exponent pole weights, strict positivity of their scaling, exact signed slope determinant, nonsingularity, and generic spectral factorization (ProofAdvances/Proposition_3_2.lean). Explicit continuous w_s integral and base Gram positivity remain open. |
| 8 | Theorem 3.3: Total positivity, leading sign, and universal signature | `Paper.Theorem_3_3` | **PARTIAL_ADVANCED** | Actual odd-weight Gram determinant > 0, exact leading-coefficient pole product, real-exponent positive/negative pole-index sets constant, finite parity identity (ProofAdvances/Theorem_3_3.lean). All non-principal minors and exact inertia counts remain open. |
| 9 | Theorem 3.4: Root interlacing and Dodgson condensation for principal minors | `Paper.Theorem_3_4` | **PARTIAL_ADVANCED** | Exact symmetric 3×3 Dodgson identity and sign at a vanishing leading minor proved in ProofAdvances/Theorem_3_4. General r and interlacing remain open. |
| 10 | Corollary 3.5: Stieltjes J-fraction from interlacing roots | `Paper.Corollary_3_5` | **CORRECTION** | As printed (3.6) misses Gram normalization and misuses the spectral parameter. Correct scalar resolvent lemma included. |
| 11 | Corollary 3.6: Stieltjes reciprocal-root power sums | `Paper.Corollary_3_6` | **CORRECTION_ADVANCED** | General finite-atomic Hankel = Vandermonde Gram factorization and two-atom rank-two obstruction proved in ProofAdvances/Corollary_3_6; printed strict all-orders assertion is false. |
| 12 | Theorem 3.7: Turanian non-negativity and Newton log-concavity | `Paper.Theorem_3_7` | **PARTIAL_ADVANCED** | Quadratic and full cubic (m=1,2) Turan identities; 3-mode Taylor bound in ProofAdvances/Theorem_3_7. Arbitrary-degree and equality cases remain open. |
| 13 | Theorem 3.8: Christoffel-Darboux pole representation and Jacobi derivative identity | `Paper.Theorem_3_8` | **PARTIAL_ADVANCED** | Full characteristic-polynomial and trace correspondence between actual relative Hankel matrix and pole kernel in all finite dimensions (ProofAdvances/Theorem_3_8_Actual.lean); symmetric-root and differentiated-integral components remain. |
| 14 | Theorem 3.9: Hyperbolicity for Hurwitz and Dirichlet Hankel determinants | `Paper.Theorem_3_9` | **PARTIAL** | Fekete polynomial positivity formally proved; complete shifted integral/character moment identities are not. |
| 15 | Theorem 4.1: Spectral irrationality measure criterion | `Paper.Theorem_4_1` | **PROVED_CORE** | Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean |
| 16 | Proposition 4.2: Transfer criterion for algebraic approximations of degree d >= 1 | `Paper.Proposition_4_2` | **OPEN** | Requires formal resultant, height and conjugate factor estimates. |
| 17 | Proposition 4.3: Ultrametric zero-free disk over Q_p | `Paper.Proposition_4_3` | **OPEN** | Requires p-adic polynomial Lipschitz/non-Archimedean ball proof. |
| 18 | Theorem 4.4: Sharpened spectral bound and effective irrationality measure for zeta(5) | `Paper.Theorem_4_4` | **CONDITIONAL** | Printed 0.0004 normalized decay and 11.411 bound are supplied by the single Witness, not proved. |
| 19 | Theorem 4.5: Irrationality and effective measure for b zeta(5) + a zeta(3) | `Paper.Theorem_4_5` | **OPEN** | Separate combined-weight positivity and uniform p-adic normalization beyond single zeta(5) Witness. |
| 20 | Theorem 4.6: Two-sided determinant bounds and coefficient heights | `Paper.Theorem_4_6` | **OPEN** | Euler-Maclaurin determinant asymptotics and lower Gram Jensen bound. |
| 21 | Theorem 4.7: Macroscopic exponential root collapse and root separation | `Paper.Theorem_4_7` | **OPEN** | Depends on 4.4 and 4.6, plus quantitative factor height. |
| 22 | Proposition 4.8: Rational root exclusion and degree bounds for cluster factors | `Paper.Proposition_4_8` | **OPEN** | Depends on repaired 4.4–4.7. |
| 23 | Conjecture 4.11: Variational limit of spectral norm exponent | `Paper.Conjecture_4_11` | **CONJECTURE** | A conjecture in the PDF; not treated as theorem. |
| 24 | Theorem 5.1: Two-variable Beukers measure for zeta(7) | `Paper.Theorem_5_1` | **PARTIAL** | Finite rational dual coefficient identities exist; double-integral identity is not proved. |
| 25 | Theorem 5.2: Dual hyperbolicity and Krein-space decomposition of the two-variable zeta(7) pencil | `Paper.Theorem_5_2` | **PARTIAL** | Finite positive/negative certificate implications proved; infinite mode tails not controlled. |
| 26 | Proposition 5.3: Two-variable Beukers measure and dual pencil for beta(4) | `Paper.Proposition_5_3` | **OPEN** | Beta integral moments and rational off-diagonal moments need proof. |
| 27 | Theorem 5.4: Cancellation of higher zeta values on even pole pairs | `Paper.Theorem_5_4` | **PARTIAL** | Simple-pole generator cancellation is proved; full tau functional/pullback remains. |
| 28 | Theorem 5.6: Weight-seven prime-sum evaluation and pole-ordered refinement | `Paper.Theorem_5_6` | **OPEN** | 11 rational affine intervals, tail integral and local p-adic unimodular argument. |
| 29 | Theorem 5.7: Simultaneous double-pole Hankel determinant for 1, zeta(5), zeta(6) | `Paper.Theorem_5_7` | **PARTIAL** | Hermite and local block algebra available; q-adic nonvanishing and valuation not closed. |
| 30 | Theorem 6.1: Divided-difference p-adic valuation law and intrinsic p^-6 barrier | `Paper.Theorem_6_1` | **OPEN** | Exact local valuations and fiber Mellin integral. |
| 31 | Theorem 6.2: Simultaneous weight-(6,7) Beukers functional with zero denominator overhead | `Paper.Theorem_6_2` | **OPEN** | Asymmetric Beukers moments and denominator-free arithmetic. |
| 32 | Theorem 6.3: Unconditional q-adic non-vanishing and explicit positive-cone approximations for G_A(7) | `Paper.Theorem_6_3` | **PARTIAL** | Source has certificate implication; existence of tail estimates and bases unproved. |
| 33 | Theorem 6.4: Character-Vandermonde sign cancellation and unconditional hyperbolicity for beta(4) | `Paper.Theorem_6_4` | **PARTIAL** | Auxiliary beta moment model interfaces, not complete PDF beta(4) weight identity. |
| 34 | Theorem 6.5: Unconditional q-adic non-vanishing for Delta_K(0) | `Paper.Theorem_6_5` | **OPEN** | Prime congruence and determinant valuation for beta pencil. |
| 35 | Theorem 6.6: Generalized multi-weight positive-definite pencil | `Paper.Theorem_6_6` | **OPEN** | Differential-shift cancellation and uniform positivity region. |
| 36 | Theorem 6.7: Universal multi-weight two-variable Beukers Krein decomposition | `Paper.Theorem_6_7` | **OPEN** | General multi-index integral and infinite-mode Krein decomposition. |
| 37 | Corollary 6.8: Unconditional three-term linear independence cone for 1,zeta(3),zeta(5) | `Paper.Corollary_6_8` | **OPEN** | Full combined normalized determinant arithmetic, not implied by spectral 3.1. |
| 38 | Theorem 6.9: Triple-pole and multi-weight Hankel determinants | `Paper.Theorem_6_9` | **PARTIAL** | Finite Hermite interpolation/local block identity proved in imported module. |
| 39 | Theorem 6.10: Universal potential-gap identity and vanishing of quadratic derivative growth in two variables | `Paper.Theorem_6_10` | **PARTIAL** | Finite determinant identity proved; full asymptotic potential conservation not. |
| 40 | Theorem 6.11: p^-(2k-1) distribution growth law and 2-adic polynomial-quotient obstruction | `Paper.Theorem_6_11` | **OPEN** | Prime-adic distribution and quotient valuation bounds. |
| 41 | Theorem 6.12: Full-dimension sign-flip restoration of positive definiteness and q-adic non-vanishing for pure beta(4) | `Paper.Theorem_6_12` | **OPEN** | Signed beta weight moment correction, full positivity and q-adic certificate. |
| 42 | Theorem 6.13: Central-factorial secant differential identity, Laplace mode annihilation, and consequences | `Paper.Theorem_6_13` | **OPEN** | Exact differential polynomial and annihilation identity. |
| 43 | Theorem 6.14: Even-pole scaling via cosh(2pi v) and coupled positive-definite pencils | `Paper.Theorem_6_14` | **OPEN** | Even-pole functional and positive weight realization. |
| 44 | Theorem 6.15: Arithmetic transcendence, strictly positive one-variable measure, and rank-one obstruction | `Paper.Theorem_6_15` | **OPEN** | Transcendence, positivity, and rank-one endpoint each need standalone proof. |
| 45 | Theorem 6.16: Generalized multi-weight Zeta-Beta positive-definite pencil | `Paper.Theorem_6_16` | **PARTIAL** | Auxiliary compact-ratio positivity lemmas present; full multi-weight pencil absent. |
| 46 | Theorem 6.17: Universal two-variable Beukers Zeta-Beta pencil, Krein decomposition, and extensions | `Paper.Theorem_6_17` | **PARTIAL** | Finite harmonic-window/index lemmas available, not universal analytic theorem. |
| 47 | Theorem 6.18: Principal-minor 2-adic integrality law, dyadic height bounds for Zeta-Beta pencils | `Paper.Theorem_6_18` | **PARTIAL** | Finite boundary-degree lemma exists; full dyadic height result remains. |

## 3.8 update in v1.2.12

Arbitrary-dimensional finite affine Jacobi determinant derivative and
logarithmic derivative are new proof targets. The actual odd-weight Hankel
affine derivative equals the CD pole trace. The separate Laplace-parameter
integral-differentiation statement is **not proved**.

### v1.2.14: Theorem 3.9 finite Hurwitz-pole development

Generic Vandermonde residue slope determinant and roots are formulated
for arbitrary finite sizes and positive shifts. Actual analytic Hurwitz and
Dirichlet moment realizations are not formalized. The new proof is not
compiler-verified until the user reports PASS.

### v1.2.15: further chronological proof candidates

* Theorem 3.8(2): full finite-dimensional exact second-order determinant
  Taylor identity, with explicit polynomial remainder (new module).
* Theorem 3.9: strict positivity for each of five Fekete character numerator
  factorizations, plus the abstract character--Vandermonde sign cancellation
  (new module). No Dirichlet character integral has been silently assumed.
* Theorem 5.1: symmetry of rational divided differences, dual-entry linear
  coefficient, finite rational evaluation at zero, and matrix entry symmetry.
  The two-dimensional Beukers integral remains a proof frontier.

The 120/120 frozen baseline is compiler-verified from the user's log.  The
Jacobi v1.2.13 and shifted-pole v1.2.14 modules are still *pending* the
user's Lean compiler. The v1.2.15 new mathematical modules are also pending.
Compilation of a file does not turn an explicit partial theorem interface
into a proof of the entire printed PDF entry.
