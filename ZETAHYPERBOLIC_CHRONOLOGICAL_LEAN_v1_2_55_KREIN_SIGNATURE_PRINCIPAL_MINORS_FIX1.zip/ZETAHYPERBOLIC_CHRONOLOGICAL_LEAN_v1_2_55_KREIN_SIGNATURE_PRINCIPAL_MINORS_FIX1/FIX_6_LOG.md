# Fix 6 — direct definitional equality, v1.2.11

- The compiler excerpt supplied by the user contains the error wording produced
  by the `simpa only` expression on line 62 of **v1.2.9**, not the source line
  in the supplied **v1.2.10** ZIP (where line 62 is `have hγ`).
- Replace the proof of `actual_derivative_factorization` with a direct `change`
  to `Proposition3_2.slope p (p.weight : ℝ)` and the existing checked theorem
  `actual_derivative_eq_real_slope`. All definition aliases are transparent.
- Only `ProofAdvances/Theorem_3_8_Actual.lean` changed as a Lean source.
  `PAPER_CHRONOLOGICAL_CHAIN.lean` is identical but its cache key is invalidated.
- The 118 earlier passes remain eligible for artifact reuse. No prior proofs
  are recompiled unless their matching .olean cache is missing or invalid.
- Native compiler check NOT executed in this packaging environment.

## Mandatory fresh run diagnostics

`RUN_REVISION=V1211_CD_DEFINITIONAL_GOAL_FIX2`

`CD_ACTUAL_SOURCE=DEFINITIONAL_GOAL_FIX2_CONFIRMED`

`ACTUAL_PROOF_REVISION=V1211_DIRECT_DEFINITIONAL_CHANGE`

If these markers are absent from the new run, the log came from an older
package or was not regenerated.
