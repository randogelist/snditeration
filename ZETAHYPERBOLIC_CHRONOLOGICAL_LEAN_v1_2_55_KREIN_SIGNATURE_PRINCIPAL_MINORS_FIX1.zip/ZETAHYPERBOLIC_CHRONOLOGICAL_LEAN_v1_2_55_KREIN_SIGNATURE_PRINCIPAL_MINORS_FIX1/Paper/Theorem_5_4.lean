import Paper.Proposition_5_3

/-!
# Theorem 5.4 — Cancellation of higher zeta values on even pole pairs
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PARTIAL
REMAINING / EVIDENCE: Simple-pole generator cancellation is proved; full tau functional/pullback remains.

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

/-- Equation (5.5) for each simple-pole pair j=n+1; all X terms cancel. -/
theorem even_pole_pair_cancellation (s n : ℕ) (X : ℚ) :
    (ManuscriptChain.Real.harmonic s (n + 1) - X) -
      (ManuscriptChain.Real.harmonic s n - X) =
        1 / (((n + 1 : ℕ) : ℚ) ^ s) := by
  rw [harmonic_succ]
  ring

end PaperChronology
