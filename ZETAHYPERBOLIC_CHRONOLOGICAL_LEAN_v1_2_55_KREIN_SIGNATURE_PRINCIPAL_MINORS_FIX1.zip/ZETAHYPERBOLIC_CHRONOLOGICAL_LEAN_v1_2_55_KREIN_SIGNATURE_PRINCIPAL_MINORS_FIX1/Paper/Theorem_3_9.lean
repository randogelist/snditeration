import Paper.Theorem_3_8
import Zetahyperbolic.Section3Elementary

/-!
# Theorem 3.9 — Hyperbolicity for Hurwitz and Dirichlet Hankel determinants
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PARTIAL
REMAINING / EVIDENCE: Fekete polynomial positivity formally proved; complete shifted integral/character moment identities are not.

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

/-- The five Fekete factor positivity checks used as a sublemma in 3.9. -/
theorem fekete_positive {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1) :
    0 < z * (1 - z) ∧
    0 < z * (1 - z ^ 2) ∧
    0 < z * (1 - z) ^ 2 * (1 + z) ∧
    0 < z * (1 - z ^ 2) * (1 - z ^ 4) ∧
    0 < z * (1 + z ^ 2) * (1 - z ^ 4) :=
  Zetahyperbolic.fekete_polynomial_positivity_basic hz0 hz1

end PaperChronology
