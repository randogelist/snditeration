import Paper.Corollary_3_6

/-!
# Theorem 3.7 — Turanian non-negativity and Newton log-concavity
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PARTIAL
REMAINING / EVIDENCE: Quadratic Turan case proved; general strict/equality assertions are not established.

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

/-- The basic quadratic real-rooted Turan identity: an exact first case of (3.7). -/
theorem quadratic_turan_identity (x a b : ℝ) :
    (2 * x - a - b) ^ 2 - 2 * ((x - a) * (x - b)) =
      (x - a) ^ 2 + (x - b) ^ 2 := by
  ring

theorem quadratic_turan_nonnegative (x a b : ℝ) :
    0 ≤ (2 * x - a - b) ^ 2 - 2 * ((x - a) * (x - b)) := by
  rw [quadratic_turan_identity]
  positivity

end PaperChronology
