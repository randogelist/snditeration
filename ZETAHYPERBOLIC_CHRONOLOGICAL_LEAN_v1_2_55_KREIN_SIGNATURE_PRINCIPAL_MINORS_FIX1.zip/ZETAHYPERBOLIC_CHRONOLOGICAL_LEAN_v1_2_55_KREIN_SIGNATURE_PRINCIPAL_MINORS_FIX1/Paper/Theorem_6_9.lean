import Paper.Corollary_6_8
import Zetahyperbolic.Theorem_6_9_Triple_Pole_Hermite_Repair

/-!
# Theorem 6.9 — Triple-pole and multi-weight Hankel determinants
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PARTIAL
REMAINING / EVIDENCE: Finite Hermite interpolation/local block identity proved in imported module.

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

#check Zetahyperbolic.TriplePoleRepair.poleFunctional_eq_jetFunctional
#check Zetahyperbolic.TriplePoleRepair.momentMatrix_det

end PaperChronology
