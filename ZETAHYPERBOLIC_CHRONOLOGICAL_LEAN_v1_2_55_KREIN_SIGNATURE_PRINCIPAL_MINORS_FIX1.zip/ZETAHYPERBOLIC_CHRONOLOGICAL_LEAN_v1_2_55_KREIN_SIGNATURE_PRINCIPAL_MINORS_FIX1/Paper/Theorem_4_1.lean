import Paper.Theorem_3_9
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion

/-!
# Theorem 4.1 — Spectral irrationality measure criterion
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PROVED_CORE
REMAINING / EVIDENCE: Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

#check ManuscriptChain.RealTransfer.conditional_measure
#check ManuscriptChain.RealTransfer.RationalMeasure.irrational

end PaperChronology
