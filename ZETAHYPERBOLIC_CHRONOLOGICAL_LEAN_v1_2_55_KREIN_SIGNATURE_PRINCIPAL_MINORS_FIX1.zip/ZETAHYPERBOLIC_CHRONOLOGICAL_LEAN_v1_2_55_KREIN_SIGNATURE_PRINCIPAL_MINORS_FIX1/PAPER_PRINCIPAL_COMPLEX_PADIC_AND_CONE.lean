import PAPER_PRINCIPAL_PADIC_DISK
import ProofAdvances.Proposition_4_3_ComplexPadicDisk
import ProofAdvances.Theorem_6_6_AnchoredSemidefiniteCone

/-!
# Principal new unconditional endpoints

* Proposition 4.3: exact zero exclusion on full C_p, not merely Q_p;
  includes an arbitrary p-adic integer center and integer coefficients.
* Theorem 6.6 finite algebraic layer: strict real hyperbolicity for a
  NONNEGATIVE positive-semidefinite cone with one positive-definite anchor.

These are mathematical consequences of previous theorems, not new
Witness instances. The full manuscript analytic + arithmetic chain
remains explicitly open.
-/

noncomputable section
open Polynomial

namespace ZetaHyperbolicPaper.PrincipalComplexPadicAndCone

/-- Complex-p-adic principal endpoint in the original integer-
polynomial formulation. -/
theorem PRINCIPAL_PROPOSITION_4_3_COMPLEX_PADIC
    {p : ℕ} [Fact p.Prime]
    (Q : ℤ[X]) (ξ : ℤ_[p]) (α : ℂ_[p])
    (hQ : (Q.map (Int.castRingHom (ℤ_[p]))).eval ξ ≠ 0)
    (hα : ‖α - ((ξ : ℚ_[p]) : ℂ_[p])‖ <
      ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖) :
    ‖(((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).map
      (algebraMap ℚ_[p] ℂ_[p])).eval α‖ =
      ‖(((Q.map (Int.castRingHom (ℤ_[p]))).eval ξ : ℤ_[p]) : ℚ_[p])‖ ∧
    (((Q.map (Int.castRingHom (ℤ_[p]))).map
      (PadicInt.Coe.ringHom)).map
      (algebraMap ℚ_[p] ℂ_[p])).eval α ≠ 0 := by
  exact PaperAdvances.Proposition4_3_ComplexPadicDisk.PROPOSITION_4_3_INTEGER_COMPLEX_PADIC
    Q ξ α hQ hα

end ZetaHyperbolicPaper.PrincipalComplexPadicAndCone

#print axioms ZetaHyperbolicPaper.PrincipalComplexPadicAndCone.PRINCIPAL_PROPOSITION_4_3_COMPLEX_PADIC
