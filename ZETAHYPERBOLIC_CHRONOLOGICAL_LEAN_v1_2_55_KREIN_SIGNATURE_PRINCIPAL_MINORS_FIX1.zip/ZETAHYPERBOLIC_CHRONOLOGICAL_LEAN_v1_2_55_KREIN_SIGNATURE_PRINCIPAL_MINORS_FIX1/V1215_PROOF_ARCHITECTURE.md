# v1.2.15: Chronological unconditional finite mathematics

The paper's original sequence starts with the rational moment functional,
basis-invariant primitive integer polynomial, Lagrange pole decomposition
and universal zero-free hyperbolic pencil. The strongest already frozen
result remains the actual general odd-weight finite pencil theorem.

## 3.8: exact Jacobi expansion

For any real n-by-n matrix A, put P_A(T)=det(I+TA). Then
P_A(T)=1 + tr(A) T + T^2 R_A(T), with R_A(T) obtained explicitly by
`Polynomial.divX.divX`. Mathlib supplies this identity in all finite
dimensions. If G is invertible, then

det(G+T H)=det(G) [1+T tr(G^-1 H)+T^2 R_(G^-1 H)(T)].

The paper's separate Laplace-parameter identity requires proving the
weight derivative of the integral Gram and interchanging derivative and
infinite integral. It is NOT the same as varying X in an affine pencil.

## 3.9: real Dirichlet character weights

For 0<z<1, the five signed sums are

F_(-3)=z(1-z), F_(-4)=z(1-z^2),
F_(5)=z(1-z)^2(1+z), F_(8)=z(1-z^2)(1-z^4),
F_(-8)=z(1+z^2)(1-z^4).

Every factor on the right is positive, a complete proof of the finite
character numerator positivity; the rational infinite generating series
is an independent analytic link. In the beta branch, `(-1)^j` from the
character cancels the `(-1)^j` from the pole derivative, giving a
positive diagonal pole slope. This is algebraically proved for abstract
positive magnitudes, but identifying the actual residue magnitudes
with the manuscript functional still needs work.

## 5.1: dual rational core

For s>=2 and distinct r,t,

A_s(r,t)=[H_(s-1)(r)-H_(s-1)(t)]/((s-1)(r-t)),

with A_s(r,r)=-H_s(r), is symmetric. The finite pencil linear
coefficient is C C^T. This handles the rational portion, without
pretending to have evaluated a two-variable integral.

## Strictly one-Witness architecture: caveat

The existing single `ZetaHyperbolicPaper.Witness` packages determinant
decay and spectral growth as universally quantified analytic estimates.
It is *not yet a finite object accepted by a terminating checker*.
Additional Sections 5 and 6 analytic and p-adic assertions are not
deduced solely from that witness in the current source. This package
does not add fake axioms to make a single-witness complete-paper
statement appear proved. The final exact one-witness transfer is a
future mathematical construction, not an achieved endpoint.

## Static-only release policy

Preserve prior byte-identical Lean source and `.olean` cache keys.
Modify only the chronological wrapper and add three new modules.
The package is static-tested, never compiled locally.

## 3.9 and 6.4: full-size positive pole derivatives

The beta/Dirichlet pole coefficient becomes positive after character and
interpolation alternating phases cancel. For **any** finite size h, if the
negative pole nodes are pairwise distinct and all such residues are
positive, the actual matrix V diag(gamma) V^T is positive definite.
This is the congruence transfer of diagonal positive definiteness through
an invertible Vandermonde matrix, without an analytic Gram hypothesis.
The new module proves this with Mathlib's PosDef congruence theorem.

The remaining input for the exact beta pencil is the functional
identification of the character residue magnitudes. It is not supplied by
this purely finite-algebra theorem.

## 5.2: dual slope positive definite in any finite dimension

For any rational polynomial basis coefficient matrix C, the X-derivative
of the dual pencil is C*C^T. When rows of C are linearly independent,
this Gram matrix is positive definite, and its determinant is positive.
Mathlib's positive-definite matrix congruence proves the result without
Krein-space infinite tail analysis. The new module also connects it to
the *actual* rational pencil entry coefficients, not a symbolic toy.
