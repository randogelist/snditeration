# v0.2.65 native upstream axiom trace

The v0.2.64 static source probe located exactly one `PaperNative.THEOREM_4_4_EFFECTIVE_MEASURE` declaration, with no explicit `sorry` in its immediate source block. That is not evidence that transitive axioms are clean. Chapter 4 continues to fail with `sorryAx`.

This ZIP generates an independent Lean file importing exactly the upstream module and asks the **user's own native Lean 4.33.0** for `#print axioms PaperNative.THEOREM_4_4_EFFECTIVE_MEASURE`. It prints the full native result, records the source excerpt and marks whether `sorryAx` occurs. It never modifies original source files or already frozen `.olean` caches, and does not invoke the full incremental runner. If import resolution fails, the log displays the failure.

The output is diagnostic and does not certify the full paper, Chapter 4 or the downstream witness theorem. All source integration checkpoints remain intact.
