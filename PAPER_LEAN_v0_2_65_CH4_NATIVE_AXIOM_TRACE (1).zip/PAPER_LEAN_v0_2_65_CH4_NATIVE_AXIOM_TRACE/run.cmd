@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RELEASE=PAPER_LEAN_v0_2_65_CH4_NATIVE_AXIOM_TRACE"
set "BASE=PAPER_LEAN_v0_2_55_T5_1_NEG_DIV_SYMMETRY_FIX1"
set "SOURCE_ROOT=%USERPROFILE%\Downloads\!BASE!"
set "CACHE_ROOT=%USERPROFILE%\lean-native\paper_chronological_fastcore_433"
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=!TOOLCHAIN!\bin\lean.exe"
set "MATHLIB_CACHE=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
set "TARGET=PaperChronological.Blueprint.quantitative_zeta5_measure_from_witness"
echo RELEASE=!RELEASE!
echo MODE=READ_ONLY_NATIVE_UPSTREAM_AXIOM_TRACE
echo TARGET=!TARGET!
echo FROZEN_CACHE=READ_ONLY
echo ORIGINAL_SOURCES=READ_ONLY
if not exist "!SOURCE_ROOT!\run.cmd" (
  echo DIAGNOSTIC=ORIGINAL_BASE_PROJECT_REQUIRED
  echo REQUIRED=!SOURCE_ROOT!
  exit /b 2
)
if not exist "!LEAN_EXE!" (
  echo DIAGNOSTIC=NATIVE_LEAN_433_NOT_FOUND
  echo EXPECTED=!LEAN_EXE!
  exit /b 2
)
if not exist "!SOURCE_ROOT!\PaperChronological\Blueprint\Chapter04.lean" (
  echo DIAGNOSTIC=CHAPTER04_SOURCE_NOT_FOUND
  exit /b 2
)
where cscript.exe >nul 2>nul
if errorlevel 1 (
  echo DIAGNOSTIC=WINDOWS_SCRIPT_HOST_MISSING
  exit /b 2
)
"!LEAN_EXE!" --version >"%~dp0LEAN_VERSION.txt" 2>&1
if errorlevel 1 (echo DIAGNOSTIC=LEAN_VERSION_COMMAND_FAILED&exit /b 2)
findstr /C:"4.33.0" "%~dp0LEAN_VERSION.txt" >nul 2>nul
if errorlevel 1 (type "%~dp0LEAN_VERSION.txt"&echo DIAGNOSTIC=LEAN_VERSION_MISMATCH&exit /b 2)
cscript.exe //nologo //E:JScript "%~dp0generate_probe.js" "!SOURCE_ROOT!" "!CACHE_ROOT!" "%~dp0"
if errorlevel 1 (echo BUILD=FAIL_SAFE_PROBE_GENERATION&exit /b 3)
set "LEAN_PATH=!CACHE_ROOT!\lib;!CACHE_ROOT!\lib\lean;!CACHE_ROOT!\build\lib\lean;!CACHE_ROOT!\build\lib;!TOOLCHAIN!\lib\lean"
if exist "!MATHLIB_CACHE!\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!MATHLIB_CACHE!\.lake\build\lib\lean"
if exist "!MATHLIB_CACHE!\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!MATHLIB_CACHE!\build\lib\lean"
for /d %%P in ("!MATHLIB_CACHE!\.lake\packages\*") do (
  if exist "%%~fP\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fP\.lake\build\lib\lean"
  if exist "%%~fP\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fP\build\lib\lean"
)
echo NATIVE_PROBE=START
"!LEAN_EXE!" -j 16 "%~dp0CH4_UPSTREAM_AXIOM_TRACE.lean" >"%~dp0CH4_NATIVE_AXIOM_TRACE.log" 2>&1
set "RC=!ERRORLEVEL!"
echo NATIVE_PROBE_EXIT_CODE=!RC!
type "%~dp0CH4_NATIVE_AXIOM_TRACE.log"
if not "!RC!"=="0" (
  echo AXIOM_TRACE=NOT_RESOLVED_LEAN_IMPORT_OR_TYPE_ERROR
  echo LOG=%~dp0CH4_NATIVE_AXIOM_TRACE.log
  echo BUILD=PROBE_FAILED_NO_PROJECT_MUTATION
  exit /b !RC!
)
findstr /C:"depends on axioms:" "%~dp0CH4_NATIVE_AXIOM_TRACE.log" >nul 2>nul
if errorlevel 1 (
  echo AXIOM_TRACE=NO_AXIOM_OUTPUT
  echo BUILD=PROBE_FAILED_NO_PROJECT_MUTATION
  exit /b 4
)
findstr /I /C:"sorryAx" "%~dp0CH4_NATIVE_AXIOM_TRACE.log" >nul 2>nul
if errorlevel 1 (
  echo UPSTREAM_THEOREM_AX_STATUS=NO_SORRYAX_IN_PRINTED_AXIOMS
  echo NEXT=INSPECT_CHAPTER04_LOCAL_PROOF_AND_ITS_OTHER_DEPS
) else (
  echo UPSTREAM_THEOREM_AX_STATUS=SORRYAX_DETECTED
  echo NEXT=RESOLVE_UNPROVED_TRANSITIVE_DEPENDENCY_IN_UPSTREAM_THEOREM
)
echo CHAPTER04_UNCONDITIONAL_PROOF=NOT_CERTIFIED_BY_THIS_TRACE
echo RUN_MODE=PROBE_ONLY_NO_SRC_OR_CACHE_MODIFICATION
echo LOG=%~dp0CH4_NATIVE_AXIOM_TRACE.log
echo BUILD=READ_ONLY_NATIVE_PROBE_PASS
exit /b 0
