// JScript 5.x / ES3. Read-only compiler probe generator; original sources/cache untouched.
var fs=new ActiveXObject('Scripting.FileSystemObject');
function log(t){WScript.Echo(t);}
function fail(t){log('PROBE_GENERATOR=FAIL_'+t);WScript.Quit(3);}
if(WScript.Arguments.length!==3)fail('INVALID_ARGUMENT_COUNT');
var root=String(WScript.Arguments.Item(0));
var cache=String(WScript.Arguments.Item(1));
var out=String(WScript.Arguments.Item(2));
function utf8(p){
 var s=new ActiveXObject('ADODB.Stream');s.Type=2;s.Charset='utf-8';s.Open();s.LoadFromFile(p);
 var t=s.ReadText(-1);s.Close();while(t.length&&t.charCodeAt(0)===0xfeff)t=t.substr(1);
 return t.replace(/\r\n/g,'\n').replace(/\r/g,'\n');
}
function saveNoBom(p,t){
 var s=new ActiveXObject('ADODB.Stream');s.Type=2;s.Charset='utf-8';s.Open();s.WriteText(t);
 s.Position=0;s.Type=1;
 var a=new VBArray(s.Read(3)).toArray();
 if(a.length!==3||a[0]!==239||a[1]!==187||a[2]!==191){s.Close();throw Error('UTF8_BOM_EXPECTED');}
 var d=new ActiveXObject('ADODB.Stream');d.Type=1;d.Open();s.CopyTo(d);d.SaveToFile(p,2);d.Close();s.Close();
}
var wanted='THEOREM_4_4_EFFECTIVE_MEASURE';
var found=[];var fileCount=0;
function walk(p,n){
 if(n>11||!fs.FolderExists(p))return;
 var folder=fs.GetFolder(p),en=new Enumerator(folder.Files);
 for(;!en.atEnd();en.moveNext()){
  var f=en.item();
  if(!/\.lean$/i.test(f.Name)||/\.PRE_/i.test(f.Name))continue;
  fileCount++;
  var text='';try{text=utf8(f.Path);}catch(e){log('SOURCE_READ_ERROR='+f.Path);continue;}
  var arr=text.split('\n'),r=new RegExp('^\\s*(?:(?:private|protected|noncomputable|unsafe)\\s+)*(?:theorem|lemma|def|abbrev|axiom)\\s+'+wanted+'\\b');
  for(var i=0;i<arr.length;i++)if(r.test(arr[i]))found.push({file:f.Path,line:i+1,src:text,lines:arr});
 }
 var subs=new Enumerator(folder.SubFolders);
 for(;!subs.atEnd();subs.moveNext()){
  var sub=subs.item();
  if(/^(?:\.lake|cache|lib|build|\.git|CHECKPOINTS)$/i.test(sub.Name))continue;
  walk(sub.Path,n+1);
 }
}
walk(root,0);
log('SCANNED_SOURCES='+fileCount);
log('UPSTREAM_DECLARATIONS='+found.length);
if(found.length!==1)fail('UPSTREAM_DEFINITION_NOT_UNIQUE_OR_NOT_FOUND');
var item=found[0];
var rel=item.file.substr(root.length).replace(/^\\/,'');
if(!/\.lean$/i.test(rel))fail('WRONG_EXTENSION');
var module=rel.replace(/\.lean$/i,'').replace(/\\/g,'.');
if(!/^[A-Za-z0-9_'.]+$/.test(module))fail('UNSAFE_MODULE_PATH');
var probe='import '+module+'\n\nset_option maxRecDepth 2048\n#print axioms PaperNative.'+wanted+'\n#check PaperNative.'+wanted+'\n';
// Avoid re-creating an identical probe file needlessly, but never patch an original source.
var target=fs.BuildPath(out,'CH4_UPSTREAM_AXIOM_TRACE.lean');
try{if(!fs.FileExists(target)||utf8(target)!==probe)saveNoBom(target,probe.replace(/\n/g,'\r\n'));}
catch(e){fail('FAILED_TO_WRITE_PROBE_'+e.message);}
var manifest=[];
manifest.push('RELEASE=PAPER_LEAN_v0_2_65_CH4_NATIVE_AXIOM_TRACE');
manifest.push('FILE='+item.file);
manifest.push('DECLARATION_LINE='+item.line);
manifest.push('UPSTREAM_MODULE='+module);
manifest.push('SOURCE_SCANNED='+fileCount);
manifest.push('PROBE_METHOD=LEAN_433_IMPORT_COMPILED_MODULE_PRINT_AXIOMS');
manifest.push('NO_ORIGINAL_SOURCE_OR_OLEAN_CACHE_MODIFIED');
manifest.push('== DECLARATION CONTEXT ==');
var start=Math.max(0,item.line-7),stop=Math.min(item.lines.length,item.line+115);
for(var k=start;k<stop;k++){
 if(k>item.line-1&&/^\s*(?:theorem|lemma|def|abbrev|namespace|section|end|#print)\b/.test(item.lines[k])&&!/^\s+/.test(item.lines[k]))break;
 manifest.push(String(k+1)+': '+item.lines[k]);
}
var report=fs.BuildPath(out,'CH4_UPSTREAM_SOURCE_CONTEXT.txt');
try{saveNoBom(report,manifest.join('\r\n')+'\r\n');}catch(e){fail('REPORT_WRITE_'+e.message);}
log('UPSTREAM_SOURCE='+rel);
log('UPSTREAM_MODULE='+module);
log('UPSTREAM_DECLARATION_LINE='+item.line);
var cand=[
 fs.BuildPath(fs.BuildPath(cache,'lib'),rel.replace(/\.lean$/i,'.olean')),
 fs.BuildPath(fs.BuildPath(fs.BuildPath(cache,'lib'),'lean'),rel.replace(/\.lean$/i,'.olean')),
 fs.BuildPath(fs.BuildPath(fs.BuildPath(cache,'build'),'lib'),rel.replace(/\.lean$/i,'.olean'))
];
var foundOlean=false;
for(var p=0;p<cand.length;p++)if(fs.FileExists(cand[p])){log('CACHED_MODULE_PRESENT='+cand[p]);foundOlean=true;break;}
if(!foundOlean)log('CACHED_MODULE_NOT_SEEN_IN_STANDARD_LOCATIONS=LET_NATIVE_LEAN_RESOLVE');
log('SOURCE_CONTEXT='+report);
log('NATIVE_LEAN_PROBE='+target);
