# 52-page manuscript — Lean theorem coverage ledger

**Source of record:** Prince Anand, *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, dated 21 October 2026, 52-page uploaded PDF. PDF theorem numbering is preserved. Status refers to the bundled source files, **not** to a fresh Lean compiler run of this audit edition.

## Unconditional core already present in the upstream Lean archive

| Paper claim | Lean file / endpoint | Coverage |
|---|---|---|
| Definition 2.1, rational moment pencil | `Definition_2_1_Order_s_Rational_Moment_Functional.lean`, `Zetahyperbolic/Section2Checked.lean` | finite definitions and exact algebra |
| Theorem 2.4, canonical basis invariance | `Theorem_2_4_Canonical_Basis_Invariance.lean` | algebraic basis invariance |
| Theorem 2.5, Lagrange diagonalization | `Theorem_2_5_Lagrange_Pole_Diagonalization.lean` | finite diagonal pencil and invertible slope |
| Equation (3.2), analytic moment realization | `Theorem_3_1_Pole_Integral_Identity.lean`, `Theorem_3_1_Concrete_Moment_Realization.lean`, `MAIN_CHAIN_ASSEMBLED.lean` | actual moment realization, not an assumed Gram identity |
| Theorem 3.1, general odd-weight real roots and zero-free disk | `MAIN_CHAIN_ASSEMBLED.lean` → `ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL`, `EXACT_ZERO_FREE_DISK` | unconditional for structurally admissible integer parameters; multiplicities allowed |
| Generic part of Theorem 4.1, transfer criterion | `Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean` | implication, with its decay and root-gap inputs explicit |
| Primitive integer normalization | `Theorem_2_4_Primitive_Normalization_Minimality.lean` | constructed and minimal among positive integral rescalings |
| Odd-weight irrationality **implication** | `MAIN_CHAIN_IRRATIONALITY.lean` | primitive quadratic decay implies irrationality; decay existence **not proved** |

The archive documents earlier Lean 4.33.0/Mathlib checks for its original modules. This audit's new modules have **not** been compiled or kernel-verified in the current environment.

## Sections whose literal claims are not discharged

| Paper | Missing component or correction |
|---|---|
| Lemmas 2.2–2.3 | Full PDF-level identification of all pullback/reflection/difference variants must be checked against existing finite definitions. |
| Prop. 3.2 | Exact real-s pole derivative, determinant nonzero and spectral reduction now coded; the analytic infinite `w_s`-Gram realization is still missing. |
| Thms. 3.3–3.4 | Sign-to-root correspondence for the spectrum is now coded. Full all-minor strict total positivity, exact signature counts, Dodgson and interlacing remain open. |
| **Cor. 3.5** | **False formula (3.6) as printed**: missing Gram Cholesky prefactor, wrong `I+tB` continued-fraction structure, and unjustified strict Lanczos off-diagonal positivity. See `PAPER_CORRECTIONS.md`. |
| **Cor. 3.6** | **False strict positivity for Hankel minors beyond the number of distinct spectral support points.** A two-point, order-three counterexample is formalized in `PAPER_COUNTEREXAMPLES.lean`. The displayed limit comparison inequality also has the wrong direction. |
| Thms. 3.7–3.9 | General Wronskian/log-concavity, Christoffel–Darboux derivative identity and the full Dirichlet/Hurwitz extensions require statement-by-statement formalization. A finite Fekete positivity lemma exists. |
| Prop. 4.2–4.3 | Algebraic resultant and p-adic transfer generality not available as full manuscript theorems in this archive. |
| **Thm. 4.4** | **Required quantitative inputs not supplied:** arithmetic multiplier bound, Archimedean determinant upper bound, and `11.411 K` spectral norm estimate for the same normalized family. The claimed irrationality measure `25687` is not an unconditional checked output of this archive. |
| Thm. 4.5 | Multivariable coupling, uniform p-adic normalization and positivity for all specified `(a,b)` not closed here. |
| Thms. 4.6–4.8 | Two-sided determinant asymptotics, coefficient heights, exponential root clustering and rational-root exclusion not fully proved. |
| Remark 4.10 | Existence and first-order nonanalyticity of limiting free energy do not follow merely from zero clustering; needs an independent limit argument. |
| **Thm. 5.1** | Two-variable rational pencil defined; its integral moment identity is **not** proved in the corresponding bundled module. |
| **Thm. 5.2** | Finite sign-certificate implications checked; analytic infinite-tail estimate and universal positive/negative polynomial subspaces remain open. |
| Prop. 5.3; Thms. 5.4–5.7 | Beta moment extension, pole cancellation and local valuation/prime sum claims need paper-faithful bridges and proofs. |
| Thms. 6.1–6.2 | Divided-difference valuation obstruction and simultaneous weight-six/seven construction not fully formalized. |
| **Thms. 6.3–6.4** | The named files explicitly document conditional replacement statements; their filenames are paper titles, **not evidence of unconditional proofs**. |
| Thms. 6.5–6.18 | Mostly isolated interface and repair modules; a complete chronological Lean transcription including all arithmetic/analytic claims is not established. |

## Decisive quantitative frontier

Let `P_p` denote the actual positive primitive integer normalization, with `p=(k,m,N,K)` structurally admissible and `s=2k+1`. The assembled Lean archive proves a sufficient implication from

    exists sequence p_n at fixed k, K_n unbounded on tails,
    exists c>0 and n0,
    forall n>=n0, 0 < P_(p_n)(zeta(s)) <= exp(-c*K_n^2)

to `Irrational (riemannZeta s).re`. This is `GeneralIrrationality.OddWeightDecayHypothesis k`; it is not proved by the manuscript sources. Integer polynomials without the decay bound are insufficient to close it. For the paper's stronger **effective measure**, a quantitative uniform root gap must also be proved for precisely the same family.

## No hidden closure

This edition does not replace missing proofs by an `axiom`, `sorry`, `admit`, opaque oracle, a theorem argument disguised as a proof, or a vacuous specialization. It retains genuine conditional interfaces under their original names; the new `PaperAudit` unconditional entry point only exports an already supported spectral theorem.

## v0.3.8 update (candidate until user compiler pass)

Theorem 3.3 arithmetic parity counts for the special N=3n,K=30n family and
spectral root/eigenvalue-sign count equivalences are formalized in
`Theorem_3_3_Pole_Signature_Counts.lean`. **Residue sign, inertia, and total
positivity remain open**, and this is not the full theorem.
