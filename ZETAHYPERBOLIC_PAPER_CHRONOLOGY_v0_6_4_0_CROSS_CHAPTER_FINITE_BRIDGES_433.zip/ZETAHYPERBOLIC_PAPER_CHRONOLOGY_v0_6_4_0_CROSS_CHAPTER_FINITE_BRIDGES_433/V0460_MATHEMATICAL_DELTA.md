# v0.4.6.0 / Theorem 3.3 actual diagonal pole inertia profile

## Compiler provenance
101 previously frozen modules were verified by the user's native Lean 4.33.0 run (BUILD_COMPILED=0, BUILD_FROZEN_REUSED=101, RESULT=PASS). Their Lean source bytes are preserved. Two NEW source modules are pending a user's compiler run; no assistant-side Lean compilation has occurred.

## New exact PDF-level claims
* Exact diagonal entries of rational slope in pole-Lagrange coordinates are equal to the actual pole weights.
* Every such entry is nonzero and has the strict sign given by parity of the pole index; both directions of the sign equivalence are formalized.
* Every off-diagonal entry in the actual congruence is identically zero.
* Combine with K=30n, N=3n arithmetic counts to obtain the full pole-diagonal sign profile.

## Still not claimed
The real spectral inertia transfer from the diagonal congruence (Sylvester's law of inertia and eigenvalue multiplicity), and all nonprincipal Hankel minors, remain distinct mathematical targets. This package does not assume an external Witness for these steps, and it does not silently assert a full Theorem 3.3.
