import Proposition_3_2_Real_s_Weight_Finite_Layer
import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
import Mathlib.MeasureTheory.Measure.WithDensity
import Mathlib.Tactic.FunProp

/-!
# PDF Proposition 3.2: the full real-exponent exponential series

These are assertions about the ACTUAL infinite series in the PDF:
  sum_{l>=1} l^(s-1) exp(-2*pi*l*y).

Every exponent s : Real is allowed in the summability and unnormalized
series-positivity statements at each y>0.  For s>1, positivity of Gamma(s)
then provides the exact normalized positive density from the manuscript.

This module deliberately does NOT claim convergence of all Gram moments,
positive definiteness of the h-by-h moment matrix, or completion of the
whole Proposition 3.2. Those analytic bridges are the next frontier.
No hypothetical real-s summability or positivity certificates are passed.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set

namespace PaperChronology.Proposition3_2.Analytic

/-- Polynomial-exponential domination for the actual real-s summands:
for every integer upper bound `k` on `s-1`, the real-exponent series is
summable.  The dominating polynomial/exponential sum has an existing
Mathlib summability proof, already used in our odd-weight Section 3. -/
theorem summable_exponentialTerm_of_exponent_le_nat
    (s : ℝ) (k : ℕ) (hsk : s - 1 ≤ (k : ℝ))
    {y : ℝ} (hy : 0 < y) :
    Summable (fun n : ℕ => exponentialTerm s n y) := by
  have hmajorant : Summable (fun n : ℕ =>
      ((n + 1 : ℕ) : ℝ) ^ k *
        Real.exp (-(2 * Real.pi * y) * ((n + 1 : ℕ) : ℝ))) := by
    exact (summable_nat_add_iff 1).mpr
      (Real.summable_pow_mul_exp_neg_nat_mul k
        (show 0 < 2 * Real.pi * y by positivity))
  refine hmajorant.of_nonneg_of_le
    (fun n => (exponentialTerm_pos s n hy).le) (fun n => ?_)
  have hn : (1 : ℝ) ≤ ((n + 1 : ℕ) : ℝ) := by
    exact_mod_cast (show 1 ≤ n + 1 by omega)
  have hp : ((n + 1 : ℕ) : ℝ) ^ (s - 1) ≤
      ((n + 1 : ℕ) : ℝ) ^ (k : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hn hsk
  have he : 0 ≤ Real.exp
      (-(2 * Real.pi * y) * ((n + 1 : ℕ) : ℝ)) :=
    (Real.exp_pos _).le
  simpa only [exponentialTerm, Real.rpow_natCast] using
    (mul_le_mul_of_nonneg_right hp he)

/-- No restriction on the real exponent: exponential decay dominates all
fixed real powers for every `y > 0`. -/
theorem summable_exponentialTerm (s : ℝ) {y : ℝ} (hy : 0 < y) :
    Summable (fun n : ℕ => exponentialTerm s n y) := by
  obtain ⟨k, hk⟩ := exists_nat_gt (s - 1)
  exact summable_exponentialTerm_of_exponent_le_nat
    s k (le_of_lt hk) hy

/-- The manuscript's *infinite*, not truncated, series. -/
def exponentialSeries (s y : ℝ) : ℝ :=
  ∑' n : ℕ, exponentialTerm s n y

theorem exponentialSeries_pos (s : ℝ) {y : ℝ} (hy : 0 < y) :
    0 < exponentialSeries s y := by
  unfold exponentialSeries
  exact (summable_exponentialTerm s hy).tsum_pos
    (fun n => (exponentialTerm_pos s n hy).le)
    0 (exponentialTerm_pos s 0 hy)

/-- The EXACT normalized real-s density in Proposition 3.2, equation (3.2)
for the continuous-weight extension (the PDF uses `w_s`). -/
def realWeight (s y : ℝ) : ℝ :=
  (2 * (2 * Real.pi) ^ (s - 1) / Real.Gamma s) *
    y ^ s * exponentialSeries s y

/-- Strict positivity of the complete, normalized real-s weight, without
assuming an unproved measure realization. -/
theorem realWeight_pos {s y : ℝ} (hs : 1 < s) (hy : 0 < y) :
    0 < realWeight s y := by
  have hs0 : 0 < s := by linarith
  have hc : 0 < 2 * (2 * Real.pi) ^ (s - 1) / Real.Gamma s := by
    exact div_pos
      (mul_pos (by norm_num) (Real.rpow_pos_of_pos (by positivity) _))
      (Real.Gamma_pos_of_pos hs0)
  unfold realWeight
  exact mul_pos (mul_pos hc (Real.rpow_pos_of_pos hy _))
    (exponentialSeries_pos s hy)

theorem measurable_exponentialTerm (s : ℝ) (n : ℕ) :
    Measurable (exponentialTerm s n) := by
  unfold exponentialTerm
  fun_prop

theorem measurable_exponentialSeries (s : ℝ) :
    Measurable (exponentialSeries s) := by
  unfold exponentialSeries
  exact Measurable.tsum (fun n => measurable_exponentialTerm s n)

/-- The real-s density is measurable, so its `withDensity` measure
exists independently of the still-pending moment-integrability bounds. -/
theorem measurable_realWeight (s : ℝ) : Measurable (realWeight s) := by
  have hpow : Measurable (fun y : ℝ => y ^ s) := by fun_prop
  unfold realWeight
  exact (measurable_const.mul hpow).mul (measurable_exponentialSeries s)

/-- The actual positive-half-line measure for the full real-s density. -/
def baseMeasure (s : ℝ) : Measure ℝ :=
  (volume.restrict (Ioi 0)).withDensity
    (fun y => ENNReal.ofReal (realWeight s y))

/-- The full-series measure is not identically zero when `s>1`. -/
theorem baseMeasure_nonzero (s : ℝ) (hs : 1 < s) :
    baseMeasure s ≠ 0 := by
  have hac : volume.restrict (Ioi (0 : ℝ)) ≪ baseMeasure s := by
    apply withDensity_absolutelyContinuous'
      (measurable_realWeight s).ennreal_ofReal.aemeasurable
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
    exact ne_of_gt (ENNReal.ofReal_pos.mpr (realWeight_pos hs hy))
  intro hzero
  rw [hzero] at hac
  have h := Measure.absolutelyContinuous_zero_iff.mp hac
  have hu := congrArg (fun μ : Measure ℝ => μ Set.univ) h
  simp at hu

/-- At the odd weights the full real-exponent series is termwise identical
to the already kernel-checked exponential series of Theorem 3.1. -/
theorem exponentialSeries_at_odd (p : ManuscriptChain.Real.Parameters)
    (y : ℝ) :
    exponentialSeries (p.weight : ℝ) y =
      ∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm p.k n y := by
  simp only [exponentialSeries, exponentialTerm_at_odd]

/-- At odd weights the normalized real-s density specializes to the
existing Theorem 3.1 density, including the Gamma/factorial normalization. -/
theorem realWeight_at_odd (p : ManuscriptChain.Real.Parameters)
    (y : ℝ) :
    realWeight (p.weight : ℝ) y =
      ManuscriptChain.Hyperbolic.density p.k y := by
  have hs : (p.weight : ℝ) - 1 = (2 * p.k : ℕ) := by
    dsimp [ManuscriptChain.Real.Parameters.weight]
    push_cast
    ring
  have hg : Real.Gamma (p.weight : ℝ) =
      (Nat.factorial (2 * p.k) : ℝ) := by
    have heq : (p.weight : ℝ) = ((2 * p.k : ℕ) : ℝ) + 1 := by
      dsimp [ManuscriptChain.Real.Parameters.weight]
      push_cast
      ring
    rw [heq, Real.Gamma_nat_eq_factorial]
  -- Make each of the three changes of normalization explicit, rather than
  -- relying on a broad simp call to identify two differently-typed powers.
  have hconstant :
      2 * (2 * Real.pi) ^ ((p.weight : ℝ) - 1) /
          Real.Gamma (p.weight : ℝ) =
        2 * (2 * Real.pi) ^ (2 * p.k) /
          (Nat.factorial (2 * p.k) : ℝ) := by
    rw [hs, hg, Real.rpow_natCast]
  have hyPower :
      y ^ (p.weight : ℝ) = y ^ (2 * p.k + 1) := by
    change y ^ ((2 * p.k + 1 : ℕ) : ℝ) = y ^ (2 * p.k + 1)
    rw [Real.rpow_natCast]
  calc
    realWeight (p.weight : ℝ) y =
        (2 * (2 * Real.pi) ^ ((p.weight : ℝ) - 1) /
           Real.Gamma (p.weight : ℝ)) *
           y ^ (p.weight : ℝ) * exponentialSeries (p.weight : ℝ) y := rfl
    _ = (2 * (2 * Real.pi) ^ (2 * p.k) /
           (Nat.factorial (2 * p.k) : ℝ)) *
          y ^ (2 * p.k + 1) *
            (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm p.k n y) := by
          rw [hconstant, hyPower, exponentialSeries_at_odd]
    _ = ManuscriptChain.Hyperbolic.density p.k y := rfl

end PaperChronology.Proposition3_2.Analytic

#print axioms PaperChronology.Proposition3_2.Analytic.summable_exponentialTerm
#print axioms PaperChronology.Proposition3_2.Analytic.exponentialSeries_pos
#print axioms PaperChronology.Proposition3_2.Analytic.realWeight_pos
#print axioms PaperChronology.Proposition3_2.Analytic.baseMeasure_nonzero
#print axioms PaperChronology.Proposition3_2.Analytic.realWeight_at_odd
