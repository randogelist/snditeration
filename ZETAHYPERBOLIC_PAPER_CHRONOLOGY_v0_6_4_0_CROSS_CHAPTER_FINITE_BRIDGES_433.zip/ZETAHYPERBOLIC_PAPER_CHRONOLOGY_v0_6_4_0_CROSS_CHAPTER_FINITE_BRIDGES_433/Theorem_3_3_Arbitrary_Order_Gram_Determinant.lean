import Zetahyperbolic.CoreLinearAlgebra
import Mathlib.Tactic

/-!
# PDF Theorem 3.3(1): finite Gram determinants of arbitrary order

The index type ι is arbitrary and finite. We work over ℚ, the coefficient
field of the paper's actual pole Vandermonde and signed residues, to avoid
unnecessary typeclass generalization in the theorem interface.

If V is nonsingular and all weights are positive, the full-order determinant
of V diag(w) Vᵀ is strictly positive. This algebraic result does NOT by
itself establish total positivity of the paper's continuous Hankel matrix.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ArbitraryGram

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The full-order rational weighted Gram matrix. -/
def weightedGram (V : Matrix ι ι ℚ) (w : ι → ℚ) : Matrix ι ι ℚ :=
  V * Matrix.diagonal w * V.transpose

/-- Exact determinant factorization at every finite matrix order. -/
theorem weightedGram_det (V : Matrix ι ι ℚ) (w : ι → ℚ) :
    (weightedGram V w).det = V.det ^ 2 * ∏ i, w i := by
  change (V * Matrix.diagonal w * V.transpose).det = V.det ^ 2 * ∏ i, w i
  exact Zetahyperbolic.det_conjugated_diagonal V w

/-- Positivity of the full Gram determinant for positive masses. -/
theorem weightedGram_det_pos (V : Matrix ι ι ℚ) (w : ι → ℚ)
    (hV : V.det ≠ 0) (hw : ∀ i, 0 < w i) :
    0 < (weightedGram V w).det := by
  rw [weightedGram_det]
  have hV2 : 0 < V.det ^ 2 := sq_pos_of_ne_zero hV
  have hwprod : 0 < ∏ i, w i := by
    apply Finset.prod_pos
    intro i _
    exact hw i
  exact mul_pos hV2 hwprod

/-- Nonvanishing follows from strict positivity. -/
theorem weightedGram_det_ne_zero (V : Matrix ι ι ℚ) (w : ι → ℚ)
    (hV : V.det ≠ 0) (hw : ∀ i, 0 < w i) :
    (weightedGram V w).det ≠ 0 :=
  ne_of_gt (weightedGram_det_pos V w hV hw)

/-- If one diagonal mass vanishes, so does the full determinant. -/
theorem weightedGram_det_zero_of_weight_zero
    (V : Matrix ι ι ℚ) (w : ι → ℚ) (i : ι) (hi : w i = 0) :
    (weightedGram V w).det = 0 := by
  change (V * Matrix.diagonal w * V.transpose).det = 0
  exact Zetahyperbolic.det_conjugated_diagonal_eq_zero_of_weight_zero V w i hi

end PaperChronology.Theorem3_3.ArbitraryGram

#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det
#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det_pos
#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det_zero_of_weight_zero
