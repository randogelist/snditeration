# 0.6.1.0 — full theorem proof run, after the seven blueprints PASS

- The user Windows Lean 4.33 checkpoint `RESULT=PASS_BLUEPRINTS_ONLY` established elaboration of seven blueprint sources, *not* proofs of their declared endpoints.
- Known baseline: 105 earlier verified mathematical source modules with pass-once / persistent `.olean` reuse.
- This release preserves ALL 120 Lean source files byte-for-byte from v0.6.0.2, adding no hidden assumptions or proof placeholders.
- `run.cmd proofs` uses `FASTCORE_ORDER.txt` over ALL 120 sources. It REUSES all unchanged prior successful modules and compiles the eight v0.5.0 theorem candidate sources that remain pending, plus any dependency-invalidated sources.
- `run.cmd blueprints` remains available for blueprint-only rechecks; `run.cmd full` forces rebuild using the user's compiler.
- The eight v0.5.0 theorem candidates, in order, are:

  1. `Theorem_3_4_Actual_Principal_Spectral_Gap`
  2. `Corollary_3_5_Corrected_Schur_Fraction`
  3. `Corollary_3_6_Reciprocal_Root_Moment_Bounds`
  4. `Theorem_3_7_All_Order_Turanian_Jets`
  5. `Theorem_3_7_Real_Rooted_Polynomial_Turanian`
  6. `Theorem_3_8_Actual_Christoffel_Darboux_Kernel`
  7. `Theorem_4_1_Witness_Free_Principal_Separation`
  8. `PAPER_CHRONOLOGICAL_EXTENSION_9`

- Successful full compilation is NOT full PDF theorem coverage. The 51-item manuscript inventory retains open analytic/p-adic bridges and its effective arithmetic Witness.

## Certificate requirement

`RESULT=PASS` following the `V050_CERTIFIED=` checks certifies all 120 source modules have been compiled or frozen at their current source fingerprints. A user reported intermediate `CHECK_PASS` is not yet an overall PASS.

Actual compilation is performed only by the user's native Windows Lean.
