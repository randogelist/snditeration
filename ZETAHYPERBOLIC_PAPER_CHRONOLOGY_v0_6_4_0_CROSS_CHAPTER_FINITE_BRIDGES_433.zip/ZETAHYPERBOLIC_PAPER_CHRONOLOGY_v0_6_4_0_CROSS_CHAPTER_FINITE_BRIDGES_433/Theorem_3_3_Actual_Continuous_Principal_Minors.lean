import Proposition_3_2_Real_s_Moment_Integrability
import MAIN_CHAIN_ASSEMBLED
import Mathlib.Tactic

/-!
# PDF Theorem 3.3(1): strictly positive principal minors of the actual Hankel matrices

This is a direct manuscript theorem, not an auxiliary finite-atom example.
It applies to the genuine continuous real-s Hankel moment matrix constructed
in Proposition 3.2, and separately to the original odd-integer moment pencil.
For EVERY finite selection of distinct monomial indices, the principal
submatrix is positive definite and its determinant is strictly positive.

The *nonprincipal* minors required for complete strict total positivity
remain a separate Andreief/generalized-Vandermonde formalization frontier.
No witness is used and no sorry/axiom is introduced.
-/

noncomputable section

namespace PaperChronology.Theorem3_3.ActualContinuousPrincipal

open PaperChronology.Proposition3_2

/-- The actual continuous real-s Gram matrix is positive definite on every
finite family of distinct monomial indices, not merely on the original basis. -/
theorem real_s_principal_posDef (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h) (hchoose : Function.Injective choose) :
    ((Gram.gram s p).submatrix choose choose).PosDef :=
  (Integrability.actualGram_posDef s p hs).submatrix hchoose

/-- The full-order continuum result behind PDF Theorem 3.3: EVERY principal
minor of the ACTUAL real-s Hankel moment matrix is strictly positive. -/
theorem real_s_all_principal_minors_pos (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h) (hchoose : Function.Injective choose) :
    0 < ((Gram.gram s p).submatrix choose choose).det :=
  (real_s_principal_posDef s p hs choose hchoose).det_pos

/-- The original PDF odd-weight Hankel Gram matrix has strictly positive
principal submatrices at every size and every subset of monomial indices. -/
theorem odd_weight_principal_posDef
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h) (hchoose : Function.Injective choose) :
    ((ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)).submatrix
      choose choose).PosDef :=
  (ManuscriptChain.GRAM_POSITIVE p hp).submatrix hchoose

/-- Every principal minor of the ORIGINAL odd-zeta Hankel matrix at the
manuscript evaluation point is strictly positive, all orders at once. -/
theorem odd_weight_all_principal_minors_pos
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h) (hchoose : Function.Injective choose) :
    0 < ((ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)).submatrix
      choose choose).det :=
  (odd_weight_principal_posDef p hp choose hchoose).det_pos

end PaperChronology.Theorem3_3.ActualContinuousPrincipal

#print axioms PaperChronology.Theorem3_3.ActualContinuousPrincipal.real_s_all_principal_minors_pos
#print axioms PaperChronology.Theorem3_3.ActualContinuousPrincipal.odd_weight_all_principal_minors_pos
