import PAPER_CHRONOLOGICAL_EXTENSION_4
import Theorem_3_3_Actual_Sign_Corrected_Pole_Gram

/-!
# Chronological Section 3, extension 5

A genuine all-dimensional algebraic step of PDF Theorem 3.3, now instantiated
with the exact negative-square pole lattice of the actual manuscript model.
No arithmetic witness is used in this algebraic/spectral groundwork.
Continuous-moment strict total positivity is NOT claimed by this theorem.
-/

noncomputable section
namespace PaperChronology

/-- Every finite size of the *actual* sign-adjusted pole Vandermonde Gram
has strictly positive determinant. -/
theorem paper_theorem_3_3_actual_all_order_corrected_pole_gram
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    0 < (Theorem3_3.ArbitraryGram.weightedGram
      (ManuscriptChain.PoleDiagonalization.poleVandermonde p)
      (Theorem3_3.ActualPoleGram.correctedPoleWeight p)).det :=
  Theorem3_3.ActualPoleGram.correctedPoleGram_det_pos p hm

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_actual_all_order_corrected_pole_gram
