import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Mathlib.Tactic

/-!
# Theorem 5.1: exact algebra of the rational Beukers divided differences

The off-diagonal entries in the printed 2D Beukers moment formula are
rational harmonic-number divided differences. This file establishes
their symmetry and the symmetry of the actual finite rational moment
pencil of the manuscript, at EVERY finite dimension.

The infinite DOUBLE INTEGRAL equality (5.2) is a separate open analytic
bridge; no integral statement is inferred from rational identities.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology.Theorem5_1.DualSymmetry
open ManuscriptChain.Real

/-- The exact divided-difference moment coefficient is symmetric,
including its diagonal convention. -/
theorem dualConstant_swap (s r t : ℕ) :
    dualConstant s r t = dualConstant s t r := by
  by_cases h : r = t
  · subst t
    rfl
  · have ht : t ≠ r := Ne.symm h
    simp only [dualConstant, if_neg h, if_neg ht]
    have hn : harmonic (s - 1) r - harmonic (s - 1) t =
        -(harmonic (s - 1) t - harmonic (s - 1) r) := by ring
    have hd : ((s - 1 : ℕ) : ℚ) * ((r : ℚ) - (t : ℚ)) =
        -(((s - 1 : ℕ) : ℚ) * ((t : ℚ) - (r : ℚ))) := by ring
    rw [hn, hd]
    simp

/-- Rational constant matrix of the weight-s two-variable pencil. -/
def constantGram {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) : ℚ :=
  ∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
    c i r * c j t * dualConstant s r.val t.val

/-- Coefficient-of-X Gram in the dual two-variable pencil. -/
def slopeGram {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) : ℚ :=
  ∑ r : Fin (K + 1), c i r * c j r

/-- The rational off-diagonal divided-difference matrix is symmetric. -/
theorem constantGram_swap {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) :
    constantGram s c i j = constantGram s c j i := by
  unfold constantGram
  calc
    (∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
      c i r * c j t * dualConstant s r.val t.val) =
        ∑ t : Fin (K + 1), ∑ r : Fin (K + 1),
          c i r * c j t * dualConstant s r.val t.val := by
            rw [Finset.sum_comm]
    _ = ∑ t : Fin (K + 1), ∑ r : Fin (K + 1),
          c j t * c i r * dualConstant s t.val r.val := by
            apply Finset.sum_congr rfl
            intro t _
            apply Finset.sum_congr rfl
            intro r _
            rw [dualConstant_swap]
            ring
    _ = ∑ r : Fin (K + 1), ∑ t : Fin (K + 1),
          c j r * c i t * dualConstant s r.val t.val := rfl

/-- The exact X-slope matrix is symmetric for ANY rational coefficient
basis. Full-rank positivity is a further independent linear-algebra step. -/
theorem slopeGram_swap {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) :
    slopeGram c i j = slopeGram c j i := by
  unfold slopeGram
  apply Finset.sum_congr rfl
  intro r _
  ring

/-- The genuine rational polynomial pencil from equation (5.3) has
symmetric entries as an identity IN ℚ[X], not only at a sampled X. -/
theorem dualEntry_swap {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) :
    dualEntry s c i j = dualEntry s c j i := by
  change Polynomial.C (constantGram s c i j) +
        Polynomial.C (slopeGram c i j) * Polynomial.X =
      Polynomial.C (constantGram s c j i) +
        Polynomial.C (slopeGram c j i) * Polynomial.X
  rw [constantGram_swap, slopeGram_swap]

end PaperChronology.Theorem5_1.DualSymmetry

#print axioms PaperChronology.Theorem5_1.DualSymmetry.dualConstant_swap
#print axioms PaperChronology.Theorem5_1.DualSymmetry.dualEntry_swap
