import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil
import Mathlib.Tactic

/-!
# Theorem 5.2: exact six-mode Krein pairing (finite rank)

At each finite series index m, the six contributions nu=0,...,5
are paired as (0,5), (1,4), (2,3). The binomial symmetry and
2ab = ((a+b)^2-(a-b)^2)/2 give a REAL signed-Krein algebraic identity.
This lemma is universal for arbitrary rational mode vectors; it does not
assume a vanishing infinite tail or any irrationality conjecture.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem5_2.FiniteKrein

/-- Six-mode paired polarization, with the manuscript's exact
1/720 and 1/1440 normalization constants. -/
theorem six_mode_pair (a b : ℕ → ℚ) :
    (∑ ν ∈ Finset.range 6,
      (Nat.choose 5 ν : ℚ) / 720 * a ν * b (5 - ν)) =
      ∑ ν ∈ Finset.range 3,
        (Nat.choose 5 ν : ℚ) / 1440 *
          ((a ν + a (5 - ν)) * (b ν + b (5 - ν)) -
           (a ν - a (5 - ν)) * (b ν - b (5 - ν))) := by
  norm_num [Finset.sum_range_succ, Nat.choose] <;> ring

/-- Quadratic specialization: every paired summand is exactly the
difference of two squares, even at arbitrary rational data. -/
theorem six_mode_quadratic (a : ℕ → ℚ) :
    (∑ ν ∈ Finset.range 6,
      (Nat.choose 5 ν : ℚ) / 720 * a ν * a (5 - ν)) =
      ∑ ν ∈ Finset.range 3,
        (Nat.choose 5 ν : ℚ) / 1440 *
          ((a ν + a (5 - ν)) ^ 2 -
           (a ν - a (5 - ν)) ^ 2) := by
  simpa only [pow_two] using six_mode_pair a a

end PaperChronology.Theorem5_2.FiniteKrein

#print axioms PaperChronology.Theorem5_2.FiniteKrein.six_mode_pair
#print axioms PaperChronology.Theorem5_2.FiniteKrein.six_mode_quadratic
