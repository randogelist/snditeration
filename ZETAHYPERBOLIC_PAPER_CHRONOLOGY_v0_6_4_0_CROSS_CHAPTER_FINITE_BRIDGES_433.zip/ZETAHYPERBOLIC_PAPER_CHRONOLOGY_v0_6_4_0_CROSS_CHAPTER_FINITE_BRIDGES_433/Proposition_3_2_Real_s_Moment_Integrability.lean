import Proposition_3_2_Real_s_Weight_Envelope
import Theorem_3_1_Concrete_Moment_Realization
import Mathlib.Tactic

/-!
# PDF Proposition 3.2: all real-s weighted moments are finite

This completes the sole outstanding analytic input from the preceding Gram
measure module.  It uses the ACTUAL infinite real-s density and ACTUAL
D_N(y^2)^(2m)/D_K(y^2) ratio.  The envelope proven in the preceding file
bounds that density by two *already proved* odd-integer densities, with
strictly positive constants.

The moment integrability for odd-integer densities, including the same
polynomial denominator, is already proved in
`Theorem_3_1_Concrete_Moment_Realization`.

No moment-integrability, positive-definiteness, real-rootedness, or
irrationality hypotheses are taken as input.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set Polynomial

namespace PaperChronology.Proposition3_2.Integrability

open PaperChronology.Proposition3_2
open PaperChronology.Proposition3_2.Envelope

/-- The denominator ratio is independent of the odd-weight index. -/
lemma weightedDensity_le_oddWeighted (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (hs : 1 < s) (hsk : s - 1 ≤ ((2 * k : ℕ) : ℝ))
    {y : ℝ} (hy : 0 < y) :
    Gram.weightedDensity s p y ≤
      (realCoefficient s / oddCoefficient 0) *
        ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y +
      (realCoefficient s / oddCoefficient k) *
        ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y := by
  have hratio : 0 ≤
      (Zetahyperbolic.D_real p.N (y ^ 2)) ^ (2 * p.m) /
        Zetahyperbolic.D_real p.K (y ^ 2) :=
    (Zetahyperbolic.D_real_ratio_pos p.N p.K p.m hy).le
  have h := mul_le_mul_of_nonneg_left
    (realWeight_le_oddWeights s k hs hsk hy) hratio
  simpa only [Gram.weightedDensity, ManuscriptChain.ConcreteMoment.weightedDensity,
    mul_add, mul_assoc, mul_left_comm, mul_comm] using h

/-- Every even-y-power weighted moment of the exact real-s density is
integrable on y>0; no external analytic witness is necessary. -/
theorem integrableOn_weightedDensity_moment (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) (e : ℕ) :
    IntegrableOn (fun y : ℝ => y ^ (2 * e) * Gram.weightedDensity s p y)
      (Ioi 0) := by
  obtain ⟨k, hsk⟩ := exists_odd_upper s
  let c0 : ℝ := realCoefficient s / oddCoefficient 0
  let ck : ℝ := realCoefficient s / oddCoefficient k
  have h0 : IntegrableOn
      (fun y : ℝ => y ^ (2 * e) *
        ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y)
        (Ioi 0) :=
    ManuscriptChain.ConcreteMoment.integrableOn_weightedDensity_moment
      {p with k := 0} e
  have hk : IntegrableOn
      (fun y : ℝ => y ^ (2 * e) *
        ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y)
        (Ioi 0) :=
    ManuscriptChain.ConcreteMoment.integrableOn_weightedDensity_moment
      {p with k := k} e
  have hsum := (h0.const_mul c0).add (hk.const_mul ck)
  -- First establish the stronger real-valued pointwise majorant; then
  -- convert it to a norm majorant in the final `Integrable.mono'` step.
  have hmeas : AEStronglyMeasurable
      (fun y : ℝ => y ^ (2 * e) * Gram.weightedDensity s p y)
      (volume.restrict (Ioi (0 : ℝ))) :=
    (((measurable_id.pow_const _).mul
      (Gram.measurable_weightedDensity s p)).aestronglyMeasurable)
  have hdom :
      ∀ᵐ y ∂(volume.restrict (Ioi (0 : ℝ))),
        ‖y ^ (2 * e) * Gram.weightedDensity s p y‖ ≤
          c0 * (y ^ (2 * e) *
                ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y) +
          ck * (y ^ (2 * e) *
                ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
    have hy0 : 0 ≤ y ^ (2 * e) := pow_nonneg hy.le _
    have htarget : 0 ≤ y ^ (2 * e) * Gram.weightedDensity s p y :=
      mul_nonneg hy0 (Gram.weightedDensity_pos s p hs hy).le
    have hbound := mul_le_mul_of_nonneg_left
      (weightedDensity_le_oddWeighted s p k hs hsk hy) hy0
    -- The envelope bound is directly a real-valued majorant.
    calc
      ‖y ^ (2 * e) * Gram.weightedDensity s p y‖ =
          y ^ (2 * e) * Gram.weightedDensity s p y :=
          Real.norm_of_nonneg htarget
      _ ≤ c0 * (y ^ (2 * e) *
            ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y) +
          ck * (y ^ (2 * e) *
            ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y) := by
          simpa only [c0, ck, mul_add, mul_assoc, mul_left_comm, mul_comm] using hbound
  -- The two `const_mul` lemmas associate multiplication on the left.
  -- Normalize the integrable envelope to the exact right-hand side of
  -- `hdom`; this version of `Integrable.mono'` accepts a real-valued
  -- majorant (not its norm) as its third argument.
  have hsum_explicit : IntegrableOn
      (fun y : ℝ =>
        c0 * (y ^ (2 * e) *
          ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y) +
        ck * (y ^ (2 * e) *
          ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y))
      (Ioi 0) := by
    -- The two definitions are definitionally equal: `IntegrableOn` is
    -- `Integrable` for the restricted measure, and addition of functions
    -- reduces to pointwise addition.  No `simp` lemma is needed here.
    change IntegrableOn
      (fun y : ℝ =>
        c0 * (y ^ (2 * e) *
          ManuscriptChain.ConcreteMoment.weightedDensity {p with k := 0} y) +
        ck * (y ^ (2 * e) *
          ManuscriptChain.ConcreteMoment.weightedDensity {p with k := k} y))
      (Ioi 0) at hsum
    exact hsum
  exact hsum_explicit.mono' hmeas hdom

/-- ALL monomial moments of the exact pushed-forward measure are finite. -/
theorem integrable_momentMeasure (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) (e : ℕ) :
    Integrable (fun t : ℝ => t ^ e) (Gram.momentMeasure s p) :=
  (Gram.integrable_momentMeasure_iff s p hs e).2
    (integrableOn_weightedDensity_moment s p hs e)

/-- Strict positive definiteness of the ACTUAL real-s Gram matrix. -/
theorem actualGram_posDef (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Gram.gram s p).PosDef :=
  Gram.gram_posDef_of_integrable s p hs
    (fun i j => integrable_momentMeasure s p hs (i.val + j.val))

/-- FULL real-s exact-degree conclusion of PDF Proposition 3.2. -/
theorem actualPencil_exact_degree (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Gram.actualPencil s p).detPolynomial.natDegree = p.h :=
  Gram.actualPencil_degree_of_integrable s p hs
    (fun i j => integrable_momentMeasure s p hs (i.val + j.val))

/-- FULL real-s real-rootedness conclusion of PDF Proposition 3.2. -/
theorem actualPencil_root_real (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Gram.actualPencil s p).detPolynomial = 0) :
    z.im = 0 :=
  Gram.actualPencil_root_real_of_integrable s p hs
    (fun i j => integrable_momentMeasure s p hs (i.val + j.val)) z hz

/-- The real-s center is excluded without assuming any spectrally
positive Gram as an external parameter. -/
theorem actualPencil_center_ne_root (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Gram.actualPencil s p).detPolynomial.eval ((riemannZeta (s : ℂ)).re) ≠ 0 :=
  PaperChronology.Proposition3_2.center_is_not_a_root s p (Gram.gram s p)
    (Gram.gram_symmetric s p) (actualGram_posDef s p hs)

end PaperChronology.Proposition3_2.Integrability

#print axioms PaperChronology.Proposition3_2.Integrability.integrable_momentMeasure
#print axioms PaperChronology.Proposition3_2.Integrability.actualGram_posDef
#print axioms PaperChronology.Proposition3_2.Integrability.actualPencil_exact_degree
#print axioms PaperChronology.Proposition3_2.Integrability.actualPencil_root_real
