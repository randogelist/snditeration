import Theorem_3_4_Dodgson_Three_By_Three
import Mathlib.Tactic

/-!
# PDF Theorem 3.4(2) — exact order-four Dodgson condensation

The preceding verified module established the order-three identities.
This proof handles the next nontrivial case, an unrestricted seven-moment
Hankel polynomial with four rows and columns.  All identities are algebraic
polynomial equalities, not spectral or arithmetic assumptions.

The `hankelDet4` expression is defined by the first-row cofactor formula.
A separate Matrix.det bridge for the manuscript's actual pencil is still
required for the complete arbitrary-order Theorem 3.4.
-/

noncomputable section
namespace PaperChronology.Theorem3_4.Dodgson4

open PaperChronology.Theorem3_4.Dodgson3

/-- Symbolic three-by-three cofactor determinant. -/
def det3Rows (a b c d e f g h i : ℝ) : ℝ :=
  a * (e * i - f * h) -
  b * (d * i - f * g) +
  c * (d * h - e * g)

/-- Exact first-row expansion of the order-four Hankel determinant. -/
def hankelDet4 (m0 m1 m2 m3 m4 m5 m6 : ℝ) : ℝ :=
    m0 * det3Rows m2 m3 m4 m3 m4 m5 m4 m5 m6 -
    m1 * det3Rows m1 m3 m4 m2 m4 m5 m3 m5 m6 +
    m2 * det3Rows m1 m2 m4 m2 m3 m5 m3 m4 m6 -
    m3 * det3Rows m1 m2 m3 m2 m3 m4 m3 m4 m5

set_option maxHeartbeats 1000000

/-- The exact size-four Hankel Dodgson/Jacobi identity. -/
theorem condensation_four (m0 m1 m2 m3 m4 m5 m6 : ℝ) :
    hankelDet4 m0 m1 m2 m3 m4 m5 m6 * (m2 * m4 - m3 ^ 2) =
      det3 m0 m1 m2 m3 m4 * det3 m2 m3 m4 m5 m6 -
        (det3 m1 m2 m3 m4 m5) ^ 2 := by
  simp only [hankelDet4, det3Rows, det3,
    PaperChronology.Theorem3_3.DiscreteSamples.hankelDet3]
  ring

/-- At a root of the upper-left order-three Hankel minor, the order-four
condensation remainder is exactly a negative square. -/
theorem condensation_four_at_minor_root
    (m0 m1 m2 m3 m4 m5 m6 : ℝ)
    (hminor : det3 m0 m1 m2 m3 m4 = 0) :
    hankelDet4 m0 m1 m2 m3 m4 m5 m6 * (m2 * m4 - m3 ^ 2) =
      -(det3 m1 m2 m3 m4 m5) ^ 2 := by
  rw [condensation_four, hminor]
  ring

/-- Sign law at a zero of the upper-left order-three minor, when the
central complementary order-two minor is strictly positive. -/
theorem det4_nonpos_at_minor_root
    (m0 m1 m2 m3 m4 m5 m6 : ℝ)
    (hcenter : 0 < m2 * m4 - m3 ^ 2)
    (hminor : det3 m0 m1 m2 m3 m4 = 0) :
    hankelDet4 m0 m1 m2 m3 m4 m5 m6 ≤ 0 := by
  have hroot := condensation_four_at_minor_root
    m0 m1 m2 m3 m4 m5 m6 hminor
  have hmul : hankelDet4 m0 m1 m2 m3 m4 m5 m6 *
      (m2 * m4 - m3 ^ 2) ≤ 0 := by
    rw [hroot]
    exact neg_nonpos.mpr (sq_nonneg _)
  by_contra hc
  have hpos : 0 < hankelDet4 m0 m1 m2 m3 m4 m5 m6 :=
    lt_of_not_ge hc
  exact (not_lt_of_ge hmul) (mul_pos hpos hcenter)

/-- Strict sign law when the complementary off-diagonal order-three
minor does not vanish. -/
theorem det4_neg_at_minor_root
    (m0 m1 m2 m3 m4 m5 m6 : ℝ)
    (hcenter : 0 < m2 * m4 - m3 ^ 2)
    (hminor : det3 m0 m1 m2 m3 m4 = 0)
    (hoff : det3 m1 m2 m3 m4 m5 ≠ 0) :
    hankelDet4 m0 m1 m2 m3 m4 m5 m6 < 0 := by
  have hroot := condensation_four_at_minor_root
    m0 m1 m2 m3 m4 m5 m6 hminor
  have hs : 0 < (det3 m1 m2 m3 m4 m5) ^ 2 :=
    sq_pos_of_ne_zero hoff
  have hmul : hankelDet4 m0 m1 m2 m3 m4 m5 m6 *
      (m2 * m4 - m3 ^ 2) < 0 := by
    rw [hroot]
    exact neg_lt_zero.mpr hs
  by_contra hc
  have hnonneg : 0 ≤ hankelDet4 m0 m1 m2 m3 m4 m5 m6 :=
    le_of_not_gt hc
  exact (not_le_of_gt hmul) (mul_nonneg hnonneg hcenter.le)

end PaperChronology.Theorem3_4.Dodgson4

#print axioms PaperChronology.Theorem3_4.Dodgson4.condensation_four
#print axioms PaperChronology.Theorem3_4.Dodgson4.det4_nonpos_at_minor_root
#print axioms PaperChronology.Theorem3_4.Dodgson4.det4_neg_at_minor_root
