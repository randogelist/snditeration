# v0.4.0.1 — Windows CMD order guard repair

The user's Windows run aborted before compilation at RESULT=DISCRETE_MOMENT_MODULE_OMITTED. The module is present in FASTCORE_ORDER.txt (86 lines) and in the ZIP. The guard incorrectly relied on Windows `findstr /X` against the LF-only manifest. This patch reuses the existing `for /F` traversal to set three presence flags and test all three new modules. No .lean source or Mathlib setup changed. Prior 83 proofs remain frozen. Lean compilation is exclusively on the user's Windows 4.33.0 compiler.
