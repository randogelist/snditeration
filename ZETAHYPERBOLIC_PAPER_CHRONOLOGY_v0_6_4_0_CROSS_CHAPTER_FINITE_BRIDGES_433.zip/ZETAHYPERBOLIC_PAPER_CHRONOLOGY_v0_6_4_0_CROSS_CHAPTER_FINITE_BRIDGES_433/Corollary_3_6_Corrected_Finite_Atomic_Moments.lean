import PAPER_COUNTEREXAMPLES
import Mathlib.Tactic

/-!
# Corrected Corollary 3.6: finite support, finite Hankel rank

The reciprocal-root even moments are finite sums `S_m = ∑ u_i^m`.
Their k×k Hankel matrix factors exactly as `V Vᵀ`, where V is k×n.
This finite-dimensional identity explains why *strict* positivity cannot
hold above the number of distinct support points, a correction recorded
in `PAPER_CORRECTIONS.md`. It does not silently assert the false printed
strict positivity at all Hankel orders.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Corollary3_6.CorrectedFiniteAtomic

/-- The m-th power sum of an n-atom real measure of unit masses. -/
def atomicMoment {n : ℕ} (u : Fin n → ℝ) (m : ℕ) : ℝ :=
  ∑ i : Fin n, (u i) ^ m

/-- Every atomic moment of nonnegative support is nonnegative. -/
theorem atomicMoment_nonneg {n : ℕ} (u : Fin n → ℝ)
    (hu : ∀ i, 0 ≤ u i) (m : ℕ) :
    0 ≤ atomicMoment u m := by
  unfold atomicMoment
  apply Finset.sum_nonneg
  intro i _
  exact pow_nonneg (hu i) m

/-- The order-zero moment counts all atoms (with multiplicity). -/
theorem atomicMoment_zero {n : ℕ} (u : Fin n → ℝ) :
    atomicMoment u 0 = (n : ℝ) := by
  simp [atomicMoment]

/-- Uniform spectral upper bound yields a finite moment upper bound. -/
theorem atomicMoment_le_card_mul_pow {n : ℕ} (u : Fin n → ℝ)
    (hu : ∀ i, 0 ≤ u i) (B : ℝ) (hB : ∀ i, u i ≤ B)
    (m : ℕ) :
    atomicMoment u m ≤ (n : ℝ) * B ^ m := by
  unfold atomicMoment
  calc
    (∑ i : Fin n, (u i) ^ m) ≤ ∑ _i : Fin n, B ^ m := by
      apply Finset.sum_le_sum
      intro i _
      exact pow_le_pow_left₀ (hu i) (hB i) m
    _ = (n : ℝ) * B ^ m := by simp

/-- The rectangular Vandermonde whose columns are powers of the atoms. -/
def atomicVandermonde {n : ℕ} (u : Fin n → ℝ) (k : ℕ) :
    Matrix (Fin k) (Fin n) ℝ :=
  fun i j => (u j) ^ i.val

/-- The k×k moment Hankel matrix. -/
def atomicHankel {n : ℕ} (u : Fin n → ℝ) (k : ℕ) :
    Matrix (Fin k) (Fin k) ℝ :=
  fun i j => atomicMoment u (i.val + j.val)

/-- Exact Gram factorization for the whole finite-atomic moment hierarchy. -/
theorem atomicHankel_factorization {n : ℕ} (u : Fin n → ℝ) (k : ℕ) :
    atomicHankel u k =
      atomicVandermonde u k * (atomicVandermonde u k).transpose := by
  classical
  ext i j
  simp [atomicHankel, atomicMoment, atomicVandermonde,
    Matrix.mul_apply, Matrix.transpose_apply, pow_add]

end PaperChronology.Corollary3_6.CorrectedFiniteAtomic

#print axioms PaperChronology.Corollary3_6.CorrectedFiniteAtomic.atomicHankel_factorization
