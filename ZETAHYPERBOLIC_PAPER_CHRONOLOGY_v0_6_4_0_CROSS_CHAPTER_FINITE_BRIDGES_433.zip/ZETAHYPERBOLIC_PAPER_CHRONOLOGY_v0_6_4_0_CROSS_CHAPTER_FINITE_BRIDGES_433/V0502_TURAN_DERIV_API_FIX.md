# v0.5.0.2 — Theorem 3.7 derivative API repair

Native Windows Lean 4.33.0 only. The previously passed proof modules are frozen and retained unchanged.

Single repaired source: `Theorem_3_7_Real_Rooted_Polynomial_Turanian.lean`.

The compiler errors at lines 34, 38, and 44 came from dot-notation selecting
`HasFDerivAtFilter` rather than the specialized `HasDerivAt` derivative API.

- Import `Mathlib.Analysis.Calculus.Deriv.Add` and `Mathlib.Analysis.Calculus.Deriv.Mul` explicitly.
- Use `HasDerivAt.sub_const a (hasDerivAt_id x)` (constant is the first explicit argument).
- Use `HasDerivAt.fun_mul` and `HasDerivAt.fun_add`, with the previously unchanged ring normalizations.

No mathematical theorem statements were altered. No `sorry`, `admit`, or custom axioms were added.

No local Lean compilation was performed; user compiler result required.
