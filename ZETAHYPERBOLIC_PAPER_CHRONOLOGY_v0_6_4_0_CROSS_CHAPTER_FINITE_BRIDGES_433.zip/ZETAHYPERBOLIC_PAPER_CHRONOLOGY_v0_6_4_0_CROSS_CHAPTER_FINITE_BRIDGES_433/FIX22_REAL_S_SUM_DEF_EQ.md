# FIX22 — pointwise-sum definitional equality

The user compiler reported a failure at line 113, where a simplification of the
IntegrableOn majorant failed to turn an `Integrable (f + g)` assertion into
`IntegrableOn (fun x => f x + g x)`.

Repair only `Proposition_3_2_Real_s_Moment_Integrability.lean`:
replace `simpa only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, mul_assoc]`
with an explicit `change IntegrableOn ... at hsum` statement followed by
`exact hsum`. The equivalence is definitional, not an analytic hypothesis.

All previously passed Lean sources are byte-identical. The other changed
file is the required single Windows launcher. No Lean compilation was run
by the assistant; user native Lean 4.33.0 remains the checker.
