import Theorem_3_3_Actual_Continuous_Principal_Minors
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Proposition_3_2_Continuous_Real_Weight_Pencil
import Mathlib.Tactic

/-!
# PDF Theorem 3.4(1): reality of ALL principal-minor roots

The manuscript's principal subpencils need not have invertible derivative
matrices; their determinant polynomials can have degree STRICTLY LESS than
the matrix size.  Therefore one cannot simply invoke the full-degree theorem
3.1 with a secretly assumed derivative nonsingularity condition.

We instead prove the *singular-direction* positive-base spectral factorization
unconditionally, keeping possible zero eigenvalues. The resulting polynomial
has only real complex roots and is strictly positive at its center, regardless
of the rank of the derivative. Then apply it to EVERY principal submatrix of
the ACTUAL real-s and odd-weight Hankel pencils. No finite certificate or
witness is assumed. Cauchy's *interlacing inequalities* remain separate.
-/

noncomputable section
open scoped BigOperators MatrixOrder
open Matrix Polynomial

namespace PaperChronology.Theorem3_4.ActualPrincipal

open ManuscriptChain.Spectral

/-- Positive-definite base implies a real spectral factorization even if
`det direction = 0`. This generalizes the already proved Theorem 3.1 lemma
by deliberately dropping its derivative-invertibility premise. -/
theorem factorization_without_direction_invertibility {n : ℕ}
    (p : SymmetricAffinePencil n) (positive : p.base.PosDef) :
    ∃ beta : Fin n → ℝ,
      p.detPolynomial =
        Polynomial.C (Matrix.det p.base) *
          ∏ i, spectralFactor p.center (beta i) := by
  let S := CFC.sqrt p.base
  have hSsq : S * S = p.base := by
    simpa [S, sq] using CFC.sq_sqrt p.base positive.posSemidef.nonneg
  have hSsymm : S.IsHermitian :=
    (CFC.sqrt_nonneg p.base).posSemidef.isHermitian
  have hbase : Matrix.det p.base ≠ 0 := ne_of_gt positive.det_pos
  have hSdet : Matrix.det S ≠ 0 := by
    have h := congrArg Matrix.det hSsq
    rw [Matrix.det_mul] at h
    intro hz
    simp [hz] at h
    exact hbase h.symm
  have hSunit : IsUnit (Matrix.det S) := isUnit_iff_ne_zero.mpr hSdet
  let B := S⁻¹ * p.direction * S⁻¹
  have hBsymm : B.IsHermitian := by
    have h := Matrix.isHermitian_conjTranspose_mul_mul (S⁻¹)
      (Matrix.isHermitian_iff_isSymm.mpr p.direction_symmetric)
    simpa only [hSsymm.inv.eq] using h
  have hconj : S * B * S = p.direction := by
    dsimp only [B]
    calc
      S * (S⁻¹ * p.direction * S⁻¹) * S =
          (S * S⁻¹) * p.direction * (S⁻¹ * S) := by
            simp only [Matrix.mul_assoc]
      _ = p.direction := by
        rw [Matrix.mul_nonsing_inv S hSunit, Matrix.nonsing_inv_mul S hSunit]
        simp
  have hpencil (x : ℝ) :
      p.matrixAt x = S * (1 + (x - p.center) • B) * S := by
    calc
      p.matrixAt x = S * S + (x - p.center) • (S * B * S) := by
        rw [hSsq, hconj]
        rfl
      _ = S * (1 + (x - p.center) • B) * S := by
        simp [Matrix.mul_add, Matrix.add_mul]
  refine ⟨hBsymm.eigenvalues, ?_⟩
  apply Polynomial.funext
  intro x
  rw [p.eval_detPolynomial, SymmetricAffinePencil.detValue, hpencil]
  rw [Matrix.det_mul, Matrix.det_mul]
  have hdetbase : Matrix.det S * Matrix.det S = Matrix.det p.base := by
    rw [← Matrix.det_mul, hSsq]
  rw [ManuscriptChain.Spectral.det_one_add_smul_of_hermitian B hBsymm]
  simp only [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_prod,
    ManuscriptChain.Spectral.eval_spectralFactor]
  calc
    Matrix.det S * (∏ i, (1 + (x - p.center) * hBsymm.eigenvalues i)) *
        Matrix.det S = (Matrix.det S * Matrix.det S) *
          ∏ i, (1 + (x - p.center) * hBsymm.eigenvalues i) := by ring
    _ = _ := by rw [hdetbase]

/-- Any complex root of a positive-base symmetric pencil lies on the REAL
axis, with no assumption on its derivative's rank. -/
theorem every_complex_root_real_without_direction_invertibility {n : ℕ}
    (p : SymmetricAffinePencil n) (positive : p.base.PosDef)
    (z : ℂ) (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0) :
    z.im = 0 := by
  obtain ⟨beta, hfactor⟩ :=
    factorization_without_direction_invertibility p positive
  have heval : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial =
      ((Matrix.det p.base : ℝ) : ℂ) *
        ∏ i, (1 + (z - (p.center : ℂ)) * (beta i : ℂ)) := by
    rw [hfactor]
    simp [spectralFactor, Polynomial.eval₂_finsetProd]
  rw [heval] at hz
  have hd : ((Matrix.det p.base : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (ne_of_gt positive.det_pos)
  have hp := (mul_eq_zero.mp hz).resolve_left hd
  obtain ⟨i, _, hi⟩ := Finset.prod_eq_zero_iff.mp hp
  have hb : beta i ≠ 0 := by
    intro hzero
    simp [hzero] at hi
  have hb_complex : (beta i : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hb
  have hx := (linear_factor_eq_zero_iff (p.center : ℂ)
    (beta i : ℂ) z hb_complex).mp hi
  rw [hx]
  simp

/-- The genuine real-s minor pencil for any chosen subset of indices. -/
def realSPrincipalPencil (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    {r : ℕ} (choose : Fin r → Fin p.h) : SymmetricAffinePencil r where
  center := (riemannZeta (s : ℂ)).re
  base := (PaperChronology.Proposition3_2.Gram.gram s p).submatrix choose choose
  direction := (PaperChronology.Proposition3_2.derivativeMatrix s p).submatrix choose choose
  base_symmetric :=
    (PaperChronology.Proposition3_2.Gram.gram_symmetric s p).submatrix choose
  direction_symmetric :=
    (PaperChronology.Proposition3_2.derivativeMatrix_symmetric s p).submatrix choose

/-- PDF Theorem 3.4: every actual real-s principal-minor polynomial is
strictly positive at its center, so cannot vanish identically. -/
theorem real_s_principal_center_positive
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hchoose : Function.Injective choose) :
    0 < (realSPrincipalPencil s p choose).detPolynomial.eval
      (riemannZeta (s : ℂ)).re := by
  change 0 < (realSPrincipalPencil s p choose).detPolynomial.eval
    (realSPrincipalPencil s p choose).center
  rw [SymmetricAffinePencil.eval_detPolynomial_center]
  exact PaperChronology.Theorem3_3.ActualContinuousPrincipal.real_s_all_principal_minors_pos
    s p hs choose hchoose

/-- PDF Theorem 3.4(1), reality of ALL actual real-s principal-minor
roots, without assuming a nonexistent full-degree condition on a minor. -/
theorem real_s_all_principal_minors_real_rooted
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hchoose : Function.Injective choose) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (realSPrincipalPencil s p choose).detPolynomial = 0) :
    z.im = 0 :=
  every_complex_root_real_without_direction_invertibility
    (realSPrincipalPencil s p choose)
    (PaperChronology.Theorem3_3.ActualContinuousPrincipal.real_s_principal_posDef
      s p hs choose hchoose) z hz

/-- The exact odd-integer original-pencil version, where the base is the
unconditional Gram from PDF Theorem 3.1. -/
def oddPrincipalPencil (p : ManuscriptChain.Real.Parameters)
    {r : ℕ} (choose : Fin r → Fin p.h) : SymmetricAffinePencil r where
  center := ManuscriptChain.Real.zeta p.weight
  base := (ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)).submatrix
    choose choose
  direction := (ManuscriptChain.Real.derivativeMatrix p).submatrix choose choose
  base_symmetric :=
    (ManuscriptChain.Real.gram_symmetric p (ManuscriptChain.Real.zeta p.weight)).submatrix
      choose
  direction_symmetric :=
    (ManuscriptChain.Real.derivativeMatrix_symmetric p).submatrix choose

/-- Every original odd-integer principal-minor determinant is positive at
the manuscript's distinguished zeta value. -/
theorem odd_principal_center_positive
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hchoose : Function.Injective choose) :
    0 < (oddPrincipalPencil p choose).detPolynomial.eval
      (ManuscriptChain.Real.zeta p.weight) := by
  change 0 < (oddPrincipalPencil p choose).detPolynomial.eval
    (oddPrincipalPencil p choose).center
  rw [SymmetricAffinePencil.eval_detPolynomial_center]
  exact PaperChronology.Theorem3_3.ActualContinuousPrincipal.odd_weight_all_principal_minors_pos
    p hp choose hchoose

/-- PDF Theorem 3.4, real-rootedness of every actual odd-zeta principal
minor, not a symbolic finite-atom proxy. No additional witness. -/
theorem odd_all_principal_minors_real_rooted
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hchoose : Function.Injective choose) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (oddPrincipalPencil p choose).detPolynomial = 0) :
    z.im = 0 :=
  every_complex_root_real_without_direction_invertibility
    (oddPrincipalPencil p choose)
    (PaperChronology.Theorem3_3.ActualContinuousPrincipal.odd_weight_principal_posDef
      p hp choose hchoose) z hz

end PaperChronology.Theorem3_4.ActualPrincipal

#print axioms PaperChronology.Theorem3_4.ActualPrincipal.factorization_without_direction_invertibility
#print axioms PaperChronology.Theorem3_4.ActualPrincipal.real_s_all_principal_minors_real_rooted
#print axioms PaperChronology.Theorem3_4.ActualPrincipal.odd_all_principal_minors_real_rooted
