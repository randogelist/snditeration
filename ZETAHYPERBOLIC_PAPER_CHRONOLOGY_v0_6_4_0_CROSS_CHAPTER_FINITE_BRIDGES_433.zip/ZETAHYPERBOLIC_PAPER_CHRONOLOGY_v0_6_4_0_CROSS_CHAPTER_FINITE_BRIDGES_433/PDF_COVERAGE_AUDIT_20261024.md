# ZETAHYPERBOLIC — PDF vs native Lean coverage assessment

**Manuscript:** Prince Anand, *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, dated 21 October 2026; **52 pages**. This audit matches the PDF uploaded in the current conversation, SHA-256 `935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`.

**Lean source snapshot:** v0.5.0.4, with v0.5.0.5 adding this audit only. **No assistant-side Lean compilation has been performed.**

## Verdict

- **Approximate equivalent mathematical proof-work coverage: ~25%, defensible rough band 20–30%.** This credits correct partial results and infrastructure. It is an expert judgment, *not* a Lean-executable percentage or a claim that all the author's arguments are true.
- **Close to complete matching the PDF at the level of a numbered item: ~6 of 51 (about 12%)**, perhaps one or two more after line-by-line equivalence audits. These include a *definition*, not six entire deep theorems. Counting theorem names or source modules as PDF claims materially overstates coverage.
- **The manuscript is NOT entirely formalized.** Conditional statements and named interfaces are not counted as establishing their premises; repaired false statements cannot be literally verified as printed.
- **Last completely successful Windows native Lean 4.33 checkpoint: 105/105 proof-source modules, `RESULT=PASS`, `FINAL_AXIOMS=NO_FORBIDDEN_AXIOMS_DETECTED`.** The user's log reported 0 newly compiled and 105 frozen reused for v0.4.7.2.
- **Current source archive:** 113 ordered proof modules, plus `lakefile.lean`; **13,942 proof-source lines**, **601,605 proof-source bytes**. There are **8 newer v0.5.0 proof modules without a confirmed successful complete 113-module run**. A prior compiler report stopped in Theorem 3.8's Christoffel–Darboux kernel; v0.5.0.4 repairs that source but its compile result has not been provided.
- **Immutable verified base:** all 105 previously certified `.lean` files in the v0.4.7.2 package have *exactly identical SHA-256 hashes* in the new archive. Only 8 new proof modules were added; none of the 105 certified sources were silently modified.

## Section-by-section assessment

| Paper section | Conservative source-level completion assessment | What is genuinely present | Largest remaining exact PDF-level gaps |
|---|---:|---|---|
| **§2 Algebra (2.1–2.5)** | **75–85%** | Rational functional generators; polynomial pullback/reflection; canonical basis invariance; actual pole Lagrange diagonalization. | Full domain equality of all rational functions rather than only the checked generators / finite decompositions. |
| **§3 Spectral theory (3.1–3.9)** | **40–55%** | Unconditional odd-`s` real roots; real-`s` positive measure/integrable moments; leading coefficient signs; exact pole sign counts; positive principal minors; finite and general-order matrix determinant identities; some Schur and Turan structures. | Arbitrary nonprincipal continuous strict total positivity; Carleman; Sylvester inertia for full root multiplicity; general Cauchy interlacing; corrected full J fraction; analytic CD/Jacobi derivative; Hurwitz and Dirichlet full extension. |
| **§4 Diophantine asymptotics** | **8–15%** | Abstract integer-polynomial transfer, actual primitive normalization, proof that `Witness → Irrational ζ(5)`, and `EffectiveWitness → bound 25687`. | **Construction/proof of Witness**; 11.411 spectral norm; prime-sum valuations; determinant energy asymptotics; root clustering; simultaneous ζ3/ζ5 bounds. |
| **§5 Two-variable/weight seven** | **5–12%** | Some rational matrix/Krein ingredients and the actual simple even-pole cancellation. | Exact 2D integral identities, infinite Krein tails, explicit cone construction, weight-seven prime-sum and double-pole p-adic steps. |
| **§6 Multiweight and barriers** | **3–8%** | Isolated finite identities, Hermite repair, source interfaces. | Most universal analytic/p-adic/general-family theorem conclusions remain open. |

**Interpretation:** Sections 4–6 form a very large fraction of the PDF and contain the most difficult unformalized asymptotic/arithmetic work. Averaging five section percentages would be misleading; the ~25% overview is necessarily a rough effort-equivalent estimate. One clean incremental build increases *trust in existing modules*, not the percentage of printed claims completed.

## PDF-level theorem inventory

The companion file `PDF_THEOREM_MATRIX_20261024.csv` has **all 51 identified numbered items** in PDF order, including Definition 2.1, 2 lemmas, 35 theorems, 5 propositions, 3 corollaries, 4 remarks and Conjecture 4.11.

| Marker | Count | Meaning |
|---|---:|---|
| `C` | 6 | Close to complete source theorem at the PDF item level, subject to exact statement/domain audit |
| `P` | 18 | Substantive partial/source abstraction, but one or more printed clauses not proved |
| `X` | 2 | Printed statement requires correction; there is a replacement/counterexample module |
| `O` | 20 | No established full matching PDF item in this branch |
| `R` | 4 | Remark, not an independent formal theorem obligation; may need scrutiny |
| `Q` | 1 | Explicit conjecture, not a claimed theorem |

## Precisely what has changed since the last user-certified PASS

**Frozen:** 105 modules, byte-for-byte verified unchanged from v0.4.7.2.

**New eight v0.5.0 modules** (as of v0.5.0.4; the candidate sources are bundled but not all officially confirmed):

- `Corollary_3_5_Corrected_Schur_Fraction.lean`
- `Corollary_3_6_Reciprocal_Root_Moment_Bounds.lean`
- `PAPER_CHRONOLOGICAL_EXTENSION_9.lean`
- `Theorem_3_4_Actual_Principal_Spectral_Gap.lean`
- `Theorem_3_7_All_Order_Turanian_Jets.lean`
- `Theorem_3_7_Real_Rooted_Polynomial_Turanian.lean`
- `Theorem_3_8_Actual_Christoffel_Darboux_Kernel.lean`
- `Theorem_4_1_Witness_Free_Principal_Separation.lean`


These new modules add a *candidate* direct theorem jump for principal spectral gaps, corrected 2×2 Schur fractions, finite atomic reciprocal-root moments, Turan jets, CD matrix kernel, and local root-free intervals. Do not count the corrected 2×2 Schur fraction as the printed full-length Lanczos continued fraction, nor a pointwise CD kernel matrix as the paper's parameter-derivative identity (3.8).

## Mathematically critical distinction: exactly one Witness

- `PaperWitness.Witness → Irrational((riemannZeta 5).re)` is a **valid conditional theorem endpoint** from the existing formal source.
- `PaperWitness.EffectiveWitness → RationalMeasure ζ(5) 25687` requires the *arithmetic* family plus an *additional quantitative spectral bound*. One Lean structure can carry both fields, but that does not establish the estimates.
- The paper asserts the quadratic decay bound in equation (4.3), but the actual number-theoretic proof (prime-sum multipliers and estimates) is **not yet established by this branch**. Therefore unconditional `Irrational ζ(5)`, unconditional measure 25687, and the paper's full arithmetic claims must not be reported as proved.
- A weight-five arithmetic Witness does **not** by itself imply Sections 5–6 (Krein and p-adic assertions). Those need unconditional Lean proofs, independent legitimate inputs, or a substantially larger and explicitly specified certificate contract.

## Known reasons literal 100% coverage is not currently possible without manuscript corrections

1. **Corollary 3.5:** printed continued fraction (3.6) omits Gram normalization / mishandles the `I+tB` algebra and is already contradicted at `h=1`. The corrected Schur complement is a different statement; full length-h J-fraction is pending.
2. **Corollary 3.6:** the reciprocal-root moment measure has at most `h` distinct atoms; all Hankel determinants of order greater than its support rank vanish, contradicting the printed all-order strict positivity. The displayed limit inequality has reversed bounds. The corrected finite-atomic theorem is formally supported.
3. **Theorem 5.2(3):** finitely orthogonalizing against negative Krein modes does not annihilate the infinite remaining negative tail. Its definiteness claim still requires an explicit tail estimate.
4. **Conjecture 4.11:** conjectural by the author's own labeling; cannot be automatically treated as a proved manuscript theorem.

## Next highest-yield milestones

1. **Verify the eight v0.5.0 modules** on the user's Lean 4.33 compiler, especially the repaired Theorem 3.8. Preserve the 105 previously certified source hashes; never force a rebuild of frozen proof modules unless inputs/toolchain/dependencies invalidate them.
2. **Close PDF Theorem 3.3(1) genuinely:** strict positivity of *every* continuous nonprincipal minor via generalized Vandermonde / Andreief, plus the Carleman determinacy clause.
3. **Finish the root-sign transfer:** from proved diagonal pole counts to the full spectral inertia/root-count statement, preserving multiplicities. Prove complete Cauchy interlacing and Jacobi condensation for Theorem 3.4.
4. **Finish PDF-level Theorems 3.7–3.9,** including the full Christoffel–Darboux eigenvalue identity and differentiation under the integral, not just algebraic kernel evaluations.
5. **Start Section 4 quantitative analysis** with independently verified finite-data arithmetic and spectral estimates; the Witness stays a single *visible hypothesis* until actually constructed and checked.

## Verification and limitations

This is a *static PDF-to-Lean source alignment audit*, not a new kernel compilation. PDF theorem naming, mathematical conclusions, proof-parameter strength, cached Lean logs supplied by the user, source fingerprints, and known counterexamples were distinguished. A module with a manuscript theorem name may still state only an auxiliary lemma or carry an explicit input. The actual interface theorem types and the user's compiler remain the authority. The one ZIP retains one root-level `run.cmd`, the original unchanged Lean modules, and a pass-once incremental dependency cache mechanism. No assistant Lean compilation, installation, or network access occurred.
