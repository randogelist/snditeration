@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 (echo RESULT=WORKDIR_ERROR&exit /b 2)

rem PASS-ONCE / FREEZE / INCREMENTAL -- ONLY YOUR WINDOWS COMPILER RUNS LEAN.
rem No Lake, Python, PowerShell, WSL, or network. One entry point.
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=%TOOLCHAIN%\bin\lean.exe"
set "LEAN_STDLIB=%TOOLCHAIN%\lib\lean"
set "MATHLIB_CACHE=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if defined ZETA_FASTCORE_CACHE set "MATHLIB_CACHE=!ZETA_FASTCORE_CACHE!"
set "MATHLIB_ROOT=!MATHLIB_CACHE!\.lake\packages\mathlib\.lake\build\lib\lean"
set "PERSIST=%USERPROFILE%\lean-native\zetahyperbolic-paper-frozen-433"
set "STORE=!PERSIST!\lib"
set "SNAP=!PERSIST!\source"
set "LOGS=!PERSIST!\logs"
set "MARK=!PERSIST!\changed"
set "LEAN_JOBS=16"
set "FORCE_FULL=0"
if /i "%~1"=="full" set "FORCE_FULL=1"
set "BLUEPRINT_ONLY=0"
if /i "%~1"=="blueprints" set "BLUEPRINT_ONLY=1"
if /i "%~1"=="proofs" set "BLUEPRINT_ONLY=0"

echo PACKAGE=ZETAHYPERBOLIC_PAPER_CHRONOLOGY_v0_6_4_0_CROSS_CHAPTER_FINITE_BRIDGES_433
echo PATCH=V0640_CROSS_CHAPTER_FINITE_KREIN_FEKETE_DUAL_MOMENTS
echo SECTION_STRUCTURE_REVIEW=SECTION_STRUCTURE_VERDICT_20261024.md
echo ASSESSMENT_REPORT=PDF_TO_LEAN_REASSESSMENT_v0631.md
echo PDF_ITEMS_AUDITED=51
echo PDF_NUMBERED_PROOF_ITEMS=46
echo PDF_NEAR_COMPLETE_ITEMS=6
echo PDF_PARTIAL_ITEMS=18
echo PDF_CORRECTIONS_REQUIRED=2
echo PDF_OPEN_ITEMS=20
echo PAPER_FULL_PROOF=NOT_YET
echo PARAGRAPH_PROVED_CLAUSES=6_LEGACY_PLUS_3_NEW_FINITE_FRAGMENTS_PENDING
echo EXPECTED_SOURCE_MODULES=138
echo NEW_TARGETS=FOUR_FINITE_THEOREM_MODULES_ONE_PARAGRAPH_PROOF_CHECKPOINT_ONE_EXTENSION
echo RUN_ID=V0640_132_FROZEN_PLUS_SIX_CROSS_CHAPTER_TARGETS
echo EXPECTED_PREVIOUS_FROZEN=132
echo EXPECTED_NEW_TARGETS_TO_COMPILE=6
echo OPEN_V050_PROOF_CANDIDATES=0
echo LAST_USER_CHECKPOINT=132_MODULES_NATIVE_PASS_RESULT_PASS
echo ONLY_FULL_PROOF_RUN_CAN_CERTIFY_V062=YES
echo COMPILER=USER_NATIVE_LEAN_433
echo MODE=PASS_ONCE_FROZEN_INCREMENTAL
echo LOCAL_ASSISTANT_COMPILATION=NONE
echo THREADS=!LEAN_JOBS!
echo NETWORK=NOT_USED
echo BLUEPRINTS=9
echo BLUEPRINT_GOAL_STATUS=DECLARED_NOT_PROVED
if "!BLUEPRINT_ONLY!"=="1" echo BLUEPRINT_ONLY=YES
if "!FORCE_FULL!"=="1" echo FORCE_FULL=YES

if not exist "!LEAN_EXE!" (echo RESULT=LEAN_EXE_NOT_FOUND&exit /b 2)
if not exist "!MATHLIB_ROOT!\Mathlib.olean" (echo RESULT=MATHLIB_CACHE_NOT_FOUND&exit /b 3)
if not exist "FASTCORE_ORDER.txt" (echo RESULT=ORDER_MISSING&exit /b 4)
if not exist "FASTCORE_DEPENDENCIES.txt" (echo RESULT=DEPS_MISSING&exit /b 4)
rem Verify corrected source in this extracted directory before using persistent cache.
if not exist "Theorem_3_3_Actual_Diagonal_Sign_Counts.lean" (echo RESULT=V0472_SOURCE_MISSING&exit /b 4)
findstr /L /C:"Theorem 3.3(3): exact positive and negative coordinate counts (v0.4.7.2 bridge)" "Theorem_3_3_Actual_Diagonal_Sign_Counts.lean" >nul
if errorlevel 1 (echo RESULT=V0472_STALE_SOURCE&exit /b 4)
findstr /L /C:"have hsplit :" "Theorem_3_3_Actual_Diagonal_Sign_Counts.lean" >nul
if errorlevel 1 (echo RESULT=V0472_SUM_BRIDGE_MISSING&exit /b 4)
echo V0472_SOURCE_PATCH=VERIFIED
if not exist "Theorem_3_4_Reciprocal_Root_Order.lean" (echo RESULT=RECIPROCAL_SOURCE_MISSING&exit /b 4)
findstr /L /C:"field_simp [hx, hy]" "Theorem_3_4_Reciprocal_Root_Order.lean" >nul
if errorlevel 1 (echo RESULT=RECIPROCAL_FIX_NOT_PRESENT&exit /b 4)
findstr /L /B /C:"  ring" "Theorem_3_4_Reciprocal_Root_Order.lean" >nul
if not errorlevel 1 (echo RESULT=OLD_RECIPROCAL_TACTIC_PRESENT&exit /b 4)
echo RECIPROCAL_PROOF=FIELD_SIMP_ONLY_SOURCE_VERIFIED
findstr /c:"Nat.card_Icc" "Theorem_3_3_Signed_Pole_Products.lean" >nul
if errorlevel 1 (echo RESULT=SOURCE_PATCH_MISSING&exit /b 4)
rem Ensure the two rational square-sign proofs use case analysis, not nonlinear automation.
findstr /c:"rcases lt_trichotomy x 0" "Theorem_3_3_Pole_Weight_Signs.lean" >nul
if errorlevel 1 (echo RESULT=POLE_SIGN_SOURCE_STALE&exit /b 4)
findstr /c:"rcases lt_trichotomy y 0" "Theorem_3_3_Pole_Weight_Signs.lean" >nul
if errorlevel 1 (echo RESULT=POLE_SIGN_SOURCE_STALE&exit /b 4)
if not exist "Proposition_3_2_Real_s_Weight_Envelope.lean" (echo RESULT=REAL_S_ENVELOPE_SOURCE_MISSING&exit /b 4)
if not exist "Proposition_3_2_Real_s_Moment_Integrability.lean" (echo RESULT=REAL_S_MOMENT_SOURCE_MISSING&exit /b 4)
findstr /L /C:"exact hsum_explicit.mono' hmeas hdom" "Proposition_3_2_Real_s_Moment_Integrability.lean" >nul
if errorlevel 1 (echo RESULT=REAL_S_MONO_PATCH_NOT_PRESENT&exit /b 4)
findstr /L /C:"change IntegrableOn" "Proposition_3_2_Real_s_Moment_Integrability.lean" >nul
if errorlevel 1 (echo RESULT=REAL_S_SUM_DEFINITION_PATCH_MISSING&exit /b 4)
set /a EXPECTED_COUNT=0 >nul
set "ORDER_HAS_NEW=0"
set "ORDER_HAS_ENVELOPE=0"
set "ORDER_HAS_SECTION3=0"
set "ORDER_HAS_T33COUNTS=0"
set "ORDER_HAS_NEW33=0"
set "ORDER_HAS_POLE_WEIGHTS=0"
set "ORDER_HAS_LEADING_SIGN=0"
set "ORDER_HAS_NEW34=0"
set "ORDER_HAS_PARITY=0"
set "ORDER_HAS_COR36=0"
set "ORDER_HAS_THEOREM54=0"
set "ORDER_HAS_CHAIN=0"
set "ORDER_HAS_DISCRETE=0"
set "ORDER_HAS_DODGSON3=0"
set "ORDER_HAS_EXTENSION=0"
set "ORDER_HAS_SHIFTED_ATOMIC=0"
set "ORDER_HAS_DODGSON4=0"
set "ORDER_HAS_EXTENSION2=0"
set "ORDER_HAS_GENERAL_MINORS=0"
set "ORDER_HAS_SHIFTED_JACOBI=0"
set "ORDER_HAS_EXTENSION3=0"
set "ORDER_HAS_FOUR_MINOR=0"
set "ORDER_HAS_FOUR_GRAM3=0"
set "ORDER_HAS_EXTENSION4=0"
set "ORDER_HAS_GRAMGENERAL=0"
set "ORDER_HAS_GRAMACTUAL=0"
set "ORDER_HAS_EXTENSION5=0"
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  set /a EXPECTED_COUNT+=1 >nul
  if /I "%%M"=="Proposition_3_2_Real_s_Moment_Integrability" set "ORDER_HAS_NEW=1"
  if /I "%%M"=="Proposition_3_2_Real_s_Weight_Envelope" set "ORDER_HAS_ENVELOPE=1"
  if /I "%%M"=="PAPER_SECTION_03" set "ORDER_HAS_SECTION3=1"
  if /I "%%M"=="Theorem_3_3_Pole_Signature_Counts" set "ORDER_HAS_T33COUNTS=1"
  if /I "%%M"=="Theorem_3_3_Signed_Pole_Products" set "ORDER_HAS_NEW33=1"
  if /I "%%M"=="Theorem_3_3_Pole_Weight_Signs" set "ORDER_HAS_POLE_WEIGHTS=1"
  if /I "%%M"=="Theorem_3_3_Actual_Leading_Coefficient_Sign" set "ORDER_HAS_LEADING_SIGN=1"
  if /I "%%M"=="Theorem_3_4_Reciprocal_Root_Order" set "ORDER_HAS_NEW34=1"
  if /I "%%M"=="Theorem_3_3_Leading_Sign_Parity" set "ORDER_HAS_PARITY=1"
  if /I "%%M"=="Corollary_3_6_Corrected_Finite_Atomic_Moments" set "ORDER_HAS_COR36=1"
  if /I "%%M"=="Theorem_5_4_Even_Pole_Pair_Cancellation" set "ORDER_HAS_THEOREM54=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_CHAIN" set "ORDER_HAS_CHAIN=1"
  if /I "%%M"=="Theorem_3_3_Discrete_Total_Positivity_Samples" set "ORDER_HAS_DISCRETE=1"
  if /I "%%M"=="Theorem_3_4_Dodgson_Three_By_Three" set "ORDER_HAS_DODGSON3=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION" set "ORDER_HAS_EXTENSION=1"
  if /I "%%M"=="Theorem_3_3_Shifted_Atomic_Gram_Minors" set "ORDER_HAS_SHIFTED_ATOMIC=1"
  if /I "%%M"=="Theorem_3_4_Dodgson_Four_By_Four" set "ORDER_HAS_DODGSON4=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_2" set "ORDER_HAS_EXTENSION2=1"
  if /I "%%M"=="Theorem_3_3_General_Three_Atom_Minors" set "ORDER_HAS_GENERAL_MINORS=1"
  if /I "%%M"=="Theorem_3_4_Shifted_Dodgson_Jacobi" set "ORDER_HAS_SHIFTED_JACOBI=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_3" set "ORDER_HAS_EXTENSION3=1"
  if /I "%%M"=="Theorem_3_3_Four_Atom_General_Minors" set "ORDER_HAS_FOUR_MINOR=1"
  if /I "%%M"=="Theorem_3_3_Four_Atom_Three_By_Three" set "ORDER_HAS_FOUR_GRAM3=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_4" set "ORDER_HAS_EXTENSION4=1"
  if /I "%%M"=="Theorem_3_3_Arbitrary_Order_Gram_Determinant" set "ORDER_HAS_GRAMGENERAL=1"
  if /I "%%M"=="Theorem_3_3_Actual_Sign_Corrected_Pole_Gram" set "ORDER_HAS_GRAMACTUAL=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_5" set "ORDER_HAS_EXTENSION5=1"
)
if not "!EXPECTED_COUNT!"=="138" (echo MODULE_COUNT_MISMATCH=!EXPECTED_COUNT!&echo RESULT=ORDER_INVALID&exit /b 4)
if "!ORDER_HAS_NEW!"=="0" (echo RESULT=NEW_TARGET_OMITTED&exit /b 4)
if "!ORDER_HAS_ENVELOPE!"=="0" (echo RESULT=ENVELOPE_TARGET_OMITTED&exit /b 4)
if "!ORDER_HAS_T33COUNTS!"=="0" (echo RESULT=THEOREM33_TARGET_OMITTED&exit /b 4)
if "!ORDER_HAS_NEW33!"=="0" (echo RESULT=THEOREM33_SIGN_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_POLE_WEIGHTS!"=="0" (echo RESULT=THEOREM33_POLE_WEIGHTS_OMITTED&exit /b 4)
if "!ORDER_HAS_LEADING_SIGN!"=="0" (echo RESULT=ACTUAL_LEADING_SIGN_OMITTED&exit /b 4)
if "!ORDER_HAS_NEW34!"=="0" (echo RESULT=THEOREM34_ORDER_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_PARITY!"=="0" (echo RESULT=THEOREM33_PARITY_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_COR36!"=="0" (echo RESULT=COR36_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_THEOREM54!"=="0" (echo RESULT=THEOREM54_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_SECTION3!"=="0" (echo RESULT=SECTION3_OMITTED&exit /b 4)
if "!ORDER_HAS_CHAIN!"=="0" (echo RESULT=CHAIN_OMITTED&exit /b 4)
echo STARTUP_ORDER=REUSE_ALL_VERIFIED_PARAGRAPH_AND_MATH_MODULES_RETRY_FAILED_CYCLIC_AND_DEPENDENTS
echo EXECUTION=FULL_PROOF_CHECKS_UNLESS_BLUEPRINTS_FLAG_SET
for %%M in ("Theorem_3_3_Discrete_Total_Positivity_Samples.lean" "Theorem_3_4_Dodgson_Three_By_Three.lean" "PAPER_CHRONOLOGICAL_EXTENSION.lean") do (
  if not exist "%%~M" (echo RESULT=NEW_CHRONOLOGY_MODULE_MISSING&exit /b 4)
)
rem Detect inclusion directly in the FOR /F traversal that already validated 86 lines.
rem Windows FINDSTR /X can misread the LF-only FASTCORE_ORDER.txt, so do not use it.
if "!ORDER_HAS_DISCRETE!"=="0" (echo RESULT=DISCRETE_MOMENT_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_DODGSON3!"=="0" (echo RESULT=DODGSON_THREE_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_EXTENSION!"=="0" (echo RESULT=CHRONOLOGICAL_EXTENSION_OMITTED&exit /b 4)
if "!ORDER_HAS_SHIFTED_ATOMIC!"=="0" (echo RESULT=SHIFTED_ATOMIC_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_DODGSON4!"=="0" (echo RESULT=DODGSON_FOUR_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_EXTENSION2!"=="0" (echo RESULT=CHRONOLOGICAL_EXTENSION_2_OMITTED&exit /b 4)
for %%M in ("Theorem_3_3_Shifted_Atomic_Gram_Minors.lean" "Theorem_3_4_Dodgson_Four_By_Four.lean" "PAPER_CHRONOLOGICAL_EXTENSION_2.lean") do (
  if not exist "%%~M" (echo RESULT=NEW_V041_MODULE_MISSING&exit /b 4)
)
if "!ORDER_HAS_GENERAL_MINORS!"=="0" (echo RESULT=GENERAL_ATOMIC_MINORS_OMITTED&exit /b 4)
if "!ORDER_HAS_SHIFTED_JACOBI!"=="0" (echo RESULT=SHIFTED_JACOBI_MODULE_OMITTED&exit /b 4)
if "!ORDER_HAS_EXTENSION3!"=="0" (echo RESULT=CHRONOLOGICAL_EXTENSION_3_OMITTED&exit /b 4)
for %%M in ("Theorem_3_3_General_Three_Atom_Minors.lean" "Theorem_3_4_Shifted_Dodgson_Jacobi.lean" "PAPER_CHRONOLOGICAL_EXTENSION_3.lean") do (
  if not exist "%%~M" (echo RESULT=V042_SOURCE_MODULE_MISSING&exit /b 4)
)
if "!ORDER_HAS_FOUR_MINOR!"=="0" (echo RESULT=FOUR_ATOM_TWO_MINOR_OMITTED&exit /b 4)
if "!ORDER_HAS_FOUR_GRAM3!"=="0" (echo RESULT=FOUR_ATOM_GRAM3_OMITTED&exit /b 4)
if "!ORDER_HAS_EXTENSION4!"=="0" (echo RESULT=CHRONOLOGICAL_EXTENSION_4_OMITTED&exit /b 4)
for %%M in ("Theorem_3_3_Four_Atom_General_Minors.lean" "Theorem_3_3_Four_Atom_Three_By_Three.lean" "PAPER_CHRONOLOGICAL_EXTENSION_4.lean") do (
  if not exist "%%~M" (echo RESULT=V043_SOURCE_MODULE_MISSING&exit /b 4)
)
if "!ORDER_HAS_GRAMGENERAL!"=="0" (echo RESULT=V044_GENERAL_GRAM_OMITTED&exit /b 4)
if "!ORDER_HAS_GRAMACTUAL!"=="0" (echo RESULT=V044_ACTUAL_GRAM_OMITTED&exit /b 4)
if "!ORDER_HAS_EXTENSION5!"=="0" (echo RESULT=V044_EXTENSION5_OMITTED&exit /b 4)
for %%M in ("Theorem_3_3_Arbitrary_Order_Gram_Determinant.lean" "Theorem_3_3_Actual_Sign_Corrected_Pole_Gram.lean" "PAPER_CHRONOLOGICAL_EXTENSION_5.lean") do (
  if not exist "%%~M" (echo RESULT=V044_SOURCE_MODULE_MISSING&exit /b 4)
)
set "V045_PRINCIPAL=0"
set "V045_REALROOTS=0"
set "V045_CHAIN=0"
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="Theorem_3_3_Actual_Continuous_Principal_Minors" set "V045_PRINCIPAL=1"
  if /I "%%M"=="Theorem_3_4_Actual_Principal_Pencil_Reality" set "V045_REALROOTS=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_6" set "V045_CHAIN=1"
)
if "!V045_PRINCIPAL!"=="0" (echo RESULT=V045_PRINCIPAL_OMITTED&exit /b 4)
if "!V045_REALROOTS!"=="0" (echo RESULT=V045_REALROOTS_OMITTED&exit /b 4)
if "!V045_CHAIN!"=="0" (echo RESULT=V045_CHAIN_OMITTED&exit /b 4)
for %%M in (Theorem_3_3_Actual_Continuous_Principal_Minors Theorem_3_4_Actual_Principal_Pencil_Reality PAPER_CHRONOLOGICAL_EXTENSION_6) do (
  if not exist "%%M.lean" (echo RESULT=V045_SOURCE_MISSING_%%M&exit /b 4)
)
rem V047: exactly two new modules must be in the order and on disk.
set "V047_SIGNS=0"
set "V047_CHAIN=0"
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="Theorem_3_3_Actual_Diagonal_Sign_Counts" set "V047_SIGNS=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_8" set "V047_CHAIN=1"
)
if "!V047_SIGNS!"=="0" (echo RESULT=V047_SIGN_COUNTS_MISSING_FROM_ORDER&exit /b 4)
if "!V047_CHAIN!"=="0" (echo RESULT=V047_EXTENSION_MISSING_FROM_ORDER&exit /b 4)
for %%M in (Theorem_3_3_Actual_Diagonal_Sign_Counts PAPER_CHRONOLOGICAL_EXTENSION_8) do (
  if not exist "%%M.lean" (echo RESULT=V047_SOURCE_MISSING_%%M&exit /b 4)
)
echo V047_ORDER_GUARD=PASS
echo V045_ORDER_GUARD=PASS
echo ORDER_GUARD=FOR_F_MEMBERSHIP_PASS
rem V050 larger mathematical jump: require every module, its file, and its
rem exact position after all 105 previously certified inputs.
set /a V050_SEEN=0 >nul
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="Theorem_3_4_Actual_Principal_Spectral_Gap" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Corollary_3_5_Corrected_Schur_Fraction" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Corollary_3_6_Reciprocal_Root_Moment_Bounds" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Theorem_3_7_All_Order_Turanian_Jets" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Theorem_3_7_Real_Rooted_Polynomial_Turanian" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Theorem_3_8_Actual_Christoffel_Darboux_Kernel" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="Theorem_4_1_Witness_Free_Principal_Separation" set /a V050_SEEN+=1 >nul
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_9" set /a V050_SEEN+=1 >nul
)
if not "!V050_SEEN!"=="8" (echo RESULT=V050_ORDER_OMITTED&exit /b 4)
for %%M in (Theorem_3_4_Actual_Principal_Spectral_Gap Corollary_3_5_Corrected_Schur_Fraction Corollary_3_6_Reciprocal_Root_Moment_Bounds Theorem_3_7_All_Order_Turanian_Jets Theorem_3_7_Real_Rooted_Polynomial_Turanian Theorem_3_8_Actual_Christoffel_Darboux_Kernel Theorem_4_1_Witness_Free_Principal_Separation PAPER_CHRONOLOGICAL_EXTENSION_9) do (
  if not exist "%%M.lean" (echo RESULT=V050_SOURCE_MISSING_%%M&exit /b 4)
)
echo V050_ORDER_GUARD=PASS
rem V062 six theorem-bearing source files; no former source is modified.
set /a V062_COUNT=0 >nul
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="Corollary_3_6_Actual_Reciprocal_Moment_Growth" set /a V062_COUNT+=1 >nul
  if /I "%%M"=="Theorem_3_7_Primitive_Scale_Turanian" set /a V062_COUNT+=1 >nul
  if /I "%%M"=="Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic" set /a V062_COUNT+=1 >nul
  if /I "%%M"=="Theorem_3_8_Actual_Pole_Kernel_Zero_Locus" set /a V062_COUNT+=1 >nul
  if /I "%%M"=="Theorem_4_1_Actual_Pole_Kernel_Zero_Free" set /a V062_COUNT+=1 >nul
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_10" set /a V062_COUNT+=1 >nul
 )
if not "!V062_COUNT!"=="6" (echo RESULT=V062_ORDER_MISMATCH&exit /b 4)
if not exist "Corollary_3_6_Actual_Reciprocal_Moment_Growth.lean" (echo RESULT=V062_SOURCE_MISSING_Corollary_3_6_Actual_Reciprocal_Moment_Growth&exit /b 4)
if not exist "Theorem_3_7_Primitive_Scale_Turanian.lean" (echo RESULT=V062_SOURCE_MISSING_Theorem_3_7_Primitive_Scale_Turanian&exit /b 4)
if not exist "Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean" (echo RESULT=V062_SOURCE_MISSING_Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic&exit /b 4)
if not exist "Theorem_3_8_Actual_Pole_Kernel_Zero_Locus.lean" (echo RESULT=V062_SOURCE_MISSING_Theorem_3_8_Actual_Pole_Kernel_Zero_Locus&exit /b 4)
if not exist "Theorem_4_1_Actual_Pole_Kernel_Zero_Free.lean" (echo RESULT=V062_SOURCE_MISSING_Theorem_4_1_Actual_Pole_Kernel_Zero_Free&exit /b 4)
if not exist "PAPER_CHRONOLOGICAL_EXTENSION_10.lean" (echo RESULT=V062_SOURCE_MISSING_PAPER_CHRONOLOGICAL_EXTENSION_10&exit /b 4)
echo V062_ORDER_GUARD=PASS
findstr /L /C:"have hproduct :" "Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean" >nul
if errorlevel 1 (echo RESULT=V0622_NONSING_DET_BRIDGE_NOT_PRESENT&exit /b 4)
echo V0622_INVERSE_DET_BRIDGE=SOURCE_PRESENT
rem Source-level paragraph checkpoint must be in the full chronological order.
if not exist "PaperBlueprint\ParagraphCheckpoint.lean" (echo RESULT=PARAGRAPH_SOURCE_MISSING&exit /b 4)
set "PARAGRAPH_IN_ORDER=0"
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="PaperBlueprint\ParagraphCheckpoint" set "PARAGRAPH_IN_ORDER=1"
)
if not "!PARAGRAPH_IN_ORDER!"=="1" (echo RESULT=PARAGRAPH_ORDER_MISSING&exit /b 4)
echo PARAGRAPH_CHECKPOINT=AWAITING_COMPILER


for %%D in ("!PERSIST!" "!STORE!" "!SNAP!" "!LOGS!" "!MARK!") do if not exist "%%~D\" mkdir "%%~D"

rem Lean+Mathlib cache identity must not silently change between runs.
"!LEAN_EXE!" --version > "!PERSIST!\_toolchain_now.txt" 2>&1
if errorlevel 1 (echo RESULT=LEAN_VERSION_FAILED&exit /b 2)
set "INVALIDATE=0"
if not exist "!PERSIST!\toolchain_verified.txt" set "INVALIDATE=1"
if exist "!PERSIST!\toolchain_verified.txt" (
  fc /B "!PERSIST!\_toolchain_now.txt" "!PERSIST!\toolchain_verified.txt" >nul 2>nul
  if errorlevel 1 set "INVALIDATE=1"
)
if not exist "!PERSIST!\Mathlib_verified.olean" set "INVALIDATE=1"
if exist "!PERSIST!\Mathlib_verified.olean" (
  fc /B "!MATHLIB_ROOT!\Mathlib.olean" "!PERSIST!\Mathlib_verified.olean" >nul 2>nul
  if errorlevel 1 set "INVALIDATE=1"
)
if "!INVALIDATE!"=="1" (
  echo CACHE_IDENTITY=CHANGED_OR_FIRST_RUN
  if exist "!STORE!\" rmdir /S /Q "!STORE!"
  if exist "!SNAP!\" rmdir /S /Q "!SNAP!"
  if exist "!LOGS!\" rmdir /S /Q "!LOGS!"
  mkdir "!STORE!" "!SNAP!" "!LOGS!"
  copy /Y "!PERSIST!\_toolchain_now.txt" "!PERSIST!\toolchain_verified.txt" >nul
  copy /Y "!MATHLIB_ROOT!\Mathlib.olean" "!PERSIST!\Mathlib_verified.olean" >nul
)

rem Respect explicit full mode; otherwise copy passed artifacts from old package.
set "OLD=%USERPROFILE%\Downloads\ZETAHYPERBOLIC_PAPER_CHRONOLOGY_v0_3_2_FASTCORE_433"
if "!FORCE_FULL!"=="0" if exist "!OLD!\build\" (
  echo LEGACY_CACHE_IMPORT=CHECKING_UNCHANGED_SOURCES
  for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
    if not exist "!STORE!\%%M.olean" if exist "!OLD!\build\%%M.olean" if exist "!OLD!\build\_sources\%%M.lean" (
      fc /B "%%M.lean" "!OLD!\build\_sources\%%M.lean" >nul 2>nul
      if not errorlevel 1 (
        for %%D in ("!STORE!\%%M.olean" "!SNAP!\%%M.lean" "!LOGS!\%%M.log") do if not exist "%%~dpD" mkdir "%%~dpD"
        copy /Y "!OLD!\build\%%M.olean" "!STORE!\%%M.olean" >nul
        copy /Y "!OLD!\build\_sources\%%M.lean" "!SNAP!\%%M.lean" >nul
        if exist "!OLD!\build\logs\%%M.log" copy /Y "!OLD!\build\logs\%%M.log" "!LOGS!\%%M.log" >nul
        echo IMPORTED_CERTIFIED=%%M
      )
    )
  )
)

rem Preserve dependency-dirty flags across failed/interrupted runs.
rem They are cleared ONLY after a successful FULL chronological pass.
if not exist "!MARK!\" mkdir "!MARK!"
set "LEAN_PATH=!STORE!;!LEAN_STDLIB!"
if exist "!MATHLIB_CACHE!\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!MATHLIB_CACHE!\.lake\build\lib\lean"
for /D %%D in ("!MATHLIB_CACHE!\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
)
set /a COMPILED=0 >nul
set /a REUSED=0 >nul
set "NEW_LAYER_RESULT=UNREACHED"
set "THEOREM33_RESULT=UNREACHED"
set "SIGNED_PRODUCTS_RESULT=UNREACHED"
set "POLE_WEIGHT_RESULT=UNREACHED"
set "ACTUAL_LEADING_SIGN_RESULT=UNREACHED"
set "RECIPROCAL_ORDER_RESULT=UNREACHED"
set "LEADING_PARITY_RESULT=UNREACHED"
set "COR36_RESULT=UNREACHED"
set "THEOREM54_RESULT=UNREACHED"
set "ENVELOPE_RESULT=UNREACHED"
set "SECTION3_RESULT=UNREACHED"
set "CHAIN_RESULT=UNREACHED"
set "COMPILE_ORDER=FASTCORE_ORDER.txt"
if "!BLUEPRINT_ONLY!"=="1" set "COMPILE_ORDER=FASTCORE_BLUEPRINT_ORDER.txt"
for /F "usebackq delims=" %%M in ("!COMPILE_ORDER!") do (
  set "SOURCE=%%M.lean"
  set "OFILE=!STORE!\%%M.olean"
  set "STAMP=!SNAP!\%%M.lean"
  set "LOG=!LOGS!\%%M.log"
  if not exist "!SOURCE!" (echo MISSING=%%M&echo RESULT=FAIL&exit /b 5)
  set "NEEDS_BUILD=!FORCE_FULL!"
  if not exist "!OFILE!" set "NEEDS_BUILD=1"
  if not exist "!STAMP!" set "NEEDS_BUILD=1"
  if "!NEEDS_BUILD!"=="0" (
    fc /B "!SOURCE!" "!STAMP!" >nul 2>nul
    if errorlevel 1 set "NEEDS_BUILD=1"
  )
  rem Dependencies manifest is generated from real Lean `import` edges.
  for /F "usebackq tokens=1,2" %%A in ("FASTCORE_DEPENDENCIES.txt") do (
    if "%%A"=="%%M" if exist "!MARK!\%%B.flag" set "NEEDS_BUILD=1"
  )
  if "!NEEDS_BUILD!"=="1" (
    echo CHECK=%%M
    for %%D in ("!OFILE!" "!STAMP!" "!LOG!") do if not exist "%%~dpD" mkdir "%%~dpD"
    "!LEAN_EXE!" -j !LEAN_JOBS! -o "!OFILE!" "!SOURCE!" > "!LOG!" 2>&1
    if errorlevel 1 (
      echo CHECK_FAIL=%%M
      echo FIRST_ERROR_LINES_BEGIN
      findstr /n /c:": error:" /c:"error:" /c:"unknown constant" /c:"invalid field" "!LOG!"
      echo FIRST_ERROR_LINES_END
      rem Print complete failure details, including the goal state after
      rem "unsolved goals" (findstr above shows only its first line).
      echo FULL_ERROR_DETAILS_BEGIN
      type "!LOG!"
      echo FULL_ERROR_DETAILS_END
      echo FULL_ERROR_LOG=!LOG!
      echo RESULT=FAIL
      exit /b 1
    )
    findstr /i /c:"sorryAx" /c:"native_decide.ax_" "!LOG!" >nul
    if not errorlevel 1 (
      echo CHECK_FAIL=%%M
      echo FORBIDDEN_AXIOM=%%M
      findstr /n /i /c:"sorryAx" /c:"native_decide.ax_" "!LOG!"
      echo RESULT=FORBIDDEN_AXIOM
      exit /b 7
    )
    copy /Y "!SOURCE!" "!STAMP!" >nul
    if errorlevel 1 (echo RESULT=STAMP_FAILED&exit /b 6)
    for %%D in ("!MARK!\%%M.flag") do if not exist "%%~dpD" mkdir "%%~dpD"
    echo changed>"!MARK!\%%M.flag"
    set /a COMPILED+=1 >nul
    echo CHECK_PASS=%%M
    if /I "%%M"=="PaperBlueprint\ParagraphCheckpoint" (
      echo PARAGRAPH_CHECKPOINT=CLAUSES_ELABORATED_NOT_FULL_PAPER
      echo PARAGRAPH_TYPED_CLAUSES=18
      echo PDF_NUMBERED_ITEMS_INVENTORIED=51
    )
    if /I "%%M"=="Proposition_3_2_Real_s_Moment_Integrability" set "NEW_LAYER_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_3_Pole_Signature_Counts" set "THEOREM33_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_3_Signed_Pole_Products" set "SIGNED_PRODUCTS_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_3_Pole_Weight_Signs" set "POLE_WEIGHT_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_3_Actual_Leading_Coefficient_Sign" set "ACTUAL_LEADING_SIGN_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_4_Reciprocal_Root_Order" set "RECIPROCAL_ORDER_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_3_3_Leading_Sign_Parity" set "LEADING_PARITY_RESULT=COMPILED_PASS"
    if /I "%%M"=="Corollary_3_6_Corrected_Finite_Atomic_Moments" set "COR36_RESULT=COMPILED_PASS"
    if /I "%%M"=="Theorem_5_4_Even_Pole_Pair_Cancellation" set "THEOREM54_RESULT=COMPILED_PASS"
    if /I "%%M"=="Proposition_3_2_Real_s_Weight_Envelope" set "ENVELOPE_RESULT=COMPILED_PASS"
    if /I "%%M"=="PAPER_SECTION_03" set "SECTION3_RESULT=COMPILED_PASS"
    if /I "%%M"=="PAPER_CHRONOLOGICAL_CHAIN" set "CHAIN_RESULT=COMPILED_PASS"
  ) else (
    set /a REUSED+=1 >nul
    echo FROZEN_REUSED=%%M
    if /I "%%M"=="PaperBlueprint\ParagraphCheckpoint" (
      echo PARAGRAPH_CHECKPOINT=CLAUSES_ELABORATED_NOT_FULL_PAPER
      echo PARAGRAPH_TYPED_CLAUSES=18
      echo PDF_NUMBERED_ITEMS_INVENTORIED=51
    )
    if /I "%%M"=="Proposition_3_2_Real_s_Moment_Integrability" set "NEW_LAYER_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_3_Pole_Signature_Counts" set "THEOREM33_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_3_Signed_Pole_Products" set "SIGNED_PRODUCTS_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_3_Pole_Weight_Signs" set "POLE_WEIGHT_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_3_Actual_Leading_Coefficient_Sign" set "ACTUAL_LEADING_SIGN_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_4_Reciprocal_Root_Order" set "RECIPROCAL_ORDER_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_3_3_Leading_Sign_Parity" set "LEADING_PARITY_RESULT=FROZEN_PASS"
    if /I "%%M"=="Corollary_3_6_Corrected_Finite_Atomic_Moments" set "COR36_RESULT=FROZEN_PASS"
    if /I "%%M"=="Theorem_5_4_Even_Pole_Pair_Cancellation" set "THEOREM54_RESULT=FROZEN_PASS"
    if /I "%%M"=="Proposition_3_2_Real_s_Weight_Envelope" set "ENVELOPE_RESULT=FROZEN_PASS"
    if /I "%%M"=="PAPER_SECTION_03" set "SECTION3_RESULT=FROZEN_PASS"
    if /I "%%M"=="PAPER_CHRONOLOGICAL_CHAIN" set "CHAIN_RESULT=FROZEN_PASS"
  )
)
if "!BLUEPRINT_ONLY!"=="1" (
  for /F "usebackq delims=" %%M in ("FASTCORE_BLUEPRINT_ORDER.txt") do (
    if not exist "!STORE!\%%M.olean" (echo RESULT=BLUEPRINT_OLEAN_MISSING_%%M&exit /b 6)
    if not exist "!SNAP!\%%M.lean" (echo RESULT=BLUEPRINT_STAMP_MISSING_%%M&exit /b 6)
    fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
    if errorlevel 1 (echo RESULT=BLUEPRINT_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
    echo BLUEPRINT_ELABORATED=%%M
  )
  echo BLUEPRINT_STATEMENTS=UNPROVED_UNLESS_EXPLICIT_THEOREM_PROOF
  echo BUILD_COMPILED=!COMPILED!
  echo BUILD_FROZEN_REUSED=!REUSED!
  echo RESULT=PASS_BLUEPRINTS_ONLY
  exit /b 0
)
if "!SIGNED_PRODUCTS_RESULT!"=="UNREACHED" (echo RESULT=SIGNED_PRODUCTS_NOT_REACHED&exit /b 4)
if "!ACTUAL_LEADING_SIGN_RESULT!"=="UNREACHED" (echo RESULT=ACTUAL_LEADING_SIGN_NOT_REACHED&exit /b 4)
if "!POLE_WEIGHT_RESULT!"=="UNREACHED" (echo RESULT=POLE_WEIGHT_NOT_REACHED&exit /b 4)
if "!RECIPROCAL_ORDER_RESULT!"=="UNREACHED" (echo RESULT=RECIPROCAL_ORDER_NOT_REACHED&exit /b 4)
if "!LEADING_PARITY_RESULT!"=="UNREACHED" (echo RESULT=LEADING_PARITY_NOT_REACHED&exit /b 4)
if "!COR36_RESULT!"=="UNREACHED" (echo RESULT=COR36_NOT_REACHED&exit /b 4)
if "!THEOREM54_RESULT!"=="UNREACHED" (echo RESULT=THEOREM54_NOT_REACHED&exit /b 4)
if "!THEOREM33_RESULT!"=="UNREACHED" (echo RESULT=THEOREM33_NOT_REACHED&exit /b 4)
if "!NEW_LAYER_RESULT!"=="UNREACHED" (echo RESULT=NEW_LAYER_NOT_REACHED&exit /b 4)
if "!ENVELOPE_RESULT!"=="UNREACHED" (echo RESULT=ENVELOPE_NOT_REACHED&exit /b 4)
if "!SECTION3_RESULT!"=="UNREACHED" (echo RESULT=SECTION3_NOT_REACHED&exit /b 4)
if "!CHAIN_RESULT!"=="UNREACHED" (echo RESULT=CHAIN_NOT_REACHED&exit /b 4)
echo THEOREM_3_3_POLE_COUNTS_STATUS=!THEOREM33_RESULT!
echo THEOREM_3_3_SIGNED_PRODUCTS_STATUS=!SIGNED_PRODUCTS_RESULT!
echo THEOREM_3_3_POLE_WEIGHT_SIGNS_STATUS=!POLE_WEIGHT_RESULT!
echo THEOREM_3_3_ACTUAL_LEADING_SIGN_STATUS=!ACTUAL_LEADING_SIGN_RESULT!
echo THEOREM_3_3_LEADING_PARITY_STATUS=!LEADING_PARITY_RESULT!
echo THEOREM_3_4_RECIPROCAL_ORDER_STATUS=!RECIPROCAL_ORDER_RESULT!
echo COROLLARY_3_6_CORRECTED_STATUS=!COR36_RESULT!
echo THEOREM_5_4_EVEN_POLE_STATUS=!THEOREM54_RESULT!
echo REAL_S_ENVELOPE_STATUS=!ENVELOPE_RESULT!
echo REAL_S_MOMENTS_STATUS=!NEW_LAYER_RESULT!
echo SECTION_03_STATUS=!SECTION3_RESULT!
echo CHRONOLOGICAL_CHAIN_STATUS=!CHAIN_RESULT!
echo CHECK=FINAL_AXIOMS
if exist "!LOGS!\CHECK_AXIOMS.log" (
  findstr /i /c:"sorryAx" /c:"native_decide.ax_" "!LOGS!\CHECK_AXIOMS.log" >nul
  if not errorlevel 1 (
    echo RESULT=FORBIDDEN_AXIOM
    findstr /n /i /c:"sorryAx" /c:"native_decide.ax_" "!LOGS!\CHECK_AXIOMS.log"
    exit /b 7
  )
)
echo FINAL_AXIOMS=NO_FORBIDDEN_AXIOMS_DETECTED
echo NEW_CHRONOLOGICAL_EXTENSION=PASSED_OR_FROZEN
echo SHIFTED_ATOMIC_AND_DODGSON4=PASSED_OR_FROZEN
rem Explicitly reject a misleading V041-only PASS: the 3 V042 sources must each
rem have a certified source stamp AND compiled olean in the persistent cache.
for %%M in (Theorem_3_3_General_Three_Atom_Minors Theorem_3_4_Shifted_Dodgson_Jacobi PAPER_CHRONOLOGICAL_EXTENSION_3) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V042_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V042_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V042_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V042_CERTIFIED=%%M
)
echo V042_NEW_THREE_SOURCE_STAMPS=VERIFIED
echo GENERAL_ATOMIC_MINORS_AND_SHIFTED_JACOBI=PASSED_OR_FROZEN
rem Explicit success certificate for each V043 source, not a stale V042 PASS.
for %%M in (Theorem_3_3_Four_Atom_General_Minors Theorem_3_3_Four_Atom_Three_By_Three PAPER_CHRONOLOGICAL_EXTENSION_4) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V043_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V043_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V043_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V043_CERTIFIED=%%M
)
echo FOUR_ATOM_GENERAL_MINORS_AND_SHIFTED_GRAM3=PASSED_OR_FROZEN
rem V044 has exactly three fresh source targets; inspect their own user compiler stamps.
for %%M in (Theorem_3_3_Arbitrary_Order_Gram_Determinant Theorem_3_3_Actual_Sign_Corrected_Pole_Gram PAPER_CHRONOLOGICAL_EXTENSION_5) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V044_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V044_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V044_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V044_CERTIFIED=%%M
)
echo ACTUAL_POLE_ALL_ORDER_CORRECTED_GRAM=PASSED_OR_FROZEN
rem V045 theorem-level proof targets require fresh user-compiler .olean and exact source stamps.
for %%M in (Theorem_3_3_Actual_Continuous_Principal_Minors Theorem_3_4_Actual_Principal_Pencil_Reality PAPER_CHRONOLOGICAL_EXTENSION_6) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V045_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V045_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V045_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V045_CERTIFIED=%%M
)
echo ACTUAL_PRINCIPAL_THEOREMS=PASSED_OR_FROZEN
rem V046 source fingerprints and new user-compiler artifact certification.
set "V046_SIGNS=0"
set "V046_CHAIN=0"
for /F "usebackq delims=" %%M in ("FASTCORE_ORDER.txt") do (
  if /I "%%M"=="Theorem_3_3_Actual_Diagonal_Inertia_Signs" set "V046_SIGNS=1"
  if /I "%%M"=="PAPER_CHRONOLOGICAL_EXTENSION_7" set "V046_CHAIN=1"
)
if "!V046_SIGNS!"=="0" (echo RESULT=V046_SIGNS_MISSING_FROM_ORDER&exit /b 4)
if "!V046_CHAIN!"=="0" (echo RESULT=V046_CHAIN_MISSING_FROM_ORDER&exit /b 4)
for %%M in (Theorem_3_3_Actual_Diagonal_Inertia_Signs PAPER_CHRONOLOGICAL_EXTENSION_7) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V046_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V046_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V046_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V046_CERTIFIED=%%M
)
echo ACTUAL_DIAGONAL_INERTIA_SIGNS=PASSED_OR_FROZEN
rem Require certified .olean and exact source fingerprint for BOTH new theorems.
for %%M in (Theorem_3_3_Actual_Diagonal_Sign_Counts PAPER_CHRONOLOGICAL_EXTENSION_8) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V047_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V047_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V047_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V047_CERTIFIED=%%M
)
echo ACTUAL_DIAGONAL_INERTIA_COUNTS=PASSED_OR_FROZEN

rem V050: explicitly certify ALL eight new real theorem sources, not stale output.
for %%M in (Theorem_3_4_Actual_Principal_Spectral_Gap Corollary_3_5_Corrected_Schur_Fraction Corollary_3_6_Reciprocal_Root_Moment_Bounds Theorem_3_7_All_Order_Turanian_Jets Theorem_3_7_Real_Rooted_Polynomial_Turanian Theorem_3_8_Actual_Christoffel_Darboux_Kernel Theorem_4_1_Witness_Free_Principal_Separation PAPER_CHRONOLOGICAL_EXTENSION_9) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V050_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V050_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V050_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V050_CERTIFIED=%%M
)
echo V050_ACTUAL_THEOREM_JUMP=PASSED_OR_FROZEN

rem V062: confirm each NEW mathematical proof source has an exact current
rem native compiler-produced olean and byte-identical certified source stamp.
if not exist "!STORE!\Corollary_3_6_Actual_Reciprocal_Moment_Growth.olean" (echo RESULT=V062_OLEAN_MISSING_Corollary_3_6_Actual_Reciprocal_Moment_Growth&exit /b 6)
if not exist "!SNAP!\Corollary_3_6_Actual_Reciprocal_Moment_Growth.lean" (echo RESULT=V062_STAMP_MISSING_Corollary_3_6_Actual_Reciprocal_Moment_Growth&exit /b 6)
fc /B "Corollary_3_6_Actual_Reciprocal_Moment_Growth.lean" "!SNAP!\Corollary_3_6_Actual_Reciprocal_Moment_Growth.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_Corollary_3_6_Actual_Reciprocal_Moment_Growth&exit /b 6)
echo V062_CERTIFIED=Corollary_3_6_Actual_Reciprocal_Moment_Growth
if not exist "!STORE!\Theorem_3_7_Primitive_Scale_Turanian.olean" (echo RESULT=V062_OLEAN_MISSING_Theorem_3_7_Primitive_Scale_Turanian&exit /b 6)
if not exist "!SNAP!\Theorem_3_7_Primitive_Scale_Turanian.lean" (echo RESULT=V062_STAMP_MISSING_Theorem_3_7_Primitive_Scale_Turanian&exit /b 6)
fc /B "Theorem_3_7_Primitive_Scale_Turanian.lean" "!SNAP!\Theorem_3_7_Primitive_Scale_Turanian.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_Theorem_3_7_Primitive_Scale_Turanian&exit /b 6)
echo V062_CERTIFIED=Theorem_3_7_Primitive_Scale_Turanian
if not exist "!STORE!\Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.olean" (echo RESULT=V062_OLEAN_MISSING_Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic&exit /b 6)
if not exist "!SNAP!\Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean" (echo RESULT=V062_STAMP_MISSING_Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic&exit /b 6)
fc /B "Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean" "!SNAP!\Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic&exit /b 6)
echo V062_CERTIFIED=Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic
if not exist "!STORE!\Theorem_3_8_Actual_Pole_Kernel_Zero_Locus.olean" (echo RESULT=V062_OLEAN_MISSING_Theorem_3_8_Actual_Pole_Kernel_Zero_Locus&exit /b 6)
if not exist "!SNAP!\Theorem_3_8_Actual_Pole_Kernel_Zero_Locus.lean" (echo RESULT=V062_STAMP_MISSING_Theorem_3_8_Actual_Pole_Kernel_Zero_Locus&exit /b 6)
fc /B "Theorem_3_8_Actual_Pole_Kernel_Zero_Locus.lean" "!SNAP!\Theorem_3_8_Actual_Pole_Kernel_Zero_Locus.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_Theorem_3_8_Actual_Pole_Kernel_Zero_Locus&exit /b 6)
echo V062_CERTIFIED=Theorem_3_8_Actual_Pole_Kernel_Zero_Locus
if not exist "!STORE!\Theorem_4_1_Actual_Pole_Kernel_Zero_Free.olean" (echo RESULT=V062_OLEAN_MISSING_Theorem_4_1_Actual_Pole_Kernel_Zero_Free&exit /b 6)
if not exist "!SNAP!\Theorem_4_1_Actual_Pole_Kernel_Zero_Free.lean" (echo RESULT=V062_STAMP_MISSING_Theorem_4_1_Actual_Pole_Kernel_Zero_Free&exit /b 6)
fc /B "Theorem_4_1_Actual_Pole_Kernel_Zero_Free.lean" "!SNAP!\Theorem_4_1_Actual_Pole_Kernel_Zero_Free.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_Theorem_4_1_Actual_Pole_Kernel_Zero_Free&exit /b 6)
echo V062_CERTIFIED=Theorem_4_1_Actual_Pole_Kernel_Zero_Free
if not exist "!STORE!\PAPER_CHRONOLOGICAL_EXTENSION_10.olean" (echo RESULT=V062_OLEAN_MISSING_PAPER_CHRONOLOGICAL_EXTENSION_10&exit /b 6)
if not exist "!SNAP!\PAPER_CHRONOLOGICAL_EXTENSION_10.lean" (echo RESULT=V062_STAMP_MISSING_PAPER_CHRONOLOGICAL_EXTENSION_10&exit /b 6)
fc /B "PAPER_CHRONOLOGICAL_EXTENSION_10.lean" "!SNAP!\PAPER_CHRONOLOGICAL_EXTENSION_10.lean" >nul 2>nul
if errorlevel 1 (echo RESULT=V062_SOURCE_NOT_CERTIFIED_PAPER_CHRONOLOGICAL_EXTENSION_10&exit /b 6)
echo V062_CERTIFIED=PAPER_CHRONOLOGICAL_EXTENSION_10
echo V062_SPECTRAL_BRIDGES=PASSED_OR_FROZEN

rem V064 check all six new sources are included in the ordered proof build.
for %%M in (Theorem_3_9_Character_Fekete_Exact_Factors Theorem_5_1_Rational_Dual_Moment_Symmetry Theorem_5_2_Finite_Krein_Pairing Theorem_5_2_Finite_Krein_Matrix PaperBlueprint\ProofCheckpointV064 PAPER_CHRONOLOGICAL_EXTENSION_12) do (
  if not exist "%%M.lean" (echo RESULT=V064_SOURCE_FILE_MISSING_%%M&exit /b 4)
  findstr /L /I /X /C:"%%M" "FASTCORE_ORDER.txt" >nul
  if errorlevel 1 (echo RESULT=V064_SOURCE_ORDER_MISSING_%%M&exit /b 4)
)
echo V064_ORDER_GUARD=PASS

rem V063: verify every NEW source has an exact compiler-generated olean and source stamp.
for %%M in (Theorem_3_8_Actual_Pole_Kernel_Determinant_Mass Theorem_3_8_Actual_Pole_Kernel_Real_Argument Theorem_4_1_Actual_Rational_Root_Exclusion PaperBlueprint\ProofCheckpointV063 PAPER_CHRONOLOGICAL_EXTENSION_11) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V063_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V063_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V063_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V063_CERTIFIED=%%M
)
echo V063_PARAGRAPH_CHECKPOINT=SIX_CLAUSES_FORMALLY_PROVED
rem All other typed, unproved clauses remain unproved; full paper not claimed.
echo FULL_PAPER=NOT_PROVED

rem V064 exact source/cached compiler proof records, no stale PASS allowed.
for %%M in (Theorem_3_9_Character_Fekete_Exact_Factors Theorem_5_1_Rational_Dual_Moment_Symmetry Theorem_5_2_Finite_Krein_Pairing Theorem_5_2_Finite_Krein_Matrix PaperBlueprint\ProofCheckpointV064 PAPER_CHRONOLOGICAL_EXTENSION_12) do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=V064_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=V064_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=V064_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo V064_CERTIFIED=%%M
)
echo V064_PROOF_PARAGRAPH_FRAGMENTS=9_THEOREM_BACKED_FRAGMENTS_NOT_9_FULL_PAPER_ITEMS
echo FULL_PAPER=NOT_PROVED

rem All invalidated dependents have now been recompiled successfully.
if exist "!MARK!\" rmdir /S /Q "!MARK!"
mkdir "!MARK!"
echo BUILD_COMPILED=!COMPILED!
echo BUILD_FROZEN_REUSED=!REUSED!
echo BLUEPRINT_STATEMENTS=NOT_CONVERTED_TO_PROOFS
for /F "usebackq delims=" %%M in ("FASTCORE_BLUEPRINT_ORDER.txt") do (
  if not exist "!STORE!\%%M.olean" (echo RESULT=BLUEPRINT_OLEAN_MISSING_%%M&exit /b 6)
  if not exist "!SNAP!\%%M.lean" (echo RESULT=BLUEPRINT_STAMP_MISSING_%%M&exit /b 6)
  fc /B "%%M.lean" "!SNAP!\%%M.lean" >nul 2>nul
  if errorlevel 1 (echo RESULT=BLUEPRINT_SOURCE_NOT_CERTIFIED_%%M&exit /b 6)
  echo BLUEPRINT_ELABORATED=%%M
)
echo RESULT=PASS
exit /b 0
