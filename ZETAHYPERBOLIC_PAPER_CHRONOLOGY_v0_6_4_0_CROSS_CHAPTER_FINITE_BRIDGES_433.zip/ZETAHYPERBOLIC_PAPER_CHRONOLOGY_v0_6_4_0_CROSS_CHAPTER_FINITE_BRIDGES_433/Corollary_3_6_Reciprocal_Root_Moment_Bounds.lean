import Corollary_3_6_Corrected_Finite_Atomic_Moments
import Theorem_3_4_Actual_Principal_Pencil_Reality
import Mathlib.Tactic

/-!
# Corollary 3.6: all-order reciprocal-root power sums (corrected)

The printed moment limit has an inequality reversed, and strict Hankel
positivity cannot persist beyond finite support. These theorems give the
correct finite-spectral moment inequalities for every order and the exact
Gram factorization, without requiring an unavailable analytic witness.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Corollary3_6.ReciprocalMoments
open PaperChronology.Corollary3_6.CorrectedFiniteAtomic

/-- The square inverse-distance atom associated to a real spectral root. -/
def invDistanceAtom {n : ℕ} (roots : Fin n → ℝ)
    (q : ℝ) (i : Fin n) : ℝ := ((roots i - q)⁻¹) ^ 2

/-- Even with coincident or repeated roots, every atom is nonnegative. -/
theorem invDistanceAtom_nonneg {n : ℕ} (roots : Fin n → ℝ)
    (q : ℝ) (i : Fin n) : 0 ≤ invDistanceAtom roots q i := by
  unfold invDistanceAtom
  exact sq_nonneg _

/-- Excluding the center point gives a strictly positive atom. -/
theorem invDistanceAtom_pos {n : ℕ} (roots : Fin n → ℝ)
    (q : ℝ) (i : Fin n) (hi : roots i ≠ q) :
    0 < invDistanceAtom roots q i := by
  unfold invDistanceAtom
  have hdiff : roots i - q ≠ 0 := sub_ne_zero.mpr hi
  exact sq_pos_of_ne_zero (inv_ne_zero hdiff)

/-- Corrected Stieltjes even-power sum, with multiplicity retained. -/
def reciprocalPowerSum {n : ℕ} (roots : Fin n → ℝ)
    (q : ℝ) (m : ℕ) : ℝ :=
  atomicMoment (invDistanceAtom roots q) m

/-- Every individual inverse-distance contribution is at most the sum. -/
theorem atom_le_reciprocalPowerSum {n : ℕ}
    (roots : Fin n → ℝ) (q : ℝ) (m : ℕ) (i : Fin n) :
    (invDistanceAtom roots q i) ^ m ≤ reciprocalPowerSum roots q m := by
  unfold reciprocalPowerSum atomicMoment
  exact Finset.single_le_sum
    (fun j _ => pow_nonneg (invDistanceAtom_nonneg roots q j) m)
    (Finset.mem_univ i)

/-- Upper estimate `S_{2m} <= n*B^m` for a uniform inverse-square
separation budget B; this is the finite ingredient in the corrected limit. -/
theorem reciprocalPowerSum_upper {n : ℕ}
    (roots : Fin n → ℝ) (q B : ℝ) (m : ℕ)
    (hB : ∀ i, invDistanceAtom roots q i ≤ B) :
    reciprocalPowerSum roots q m ≤ (n : ℝ) * B ^ m := by
  exact atomicMoment_le_card_mul_pow
    (invDistanceAtom roots q)
    (fun i => invDistanceAtom_nonneg roots q i) B hB m

/-- The actual finite root system's full even-moment Hankel matrix is
EXACTLY a Gram matrix of inverse-square root-distance Vandermonde vectors.
No false all-order strict determinant claim is made. -/
theorem reciprocal_hankel_gram {n : ℕ}
    (roots : Fin n → ℝ) (q : ℝ) (k : ℕ) :
    atomicHankel (invDistanceAtom roots q) k =
      atomicVandermonde (invDistanceAtom roots q) k *
        (atomicVandermonde (invDistanceAtom roots q) k).transpose := by
  exact atomicHankel_factorization (invDistanceAtom roots q) k

end PaperChronology.Corollary3_6.ReciprocalMoments

#print axioms PaperChronology.Corollary3_6.ReciprocalMoments.atom_le_reciprocalPowerSum
#print axioms PaperChronology.Corollary3_6.ReciprocalMoments.reciprocal_hankel_gram
