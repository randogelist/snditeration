import PAPER_CHRONOLOGICAL_EXTENSION_10
import Theorem_3_8_Actual_Pole_Kernel_Determinant_Mass
import Theorem_3_8_Actual_Pole_Kernel_Real_Argument
import Theorem_4_1_Actual_Rational_Root_Exclusion
import PaperBlueprint.ProofCheckpointV063

/-!
# Chronological extension 11 — v0.6.3.0

New unconditional actual real-s finite-spectral results:
* pole-kernel determinant factorization and nonsingularity;
* exact Gram/pole-kernel/derivative determinant mass identity;
* the paper's determinant identity for every real X;
* an explicit finite (not uniform-in-K) local rational root exclusion;
* six verified, source-faithful paragraph clauses, including the
  three proven targets 3.8, 3.8 and 4.1 promoted from typed-only status.

No new arithmetic witness, all-order nonprincipal strict total positivity,
Carleman uniqueness, Krein infinite-tail bound, or unconditional
irrationality conclusion is claimed.
-/

#print axioms PaperChronology.Theorem3_8.ActualDetMass.gram_det_mul_weighted_kernel_det
#print axioms PaperChronology.Theorem3_8.ActualRealArgument.actual_pencil_det_at_every_real_x
#print axioms PaperChronology.Theorem4_1.ActualRationalExclusion.rational_points_in_local_gap_are_not_roots
#print axioms PaperBlueprint.ProofCheckpointV063.six_paragraph_clauses_with_proofs
