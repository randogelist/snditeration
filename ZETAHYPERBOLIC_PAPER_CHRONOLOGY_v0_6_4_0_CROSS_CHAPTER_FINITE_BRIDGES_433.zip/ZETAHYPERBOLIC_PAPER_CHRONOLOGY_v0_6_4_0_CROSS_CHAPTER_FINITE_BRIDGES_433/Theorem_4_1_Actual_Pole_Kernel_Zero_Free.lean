import Theorem_3_8_Actual_Pole_Kernel_Zero_Locus
import Theorem_3_4_Actual_Principal_Spectral_Gap
import Mathlib.Tactic

/-!
# Theorem 4.1: witness-free finite pole-kernel exclusion certificate

The genuine Christoffel-Darboux pole-kernel matrix has a positive
zero-free neighborhood in the displacement variable t about zero.
This radius is the actual spectrum-dependent radius constructed in
Theorem 3.4, transferred through the proved Theorem 3.8 determinant
identity. It is NOT the uniform exp(-11.411 K) bound, which still needs
an independent analytic estimate.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem4_1.ActualKernelSeparation
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel
open PaperChronology.Theorem3_8.ActualZeroLocus

/-- An explicit existential finite root-exclusion radius for the actual
spectral pole-kernel determinant, without an arithmetic Witness. -/
theorem actual_pole_kernel_zero_free
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    ∃ B : ℝ, 0 < B ∧ ∀ t : ℝ, |t| < 1 / B →
      (1 + t • (Matrix.diagonal (poleWeight s p) *
        poleKernel s p)).det ≠ 0 := by
  obtain ⟨B, hB, hpos⟩ :=
    PaperChronology.Theorem3_4.ActualSpectralGap.zero_free_radius_of_posDef
      (Gram.actualPencil s p)
      (PaperChronology.Proposition3_2.Integrability.actualGram_posDef s p hs)
  refine ⟨B, hB, ?_⟩
  intro t ht
  have hoff : ((riemannZeta (s : ℂ)).re + t) -
      (riemannZeta (s : ℂ)).re = t := by ring
  have hnear :
      |((riemannZeta (s : ℂ)).re + t) -
        (riemannZeta (s : ℂ)).re| < 1 / B := by
    rw [hoff]
    exact ht
  have heval : 0 < (Gram.actualPencil s p).detPolynomial.eval
      ((riemannZeta (s : ℂ)).re + t) := hpos _ hnear
  intro hzero
  have hzeroPencil :=
    (actual_pencil_root_iff_kernel_zero s p hs t).mpr hzero
  exact (ne_of_gt heval) hzeroPencil

/-- This is an actual finite spectral certificate; its construction
requires only the real-s positive Gram input already proved, rather
than an unconstructed arithmetic decay or integrality certificate. -/
theorem actual_pole_kernel_no_center_root
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (1 + (0 : ℝ) • (Matrix.diagonal (poleWeight s p) *
      poleKernel s p)).det ≠ 0 := by
  exact PaperChronology.Theorem3_8.ActualZeroLocus.actual_kernel_center_nonzero s p

end PaperChronology.Theorem4_1.ActualKernelSeparation

#print axioms PaperChronology.Theorem4_1.ActualKernelSeparation.actual_pole_kernel_zero_free
