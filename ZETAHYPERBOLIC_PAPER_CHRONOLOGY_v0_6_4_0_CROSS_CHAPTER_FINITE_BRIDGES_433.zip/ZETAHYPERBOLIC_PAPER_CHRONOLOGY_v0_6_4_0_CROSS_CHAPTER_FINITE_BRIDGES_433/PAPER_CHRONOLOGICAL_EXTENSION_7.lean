import PAPER_CHRONOLOGICAL_EXTENSION_6
import Theorem_3_3_Actual_Diagonal_Inertia_Signs
import Theorem_3_3_Pole_Signature_Counts

/-!
# PDF Theorem 3.3(3): actual full-size pole congruence sign profile

This theorem combines the verified arithmetic pole counts and the exact
alternating signs of the actual diagonalized derivative. It is an
unconditional algebraic certificate, with no input besides ordinary
finite manuscript parameters. The remaining connection to inertia of
the real normalized spectral matrix must use Sylvester's law; no such
unproved conclusion is smuggled into this theorem statement.
-/

noncomputable section
namespace PaperChronology

/-- The PDF's actual derivative in pole coordinates has a fully
classified nonzero sign at every coordinate. -/
theorem paper_theorem_3_3_actual_diagonal_profile
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    ∀ i : Fin p.h,
      ((0 < Theorem3_3.ActualDiagonalSigns.diagonalSlope p i ↔
        Even (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1)) ∧
       (Theorem3_3.ActualDiagonalSigns.diagonalSlope p i < 0 ↔
        Odd (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1))) := by
  intro i
  exact ⟨Theorem3_3.ActualDiagonalSigns.diagonalSlope_pos_iff_even p hm i,
    Theorem3_3.ActualDiagonalSigns.diagonalSlope_neg_iff_odd p hm i⟩

/-- For K=30n and N=3n, the weight-five arithmetic sign counts and
actual Lagrange-coordinate sign profile are obtained simultaneously.
The spectral inertia transfer is intentionally kept distinct. -/
theorem paper_theorem_3_3_weight_five_actual_sign_data
    (n : ℕ) (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (hN : p.N = 3 * n) (hK : p.K = 30 * n) :
    Theorem3_3.PoleCounts.oddPoleCount p.N p.K = (27 * n) / 2 ∧
    Theorem3_3.PoleCounts.evenPoleCount p.N p.K = (27 * n + 1) / 2 ∧
    (∀ i : Fin p.h,
      (Even (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1) →
        0 < Theorem3_3.ActualDiagonalSigns.diagonalSlope p i) ∧
      (Odd (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1) →
        Theorem3_3.ActualDiagonalSigns.diagonalSlope p i < 0)) := by
  refine ⟨?_, ?_, ?_⟩
  · simpa [hN, hK] using Theorem3_3.PoleCounts.weightFive_odd_count n
  · simpa [hN, hK] using Theorem3_3.PoleCounts.weightFive_even_count n
  · intro i
    exact ⟨Theorem3_3.ActualDiagonalSigns.diagonalSlope_pos_of_even p hm i,
      Theorem3_3.ActualDiagonalSigns.diagonalSlope_neg_of_odd p hm i⟩

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_actual_diagonal_profile
#print axioms PaperChronology.paper_theorem_3_3_weight_five_actual_sign_data
