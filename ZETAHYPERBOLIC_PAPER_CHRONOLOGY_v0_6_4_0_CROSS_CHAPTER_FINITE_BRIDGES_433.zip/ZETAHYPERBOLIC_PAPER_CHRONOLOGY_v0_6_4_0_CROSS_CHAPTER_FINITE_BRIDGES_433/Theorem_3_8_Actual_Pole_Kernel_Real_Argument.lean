import Theorem_3_8_Actual_Pole_Kernel_Determinant_Mass
import Theorem_3_8_Actual_Pole_Kernel_Zero_Locus
import Mathlib.Tactic

/-!
# Theorem 3.8: exact determinant identity in the manuscript's X variable

The previously certified cyclic identity is parameterized by the
real displacement t = X-zeta(s). Here it is transferred to EVERY
real X (not only the center) in the actual Section 3 polynomial.
No change is made to any previously compiled source.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_8.ActualRealArgument
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel
open PaperChronology.Theorem3_8.ActualZeroLocus

/-- Pointwise determinant equality of the genuine real-s paper pencil. -/
theorem actual_pencil_det_at_every_real_x
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (x : ℝ) :
    (Gram.actualPencil s p).detPolynomial.eval x =
      (Gram.gram s p).det *
        (1 + (x - (riemannZeta (s : ℂ)).re) •
          (Matrix.diagonal (poleWeight s p) * poleKernel s p)).det := by
  have h := actual_pencil_kernel_det_exact s p hs
    (x - (riemannZeta (s : ℂ)).re)
  have hc : (riemannZeta (s : ℂ)).re +
      (x - (riemannZeta (s : ℂ)).re) = x := by ring
  rw [hc] at h
  exact h

/-- The polynomial zero locus and finite pole-kernel zero locus agree
at every real parameter, without a separately postulated spectrum. -/
theorem actual_pencil_root_iff_weighted_kernel_root
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (x : ℝ) :
    (Gram.actualPencil s p).detPolynomial.eval x = 0 ↔
      (1 + (x - (riemannZeta (s : ℂ)).re) •
        (Matrix.diagonal (poleWeight s p) * poleKernel s p)).det = 0 := by
  have h := actual_pencil_root_iff_kernel_zero s p hs
    (x - (riemannZeta (s : ℂ)).re)
  have hc : (riemannZeta (s : ℂ)).re +
      (x - (riemannZeta (s : ℂ)).re) = x := by ring
  rw [hc] at h
  exact h

end PaperChronology.Theorem3_8.ActualRealArgument

#print axioms PaperChronology.Theorem3_8.ActualRealArgument.actual_pencil_det_at_every_real_x
#print axioms PaperChronology.Theorem3_8.ActualRealArgument.actual_pencil_root_iff_weighted_kernel_root
