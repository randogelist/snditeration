# Native-Lean paragraph checkpoint v0.6.3.0 (candidate)

## Input certificate (from user's Windows compiler, 24 October 2026)

`RESULT=PASS`, `BUILD_COMPILED=5`, `BUILD_FROZEN_REUSED=122` at v0.6.2.2:
127/127 Lean source modules passed, including 8 blueprint inventory/source files.
The source versions of **all 127 previously certified modules are unchanged**.
No local assistant-side Lean compilation was used.

## §3.8–§4.1 mathematical extension

- `Theorem_3_8_Actual_Pole_Kernel_Determinant_Mass`: for the actual
  infinite-measure Gram G and pole Vandermonde V, prove
  `det(V^T G^-1 V) = det(V)^2 det(G^-1)` and
  `det G · det(diag(γ) K) = det M`, with both the plain kernel and
  weighted kernel nonsingular for real s>1.
- `Theorem_3_8_Actual_Pole_Kernel_Real_Argument`: express the exact
  determinant and zero locus at arbitrary real X, rather than a
  displaced parameter t.
- `Theorem_4_1_Actual_Rational_Root_Exclusion`: no rational point
  `a/b` (nor any real point) inside the actual, finite kernel's
  positive spectral gap can be a root. This is NOT uniform in K.
- `PaperBlueprint/ProofCheckpointV063`: compile three true proofs of
  previously typed-only targets, §3.8 cyclic determinant, §3.8 zero
  locus, §4.1 local gap. In all, six selected paragraph clauses now
  have proof-checkable support (two §2 generators, one §5.4,
  three promoted §3.8/§4.1). 18 anchors have been type elaborated.

## Honest scope

**A successful native PASS would promote the five new modules**, and
would confirm the six paragraph clauses are theorem-backed. Other full numbered-paper proof obligations remain unsolved;
51 is a manuscript inventory, not a proof count. The Section 3.3
all-nonprincipal-minor and Carleman uniqueness theorems, exact eigenvalue
signature count, complete Section 4 exponential/p-adic estimates,
Section 5 infinite Krein truncation, and many Section 6 targets are
still open. The effective arithmetic Witness is not constructed.

A failed candidate module leaves the 127 native-passed modules frozen.
