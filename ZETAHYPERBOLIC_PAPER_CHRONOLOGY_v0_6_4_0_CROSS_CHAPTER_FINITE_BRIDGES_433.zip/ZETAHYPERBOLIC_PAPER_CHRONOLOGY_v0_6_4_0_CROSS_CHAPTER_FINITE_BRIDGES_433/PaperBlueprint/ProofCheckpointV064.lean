import PaperBlueprint.ProofCheckpointV063
import Theorem_3_9_Character_Fekete_Exact_Factors
import Theorem_5_1_Rational_Dual_Moment_Symmetry
import Theorem_5_2_Finite_Krein_Matrix

/-!
# Exact PDF paragraph proof checkpoint: 6 previously PASS + 3 new fragments

The six v0.6.3 proof clauses are imported without editing their sources.
We add three *new fragment targets* linked to numbered paper paragraphs:
- Theorem 3.9, p.13: five exact Fekete factorizations;
- Theorem 5.1, p.23: rational off-diagonal moment symmetry;
- Theorem 5.2, pp.23-24: exact finite Krein truncation decomposition.

These three are NOT the whole respective manuscript theorems. Their
unbounded analytic and spectral consequences still require separate proofs.
The `ninE_proved_fragments` theorem below is only a conjunction of
these exact, bounded statements and the earlier six statements.
-/

noncomputable section
namespace PaperBlueprint.ProofCheckpointV064
open PaperChronology.Theorem3_9.Fekete
open PaperChronology.Theorem5_1.DualSymmetry
open PaperChronology.Theorem5_2.FiniteKreinMatrix

/-- Printed five character factorizations, not yet character-hyperbolicity. -/
def characterFiveFactorTarget : Prop :=
  ∀ z : ℝ,
    characterMinusThree z = z * (1 - z) ∧
    characterMinusFour z = z * (1 - z ^ 2) ∧
    characterFive z = z * (1 - z) ^ 2 * (1 + z) ∧
    characterEight z = z * (1 - z ^ 2) * (1 - z ^ 4) ∧
    characterMinusEight z = z * (1 + z ^ 2) * (1 - z ^ 4)

/-- The precise finite harmonic divided-difference symmetry of §5.1. -/
def rationalDualSymmetryTarget : Prop :=
  ∀ (r t : ℕ),
    ManuscriptChain.Real.dualConstant 7 r t =
      ManuscriptChain.Real.dualConstant 7 t r

/-- The finite signed moment decomposition in §5.2, no infinite tail. -/
def finiteKreinTarget : Prop :=
  ∀ {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ),
    ManuscriptChain.Extensions.weightSevenTruncation c M =
      finiteKreinMatrix c M

theorem characterFiveFactor_proved : characterFiveFactorTarget := by
  intro z
  exact all_character_factors z

theorem rationalDualSymmetry_proved : rationalDualSymmetryTarget := by
  intro r t
  exact dualConstant_swap 7 r t

theorem finiteKrein_proved : finiteKreinTarget := by
  intro h K c M
  exact weightSevenTruncation_eq_finiteKreinMatrix c M

/-- Nine *fragment-level* proof obligations, NOT nine completely proved
PDF numbered items and NOT the manuscript's irrationality endpoint. -/
theorem nine_proved_fragments :
    (PaperBlueprint.Section02.currentPullback ∧
      PaperBlueprint.Section02.currentReflectionAndDifference ∧
      PaperBlueprint.Section05.evenPoleCancellation ∧
      PaperBlueprint.ParagraphCheckpoint.cyclicPoleKernelTarget ∧
      PaperBlueprint.ParagraphCheckpoint.poleKernelZeroTarget ∧
      PaperBlueprint.ParagraphCheckpoint.finiteKernelGapTarget) ∧
      characterFiveFactorTarget ∧
      rationalDualSymmetryTarget ∧
      finiteKreinTarget := by
  exact ⟨PaperBlueprint.ProofCheckpointV063.six_paragraph_clauses_with_proofs,
    characterFiveFactor_proved, rationalDualSymmetry_proved, finiteKrein_proved⟩

end PaperBlueprint.ProofCheckpointV064

#print axioms PaperBlueprint.ProofCheckpointV064.nine_proved_fragments
