import PaperBlueprint.Inventory
import PaperBlueprint.Section04

/-!
# Section 6 — source-faithful priority target statements

The inventory includes ALL 18 Section 6 numbered proof items. The majority
need new concrete analytic / p-adic definitions before their entire PDF
statements can be transported into Lean. We formalize selected exact
endpoints below, and keep every remaining gate in SECTION_06.md.

DO NOT infer that weight-five arithmetic decay proves the generalization
claims. The section requires independent analytic and local arithmetic work.
-/

noncomputable section
open Polynomial

namespace PaperBlueprint.Section06

/-- PDF Corollary 6.8: unconditional nonvanishing on the printed cone.
This is an open Prop, *not* a theorem proved from Section 4 in the archive. -/
def theorem68ThreeTermCone : Prop :=
  ∀ (c a b : ℤ), (c ≠ 0 ∨ a ≠ 0 ∨ b ≠ 0) →
    (b = 0 ∨ (a : ℝ) / (b : ℝ) < Real.pi ^ 2 / 3) →
      (c : ℝ) + (a : ℝ) * PaperBlueprint.Section04.zeta3 +
        (b : ℝ) * PaperBlueprint.Section04.zeta5 ≠ 0

/-- Real Dirichlet beta at odd positive argument, as a numerical sum. -/
def betaOdd (k : ℕ) : ℝ :=
  ∑' n : ℕ, (-1 : ℝ) ^ n / (((2 * n + 1 : ℕ) : ℝ) ^ (2 * k + 1))

/-- Exact transcendence component of printed Theorem 6.15(1) for every
odd Dirichlet beta value. Includes k=0 (beta(1)=pi/4). -/
def theorem615OddBetaTranscendence : Prop :=
  ∀ k : ℕ, ∀ p : ℚ[X], p ≠ 0 →
    Polynomial.eval₂ (algebraMap ℚ ℝ) (betaOdd k) p ≠ 0

/-- The Section 6 finite certificate cannot replace these independent
arithmetic endpoints. Additional 16 theorem targets remain in inventory. -/
def selectedArithmeticTargets : Prop :=
  theorem68ThreeTermCone ∧ theorem615OddBetaTranscendence

end PaperBlueprint.Section06
