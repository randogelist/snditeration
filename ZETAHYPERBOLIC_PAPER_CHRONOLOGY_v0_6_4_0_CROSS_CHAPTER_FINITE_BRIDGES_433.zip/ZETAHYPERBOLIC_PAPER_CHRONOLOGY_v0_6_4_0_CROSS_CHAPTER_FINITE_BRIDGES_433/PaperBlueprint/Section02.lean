import PaperBlueprint.Inventory
import Lemma_2_3_Reflection_And_Difference_Identities
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Section 2 — rational functional algebra (PDF 2.1–2.5)

These are explicit Lean interfaces for the *proved generator domain* and
its concrete finite decomposition. They do NOT assert that any Lean RatFunc
expression has already been normalized to this domain. The still-missing
RatFunc/normal-form bridge is recorded in the chapter roadmap.
-/

noncomputable section
open Polynomial

namespace PaperBlueprint.Section02

/-- Existing finite-decomposition form of (2.5), checked downstream here. -/
def currentPullback : Prop :=
  ∀ (k : ℕ), 1 ≤ k → ∀ R : Zetahyperbolic.RatMomentElem,
    Zetahyperbolic.muFunctionalPoly k R =
      PaperChronology.Section2.tauPullbackOnDecomposition k R

theorem currentPullback_verified : currentPullback := by
  intro k hk R
  exact PaperChronology.Section2.lemma_2_2_pullback k hk R

/-- All three actual source-domain generator statements from (2.6)-(2.7). -/
def currentReflectionAndDifference : Prop :=
  ∀ (k : ℕ), 1 ≤ k →
    (∀ d : ℕ,
      (-1 : ℚ) ^ d *
        (∑ i ∈ Finset.range (d + 1),
          (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
      -Zetahyperbolic.tauMonomial k d) ∧
    (∀ r : ℤ,
      -Zetahyperbolic.tauPolePoly k (-1 - r) =
        -Zetahyperbolic.tauPolePoly k r) ∧
    (∀ r : ℤ, r ≠ 0 → r ≠ 1 →
      Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r =
          Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹))

theorem currentReflectionAndDifference_verified :
    currentReflectionAndDifference := by
  intro k hk
  exact PaperChronology.Section2.lemma_2_3_all_generators k hk

/-- Section 2's current checked generator-level spine. Full direct RatFunc
syntax equivalence remains a distinct task, not inferred from this theorem. -/
theorem provedFiniteDomainSpine :
    currentPullback ∧ currentReflectionAndDifference :=
  ⟨currentPullback_verified, currentReflectionAndDifference_verified⟩

end PaperBlueprint.Section02
