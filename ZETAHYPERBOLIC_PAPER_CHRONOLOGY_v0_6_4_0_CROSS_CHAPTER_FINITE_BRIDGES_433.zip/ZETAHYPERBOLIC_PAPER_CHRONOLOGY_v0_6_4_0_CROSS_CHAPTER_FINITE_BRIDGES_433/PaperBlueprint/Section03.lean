import PaperBlueprint.Inventory
import Proposition_3_2_Real_s_Moment_Integrability
import Theorem_3_3_Actual_Continuous_Principal_Minors
import Theorem_3_3_Actual_Diagonal_Sign_Counts
import Theorem_3_4_Actual_Principal_Pencil_Reality

/-!
# Section 3 — explicit unproved theorem statements

The Prop-valued declarations below are proof TARGETS, not axioms or theorems.
They retain the actual real-s moment matrix from the manuscript.

3.5 and 3.6 are not stated verbatim: the PDF's finite J-fraction formula
and the all-orders strict Hankel rank claim require correction.
-/

noncomputable section
open scoped BigOperators
open Polynomial MeasureTheory

namespace PaperBlueprint.Section03
open PaperChronology.Proposition3_2

/-- Missing Theorem 3.3(1): positivity for ALL nonprincipal minors of
actual infinite-measure Hankel matrices, not only principal minors. -/
def allNonprincipalMinors : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∀ {r : ℕ} (rows cols : Fin r → Fin p.h),
      StrictMono rows → StrictMono cols →
      0 < ((Gram.gram s p).submatrix rows cols).det

/-- Missing Carleman/Stieltjes uniqueness part of 3.3(1). The comparison
measure must also be supported on the nonnegative real axis. -/
def stieltjesDeterminate : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∀ (μ : Measure ℝ), μ (Set.Iio (0 : ℝ)) = 0 →
      (∀ n : ℕ,
        Integrable (fun t : ℝ => t ^ n) μ ∧
        (∫ t, t ^ n ∂μ) =
          (∫ t, t ^ n ∂Gram.momentMeasure s p)) →
      μ = Gram.momentMeasure s p

/-- The missing Sylvester transfer for the *actual* real-s pencil.
The factorization fixes multiplicities and the positive/negative counts
are the exact parity counts of the genuine negative-square pole lattice.
No diagonal entries, factorization, or inertia equalities are postulated
as new axioms. -/
def actualSpectralSignature : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∃ beta : Fin p.h → ℝ,
      (∀ i, beta i ≠ 0) ∧
      (∀ x : ℝ,
        ((Gram.actualPencil s p).detPolynomial).eval x =
          (Gram.gram s p).det *
            ∏ i : Fin p.h,
              (1 + (x - (riemannZeta (s : ℂ)).re) * beta i)) ∧
      (∑ i : Fin p.h, if 0 < beta i then 1 else 0) =
        (∑ i : Fin p.h,
          if (p.N + 1 + i.val) % 2 = 1 then 1 else 0) ∧
      (∑ i : Fin p.h, if beta i < 0 then 1 else 0) =
        (∑ i : Fin p.h,
          if (p.N + 1 + i.val) % 2 = 0 then 1 else 0)

/-- Full Theorem 3.3 target. The frozen diagonal counts by themselves do NOT
imply this conjunction: these three obligations remain distinct. -/
def theorem33Full : Prop :=
  allNonprincipalMinors ∧ stieltjesDeterminate ∧ actualSpectralSignature

/-- A precise finite-dimensional ordered-root relation used by the remaining
Theorem 3.4 Cauchy/Cholesky bridge. Ties are allowed, as in Cauchy interlacing. -/
def Interlaces {n : ℕ} (small : Fin n → ℝ)
    (large : Fin (n + 1) → ℝ) : Prop :=
  (∀ i j, i < j → small i ≤ small j) ∧
  (∀ i j, i < j → large i ≤ large j) ∧
  ∀ i : Fin n, ∃ j k : Fin (n + 1),
    j.val = i.val ∧ k.val = i.val + 1 ∧
      large j ≤ small i ∧ small i ≤ large k

/-- The higher-derivative Turan target of printed Theorem 3.7.
Unlike the m=1 source candidate, this ranges over every derivative order. -/
def derivativeIter : ℕ → ℝ[X] → ℝ[X]
  | 0, P => P
  | m + 1, P => (derivativeIter m P).derivative

def allOrderActualTuran : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∀ m : ℕ, 1 ≤ m → m < p.h →
      ∀ x : ℝ,
        0 ≤
          ((derivativeIter m ((Gram.actualPencil s p).detPolynomial)).eval x) ^ 2 -
          (derivativeIter (m - 1) ((Gram.actualPencil s p).detPolynomial)).eval x *
          (derivativeIter (m + 1) ((Gram.actualPencil s p).detPolynomial)).eval x

/- The Jacobian differentiation identity of Theorem 3.8 still needs
explicit τ-dependent infinite weight / differentiation-under-the-integral.
Its exact construction and domain are listed in SECTION_03.md. -/

end PaperBlueprint.Section03
