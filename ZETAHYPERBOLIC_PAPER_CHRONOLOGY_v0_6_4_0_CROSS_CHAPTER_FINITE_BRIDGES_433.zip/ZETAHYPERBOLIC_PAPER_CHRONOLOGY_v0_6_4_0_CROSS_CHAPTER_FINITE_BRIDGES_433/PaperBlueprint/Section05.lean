import PaperBlueprint.Inventory
import Zetahyperbolic.Foundations
import Theorem_5_4_Even_Pole_Pair_Cancellation
import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil

/-!
# Section 5 — honest 2D Beukers and Krein targets

The finite Krein certificate in earlier code DOES NOT eliminate the
infinitely many omitted negative modes. `uniformTailBound` below is an
explicit proof target, not an accepted axiom.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Polynomial

namespace PaperBlueprint.Section05

/-- Actual manuscript density (5.1), on (0,1)^2. -/
def beukers7Density (x y : ℝ) : ℝ :=
  (-Real.log (x * y)) ^ 5 / (720 * (1 - x * y))

/-- The two-variable moment in equation (5.2). -/
def beukers7Moment (r s : ℕ) : ℝ :=
  ∫ x in Set.Ioo (0 : ℝ) 1,
    ∫ y in Set.Ioo (0 : ℝ) 1,
      x ^ r * y ^ s * beukers7Density x y

/-- Entire printed Theorem 5.1 moment identity, not just a finite symbolic
matrix representation of the rational divided difference. -/
def theorem51ExactMoments : Prop :=
  (∀ r : ℕ,
    beukers7Moment r r =
      (riemannZeta (7 : ℂ)).re -
        (Zetahyperbolic.harmonicNumber 7 r : ℝ)) ∧
  (∀ r s : ℕ, r ≠ s →
    6 * ((r : ℝ) - (s : ℝ)) * beukers7Moment r s =
      (Zetahyperbolic.harmonicNumber 6 r : ℝ) -
        (Zetahyperbolic.harmonicNumber 6 s : ℝ))

/-- Missing analytic uniform Krein truncation control: it is quantified
for the same actual weight-seven moment matrix and *every* rational basis.
This is strictly stronger than checking a finite sample. Its validity and
constant must be audited against (5.4) before a proof is attempted. -/
def uniformTailBound : Prop :=
  ∀ {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ),
    ManuscriptChain.Extensions.WeightSevenTailBound c M

/-- Missing Theorem 5.2(3): positive and negative full-form
finite-dimensional subspaces for every dimension h. -/
def theorem52BothCones : Prop :=
  ∀ h : ℕ, 0 < h →
    (∃ K : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
      ManuscriptChain.Extensions.PositiveQForm
        (ManuscriptChain.Extensions.weightSevenGram c)) ∧
    (∃ K : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
      ManuscriptChain.Extensions.NegativeQForm
        (ManuscriptChain.Extensions.weightSevenGram c))

/-- Actual already-certified equation (5.5). -/
def evenPoleCancellation : Prop :=
  ∀ (k j : ℕ), 1 ≤ j →
    PaperChronology.Theorem5_4.evenPolePairValue k j =
      Polynomial.C (((j : ℚ) ^ (2 * k + 1))⁻¹)

theorem evenPoleCancellation_verified : evenPoleCancellation := by
  intro k j hj
  exact PaperChronology.Theorem5_4.evenPolePairValue_eq k j hj

/-- Unproved analytic closure tasks are separate from the proved pair identity. -/
def analyticClosureTargets : Prop :=
  theorem51ExactMoments ∧ uniformTailBound ∧ theorem52BothCones

end PaperBlueprint.Section05
