import PaperBlueprint.Inventory
import PaperBlueprint.Section02
import PaperBlueprint.Section03
import PaperBlueprint.Section04
import PaperBlueprint.Section05
import PaperBlueprint.Section06

/-!
# Whole-paper formalization blueprint — not a paper proof

51 numbered manuscript items: 46 proof-relevant items, four remarks and one
conjecture. 3.5 and 3.6 need corrected propositions. The finite arithmetic
Witness remains **unconstructed**. The Prop below is a roadmap of selected
actual mathematical closure targets, not an exported proved theorem.

The 51-item inventory contains all remaining theorem names and dependencies.
Source theorem names are NOT a proxy for PDF-level equivalence.
-/

namespace PaperBlueprint

/-- A selected strong closure contract, deliberately UNPROVED.
Passing a Blueprint source through Lean checks elaboration ONLY. -/
def selectedMathematicalClosure : Prop :=
  Section03.theorem33Full ∧
  Section03.allOrderActualTuran ∧
  Section04.arithmeticClosureTargets ∧
  Section05.analyticClosureTargets ∧
  Section06.selectedArithmeticTargets

/-- The currently available generator statements are actually proved. -/
theorem checkedSection2FiniteSpine :
    Section02.currentPullback ∧
    Section02.currentReflectionAndDifference :=
  Section02.provedFiniteDomainSpine

/-- The simple-pole cancellation from Section 5 is actually proved. -/
theorem checkedSection5EvenPole : Section05.evenPoleCancellation :=
  Section05.evenPoleCancellation_verified

/-- An effective witness implies Theorem 4.4, but existence is not proved. -/
theorem checkedConditionalTheorem44 :
    Section04.effectiveWitnessExists → Section04.theorem44Unconditional :=
  Section04.theorem44_of_effectiveWitness

end PaperBlueprint

#print axioms PaperBlueprint.checkedSection2FiniteSpine
#print axioms PaperBlueprint.checkedSection5EvenPole
#print axioms PaperBlueprint.checkedConditionalTheorem44
