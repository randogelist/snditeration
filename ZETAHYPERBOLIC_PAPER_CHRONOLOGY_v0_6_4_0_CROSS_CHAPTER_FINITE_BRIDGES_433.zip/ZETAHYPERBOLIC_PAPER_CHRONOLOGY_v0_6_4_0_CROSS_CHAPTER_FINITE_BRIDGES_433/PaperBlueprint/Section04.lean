import PaperBlueprint.Inventory
import PAPER_WITNESS_ONLY

/-!
# Section 4 — arithmetic targets, with the Witness boundary visible

Unlike the manuscript's unconditional conclusion, the current theorem
in PAPER_WITNESS_ONLY requires an unconstructed arithmetic+spectral witness.
We restate the UNCONDITIONAL printed target as a Prop, and separately prove
the already-available downstream implication from a Witness's existence.
No hidden estimate or oracle is introduced.
-/

noncomputable section

namespace PaperBlueprint.Section04
open ManuscriptChain

def zeta5 : ℝ := (riemannZeta (5 : ℂ)).re
def zeta3 : ℝ := (riemannZeta (3 : ℂ)).re

/-- Full arithmetic certificate is not constructed. This records its
mathematical existence, not a finite terminating checker. -/
def effectiveWitnessExists : Prop := Nonempty PaperWitness.EffectiveWitness

/-- Literal unconditional endpoint of PDF Theorem 4.4. -/
def theorem44Unconditional : Prop :=
  Irrational zeta5 ∧
    ∃ b0 : ℕ, ∀ (a : ℤ) (b : ℕ), 0 < b → b0 ≤ b →
      1 / (b : ℝ) ^ (25687 : ℕ) <
        |zeta5 - (a : ℝ) / (b : ℝ)|

/-- The existing downstream transfer genuinely proves this implication.
It does NOT establish `effectiveWitnessExists` by itself. -/
theorem theorem44_of_effectiveWitness :
    effectiveWitnessExists → theorem44Unconditional := by
  rintro ⟨w⟩
  refine ⟨?_, ?_⟩
  · exact PaperWitness.THEOREM_4_4_IRRATIONALITY w
  · refine ⟨MainChain.indexDenominatorThreshold
        w.arithmetic.normalization.onset, ?_⟩
    intro a b hb hlarge
    exact PaperWitness.THEOREM_4_4_MEASURE_25687 w a b hb hlarge

/-- PDF Theorem 4.5: all permitted b*zeta5+a*zeta3 linear forms,
including the quantitative exponent. Currently an unproved target. -/
def theorem45Unconditional : Prop :=
  ∀ (a b : ℤ), 0 < b →
    (a : ℝ) < Real.pi ^ 2 / 3 * (b : ℝ) →
    Irrational ((b : ℝ) * zeta5 + (a : ℝ) * zeta3) ∧
    ∃ q0 : ℕ, ∀ (c : ℤ) (q : ℕ), 0 < q → q0 ≤ q →
      1 / (q : ℝ) ^ (25687 : ℕ) <
        |(b : ℝ) * zeta5 + (a : ℝ) * zeta3 - (c : ℝ) / (q : ℝ)|

/-- Intended final interface after the missing 4.1--4.8 algebraic,
archimedean and p-adic bridges have been proved. -/
def arithmeticClosureTargets : Prop :=
  theorem44Unconditional ∧ theorem45Unconditional

end PaperBlueprint.Section04
