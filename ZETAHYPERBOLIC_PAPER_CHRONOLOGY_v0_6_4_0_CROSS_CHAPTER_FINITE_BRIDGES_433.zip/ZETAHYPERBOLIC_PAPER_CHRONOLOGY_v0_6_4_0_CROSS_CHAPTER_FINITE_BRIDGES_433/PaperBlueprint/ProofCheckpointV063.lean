import PaperBlueprint.ParagraphCheckpoint
import Theorem_3_8_Actual_Pole_Kernel_Determinant_Mass
import Theorem_3_8_Actual_Pole_Kernel_Real_Argument
import Theorem_4_1_Actual_Rational_Root_Exclusion
import Mathlib.Tactic

/-!
# Paragraph proof checkpoint v0.6.3

This file PROMOTES three formerly typed-only paragraph statements
(3.8 cyclic determinant, 3.8 zero locus, 4.1 finite local gap) into
THEOREMS, by reusing unconditional proof modules that the user's
native Lean compiler verified in v0.6.2.2.

The 51-item inventory and 18 typed paragraph anchors stay unchanged,
thereby preserving all previous PASS fingerprints. This separate file
is the versioned proof-status checkpoint.

Only the exact six targets below are counted as certified clauses;
the remaining paper sections and all arithmetical witness-existence
goals are NOT proved by this checkpoint.
-/

noncomputable section
open scoped BigOperators

namespace PaperBlueprint.ProofCheckpointV063
open PaperBlueprint.ParagraphCheckpoint
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualCyclicKernel
open PaperChronology.Theorem3_8.ActualZeroLocus
open PaperChronology.Theorem4_1.ActualKernelSeparation

/-- PDF 3.8: formerly typed-only, now a checked theorem. -/
theorem section38_cyclic_determinant_proved : cyclicPoleKernelTarget := by
  intro s p hs t
  exact actual_pole_kernel_cyclic_det s p hs t

/-- PDF 3.8: formerly typed-only, now a checked theorem. -/
theorem section38_exact_zero_locus_proved : poleKernelZeroTarget := by
  intro s p hs t
  exact actual_pencil_root_iff_kernel_zero s p hs t

/-- PDF 4.1: finite witness-free gap, not the K-uniform exponential bound. -/
theorem section41_finite_gap_proved : finiteKernelGapTarget := by
  intro s p hs
  exact actual_pole_kernel_zero_free s p hs

/-- Exactly six printed paragraph clauses have direct formal proof
support: two generator-level clauses in §2, one even-pole in §5, and
the three promoted §3.8/§4.1 spectral clauses. -/
theorem six_paragraph_clauses_with_proofs :
    PaperBlueprint.Section02.currentPullback ∧
    PaperBlueprint.Section02.currentReflectionAndDifference ∧
    PaperBlueprint.Section05.evenPoleCancellation ∧
    cyclicPoleKernelTarget ∧
    poleKernelZeroTarget ∧
    finiteKernelGapTarget := by
  exact ⟨PaperBlueprint.checkedSection2FiniteSpine.1,
    PaperBlueprint.checkedSection2FiniteSpine.2,
    PaperBlueprint.checkedSection5EvenPole,
    section38_cyclic_determinant_proved,
    section38_exact_zero_locus_proved,
    section41_finite_gap_proved⟩

/-- The arithmetic endpoint remains explicitly conditional on a witness;
this is a proven implication, NOT a seventh unconditional paragraph. -/
theorem witness_required_for_theorem44 :
    PaperBlueprint.Section04.effectiveWitnessExists →
    PaperBlueprint.Section04.theorem44Unconditional :=
  PaperBlueprint.checkedConditionalTheorem44

end PaperBlueprint.ProofCheckpointV063

#print axioms PaperBlueprint.ProofCheckpointV063.six_paragraph_clauses_with_proofs
#print axioms PaperBlueprint.ProofCheckpointV063.witness_required_for_theorem44
