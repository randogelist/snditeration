import PaperBlueprint.All
import Theorem_3_8_Actual_Christoffel_Darboux_Kernel

/-!
# Source paragraph integration checkpoint (not a full-paper proof)

A checkpoint entry means: a mathematical CLAUSE corresponding to a
paragraph of the printed manuscript has a well-typed Lean proposition.
It does not mean that proposition was proved or that every paragraph
in the corresponding numbered theorem has been formalized.

The chronological Inventory records all 51 numbered PDF items; this
file binds an initial finer-grained selection of printed subclaims to
actual Lean Prop terms. Previously user-certified fragments are
linked below by theorem applications (not assumed as axioms).

Levels are descriptive only. Only theorem declarations containing `by`
or an already kernel-checked theorem identifier represent proofs.
The definitive status is user-native Lean 4.33 PASS + axiom inspection.
-/

noncomputable section
open scoped BigOperators

namespace PaperBlueprint.ParagraphCheckpoint
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel

inductive Level where
  | typedUnproved
  | provedFragment
  | conditionalTransfer
  | needsCorrection
  deriving Repr, DecidableEq

structure Anchor where
  pdfItem : String
  pdfPage : Nat
  paragraphClause : String
  target : Prop
  status : Level
  leanAnchor : String

/-- An *unproved*, fully typed finite-dimensional PDF 3.8 spectral identity.
The theorem in Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean
is the separate proof attempt and is NOT imported here. -/
def cyclicPoleKernelTarget : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∀ t : ℝ,
      (1 + t • ((Gram.gram s p)⁻¹ * derivativeMatrix s p)).det =
        (1 + t • (Matrix.diagonal (poleWeight s p) *
          poleKernel s p)).det

/-- Unproved typed root-identity segment, not a uniform gap bound. -/
def poleKernelZeroTarget : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∀ t : ℝ,
      (Gram.actualPencil s p).detPolynomial.eval
        ((riemannZeta (s : ℂ)).re + t) = 0 ↔
      (1 + t • (Matrix.diagonal (poleWeight s p) *
        poleKernel s p)).det = 0

/-- Unproved typed Section 4 finite kernel-separation claim. -/
def finiteKernelGapTarget : Prop :=
  ∀ (s : ℝ) (p : ManuscriptChain.Real.Parameters), 1 < s →
    ∃ B : ℝ, 0 < B ∧ ∀ t : ℝ, |t| < 1 / B →
      (1 + t • (Matrix.diagonal (poleWeight s p) *
        poleKernel s p)).det ≠ 0

/-- An initial per-paragraph-clause index, with source PDF page references.
`target : Prop` elaborates without granting a proof. Do not count
`typedUnproved` as theorem coverage. -/
def typedParagraphs : List Anchor := [
  { pdfItem := "2.2", pdfPage := 4,
    paragraphClause := "Pole/monomial pullback on verified generators",
    target := Section02.currentPullback, status := .provedFragment,
    leanAnchor := "PaperBlueprint.Section02.currentPullback" },
  { pdfItem := "2.3", pdfPage := 5,
    paragraphClause := "Reflection and difference on verified generators",
    target := Section02.currentReflectionAndDifference, status := .provedFragment,
    leanAnchor := "PaperBlueprint.Section02.currentReflectionAndDifference" },
  { pdfItem := "3.3", pdfPage := 8,
    paragraphClause := "Strict total positivity for nonprincipal real-s minors",
    target := Section03.allNonprincipalMinors, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section03.allNonprincipalMinors" },
  { pdfItem := "3.3", pdfPage := 8,
    paragraphClause := "Carleman/Stieltjes moment determinacy",
    target := Section03.stieltjesDeterminate, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section03.stieltjesDeterminate" },
  { pdfItem := "3.3", pdfPage := 9,
    paragraphClause := "Full actual spectral inertia and signed root multiplicities",
    target := Section03.actualSpectralSignature, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section03.actualSpectralSignature" },
  { pdfItem := "3.7", pdfPage := 11,
    paragraphClause := "Higher derivative real-rooted Turanian inequalities",
    target := Section03.allOrderActualTuran, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section03.allOrderActualTuran" },
  { pdfItem := "3.8", pdfPage := 12,
    paragraphClause := "Cyclic determinant identity for the actual pole kernel",
    target := cyclicPoleKernelTarget, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.ParagraphCheckpoint.cyclicPoleKernelTarget" },
  { pdfItem := "3.8", pdfPage := 12,
    paragraphClause := "Equivalence of actual pencil and pole-kernel zero loci",
    target := poleKernelZeroTarget, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.ParagraphCheckpoint.poleKernelZeroTarget" },
  { pdfItem := "4.1", pdfPage := 14,
    paragraphClause := "Witness-free finite local pole-kernel spectral gap",
    target := finiteKernelGapTarget, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.ParagraphCheckpoint.finiteKernelGapTarget" },
  { pdfItem := "4.4", pdfPage := 16,
    paragraphClause := "Existence of fully quantitative arithmetic and spectral witness",
    target := Section04.effectiveWitnessExists, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section04.effectiveWitnessExists" },
  { pdfItem := "4.4", pdfPage := 16,
    paragraphClause := "Unconditional zeta5 irrationality and measure exponent 25687",
    target := Section04.theorem44Unconditional, status := .conditionalTransfer,
    leanAnchor := "PaperBlueprint.Section04.theorem44Unconditional" },
  { pdfItem := "4.5", pdfPage := 18,
    paragraphClause := "Joint zeta5/zeta3 linear forms with effective measure",
    target := Section04.theorem45Unconditional, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section04.theorem45Unconditional" },
  { pdfItem := "5.1", pdfPage := 22,
    paragraphClause := "Exact diagonal and offdiagonal double Beukers moments",
    target := Section05.theorem51ExactMoments, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section05.theorem51ExactMoments" },
  { pdfItem := "5.2", pdfPage := 23,
    paragraphClause := "Uniform control of the infinitely many omitted Krein modes",
    target := Section05.uniformTailBound, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section05.uniformTailBound" },
  { pdfItem := "5.2", pdfPage := 23,
    paragraphClause := "Actual positive/negative rational polynomial cones",
    target := Section05.theorem52BothCones, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section05.theorem52BothCones" },
  { pdfItem := "5.4", pdfPage := 25,
    paragraphClause := "Even simple-pole pair cancellation",
    target := Section05.evenPoleCancellation, status := .provedFragment,
    leanAnchor := "PaperBlueprint.Section05.evenPoleCancellation" },
  { pdfItem := "6.8", pdfPage := 38,
    paragraphClause := "Three term zeta3/zeta5 cone nonvanishing",
    target := Section06.theorem68ThreeTermCone, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section06.theorem68ThreeTermCone" },
  { pdfItem := "6.15", pdfPage := 46,
    paragraphClause := "All odd beta values transcendental",
    target := Section06.theorem615OddBetaTranscendence, status := .typedUnproved,
    leanAnchor := "PaperBlueprint.Section06.theorem615OddBetaTranscendence" }
]

/-- Exactly the already verified §2 generator-level implications. -/
theorem section2_fragments_proved :
    Section02.currentPullback ∧ Section02.currentReflectionAndDifference :=
  PaperBlueprint.checkedSection2FiniteSpine

/-- Exact §5.4 simple-pole endpoint (does not claim all §5). -/
theorem section5_even_pole_proved : Section05.evenPoleCancellation :=
  PaperBlueprint.checkedSection5EvenPole

/-- §4.4 is proved ONLY as a conditional transfer. -/
theorem section4_witness_conditional :
    Section04.effectiveWitnessExists → Section04.theorem44Unconditional :=
  PaperBlueprint.checkedConditionalTheorem44

end PaperBlueprint.ParagraphCheckpoint

#print axioms PaperBlueprint.ParagraphCheckpoint.section2_fragments_proved
#print axioms PaperBlueprint.ParagraphCheckpoint.section5_even_pole_proved
#print axioms PaperBlueprint.ParagraphCheckpoint.section4_witness_conditional
