# ZETAHYPERBOLIC vs the manuscript: kernel-verified checkpoint v0.6.3 (24 October 2026)

**Source of assessment:** the uploaded 52-page *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, 21 October 2026; all 51 numbered manuscript items in `PDF_THEOREM_MATRIX_20261024.csv`; exact source files in this archive; and the **user's reported Windows native Lean 4.33.0 PASS**, including `BUILD_COMPILED=5`, `BUILD_FROZEN_REUSED=127`, and `RESULT=PASS` for v0.6.3.0. This report does *not* perform a new Lean compilation. All 132 ordered Lean source files are preserved byte-for-byte.

## A three-level verdict (do not collapse them)

| Layer | What can be asserted now | What it does NOT establish |
|---|---|---|
| **Compiler/source certification** | **132/132 ordered source modules PASS** on the user's compiler (127 frozen and 5 newly compiled in reported v0.6.3.0 run); there are 9 `PaperBlueprint/` modules and 123 other source modules. | 132/132 is NOT 100% manuscript coverage. Module number and theorem count are not equivalent. |
| **Paragraph-level integration** | **51/51 numbered items indexed; 18 selected clauses have typed Lean `Prop` anchors; 6 of these specific clauses have checked theorem support.** The three newest proof promotions are §3.8 cyclic determinant, §3.8 actual zero-locus equality, §4.1 finite local gap. | 18 is NOT the number of all PDF paragraphs; typed does not mean proven. Three of the six already proven clauses are generator- or simple-pole fragments. |
| **Exact manuscript statement alignment** | **6 near-complete (C), 18 partial (P), 2 printed statements requiring corrections (X), 20 open (O)** among **46 proof-relevant numbered items**, plus four remarks and one explicit conjecture. These statuses are still conservative static statement audits, **not** final item-by-item equivalence certificates. | There is NO reliable basis to declare the full 52-page paper proved or the central ζ(5) result unconditional. |

**Best headline:** We have a *verified, substantial algebraic and finite spectral core*, increasingly anchored to the actual Gram/pole-kernel definitions, but the paper's deepest **quantitative Archimedean and p-adic estimates are not closed**. The previous informal 20–30% proof-effort estimate remains plausible but subjective; the present source PASS is stronger, not a demonstrated jump to 50%+ paper completion.

## Paper-by-paper section accounting

| Chapter | Printed proof items | Near-complete C | Partial P | Correction X | Open O | Most important advance / missing gate |
|---|---:|---:|---:|---:|---:|---|
| **§2** algebra and functionals | 5 | **3** | 2 | 0 | 0 | Canonical invariance, rational pole Lagrange diagonalization. Remaining: full arbitrary rational-function domains for 2.2–2.3. |
| **§3** positive Hankel spectrum | 9 | **2** | 5 | 2 | 0 | Principal minors, diagonal signs/inertia, corrected finite moment bounds, Turán family, actual CD pole-kernel determinant and zero locus. Missing: nonprincipal total positivity + Carleman; exact full inertia and nested interlacing; full-length valid J-fraction, 3.7 Newton coefficient cases, 3.8 parameter derivative, 3.9 character extension. |
| **§4** Diophantine/height | 8 | **0** | 2 | 0 | 6 | Transfer machinery and actual finite local root-free disk are proved, *not* the uniform rate. Main gaps: integer-normalization/prime-sum estimate, exp(-K²/2500) bound, spectral norm exp(11.411K), 25687 bound, asymptotic height/cluster results. |
| **§5** two-variable/ζ(7) | 6 | **1** | 2 | 0 | 3 | §5.4 simple-pole cancellation is close; exact two-variable integral, infinite Krein negative tail, rational sign cones, p-adic/prime bounds are open. |
| **§6** extensions | 18 | **0** | 7 | 0 | 11 | Finite algebraic, Hermite and compatibility fragments; independent analytic, q-/p-adic and multiweight global transfers remain to be proved. |
| **TOTAL** | **46** | **6** | **18** | **2** | **20** | Conjecture 4.11 and four remarks are excluded from the 46 proof obligations. |

This preserves the existing 51-row matrix's **C/P/X/O classification**, because the recent v0.6.2–v0.6.3 advances finish important *subclaims* of already-partial items 3.8 and 4.1, not every clause of those whole printed items. Do **not** upgrade their C/P status merely because the source filename includes the theorem number.

## Strongest independently proved (user-compiled) mathematics to cite

1. **Section 2 algebraic spine:** finite rational functional generators, pullback/reflection fragments, basis invariance, negative-square-pole Lagrange factorization of the derivative pencil.
2. **Section 3 qualitative reality and sign structure:** real-s positive Gram moment construction; actual principal-minor positivity; leading determinant parity; alternating pole-weight signs and their exact finite counts; real roots for the appropriate positive Gram/symmetric-pencil statement. These are finite/qualitative statements and do not imply all nonprincipal minors or Carleman uniqueness.
3. **Section 3.6–3.7 corrected finite consequences:** finite-atomic reciprocal-root growth bounds, real-rooted product Turánians, and primitive-scale transfer, without yet asserting all printed Newton/log-concavity equality clauses.
4. **Section 3.8 actually connected kernel:** cyclic determinant identity for the real-s genuine Gram/pole Vandermonde, weighted pole-kernel determinant/nonvanishing identity, equivalent shifted zero loci; root-free region with a finite strictly positive radius.
5. **Section 4.1 actual rational-point exclusion:** every real (hence rational) x inside that finite local region is not a root. The radius depends on the chosen finite pencil; this is *not* the paper's K-uniform `exp(-11.411 K)` gap.
6. **Section 5.4:** simple even-pole pair cancellation. This is not the 2D ζ(7) measure/cone theorem.

**Six-clause ledger status:** §2.2 generator pullback; §2.3 generator reflection/difference; §3.8 cyclic pole-kernel determinant; §3.8 equivalence of zero loci; §4.1 finite local separation; §5.4 simple-pole cancellation. All other twelve of the eighteen selected typed paragraph anchors remain unproved or conditional by design.

## What remains between today's checkpoint and the PDF's central conclusion

**Formal pipeline:** proved actual finite Gram/pole-kernel identities and a local root-free neighborhood; still missing unconditional integer-polynomial normalization with quadratic decay `exp(-K^2/2500)` and the uniform spectral bound `||B_K|| <= exp(11.411 K)`; their conjunction would activate the existing *conditional* Lean implication to the exponent `25687`.

The user-checked `PaperWitness.Witness` and `PaperWitness.EffectiveWitness` structures are legitimate *conditional* Lean theorem inputs, **not constructions of finite verifiable certificates**. A single inhabited `EffectiveWitness` is a useful interface, but it currently bundles universal estimates quantified over unbounded K; it is **not** a finite object that a terminating checker can verify without an already-proved universal bound. Neither the arbitrary odd-ζ family nor Sections 5–6 follow automatically from this ζ(5) input.

## Mathematical caveats in the printed manuscript

- **Corollary 3.5:** the published full J-fraction has a normalization/Schur issue already seen at rank one; the checked corrected 2×2 Schur fraction is not a proof of the printed full formula.
- **Corollary 3.6:** a finite atomic moment measure has rank at most its support size, contradicting any *all-orders strict positivity* claim; a reciprocal-root moment inequality is reversed in print. Lean proves corrected finite formulas.
- **Theorem 5.2(3):** finite annihilation of negative Krein modes cannot by itself control the infinite negative tail. Its unproved tail estimate is an actual mathematical frontier.
- **Remark 4.10:** zero pinching alone does not certify a nonanalytic free-energy limit/phase transition.
- **Conjecture 4.11:** explicitly conjectural, not to be counted as a proved theorem.

## What I would certify as the next checkpoint, not yet achieved

1. **Independent source-to-PDF theorem type equality:** each C item supplied with its exact printed quantifiers/domains/normalization and a matching Lean theorem; record proof and assumption audit. Current `C` is *near*, not *identical*.
2. **Finish §3.3's three unproved typed clauses** (all nonprincipal continuous minors, Carleman, actual inertia multiplicity transfer) and §3.8's analytic Jacobi derivative identity. This would upgrade a substantial mathematical cluster beyond finite matrix manipulations.
3. **Make an unconditional finite witness checker**: a finite certificate structure, a decidable/terminating checker, an independently proved universal propagation theorem, and a proof that acceptance yields the complete unconditional downstream theorem chain. Current `EffectiveWitness` is **not yet that checker**.
4. **Quantitative §4 closure**, then independent §5–§6 bridges. Before this, do not state unconditional ζ(5) irrationality or 25687 exponent as a verified consequence of this project.

## Verification boundary and package integrity

- The user's last pasted compilation output is authoritative for **132/132 ordered modules** and `RESULT=PASS`; this assistant has not run Lean locally.
- The `PaperBlueprint` files use `def : Prop` for outstanding goals. Elaborating these declarations does not discharge them. The 6-clause aggregate is a real proved conjunction of *just those* clauses.
- This v0.6.3.1 archive changes **no `.lean` source**, dependency map, or order file. The `run.cmd proofs` reuses all 132 frozen artifacts on the same user compiler/cache; `run.cmd full` remains an explicit forced rebuild. Only this updated assessment, CSV snapshots and the runner's informational banner change.
- Source hash manifest `AUDIT_SOURCE_SHA256_v0631.json` makes preservation of the exact 132 ordered sources independently checkable.

**Strongest honest claim:** `132/132` user-native Lean compilation and selected axiom audits passed, a material true finite spectral theory is formally established, and precise integration targets cover all numbered sections; **full proof coverage and the quantitative arithmetic endgame remain open**.
