# v0.4.2.0 — Theorem 3.3 / 3.4 finite chronology

User-certified 89/89 source modules are preserved byte-for-byte. Exactly three new `.lean` modules were appended; FASTCORE build remains pass-once and uses the user's Windows Lean 4.33 compiler.

1. **Theorem 3.3 finite model**: arbitrary-index 2×2 minors of the three-atom moment sequence factor exactly into three weighted Vandermonde products and are strictly positive for positive, strictly ordered nodes, arbitrary positive row/column gaps and arbitrary shift. This is stronger than the earlier consecutive-minor positivity.
2. **Theorem 3.4 symbolic algebra**: exact shifted Jacobi/Dodgson identities for orders three and four for any real moment sequence, with nonpositive and strict-negative minor-root conclusions.
3. **Chronological aggregation**: all new results are available from `PAPER_CHRONOLOGICAL_EXTENSION_3`.

**Not claimed:** full strict total positivity for every minor of the actual infinite continuous Hankel moment measure, arbitrary-order Jacobi identity, or full-paper formalization. No witness is used in these finite algebraic results. No local Lean compilation is performed.
