import Theorem_3_4_Shifted_Dodgson_Jacobi
import Mathlib.Tactic

/-!
# Corrected Corollary 3.5: the exact Schur complement

The printed continued fraction omits the Gram normalization and puts
spectral slope entries where `1+t*eigenvalue` is required. The precise
order-two Schur/J-fraction identity below is an unconditional polynomial
matrix calculation, valid for every symmetric affine 2x2 pencil.
It is NOT an assertion of the false printed equation (3.6) in all sizes.
-/

noncomputable section
namespace PaperChronology.Corollary3_5.CorrectedSchur

/-- Determinant of a symmetric two-by-two matrix. -/
def det2 (a b c : ℝ) : ℝ := a * c - b ^ 2

/-- The determinant is the pivot times its Schur complement. -/
theorem det2_schur_factor (a b c : ℝ) (ha : a ≠ 0) :
    det2 a b c = a * (c - b ^ 2 / a) := by
  unfold det2
  field_simp [ha] <;> ring

/-- Exact finite continued-fraction identity for the 2x2 pencil;
all denominators are explicitly nonzero. -/
theorem ratio2_corrected (a b c : ℝ)
    (ha : a ≠ 0) (hd : det2 a b c ≠ 0) :
    a / det2 a b c = 1 / (c - b ^ 2 / a) := by
  have hschur : c - b ^ 2 / a ≠ 0 := by
    intro hz
    have hfactor := det2_schur_factor a b c ha
    rw [hz, mul_zero] at hfactor
    exact hd hfactor
  rw [det2_schur_factor a b c ha]
  field_simp [ha, hschur] <;> ring

/-- Entrywise affine coefficients of the manuscript's 2x2 pencil. -/
def pivot (t g11 m11 : ℝ) : ℝ := g11 + t * m11
def offdiag (t g12 m12 : ℝ) : ℝ := g12 + t * m12
def corner (t g22 m22 : ℝ) : ℝ := g22 + t * m22

/-- The VALID 2x2 J-fraction has the affine pivot `G+tM`, not `B+tI`. -/
theorem affine_pencil_ratio (t g11 g12 g22 m11 m12 m22 : ℝ)
    (ha : pivot t g11 m11 ≠ 0)
    (hd : det2 (pivot t g11 m11)
      (offdiag t g12 m12) (corner t g22 m22) ≠ 0) :
    pivot t g11 m11 /
      det2 (pivot t g11 m11) (offdiag t g12 m12) (corner t g22 m22) =
    1 / (corner t g22 m22 -
      (offdiag t g12 m12) ^ 2 / pivot t g11 m11) :=
  ratio2_corrected _ _ _ ha hd

/-- At the center, positive Gram determinants make the corrected scalar
continued fraction valid and strictly positive. -/
theorem center_ratio_positive (a b c : ℝ)
    (ha : 0 < a) (hdet : 0 < det2 a b c) :
    0 < a / det2 a b c ∧
    a / det2 a b c = 1 / (c - b ^ 2 / a) := by
  exact ⟨div_pos ha hdet,
    ratio2_corrected a b c (ne_of_gt ha) (ne_of_gt hdet)⟩

end PaperChronology.Corollary3_5.CorrectedSchur

#print axioms PaperChronology.Corollary3_5.CorrectedSchur.ratio2_corrected
#print axioms PaperChronology.Corollary3_5.CorrectedSchur.affine_pencil_ratio
