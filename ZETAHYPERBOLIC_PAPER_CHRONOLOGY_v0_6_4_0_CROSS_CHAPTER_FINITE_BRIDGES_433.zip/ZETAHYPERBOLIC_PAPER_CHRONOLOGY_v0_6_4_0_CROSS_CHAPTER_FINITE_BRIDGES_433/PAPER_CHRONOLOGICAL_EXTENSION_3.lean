import PAPER_CHRONOLOGICAL_EXTENSION_2
import Theorem_3_3_General_Three_Atom_Minors
import Theorem_3_4_Shifted_Dodgson_Jacobi

/-!
# Chronological Section 3 extension — generalized finite Hankel minors

Certified old modules are unchanged. New mathematical content: strictly
positive *all* 2×2 minors for a three-point positive discrete measure,
with arbitrary row/column gaps; strict log-convexity; translated universal
order-three and order-four Jacobi identities and root sign consequences.

These are not identified with the exact continuous pencil's arbitrarily
large minors. This package does not replace the manuscript's one-witness
arithmetic endpoint and does not introduce any new axiom.
-/

namespace PaperChronology

/-- Finite-atomic model of PDF Theorem 3.3, for every 2×2 Hankel minor. -/
theorem paper_theorem_3_3_general_three_atom_minor
    (a b c u v w : ℝ) (n i j : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (huv : u < v) (hvw : v < w)
    (hi : 0 < i) (hj : 0 < j) :
    0 < Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 0) *
          Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + (i + j)) -
        Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + i) *
          Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + j) :=
  Theorem3_3.GeneralAtomic.three_atom_general_minor_pos
    a b c u v w n i j ha hb hc hu huv hvw hi hj

/-- Universal translated order-four Dodgson identity of PDF Theorem 3.4. -/
theorem paper_theorem_3_4_jacobi_four_all_shifts (μ : ℕ → ℝ) (n : ℕ) :
    Theorem3_4.Dodgson4.hankelDet4
      (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
      (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) *
      (μ (n + 2) * μ (n + 4) - (μ (n + 3)) ^ 2) =
      Theorem3_4.Dodgson3.det3
        (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) *
      Theorem3_4.Dodgson3.det3
        (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) -
      (Theorem3_4.Dodgson3.det3
        (μ (n + 1)) (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) (μ (n + 5))) ^ 2 :=
  Theorem3_4.ShiftedDodgson.jacobi_four_all_shifts μ n

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_general_three_atom_minor
#print axioms PaperChronology.paper_theorem_3_4_jacobi_four_all_shifts
