# Paper order — theorem-by-theorem Lean contract

**Source:** attached 52-page PDF, Prince Anand, 21 October 2026.
**Goal:** compile the real theorem chain in printed order. The single external mathematical input for the eventual Diophantine closure should be `Witness`; separate independent estimates cannot be concealed inside it.
**Scope in v0.3.0:** expose all five Section 2 items at their finite algebra/partial-fraction representation level, plus Theorem 3.1 first. An exact `RatFunc` substitution theorem for Lemma 2.2 still needs its own representation bridge. Neither the whole PDF nor the new edition has been compiler certified yet. **User compiler only.**

| Sequence | PDF item | Coverage as of this source edition | Existing or new source |
|---:|---|---|---|
| 1 | **Definition 2.1** — Order-s rational moment functional | Definition checked | `Zetahyperbolic.Section2Checked; Definition_2_1...` |
| 2 | **Lemma 2.2** — Pullback identity | Finite decomposition/generator source theorem; USER COMPILER PENDING | `Lemma_2_2_Pullback_Identity.lean` |
| 3 | **Lemma 2.3** — Reflection and difference identities | Generator source theorem; USER COMPILER PENDING | `Lemma_2_3_Reflection_And_Difference_Identities.lean` |
| 4 | **Theorem 2.4** — Canonical basis invariance | Existing source proof; user rebuild pending | `Theorem_2_4_Canonical_Basis_Invariance.lean` |
| 5 | **Theorem 2.5** — Lagrange pole diagonalization | Existing source proof plus new exact degree endpoint | `Theorem_2_5_Lagrange_Pole_Diagonalization.lean` |
| 6 | **Theorem 3.1** — Universal hyperbolicity and zero-free disk | Existing unconditional source proof; user rebuild pending | `PAPER_SECTION_03.lean; MAIN_CHAIN_ASSEMBLED.lean` |
| 7 | **Proposition 3.2** — Continuous hyperbolic pencil for all real s > 1 | PARTIAL: explicit real-s slope, nonzero determinant, root factorization if actual A(s) is positive; infinite real-s integral missing | `Proposition_3_2_Continuous_Real_Weight_Pencil.lean` |
| 8 | **Theorem 3.3** — Total positivity, leading sign, universal signature | PARTIAL: eigenvalue-sign / root-side equivalences proved; Carleman, all minors, residue signs and counts open | `Theorem_3_3_Spectral_Root_Sign_Correspondence.lean` |
| 9 | **Theorem 3.4** — Root interlacing and Dodgson condensation | OPEN: Cauchy interlacing on compatible Cholesky blocks | `Section 3 targets` |
| 10 | **Corollary 3.5** — Stieltjes J-fraction from interlacing roots | PRINTED FORMULA FALSE; requires correction | `PAPER_COUNTEREXAMPLES.lean` |
| 11 | **Corollary 3.6** — Stieltjes reciprocal-root power sums | PRINTED STRICT POSITIVITY/RATIO FALSE; correction needed | `PAPER_COUNTEREXAMPLES.lean` |
| 12 | **Theorem 3.7** — Turanian non-negativity and Newton log-concavity | OPEN: full coefficients and strictness | `Section 3 targets` |
| 13 | **Theorem 3.8** — Christoffel-Darboux pole representation and Jacobi derivative | OPEN: kernel analytic derivative | `Section 3 targets` |
| 14 | **Theorem 3.9** — Hurwitz and Dirichlet Hankel hyperbolicity | PARTIAL: finite Fekete-positivity lemma | `Zetahyperbolic/Section3Elementary.lean` |
| 15 | **Remark 3.10** — Non-classicality of the Hankel family | NEEDS MATHEMATICAL AUDIT; not theorem | `Not compiled` |
| 16 | **Theorem 4.1** — Spectral irrationality measure criterion | EXISTING conditional transfer (not unconditional ξ statement) | `Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean` |
| 17 | **Proposition 4.2** — Transfer for algebraic approximations | OPEN: resultant and height asymptotics | `Section 4 targets` |
| 18 | **Proposition 4.3** — Ultrametric zero-free disk over Qp | OPEN: generic p-adic polynomial lemma | `Section 4 targets` |
| 19 | **Theorem 4.4** — Sharp spectral bound and effective ζ(5) measure | CONDITIONAL witness+quantitative norm; not one proved estimate | `PAPER_WITNESS_ONLY.lean` |
| 20 | **Theorem 4.5** — Irrationality/measure for b ζ(5)+a ζ(3) | OPEN: combined weight and p-adic normalization | `Section 4 targets` |
| 21 | **Theorem 4.6** — Two-sided determinant and coefficient height bounds | OPEN: quantitative asymptotics | `Section 4 targets` |
| 22 | **Theorem 4.7** — Root collapse and separation | OPEN: depends on Theorem 4.6 and height data | `Section 4 targets` |
| 23 | **Proposition 4.8** — Rational-root exclusion and cluster-factor degree | OPEN: depends on 4.4 and 4.7 | `Section 4 targets` |
| 24 | **Remark 4.9** — Spectral bounds and variational conjecture | OPEN: analytic bounds; not numbered theorem | `Not compiled` |
| 25 | **Remark 4.10** — Lee-Yang phase transition | NOT JUSTIFIED by zero-clustering alone | `PAPER_CORRECTIONS.md` |
| 26 | **Conjecture 4.11** — Existence of variational limiting spectral exponent | OPEN CONJECTURE, not a theorem | `Not compiled` |
| 27 | **Theorem 5.1** — Two-variable Beukers measure for ζ(7) | PARTIAL: rational matrix algebra; missing integral realization | `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.lean` |
| 28 | **Theorem 5.2** — Dual hyperbolicity and Krein-space decomposition | PARTIAL: finite certificates; missing tail control | `Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil.lean` |
| 29 | **Proposition 5.3** — Two-variable beta(4) measure and dual pencil | OPEN | `Section 5 targets` |
| 30 | **Theorem 5.4** — Cancellation on x-even pole pairs | OPEN: follows τ reflection/difference once formulated for E_j | `Lemma_2_3_Reflection_And_Difference_Identities.lean` |
| 31 | **Remark 5.5** — Simple-pole-only scope | DOCUMENTED, not theorem | `Section 5 targets` |
| 32 | **Theorem 5.6** — Weight-seven prime-sum and pole-ordered refinement | OPEN: exact integrals and p-adic basis | `Section 5 targets` |
| 33 | **Theorem 5.7** — Double-pole Hankel for {1,ζ(5),ζ(6)} | OPEN: q-adic nonvanishing, valuation minors | `Section 5 targets` |
| 34 | **Theorem 6.1** — Divided-difference p-adic valuation obstruction | OPEN | `Section 6 targets` |
| 35 | **Theorem 6.2** — Simultaneous weight (6,7) Beukers functional | OPEN | `Section 6 targets` |
| 36 | **Theorem 6.3** — Unconditional q-adic nonvanishing + positive-cone | PARTIAL/conditional source only | `Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7.lean` |
| 37 | **Theorem 6.4** — Character-Vandermonde beta(4) cancellation | PARTIAL source, not paper-wide proof | `Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4.lean` |
| 38 | **Theorem 6.5** — Unconditional beta(4) q-adic nonvanishing | OPEN | `Section 6 targets` |
| 39 | **Theorem 6.6** — Generalized multi-weight positive-definite pencil | OPEN | `Section 6 targets` |
| 40 | **Theorem 6.7** — Universal multi-weight Beukers Krein decomposition | OPEN: tail issue | `Section 6 targets` |
| 41 | **Corollary 6.8** — Three-term linear-independence cone | OPEN: depends on 4.5 | `Section 6 targets` |
| 42 | **Theorem 6.9** — Triple-pole and multi-weight Hankel determinants | PARTIAL: finite Hermite repair | `Zetahyperbolic/Theorem_6_9_Triple_Pole_Hermite_Repair.lean` |
| 43 | **Theorem 6.10** — Universal potential-gap + vanishing derivative growth | PARTIAL: finite determinant identity | `Zetahyperbolic/Theorem_6_10_Finite_Determinant_Identity.lean` |
| 44 | **Theorem 6.11** — Distribution growth law / 2-adic quotient obstruction | OPEN | `Section 6 targets` |
| 45 | **Theorem 6.12** — Full-dimension sign-flip restoration | OPEN | `Section 6 targets` |
| 46 | **Theorem 6.13** — Central-factorial secant differential identity | OPEN | `Section 6 targets` |
| 47 | **Theorem 6.14** — Even-pole scaling and coupled pencils | OPEN | `Section 6 targets` |
| 48 | **Theorem 6.15** — Arithmetic transcendence / positive measure / rank-one | OPEN | `Section 6 targets` |
| 49 | **Theorem 6.16** — Generalized Zeta-Beta multi-weight pencil | PARTIAL: source interface | `Zeta5Merge/Theorem6_16.lean` |
| 50 | **Theorem 6.17** — Universal two-variable Zeta-Beta pencil/Krein | PARTIAL: source interface | `Zeta5Merge/Theorem6_17.lean` |
| 51 | **Theorem 6.18** — Principal-minor 2-adic integrality and heights | PARTIAL: source interface | `Zeta5Merge/Theorem6_18.lean` |

## Next proof milestone
1. Run the single incremental `run.cmd` with your existing Lean 4.33.0 compiler; unchanged already-certified modules will be reused.
2. Complete Proposition 3.2 by proving integrability and strictly positive Gram representation of the PDF's **actual** infinite real-s kernel `w_s`; the exact real-s pole slope is now constructed.
3. Prove Theorem 3.3 in three layers: Carleman/all-minor positivity, signed pole residues / precise signature counts, and manuscript specializations.
4. Proceed strictly in PDF order, correcting printed Corollaries 3.5 and 3.6 before downstream use.

## Proof integrity rule
An item is called complete only when its PDF-level conclusion is reached from definitions and earlier checked imports, with no `sorry`, `admit`, custom `axiom`, or an unproved parameter other than the explicitly registered future witness. Existing conditional modules are kept but **not** reclassified as theorems without proof.
