# FIX14 — pole sign squared positivity, Lean 4.33.0

`Theorem_3_3_Pole_Weight_Signs.lean` failed when `nlinarith` attempted to prove `0 < y ^ 2` from `y ≠ 0` and `sq_nonneg`. We replace both the rational `x` and `y` squared-positivity arguments with explicit total-order trichotomy. Positive or negative cases are discharged using `mul_pos` or `mul_pos_of_neg_of_neg`; zero contradicts nonzero. No new axioms, hypotheses, theorem claims or precompiled modules.

All other `.lean` source files unchanged from v0.3.9.7. No local Lean compilation. Keep pass-once frozen cache and recompile changed source and invalidated dependents only.
