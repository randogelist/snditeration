# Section-by-section Lean structure: verdict on the proposed 5/5, 1/9, 0/9, 0/6, 0/18 table

**Verdict: Agree with the *classification architecture*, but not the numerical statuses as stated.** This addendum is an audit of the **exact printed PDF statements** relative to the v0.5.0.5 project, not a Lean build and not an unconditional certification of the manuscript.

## Consistent theorem inventory

The PDF has **46 numbered proof-relevant items**: section 2 has 5, section 3 has 9, section 4 has **8**, section 5 has 6, and section 6 has 18. There are **five additional** numbered non-theorem entries (four remarks and Conjecture 4.11), for **51** total. Section 4 has eight theorems/propositions, not nine, when remarks and conjectures are consistently excluded.

A strict source-to-PDF audit should use these statuses:

- **C = close to complete / substantially exact endpoint**, subject to a final line-by-line exact-definition and domain audit. This must **not** be represented as 100%-certified paper theorem until an exact statement audit succeeds.
- **P = partial:** genuinely checked mathematical results exist but one or more printed clauses are missing.
- **X = printed statement incorrect:** a corrected substitute or counterexample exists, not a proof of the literal PDF claim.
- **O = open:** no complete Lean proof of the printed item in this archive.

| Section | Numbered proof items | C (near complete) | P (partial) | X (requires correction) | O (open) | Specific adjustment to the proposed table |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| §2 Algebra | 5 | **3** | 2 | 0 | 0 | `5/5 fully formalized` is too strong: Lemmas 2.2 and 2.3 are checked on generators/finite presentations, not their whole asserted rational-function domain. |
| §3 Spectral | 9 | **2** | 5 | 2 | 0 | 3.1 and 3.2 are near complete; 3.3, 3.4, 3.7–3.9 remain partial; **3.5/3.6 must be corrected**, not simply treated as unfinished. |
| §4 Diophantine | **8** | **0** | 2 | 0 | 6 | 4.1 and 4.4 have substantial *conditional* transfer interfaces; neither constructs the needed arithmetic witness and norm estimate. |
| §5 Two-variable | 6 | **1** | 2 | 0 | 3 | 5.4 simple-pole cancellation is near complete; 5.1/5.2 are partial; remaining claims open. |
| §6 Generalizations | 18 | **0** | 7 | 0 | 11 | Includes conditional/finite algebraic scaffolding, but no entire printed §6 theorem is certified. |
| **Total** | **46** | **6** | **18** | **2** | **20** | **6/46 (13%) near-complete numbered proof items**, not a page or proof-effort percentage. |

The manuscript additionally has **4 remarks and 1 conjecture**. Do not count Conjecture 4.11 as an outstanding *claimed theorem* in the full-theorem closure metric.

## How to express progress without overstating

1. **Strongest conservative headline:** `6/46 numbered proof items are close to complete; 18 partial; 2 require corrected statements; 20 open`. These numbers follow the **source alignment ledger**, not automatic kernel checking of complete PDF statements.
2. **Equivalent proof-effort estimate:** approximately **25%**, with broad uncertainty **20–30%**, based on the relative difficulty of the remaining analytic, spectral, arithmetic, and p-adic arguments. The 6/46 (~13%) item count is not contradictory: hard unfinished items dominate the work.
3. **Compiler baseline:** user-certified **105/105** unchanged proof modules PASS in v0.4.7.2. The v0.5.0.5 archive has **113** project proof modules: 105 byte-identical frozen, **8 new candidate modules** with no complete user-certified PASS yet. The current ZIP adds no Lean proofs.
4. **Single Witness endpoint:** the `PaperWitness.Witness` hypothesis gives a conditional irrationality theorem. An `EffectiveWitness` includes additional spectral data. Embedding unproved estimates into a structure does not discharge them. §5–6's analytic and p-adic results do not follow merely from the weight-five Witness.

## Corrections which a fully chronological proof must face

- Corollary 3.5: printed J-fraction identity fails even at dimension one; currently only a corrected Schur statement is available.
- Corollary 3.6: finite atomic measures have Hankel rank at most the support size; the printed 'all orders strictly positive' and a displayed bound direction require correction.
- Theorem 5.2(3): a finite negative-mode annihilator cannot automatically annihilate the remaining infinite Krein tail; a quantitative tail proof is needed.
- Remark 4.10: clustering of zeros alone does not prove nonanalyticity of the proposed limiting free energy.

## Counting discipline going forward

Each numbered printed item receives a ledger entry with (a) exact PDF statement, (b) Lean declaration name, (c) theorem statement equivalence status, (d) proof axiom audit, (e) user compiler PASS stamp, and (f) independently unproved premises. Keep **conditional theorem typechecks** and **full manuscript theorem closure** as separate columns. An unchanged verified proof source is frozen and never recompiled unless dependencies or toolchain change. One ZIP and exactly one `run.cmd` remain the only runnable artifact; no assistant-side Lean compilation is performed.

See `PDF_THEOREM_MATRIX_20261024.csv` for the full 51-row inventory and `PDF_COVERAGE_AUDIT_20261024.md` for source rationale.
