import Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic
import Mathlib.Tactic

/-!
# Theorem 3.8: exact equality of the pencil and kernel zero loci

The finite pole-kernel determinant is a spectral polynomial in the
relative displacement t.  We prove, for the ACTUAL real-s measure,
that its zeros agree exactly with the genuine determinant pencil
about zeta(s).  No zeta irrationality, quantitative estimate, or
Krein-tail premise enters this equality.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_8.ActualZeroLocus
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel
open PaperChronology.Theorem3_8.ActualCyclicKernel

/-- The genuine determinant polynomial at zeta(s)+t is the pole-kernel
characteristic determinant times the genuine Gram determinant. -/
theorem actual_pencil_kernel_det_exact
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (t : ℝ) :
    (Gram.actualPencil s p).detPolynomial.eval
      ((riemannZeta (s : ℂ)).re + t) =
        (Gram.gram s p).det *
          (1 + t • (Matrix.diagonal (poleWeight s p) *
            poleKernel s p)).det := by
  rw [(Gram.actualPencil s p).eval_detPolynomial]
  change
    (Gram.gram s p +
      (((riemannZeta (s : ℂ)).re + t) - (riemannZeta (s : ℂ)).re) •
        derivativeMatrix s p).det = _
  have ht : ((riemannZeta (s : ℂ)).re + t) -
      (riemannZeta (s : ℂ)).re = t := by ring
  rw [ht]
  exact actual_pole_kernel_affine_det s p hs t

/-- REAL zeros correspond exactly, with multiplicity supplied by the
explicit polynomial identity above. -/
theorem actual_pencil_root_iff_kernel_zero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (t : ℝ) :
    (Gram.actualPencil s p).detPolynomial.eval
      ((riemannZeta (s : ℂ)).re + t) = 0 ↔
      (1 + t • (Matrix.diagonal (poleWeight s p) *
        poleKernel s p)).det = 0 := by
  rw [actual_pencil_kernel_det_exact s p hs t]
  have hg : (Gram.gram s p).det ≠ 0 :=
    ne_of_gt (PaperChronology.Proposition3_2.Integrability.actualGram_posDef
      s p hs).det_pos
  constructor
  · intro h
    exact (mul_eq_zero.mp h).resolve_left hg
  · intro h
    exact mul_eq_zero.mpr (Or.inr h)

/-- No kernel singularity at the distinguished zeta center. -/
theorem actual_kernel_center_nonzero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    (1 + (0 : ℝ) • (Matrix.diagonal (poleWeight s p) *
      poleKernel s p)).det ≠ 0 := by
  simp

end PaperChronology.Theorem3_8.ActualZeroLocus

#print axioms PaperChronology.Theorem3_8.ActualZeroLocus.actual_pencil_root_iff_kernel_zero
