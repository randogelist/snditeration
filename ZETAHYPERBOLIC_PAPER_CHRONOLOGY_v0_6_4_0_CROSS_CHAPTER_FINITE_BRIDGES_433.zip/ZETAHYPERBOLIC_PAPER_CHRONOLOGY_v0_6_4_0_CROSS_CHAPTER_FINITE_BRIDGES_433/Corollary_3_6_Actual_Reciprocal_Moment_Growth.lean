import Corollary_3_6_Reciprocal_Root_Moment_Bounds
import Mathlib.Tactic

/-!
# Corollary 3.6: finite spectral moment growth and strict positivity

The corrected finite spectral moments satisfy the genuine sharp recursion
`S_(m+1) <= B * S_m` if every inverse-square atom is bounded by `B`.
As long as the finite spectrum is nonempty and the reference point is
not a root, every moment is strictly positive. These are UNCONDITIONAL
finite-root statements, not the manuscript's false assertion that the
finite-rank Hankel hierarchy is positive definite at *every* order.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Corollary3_6.ActualMomentGrowth
open PaperChronology.Corollary3_6.ReciprocalMoments
open PaperChronology.Corollary3_6.CorrectedFiniteAtomic

/-- The finite moment recurrence works at every order, including m=0. -/
theorem reciprocalPowerSum_step_bound {n : ℕ}
    (roots : Fin n → ℝ) (q B : ℝ) (m : ℕ)
    (hB : ∀ i, invDistanceAtom roots q i ≤ B) :
    reciprocalPowerSum roots q (m + 1) ≤
      B * reciprocalPowerSum roots q m := by
  calc
    reciprocalPowerSum roots q (m + 1) =
        ∑ i : Fin n,
          (invDistanceAtom roots q i) ^ m * invDistanceAtom roots q i := by
            simp only [reciprocalPowerSum, atomicMoment, pow_succ]
    _ ≤ ∑ i : Fin n, (invDistanceAtom roots q i) ^ m * B := by
          apply Finset.sum_le_sum
          intro i _
          exact mul_le_mul_of_nonneg_left (hB i)
            (pow_nonneg (invDistanceAtom_nonneg roots q i) m)
    _ = B * reciprocalPowerSum roots q m := by
          rw [← Finset.sum_mul]
          simp only [reciprocalPowerSum, atomicMoment]
          ring

/-- For nonempty spectra disjoint from q, every even reciprocal moment
is positive; repeated roots and atoms are allowed. -/
theorem reciprocalPowerSum_strictly_positive {n : ℕ}
    (hn : 0 < n) (roots : Fin n → ℝ) (q : ℝ) (m : ℕ)
    (hsep : ∀ i, roots i ≠ q) :
    0 < reciprocalPowerSum roots q m := by
  let i : Fin n := ⟨0, hn⟩
  have hterm : 0 < (invDistanceAtom roots q i) ^ m :=
    pow_pos (invDistanceAtom_pos roots q i (hsep i)) m
  exact lt_of_lt_of_le hterm
    (atom_le_reciprocalPowerSum roots q m i)

end PaperChronology.Corollary3_6.ActualMomentGrowth

#print axioms PaperChronology.Corollary3_6.ActualMomentGrowth.reciprocalPowerSum_step_bound
#print axioms PaperChronology.Corollary3_6.ActualMomentGrowth.reciprocalPowerSum_strictly_positive
