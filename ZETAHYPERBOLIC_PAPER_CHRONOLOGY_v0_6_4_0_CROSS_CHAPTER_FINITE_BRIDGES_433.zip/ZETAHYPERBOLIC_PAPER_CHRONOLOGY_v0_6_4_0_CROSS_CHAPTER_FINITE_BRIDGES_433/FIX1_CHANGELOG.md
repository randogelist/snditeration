# v0.3.3.1 — Native incremental repair

## Compiler feedback received

```text
CHECK=PAPER_COUNTEREXAMPLES
PAPER_COUNTEREXAMPLES.lean:45:34: error: not a positivity goal
'PaperAudit.j_fraction_h1_sign_obstruction' depends on axioms:
[propext, sorryAx, Classical.choice, Quot.sound]
RESULT=FAIL
```

## Surgical correction

Changed **only** the proof of `PaperAudit.j_fraction_h1_sign_obstruction`.
The signed hypotheses `hM : M < 0`, `hG : 0 < G` imply `M/G < 0`;
the reciprocal is negative, whereas `1/G` is positive. The old use
of `positivity` on a negative target is replaced by explicit
`div_neg_of_neg_of_pos` and `div_neg_of_pos_of_neg` proof steps.
No new hypotheses, `sorry`, `admit`, or axioms were inserted.

## Compiler protocol

The existing persistent cache is unchanged:
`%USERPROFILE%\lean-native\zetahyperbolic-paper-frozen-433`.
Pass-once snapshots of unchanged source and `.olean` files remain
reusable. Only the edited module and any invalidated dependents should
recompile. No Lean compilation was run by the packaging assistant.
The user's Windows Lean compiler is the sole source of proof status.

## Scope

Every other `.lean` file was copied byte-for-byte from v0.3.3.
The launcher banner and SHA256 manifest were regenerated.
