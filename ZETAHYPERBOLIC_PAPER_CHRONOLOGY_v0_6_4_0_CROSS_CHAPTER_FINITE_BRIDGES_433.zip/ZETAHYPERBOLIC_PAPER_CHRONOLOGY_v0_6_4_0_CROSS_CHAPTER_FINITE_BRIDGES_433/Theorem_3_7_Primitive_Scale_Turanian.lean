import Theorem_3_7_All_Order_Turanian_Jets
import Mathlib.Tactic

/-!
# Theorem 3.7: Turan positivity is invariant under primitive normalization

The manuscript replaces its rational determinant by a nonzero scalar
multiple to obtain an integer polynomial. At the derivative-jet level,
this scaling multiplies the Turanian by a square and therefore cannot
change its sign. Applies to all finite real-root products, every degree.

This complements the compiler-verified actual derivative theorem;
it does not claim the still-open *all higher derivative orders* bridge.
-/

noncomputable section
namespace PaperChronology.Theorem3_7.PrimitiveTuran
open PaperChronology.Theorem3_7.TuranJets

/-- Multiplying a real-root polynomial by an arbitrary normalization. -/
def scaleJet (c : ℝ) (j : Jet) : Jet :=
  ⟨c * j.value, c * j.first, c * j.second⟩

/-- The Turanian transforms by precisely the square of the scale. -/
theorem turanian_scale (c : ℝ) (j : Jet) :
    turanian (scaleJet c j) = c ^ 2 * turanian j := by
  unfold scaleJet turanian
  ring

/-- The real-rooted Turanian stays nonnegative under every (including
negative) rational-content or leading-coefficient rescaling. -/
theorem scaled_real_root_turanian_nonneg (c x : ℝ)
    (roots : List ℝ) :
    0 ≤ turanian (scaleJet c (rootJet x roots)) := by
  rw [turanian_scale]
  exact mul_nonneg (sq_nonneg c) (rootJet_turanian_nonneg x roots)

/-- The underlying root product is multiplied by exactly its scale. -/
theorem scaled_root_value (c x : ℝ) (roots : List ℝ) :
    (scaleJet c (rootJet x roots)).value =
      c * rootProduct roots x := by
  simpa only [scaleJet] using
    congrArg (fun v : ℝ => c * v)
      (rootJet_value_eq_rootProduct x roots)

end PaperChronology.Theorem3_7.PrimitiveTuran

#print axioms PaperChronology.Theorem3_7.PrimitiveTuran.scaled_real_root_turanian_nonneg
