import Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic
import Mathlib.Tactic

/-!
# Theorem 3.8: exact pole-kernel determinant mass

The actual real-s Christoffel-Darboux pole kernel K = V^T G^{-1} V
satisfies det K = det(V)^2 det(G^{-1}). In particular det K is nonzero.
The pole-weighted kernel W = diag(gamma) K obeys the exact invariant

                 det G * det W = det M.

Here G is the original infinite-measure real-s Gram, M its genuine
negative-square-pole slope, and V the negative-square Vandermonde.
This identity contains NO asymptotic estimate or arithmetic Witness.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_8.ActualDetMass
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel
open PaperChronology.Theorem3_8.ActualCyclicKernel

/-- Determinant of the actual pole kernel, including all finite dimensions. -/
theorem poleKernel_det (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    (poleKernel s p).det =
      (vandermonde p).det ^ 2 * ((Gram.gram s p)⁻¹).det := by
  unfold poleKernel
  rw [Matrix.det_mul, Matrix.det_mul, Matrix.det_transpose]
  ring

/-- Exact determinant identity of the inverse of the actual positive Gram. -/
theorem gram_det_mul_inverse_det (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Gram.gram s p).det * ((Gram.gram s p)⁻¹).det = 1 := by
  have hg : (Gram.gram s p).det ≠ 0 :=
    ne_of_gt (PaperChronology.Proposition3_2.Integrability.actualGram_posDef
      s p hs).det_pos
  have hunit : IsUnit (Gram.gram s p).det :=
    isUnit_iff_ne_zero.mpr hg
  calc
    (Gram.gram s p).det * ((Gram.gram s p)⁻¹).det =
        ((Gram.gram s p) * (Gram.gram s p)⁻¹).det := by
          rw [Matrix.det_mul]
    _ = 1 := by
      rw [Matrix.mul_nonsing_inv (Gram.gram s p) hunit]
      simp

/-- Exact equality of determinant masses: no asymptotic or root estimate. -/
theorem gram_det_mul_weighted_kernel_det
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Gram.gram s p).det *
      (Matrix.diagonal (poleWeight s p) * poleKernel s p).det =
        (derivativeMatrix s p).det := by
  rw [Matrix.det_mul, Matrix.det_diagonal,
    poleKernel_det, derivativeMatrix_det]
  calc
    (Gram.gram s p).det *
        ((∏ i : Fin p.h, poleWeight s p i) *
          ((vandermonde p).det ^ 2 * ((Gram.gram s p)⁻¹).det)) =
      ((Gram.gram s p).det * ((Gram.gram s p)⁻¹).det) *
        ((vandermonde p).det ^ 2 *
          ∏ i : Fin p.h, poleWeight s p i) := by ring
    _ = (vandermonde p).det ^ 2 *
          ∏ i : Fin p.h, poleWeight s p i := by
      rw [gram_det_mul_inverse_det s p hs]
      ring

/-- The ACTUAL weighted Christoffel-Darboux pole-kernel is nonsingular. -/
theorem weighted_poleKernel_det_ne_zero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Matrix.diagonal (poleWeight s p) * poleKernel s p).det ≠ 0 := by
  have hdir : (derivativeMatrix s p).det ≠ 0 :=
    derivativeMatrix_det_ne_zero s p
  have hmass := gram_det_mul_weighted_kernel_det s p hs
  intro hz
  rw [hz, mul_zero] at hmass
  exact hdir hmass.symm

/-- The unweighted actual pole-kernel matrix is nonsingular as well. -/
theorem poleKernel_det_ne_zero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (poleKernel s p).det ≠ 0 := by
  have hw := weighted_poleKernel_det_ne_zero s p hs
  intro hz
  apply hw
  rw [Matrix.det_mul, hz, mul_zero]

end PaperChronology.Theorem3_8.ActualDetMass

#print axioms PaperChronology.Theorem3_8.ActualDetMass.poleKernel_det
#print axioms PaperChronology.Theorem3_8.ActualDetMass.gram_det_mul_weighted_kernel_det
#print axioms PaperChronology.Theorem3_8.ActualDetMass.poleKernel_det_ne_zero
