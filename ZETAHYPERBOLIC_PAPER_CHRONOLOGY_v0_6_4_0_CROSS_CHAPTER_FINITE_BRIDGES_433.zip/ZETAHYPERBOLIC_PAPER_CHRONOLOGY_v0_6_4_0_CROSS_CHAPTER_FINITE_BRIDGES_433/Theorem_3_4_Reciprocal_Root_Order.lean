import Theorem_3_3_Spectral_Root_Sign_Correspondence
import Mathlib.Tactic

/-!
# Theorem 3.4: the exact reciprocal transform used for root interlacing

For a positive-definite affine pencil the roots are `ξ - β⁻¹` with
`β ≠ 0`. The map is strictly increasing separately on the positive and
negative half-lines. Here this is proved directly using the common
positive product of two same-sign eigenvalues; no assumption on RH,
ζ-value arithmetic, or a finite witness occurs.

Cauchy interlacing for Cholesky-compatible principal blocks and the
full Dodgson condensation law are separate, still-open Lean bridges.
-/

noncomputable section
namespace PaperChronology.Theorem3_4.ReciprocalOrder

/-- Algebraic identity behind the order reversal of reciprocals. -/
theorem inverse_sub_inverse (x y : ℝ)
    (hx : x ≠ 0) (hy : y ≠ 0) :
    x⁻¹ - y⁻¹ = (y - x) / (x * y) := by
  -- `field_simp` closes this goal completely: do not append `ring`.
  field_simp [hx, hy]

/-- The root map ξ-β⁻¹ is nondecreasing on each connected component
of ℝ\\{0}. This is the order-preserving step in PDF Theorem 3.4. -/
theorem reciprocal_root_monotone_same_sign
    (ξ x y : ℝ) (hxy : x ≤ y)
    (hx : x ≠ 0) (hy : y ≠ 0)
    (hprod : 0 < x * y) :
    ξ - x⁻¹ ≤ ξ - y⁻¹ := by
  have hnum : 0 ≤ y - x := sub_nonneg.mpr hxy
  have hdiff : x⁻¹ - y⁻¹ = (y - x) / (x * y) :=
    inverse_sub_inverse x y hx hy
  have hnonneg : 0 ≤ x⁻¹ - y⁻¹ := by
    rw [hdiff]
    exact div_nonneg hnum hprod.le
  linarith

/-- Positive eigenvalues: monotonic spectral transfer. -/
theorem reciprocal_root_monotone_positive
    (ξ x y : ℝ) (hx : 0 < x) (hxy : x ≤ y) :
    ξ - x⁻¹ ≤ ξ - y⁻¹ := by
  have hy : 0 < y := lt_of_lt_of_le hx hxy
  exact reciprocal_root_monotone_same_sign ξ x y hxy
    (ne_of_gt hx) (ne_of_gt hy) (mul_pos hx hy)

/-- Negative eigenvalues: the same order-preserving transfer. -/
theorem reciprocal_root_monotone_negative
    (ξ x y : ℝ) (hxy : x ≤ y) (hy : y < 0) :
    ξ - x⁻¹ ≤ ξ - y⁻¹ := by
  have hx : x < 0 := lt_of_le_of_lt hxy hy
  exact reciprocal_root_monotone_same_sign ξ x y hxy
    (ne_of_lt hx) (ne_of_lt hy) (mul_pos_of_neg_of_neg hx hy)

/-- The two spectral half-lines map to the appropriate sides of ξ. -/
theorem positive_beta_root_below (ξ β : ℝ) (hβ : 0 < β) :
    ξ - β⁻¹ < ξ := by
  have hi : 0 < β⁻¹ := inv_pos.mpr hβ
  linarith

theorem negative_beta_root_above (ξ β : ℝ) (hβ : β < 0) :
    ξ < ξ - β⁻¹ := by
  have hi : β⁻¹ < 0 := inv_lt_zero.mpr hβ
  linarith

end PaperChronology.Theorem3_4.ReciprocalOrder

#print axioms PaperChronology.Theorem3_4.ReciprocalOrder.reciprocal_root_monotone_same_sign
#print axioms PaperChronology.Theorem3_4.ReciprocalOrder.reciprocal_root_monotone_positive
#print axioms PaperChronology.Theorem3_4.ReciprocalOrder.reciprocal_root_monotone_negative
