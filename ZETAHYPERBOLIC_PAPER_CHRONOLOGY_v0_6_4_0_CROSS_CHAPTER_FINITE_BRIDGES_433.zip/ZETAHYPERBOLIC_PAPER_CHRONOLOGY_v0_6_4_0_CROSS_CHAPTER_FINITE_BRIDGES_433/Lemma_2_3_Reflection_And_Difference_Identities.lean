import Lemma_2_2_Pullback_Identity

/-!
# Lemma 2.3 — Reflection and difference identities (PDF p. 5)

The three formulas below are the stated identities on the generators of the
Q-linear domain of τ. Extension to arbitrary finite linear combinations is by
linearity. The exceptional indices r=0 and r=1 are explicitly excluded in the
difference identity, exactly as in the manuscript.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperChronology.Section2
open Zetahyperbolic

/-- Reflection on the polynomial monomial generators, equation (2.6). -/
theorem lemma_2_3_reflection_monomial (k d : ℕ) (hk : 1 ≤ k) :
    (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * tauMonomial k i) =
      -tauMonomial k d :=
  tau_reflection_monomial k d hk

/-- Reflection on the simple-pole generators, equation (2.6). The initial
minus sign is the one contributed by x ↦ -1-x. -/
theorem lemma_2_3_reflection_pole (k : ℕ) (r : ℤ) :
    -tauPolePoly k (-1 - r) = -tauPolePoly k r :=
  tau_reflection_pole k r

/-- Difference equation on simple poles, equation (2.7). -/
theorem lemma_2_3_difference_pole (k : ℕ) (r : ℤ)
    (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    tauPolePoly k (r - 1) - tauPolePoly k r =
      C (-((r : ℚ) ^ (2 * k + 1))⁻¹) :=
  tau_difference_pole k r hr0 hr1

/-- Single theorem exposing ALL three generator cases of Lemma 2.3, without
any hypothesis on ζ-values, primes, integrals, or a witness. -/
theorem lemma_2_3_all_generators (k : ℕ) (hk : 1 ≤ k) :
    (∀ d : ℕ,
      (-1 : ℚ) ^ d *
          (∑ i ∈ Finset.range (d + 1),
            (Nat.choose d i : ℚ) * tauMonomial k i) =
        -tauMonomial k d) ∧
    (∀ r : ℤ, -tauPolePoly k (-1 - r) = -tauPolePoly k r) ∧
    (∀ r : ℤ, r ≠ 0 → r ≠ 1 →
      tauPolePoly k (r - 1) - tauPolePoly k r =
        C (-((r : ℚ) ^ (2 * k + 1))⁻¹)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro d
    exact lemma_2_3_reflection_monomial k d hk
  · intro r
    exact lemma_2_3_reflection_pole k r
  · intro r hr0 hr1
    exact lemma_2_3_difference_pole k r hr0 hr1

end PaperChronology.Section2

#print axioms PaperChronology.Section2.lemma_2_3_all_generators
