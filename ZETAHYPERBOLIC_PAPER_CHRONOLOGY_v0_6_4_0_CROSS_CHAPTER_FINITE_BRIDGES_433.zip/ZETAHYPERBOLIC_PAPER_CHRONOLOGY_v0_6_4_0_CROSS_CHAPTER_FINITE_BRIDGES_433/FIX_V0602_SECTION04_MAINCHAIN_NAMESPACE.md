# v0.6.0.2 — Section 4 MainChain namespace fix

Observed native Windows Lean 4.33 error:

    PaperBlueprint\Section04.lean:39:12: unknown identifier MainChain.indexDenominatorThreshold

Cause: the previously checked threshold is declared inside
`ManuscriptChain.MainChain` rather than the root namespace `MainChain`.

Correction: add `open ManuscriptChain` inside `PaperBlueprint.Section04`.
The downstream theorem `PaperWitness.THEOREM_4_4_MEASURE_25687` remains
conditional on an explicit `EffectiveWitness`; no witness construction is claimed.

All 105 previously native-compiler-certified Lean sources are byte-for-byte unchanged.
Section03 and Section02 are unchanged. Only Section04 source is edited.
The local assistant has **not compiled Lean**. Use the user's native compiler.
