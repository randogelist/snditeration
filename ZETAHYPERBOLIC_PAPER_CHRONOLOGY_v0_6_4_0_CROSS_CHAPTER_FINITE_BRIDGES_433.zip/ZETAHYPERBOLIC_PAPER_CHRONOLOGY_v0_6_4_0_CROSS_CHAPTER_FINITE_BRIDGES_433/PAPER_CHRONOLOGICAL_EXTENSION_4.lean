import PAPER_CHRONOLOGICAL_EXTENSION_3
import Theorem_3_3_Four_Atom_General_Minors
import Theorem_3_3_Four_Atom_Three_By_Three

/-!
# PDF chronological Section 3 extension 4

Connects the two additional finite-atomic Theorem 3.3 steps to the
already checked Section 3 proof chain. This is a genuine finite model;
no claim of full continuous-measure total positivity is made here.
-/

namespace PaperChronology

/-- Every translated and independently gapped 2×2 Hankel minor of a positive
four-atomic moment functional is strictly positive. -/
theorem paper_theorem_3_3_four_atom_all_two_minors
    (a b c d u v w z : ℝ) (n i j : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d)
    (hu : 0 < u) (huv : u < v) (hvw : v < w) (hwz : w < z)
    (hi : 0 < i) (hj : 0 < j) :
    0 < Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 0) *
          Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + (i + j)) -
        Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + i) *
          Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + j) :=
  Theorem3_3.FourAtomic.four_atom_general_minor_pos
    a b c d u v w z n i j ha hb hc hd hu huv hvw hwz hi hj

/-- Every translated 3×3 Hankel principal determinant of a positive
four-atomic moment functional is strictly positive. -/
theorem paper_theorem_3_3_four_atom_shifted_three_minor
    (a b c d u v w z : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d)
    (hu : 0 < u) (huv : u < v) (hvw : v < w) (hwz : w < z) :
    0 < Theorem3_3.DiscreteSamples.hankelDet3
      (Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 0))
      (Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 1))
      (Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 2))
      (Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 3))
      (Theorem3_3.FourAtomic.fourMoment a b c d u v w z (n + 4)) :=
  Theorem3_3.FourAtomic.four_atom_det3_shift_pos
    a b c d u v w z n ha hb hc hd hu huv hvw hwz

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_four_atom_all_two_minors
#print axioms PaperChronology.paper_theorem_3_3_four_atom_shifted_three_minor
