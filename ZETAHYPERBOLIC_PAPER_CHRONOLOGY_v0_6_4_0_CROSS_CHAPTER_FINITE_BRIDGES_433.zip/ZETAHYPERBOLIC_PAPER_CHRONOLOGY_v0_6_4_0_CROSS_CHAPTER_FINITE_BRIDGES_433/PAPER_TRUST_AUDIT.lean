import PAPER_MAIN_CHAIN
import PAPER_COUNTEREXAMPLES
import MAIN_CHAIN_IRRATIONALITY
import Theorem_4_1_Leading_Coefficient_Gap
import ZETA5_DIRECT_IRRATIONALITY

/-!
# Audit the genuine exported endpoints

The checks below show the named theorem types and kernel dependencies.
A theorem with an explicit `decay` or `certificate` argument stays
conditional even if `#print axioms` reports only standard logical axioms.

The proof graph imports no custom mathematical axioms into the
unconditional spectral endpoint. Compilation is still required to certify
new additions; this source-only merge was not rebuilt in this environment.
-/

#check ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#check ManuscriptChain.EXACT_ZERO_FREE_DISK
#check Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL
#check ManuscriptChain.GeneralIrrationality.OddWeightDecayHypothesis
#check ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational

#print axioms ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#print axioms ManuscriptChain.EXACT_ZERO_FREE_DISK
#print axioms PaperAudit.general_odd_weight_spectral
#print axioms PaperAudit.original_manuscript_pencil
#print axioms PaperAudit.two_atom_hankel3_zero
#print axioms PaperAudit.j_fraction_h1_sign_obstruction
