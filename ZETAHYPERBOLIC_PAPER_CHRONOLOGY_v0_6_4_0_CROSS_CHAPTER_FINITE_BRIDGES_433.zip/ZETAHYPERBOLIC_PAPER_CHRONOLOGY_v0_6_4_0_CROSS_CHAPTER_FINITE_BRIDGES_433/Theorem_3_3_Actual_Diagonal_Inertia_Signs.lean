import Theorem_3_3_Actual_Leading_Coefficient_Sign
import Mathlib.Tactic

/-!
# Theorem 3.3(3): actual rational pole derivative, diagonal inertia signs

This is the exact negative-square-pole derivative matrix from the PDF,
not a free example. In Lagrange coordinates the derivative is diagonal.
Its diagonal entries are nonzero, and their signs alternate according
to the parity of the actual pole index. No arithmetic witness, no new
analytic hypothesis, and no axiom is needed.

This is the diagonal congruence certificate for Sylvester inertia. The
subsequent *spectral eigenvalue-count transfer* is a separate theorem
frontier; this module does not assume or assert that unproved transfer.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ActualDiagonalSigns

open ManuscriptChain.PoleDiagonalization

/-- The exact diagonal entry of the manuscript slope after the
invertible pole-Vandermonde change of coordinates. -/
def diagonalSlope (p : ManuscriptChain.Real.Parameters) (i : Fin p.h) : ℚ :=
  ((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
    ((poleVandermonde p)⁻¹).transpose) i i

/-- The exact Lagrange congruence identifies every diagonal slope with
the residue weight at its genuine negative-square pole. -/
theorem diagonalSlope_eq_poleWeight (p : ManuscriptChain.Real.Parameters)
    (i : Fin p.h) : diagonalSlope p i = poleWeight p i := by
  unfold diagonalSlope
  rw [pole_slope_diagonal]
  simp

/-- None of the actual diagonal slopes is zero. -/
theorem diagonalSlope_ne_zero (p : ManuscriptChain.Real.Parameters)
    (i : Fin p.h) : diagonalSlope p i ≠ 0 := by
  rw [diagonalSlope_eq_poleWeight]
  exact poleWeight_ne_zero p i

private theorem neg_one_even (n : ℕ) (hn : Even n) :
    (-1 : ℚ) ^ n = 1 := by
  obtain ⟨k, hk⟩ := hn
  have heq : n = 2 * k := by omega
  rw [heq, pow_mul]
  norm_num

/-- Even exponent `a-1` means that the actual pole index `a` is odd:
its diagonalized slope is strictly positive. -/
theorem diagonalSlope_pos_of_even (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (heven : Even (poleIndex p i - 1)) :
    0 < diagonalSlope p i := by
  have hs : 0 < (-1 : ℚ) ^ (poleIndex p i - 1) *
      diagonalSlope p i :=
    PaperChronology.Theorem3_3.ActualLeadingSign.actual_diagonalized_slope_signed_positive
      p hm i
  rw [neg_one_even _ heven, one_mul] at hs
  exact hs

/-- Odd exponent `a-1` means that the actual pole index `a` is even:
its diagonalized slope is strictly negative. -/
theorem diagonalSlope_neg_of_odd (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (hodd : Odd (poleIndex p i - 1)) :
    diagonalSlope p i < 0 := by
  have hs : 0 < (-1 : ℚ) ^ (poleIndex p i - 1) *
      diagonalSlope p i :=
    PaperChronology.Theorem3_3.ActualLeadingSign.actual_diagonalized_slope_signed_positive
      p hm i
  rw [hodd.neg_one_pow] at hs
  have hneg : 0 < -diagonalSlope p i := by
    simpa only [neg_one_mul] using hs
  exact neg_pos.mp hneg

/-- An exact sign *equivalence*, not merely a one-direction sign bound. -/
theorem diagonalSlope_pos_iff_even (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < diagonalSlope p i ↔ Even (poleIndex p i - 1) := by
  constructor
  · intro hpos
    by_contra hnot
    have hodd : Odd (poleIndex p i - 1) := Nat.not_even_iff_odd.mp hnot
    have hneg := diagonalSlope_neg_of_odd p hm i hodd
    linarith
  · exact diagonalSlope_pos_of_even p hm i

/-- Equivalently, strict negativity is exactly the opposite pole parity. -/
theorem diagonalSlope_neg_iff_odd (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    diagonalSlope p i < 0 ↔ Odd (poleIndex p i - 1) := by
  constructor
  · intro hneg
    by_contra hnot
    have heven : Even (poleIndex p i - 1) := Nat.not_odd_iff_even.mp hnot
    have hpos := diagonalSlope_pos_of_even p hm i heven
    linarith
  · exact diagonalSlope_neg_of_odd p hm i

/-- All pole-congruence off-diagonal entries vanish: actual, not sampled. -/
theorem diagonalSlope_offdiag_zero (p : ManuscriptChain.Real.Parameters)
    (i j : Fin p.h) (hij : i ≠ j) :
    ((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose) i j = 0 := by
  rw [pole_slope_diagonal]
  simp [hij]

end PaperChronology.Theorem3_3.ActualDiagonalSigns

#print axioms PaperChronology.Theorem3_3.ActualDiagonalSigns.diagonalSlope_eq_poleWeight
#print axioms PaperChronology.Theorem3_3.ActualDiagonalSigns.diagonalSlope_pos_iff_even
#print axioms PaperChronology.Theorem3_3.ActualDiagonalSigns.diagonalSlope_neg_iff_odd
#print axioms PaperChronology.Theorem3_3.ActualDiagonalSigns.diagonalSlope_offdiag_zero
