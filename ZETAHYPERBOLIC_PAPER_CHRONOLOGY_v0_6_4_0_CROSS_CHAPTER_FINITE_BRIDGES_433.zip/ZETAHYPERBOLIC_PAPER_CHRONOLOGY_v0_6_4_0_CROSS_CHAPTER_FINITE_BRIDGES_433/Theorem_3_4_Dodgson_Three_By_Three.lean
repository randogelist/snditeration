import Theorem_3_3_Discrete_Total_Positivity_Samples
import Theorem_3_4_Reciprocal_Root_Order
import Mathlib.Tactic

/-!
# PDF Theorem 3.4(2) — Dodgson/Jacobi condensation at order three

The exact Jacobi identity is proved for the *symbolic* 3×3 Hankel matrix
of moments m0,...,m4.  Its principal-minor-root specialization gives a
nonpositive determinant, and is strictly negative when the off-diagonal
minor is nonzero. No spectrum, arithmetic witness, or external hypothesis
is used. The arbitrary-order Jacobi identity remains a separate frontier.
-/

noncomputable section
namespace PaperChronology.Theorem3_4.Dodgson3

/-- The order-three Hankel determinant from the preceding finite model. -/
abbrev det3 (m0 m1 m2 m3 m4 : ℝ) : ℝ :=
  PaperChronology.Theorem3_3.DiscreteSamples.hankelDet3 m0 m1 m2 m3 m4

/-- Exact 3×3 Jacobi identity using the complementary principal minors
anchored at the upper-left entry.  This matches the r=3 instance of
PDF Theorem 3.4(2), before specializing the (r-1)-st minor to zero. -/
theorem condensation_top_left (m0 m1 m2 m3 m4 : ℝ) :
    det3 m0 m1 m2 m3 m4 * m0 =
      (m0 * m2 - m1 ^ 2) * (m0 * m4 - m2 ^ 2) -
        (m0 * m3 - m1 * m2) ^ 2 := by
  unfold det3 PaperChronology.Theorem3_3.DiscreteSamples.hankelDet3
  ring

/-- The contiguous-minor form of the same order-three identity,
with central pivot m2 and two adjacent 2×2 Hankel minors. -/
theorem condensation_center (m0 m1 m2 m3 m4 : ℝ) :
    det3 m0 m1 m2 m3 m4 * m2 =
      (m0 * m2 - m1 ^ 2) * (m2 * m4 - m3 ^ 2) -
        (m1 * m3 - m2 ^ 2) ^ 2 := by
  unfold det3 PaperChronology.Theorem3_3.DiscreteSamples.hankelDet3
  ring

/-- At a root of the leading 2×2 minor, the condensation remainder is
the negative square of the off-diagonal complementary minor. -/
theorem condensation_at_minor_root (m0 m1 m2 m3 m4 : ℝ)
    (hminor : m0 * m2 - m1 ^ 2 = 0) :
    det3 m0 m1 m2 m3 m4 * m0 =
      -(m0 * m3 - m1 * m2) ^ 2 := by
  rw [condensation_top_left, hminor]
  ring

/-- The determinant-sign conclusion when the remaining 1×1 minor is
strictly positive.  This is the order-three version of the manuscript's
nonpositive Dodgson sign law at roots. -/
theorem det3_nonpos_at_minor_root (m0 m1 m2 m3 m4 : ℝ)
    (hm0 : 0 < m0) (hminor : m0 * m2 - m1 ^ 2 = 0) :
    det3 m0 m1 m2 m3 m4 ≤ 0 := by
  have hroot := condensation_at_minor_root m0 m1 m2 m3 m4 hminor
  have hmul : det3 m0 m1 m2 m3 m4 * m0 ≤ 0 := by
    rw [hroot]
    exact neg_nonpos.mpr (sq_nonneg _)
  by_contra hcontra
  have hpos : 0 < det3 m0 m1 m2 m3 m4 := lt_of_not_ge hcontra
  exact (not_lt_of_ge hmul) (mul_pos hpos hm0)

/-- Strict inequality when the off-diagonal minor does not also vanish. -/
theorem det3_neg_at_minor_root (m0 m1 m2 m3 m4 : ℝ)
    (hm0 : 0 < m0) (hminor : m0 * m2 - m1 ^ 2 = 0)
    (hoff : m0 * m3 - m1 * m2 ≠ 0) :
    det3 m0 m1 m2 m3 m4 < 0 := by
  have hroot := condensation_at_minor_root m0 m1 m2 m3 m4 hminor
  have hs : 0 < (m0 * m3 - m1 * m2) ^ 2 := sq_pos_of_ne_zero hoff
  have hmul : det3 m0 m1 m2 m3 m4 * m0 < 0 := by
    rw [hroot]
    exact neg_lt_zero.mpr hs
  by_contra hcontra
  have hnonneg : 0 ≤ det3 m0 m1 m2 m3 m4 := le_of_not_gt hcontra
  exact (not_le_of_gt hmul) (mul_nonneg hnonneg hm0.le)

end PaperChronology.Theorem3_4.Dodgson3

#print axioms PaperChronology.Theorem3_4.Dodgson3.condensation_top_left
#print axioms PaperChronology.Theorem3_4.Dodgson3.condensation_center
#print axioms PaperChronology.Theorem3_4.Dodgson3.det3_nonpos_at_minor_root
#print axioms PaperChronology.Theorem3_4.Dodgson3.det3_neg_at_minor_root
