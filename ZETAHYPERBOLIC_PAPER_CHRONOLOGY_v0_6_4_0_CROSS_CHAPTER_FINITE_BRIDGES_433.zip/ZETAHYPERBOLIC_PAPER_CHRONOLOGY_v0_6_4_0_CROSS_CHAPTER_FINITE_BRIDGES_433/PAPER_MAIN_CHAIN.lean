import MAIN_CHAIN_ASSEMBLED
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# PaperAudit: unconditional general odd-weight spectral core

This file only re-exports proved assertions about the actual manuscript
pencil. `Real.Admissible p` is the standard index-domain condition
(k,m,N >= 1 and N < K), not an analytic or Diophantine conjecture.

This file does not claim the arithmetic estimates needed for the rest of
Section 4 or the unresolved weight-seven and beta extensions.
-/

noncomputable section
namespace PaperAudit

/-- Exact degree, real zero locus, exclusion of the center, and the
spectral radius conclusions for every admissible odd-weight pencil. -/
theorem general_odd_weight_spectral
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- The original Hankel pencil agrees with the general checked model. -/
theorem original_manuscript_pencil
    (p : Zetahyperbolic.HankelParams) (k : ℕ) (hk : 1 ≤ k) :
    ManuscriptChain.General.GeneralStatement
      (Zetahyperbolic.ManuscriptCompatibility.toParameters p k) :=
  Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL p k hk

end PaperAudit

#print axioms PaperAudit.general_odd_weight_spectral
#print axioms PaperAudit.original_manuscript_pencil
