# FIX21: Real-s moment majorant application

The previous code attempted to supply a norm-valued majorant to `Integrable.mono'`, but this overload expects the nonnegative real majorizing function itself. The change uses the established a.e. inequality `hdom` directly. The `const_mul`/`add` integrable majorant is normalized by simplifying function application and multiplication associativity (`mul_assoc`).

Only `Proposition_3_2_Real_s_Moment_Integrability.lean` is altered mathematically. The 82 other Lean files remain byte-identical to v0.3.9.14. This patch is source-only and requires compilation on the user's native Lean 4.33.0; none was performed here.
