# v0.6.2.2 — cyclic determinant proof repair

## Exact native Lean failure

The attempted application of `Matrix.isUnit_nonsing_inv_det`/`Matrix.det_nonsing_inv` at source line 62 is invalid: the resolved term is an equality `det(G⁻¹) = Ring.inverse (det G)`, not a function accepting an `IsUnit` argument. Its failure left `det(G⁻¹) ≠ 0` unproved, so a later `mul_ne_zero` failed.

## Revised proof

From `actualGram_posDef` obtain `det G ≠ 0` and hence `IsUnit (det G)`. Reuse Mathlib's already compiler-verified `Matrix.mul_nonsing_inv` to get `G · G⁻¹ = 1`; `Matrix.det_mul` implies `det G · det(G⁻¹) = 1`. If `det(G⁻¹) = 0`, this would force `0 = 1`. Therefore `det(G⁻¹) ≠ 0`. Conclude `det(G⁻¹ V) ≠ 0` using the previously certified `vandermonde_det_ne_zero`.

No new axiom, `sorry`, additional hypothesis or arithmetic Witness. No assistant-side Lean compilation. The Windows runner recompiles only the repaired file and any uncertified/invalidation-sensitive dependents, reusing earlier certified sources.

## Paragraph checkpoint

Retained: `PaperBlueprint/ParagraphCheckpoint.lean`, `PARAGRAPH_INTEGRATION_CHECKPOINT_20261024.md` and CSV ledgers. The 18 selected manuscript paragraph clauses are a typed-in-Lean integration checkpoint, *not* 18 completed proofs or full manuscript formalization. Promotion to a compiler-certified checkpoint requires the user-run output.
