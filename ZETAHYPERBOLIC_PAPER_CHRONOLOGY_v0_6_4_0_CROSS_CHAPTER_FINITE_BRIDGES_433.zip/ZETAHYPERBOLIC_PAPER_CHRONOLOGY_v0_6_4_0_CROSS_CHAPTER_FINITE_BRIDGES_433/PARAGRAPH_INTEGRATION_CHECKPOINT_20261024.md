# Paragraph integration checkpoint — 24 October 2026

## Native Lean compilation boundary

**Last actual user-confirmed result:** 120/120 modules `RESULT=PASS`, 0 compiled / 120 reused. Includes 7 elaborated blueprint files plus 113 proof/candidate source files. It does **not** certify the whole 52-page paper. The v0.6.2.0 attempt failed in `Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic.lean`; the v0.6.2.1 correction did not compile: Mathlib 4.33 resolved its proposed lemma as an equality rather than a function, so this package instead proves nonvanishing of `det(G⁻¹)` from `G · G⁻¹ = 1` and `det(G · G⁻¹) = det(G)det(G⁻¹)`. The native compiler must still check the repair. No assistant-side Lean compilation is claimed.

## Checkpoint definition

The new source `PaperBlueprint/ParagraphCheckpoint.lean` explicitly binds **18 selected printed subclaim/paragraph clauses** to typed Lean propositions, grouped under the **51 numbered items** already indexed in `PaperBlueprint.Inventory`. A paragraph is **integrated in Lean** only if its proposition elaborates under the user's compiler. This is the *minimal checkpoint*, not proof certification. The 18 clauses are selectively drawn from Sections 2–6 and do not purport to exhaust all typographic paragraphs of the PDF.

Stages:

- `typedUnproved`: mathematics is stated as a `Prop` and compiles, but no proof is provided.
- `provedFragment`: the specific finite-generator or even-pole identity has a checked theorem; the entire manuscript theorem is not claimed.
- `conditionalTransfer`: the theorem follows from the explicitly unconstructed `EffectiveWitness` assumption. It is not an unconditional irrationality proof.
- `NUMBERED_ITEM_INVENTORIED_ONLY`: printed item appears in the ledger, but its entire statement is not yet a Lean proposition.

**Completion gate:** native Lean 4.33 reports `CHECK_PASS=PaperBlueprint\ParagraphCheckpoint` or `FROZEN_REUSED=PaperBlueprint\ParagraphCheckpoint` and prints `PARAGRAPH_CHECKPOINT=CLAUSES_ELABORATED_NOT_FULL_PAPER`. This certifies that all 18 selected Prop expressions elaborate. Full-paper completion still requires proof of all legitimate claims, corrections for false printed assertions, and every remaining analytic/p-adic bridge.

## What is already source linked

- §2.2–2.3: generator pullback/reflection/difference proof fragments.
- §3.3: three separate unproved exact PDF obligations: all nonprincipal minors, Carleman determinacy, actual spectral inertia.
- §3.7: all-order actual Turanian target.
- §3.8: actual Gram/pole-kernel cyclic determinant and root-locus goals; v0.6.2 proof remains pending native compiler confirmation.
- §4.1: finite relative pole-kernel separation, **not** uniform `exp(-11.411 K)`.
- §4.4–4.5: effective Witness existence and full unconditional target are separate; only the conditional theorem is proved so far.
- §5.1–5.2: 2D integral, full infinite Krein tail, both rational sign cones are *unproved*.
- §5.4: printed simple even-pole formula has a certified algebraic endpoint.
- §6.8 and §6.15: three-term nonvanishing and universal odd-beta transcendence are merely typed goals, NOT proved.

## Remaining safeguards

The 120 previously user-certified Lean modules and both newly passed v0.6.2 modules (`Corollary_3_6_Actual_Reciprocal_Moment_Growth` and `Theorem_3_7_Primitive_Scale_Turanian`) are untouched byte-for-byte. This repair changes only the previously failing cyclic-determinant source; the full checkpoint and order/dependency manifest remain unchanged. The user compiler alone can promote the repaired proof and dependents to PASS.

`Corollary 3.5`, `Corollary 3.6` are still treated as requiring paper corrections. A §5 finite Krein truncation does not prove an infinite-tail bound. `Conjecture 4.11` remains conjectural. No new axiom, sorry, admission, or Witness existence theorem is introduced.

Run the root `run.cmd proofs` to compile the new checkpoint before v0.6.2 proof candidates. `run.cmd blueprints` verifies only the eight blueprint/ledger files (not the six v0.6.2 proof candidates); in that mode a checkpoint can be certified even when later proof modules fail. Preserve previous user-cache PASS stamps.
