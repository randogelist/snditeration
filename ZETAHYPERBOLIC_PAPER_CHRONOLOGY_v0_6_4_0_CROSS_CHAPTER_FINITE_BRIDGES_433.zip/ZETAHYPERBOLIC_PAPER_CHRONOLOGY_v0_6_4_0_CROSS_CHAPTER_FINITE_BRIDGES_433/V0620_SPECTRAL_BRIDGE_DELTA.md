# v0.6.2.0 — actual Christoffel–Darboux spectral bridge

**Baseline user compiler:** `RESULT=PASS`, `BUILD_FROZEN_REUSED=120` with
all eight v0.5 theorem candidates and seven blueprint files accepted.
The original 120 `.lean` sources are copied BYTE-FOR-BYTE unchanged.

This new package adds six proof modules (five mathematics + one aggregator).
Primary result: the exact `G` and `V` from the actual infinite real-s moment
construction satisfy

```
det(I+t G^{-1} M) = det(I+t diag(gamma) V^T G^{-1} V).
```

It proves polynomial equality, equivalence of the real zero loci, and an
unconditional *finite* positive kernel gap. It also supplies new finite
reciprocal-moment and normalization-invariant Turanian identities.

Caution: proof candidates require USER NATIVE Lean 4.33 compilation to
be certified. At packaging time, no assistant-side Lean compilation
is performed. These are not the paper's still-open K-uniform exponential
spectral bound or p-adic witness.

Still OPEN: PaperBlueprint.Section03.allNonprincipalMinors,
PaperBlueprint.Section03.stieltjesDeterminate,
PaperBlueprint.Section03.actualSpectralSignature,
full higher derivative actual Turanian, §4 complete prime-sum certificate,
§5 infinite Krein positivity/control, and §6 several L-value targets.

Runner: one root `run.cmd` without args for all 126 in pass-once mode;
`blueprints` for its seven precompiled declarations; `full` forces rebuild.
