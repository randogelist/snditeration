# v0.6.4.0 — First cross-chapter §3.9 × §5.1 × §5.2 exact finite proofs

**Previous Windows compiler checkpoint:** 132/132 source modules, all PASS; all 132 frozen .lean sources remain byte-for-byte unchanged. Only the user native Windows Lean 4.33.0 may certify these six new source modules. This assistant has NOT compiled Lean.

## Genuine new proof targets

1. **§3.9, p.13:** exact factorizations of five Fekete character numerator polynomials, and positivity for 0<z<1. This is not a proof of the infinite Dirichlet kernel/Hurwitz hyperbolicity.
2. **§5.1, pp.22–23:** exact ℚ-valued divided-difference moment symmetry and polynomial pencil entry symmetry at every finite matrix size. The double integral identity of printed equation (5.2) remains open.
3. **§5.2, pp.23–24:** universally quantified six-mode finite signed-Krein pairing, including correct 1/720 ↔ 1/1440 factors, and **equality of the actual pre-existing `weightSevenTruncation c M` matrix with its exact plus/minus finite Krein decomposition**, for arbitrary coefficients c and finite M. This does NOT prove a uniform infinite-tail bound or construct both sign cones.
4. **PaperBlueprint.ProofCheckpointV064:** three corresponding fragment-level Prop targets are proved, and conjoined with the previous six checked paragraph fragments. Nine subclauses have proof candidates, NOT nine complete PDF numbered theorems.
5. **PAPER_CHRONOLOGICAL_EXTENSION_12:** imports all new proofs in chronological order and prints axiom dependencies.

## Completion boundary

- `FULL_PAPER=NOT_PROVED`; §§4.4/4.5 arithmetic witness, 2D ζ(7) integral, §5.2 infinite Krein series, §3.3 all nonprincipal minors, §3.3 Carleman, and §3.3 spectral eigenvalue count are not established.
- One immutable old 132-source manifest and separate hashes of six candidate files are included.
- `run.cmd proofs` checks only new or invalidated source modules, prints exact olean/source-stamp certificates for all six additions; `run.cmd full` forces a rebuild. Old modules are *not* recompiled without invalidation.
