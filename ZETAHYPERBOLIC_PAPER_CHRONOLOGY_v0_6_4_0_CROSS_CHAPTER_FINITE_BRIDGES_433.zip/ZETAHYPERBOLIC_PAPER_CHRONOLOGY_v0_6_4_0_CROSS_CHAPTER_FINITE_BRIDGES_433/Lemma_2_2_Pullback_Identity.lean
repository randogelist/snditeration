import Zetahyperbolic.Section2Checked

/-!
# Lemma 2.2 — Pullback identity (PDF pp. 4–5)

The generator identities are already proved in `Zetahyperbolic.Section2Checked`.
Here they are assembled into a single statement on every finite polynomial +
simple negative-square pole decomposition, which models the domain of Definition 2.1. An additional representation
bridge would be needed to assert direct syntactic equality in `RatFunc`. The pullback formula on a decomposition is the explicit
coefficientwise evaluation of `τ_X(x^(2k+1) * R(-x²))` after partial fractions.

No additional mathematical hypotheses beyond k ≥ 1. This is not a claim that
an arbitrary Lean rational-function expression is definitionally identical
to its partial-fraction normal form; that normalization lives in Section2Checked.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperChronology.Section2
open Zetahyperbolic

/-- The τ-pullback of the moment-functional basis coefficients. The terms
implement the displayed polynomial-division identity in Lemma 2.2. -/
def tauPullbackOnDecomposition (k : ℕ) (R : RatMomentElem) : ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
    C (R.polyPart.coeff e * ((-1 : ℚ) ^ e * tauMonomial k (2 * e + 2 * k + 1)))) +
  (∑ j ∈ Finset.Icc 1 R.maxPole,
    C (R.poleRes j) *
      (C (-tauMonomial k (2 * k - 1)) -
       C ((j : ℚ) ^ (2 * k) / 2) *
         (tauPolePoly k (j : ℤ) + tauPolePoly k (-(j : ℤ)))))

/-- The exact equality of the two linear functionals on every allowed
finite partial-fraction decomposition (paper equation (2.5)). -/
theorem lemma_2_2_pullback (k : ℕ) (hk : 1 ≤ k) (R : RatMomentElem) :
    muFunctionalPoly k R = tauPullbackOnDecomposition k R := by
  classical
  unfold muFunctionalPoly tauPullbackOnDecomposition
  congr 1
  · apply Finset.sum_congr rfl
    intro e _
    rw [pullback_identity_monomial k e hk]
  · apply Finset.sum_congr rfl
    intro j hj
    have hjpos : 1 ≤ j := (Finset.mem_Icc.mp hj).1
    rw [pullback_identity_pole k j hk hjpos]

/-- First displayed generator case of Lemma 2.2: monomials. -/
theorem lemma_2_2_monomial (k e : ℕ) (hk : 1 ≤ k) :
    muMonomial k e = (-1 : ℚ) ^ e * tauMonomial k (2 * e + 2 * k + 1) :=
  pullback_identity_monomial k e hk

/-- Second displayed generator case of Lemma 2.2: simple poles. -/
theorem lemma_2_2_pole (k j : ℕ) (hk : 1 ≤ k) (hj : 1 ≤ j) :
    muPolePoly k j =
      C (-tauMonomial k (2 * k - 1)) -
      C ((j : ℚ) ^ (2 * k) / 2) *
        (tauPolePoly k (j : ℤ) + tauPolePoly k (-(j : ℤ))) :=
  pullback_identity_pole k j hk hj

end PaperChronology.Section2

#print axioms PaperChronology.Section2.lemma_2_2_pullback
