import Theorem_3_3_Four_Atom_General_Minors
import Mathlib.Tactic

/-!
# PDF Theorem 3.3 — four-atom translated 3×3 Hankel determinants

For four positive, pairwise distinct atoms, the order-three determinant
is a sum of four strictly positive squared-Vandermonde terms. The proof
is exact polynomial algebra: no spectral approximation or arithmetic witness.
The extension still concerns the finite-atomic model, not the actual infinite
measure's all-minor strict total positivity.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.FourAtomic

open PaperChronology.Theorem3_3.DiscreteSamples (hankelDet3)

set_option maxHeartbeats 2000000

/-- Exact 3×3 Hankel determinant for a four-atomic moment functional:
four three-element subsets, each contributing one Vandermonde square. -/
theorem four_atom_det3 (a b c d u v w z : ℝ) :
    hankelDet3
      (fourMoment a b c d u v w z 0)
      (fourMoment a b c d u v w z 1)
      (fourMoment a b c d u v w z 2)
      (fourMoment a b c d u v w z 3)
      (fourMoment a b c d u v w z 4) =
      a * b * c * (u - v) ^ 2 * (u - w) ^ 2 * (v - w) ^ 2 +
      a * b * d * (u - v) ^ 2 * (u - z) ^ 2 * (v - z) ^ 2 +
      a * c * d * (u - w) ^ 2 * (u - z) ^ 2 * (w - z) ^ 2 +
      b * c * d * (v - w) ^ 2 * (v - z) ^ 2 * (w - z) ^ 2 := by
  simp only [hankelDet3, fourMoment, pow_zero, pow_one]
  ring

/-- The determinant formula remains exact after any natural-number shift. -/
theorem four_atom_det3_shift
    (a b c d u v w z : ℝ) (n : ℕ) :
    hankelDet3
      (fourMoment a b c d u v w z (n + 0))
      (fourMoment a b c d u v w z (n + 1))
      (fourMoment a b c d u v w z (n + 2))
      (fourMoment a b c d u v w z (n + 3))
      (fourMoment a b c d u v w z (n + 4)) =
      a * b * c * (u * v * w) ^ n * (u - v) ^ 2 * (u - w) ^ 2 * (v - w) ^ 2 +
      a * b * d * (u * v * z) ^ n * (u - v) ^ 2 * (u - z) ^ 2 * (v - z) ^ 2 +
      a * c * d * (u * w * z) ^ n * (u - w) ^ 2 * (u - z) ^ 2 * (w - z) ^ 2 +
      b * c * d * (v * w * z) ^ n * (v - w) ^ 2 * (v - z) ^ 2 * (w - z) ^ 2 := by
  rw [fourMoment_shift a b c d u v w z n 0,
      fourMoment_shift a b c d u v w z n 1,
      fourMoment_shift a b c d u v w z n 2,
      fourMoment_shift a b c d u v w z n 3,
      fourMoment_shift a b c d u v w z n 4]
  rw [four_atom_det3]
  simp only [mul_pow]
  ring

/-- Each three-atom Vandermonde summand has a positive sign whenever
masses are positive and the three nodes are distinct and positive. -/
private theorem tripleTerm_pos
    (a b c u v w : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (hv : 0 < v) (hw : 0 < w)
    (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
    0 < a * b * c * (u * v * w) ^ n *
      (u - v) ^ 2 * (u - w) ^ 2 * (v - w) ^ 2 := by
  have hp : 0 < (u * v * w) ^ n :=
    pow_pos (mul_pos (mul_pos hu hv) hw) n
  have hUV : 0 < (u - v) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv)
  have hUW : 0 < (u - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huw)
  have hVW : 0 < (v - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr hvw)
  exact mul_pos (mul_pos (mul_pos (mul_pos (mul_pos
    (mul_pos ha hb) hc) hp) hUV) hUW) hVW

/-- Every translated 3×3 Hankel determinant of the positive four-atomic
measure is strictly positive. -/
theorem four_atom_det3_shift_pos
    (a b c d u v w z : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d)
    (hu : 0 < u) (huv : u < v) (hvw : v < w) (hwz : w < z) :
    0 < hankelDet3
      (fourMoment a b c d u v w z (n + 0))
      (fourMoment a b c d u v w z (n + 1))
      (fourMoment a b c d u v w z (n + 2))
      (fourMoment a b c d u v w z (n + 3))
      (fourMoment a b c d u v w z (n + 4)) := by
  rw [four_atom_det3_shift]
  have hv : 0 < v := lt_trans hu huv
  have hw : 0 < w := lt_trans hv hvw
  have hz : 0 < z := lt_trans hw hwz
  have huw : u < w := lt_trans huv hvw
  have huz : u < z := lt_trans huw hwz
  have hvz : v < z := lt_trans hvw hwz
  have h1 := tripleTerm_pos a b c u v w n ha hb hc
    hu hv hw (ne_of_lt huv) (ne_of_lt huw) (ne_of_lt hvw)
  have h2 := tripleTerm_pos a b d u v z n ha hb hd
    hu hv hz (ne_of_lt huv) (ne_of_lt huz) (ne_of_lt hvz)
  have h3 := tripleTerm_pos a c d u w z n ha hc hd
    hu hw hz (ne_of_lt huw) (ne_of_lt huz) (ne_of_lt hwz)
  have h4 := tripleTerm_pos b c d v w z n hb hc hd
    hv hw hz (ne_of_lt hvw) (ne_of_lt hvz) (ne_of_lt hwz)
  exact add_pos (add_pos (add_pos h1 h2) h3) h4

end PaperChronology.Theorem3_3.FourAtomic

#print axioms PaperChronology.Theorem3_3.FourAtomic.four_atom_det3
#print axioms PaperChronology.Theorem3_3.FourAtomic.four_atom_det3_shift_pos
