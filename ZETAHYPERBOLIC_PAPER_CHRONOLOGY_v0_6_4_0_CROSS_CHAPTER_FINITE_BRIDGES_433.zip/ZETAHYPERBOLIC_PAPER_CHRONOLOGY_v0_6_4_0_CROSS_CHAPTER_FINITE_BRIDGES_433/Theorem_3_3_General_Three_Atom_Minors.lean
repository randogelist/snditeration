import Theorem_3_3_Shifted_Atomic_Gram_Minors
import Mathlib.Tactic

/-!
# PDF Theorem 3.3(1): arbitrary shifted 2×2 minors for three positive atoms

Unlike the consecutive-principal-minor identities already certified, this
unconditional model controls all 2×2 Hankel minors with independent positive
row/column gaps. The proof is an exact three-pair Cauchy–Binet/Vandermonde
expansion. It is a finite-atomic model, not the complete continuous-moment
statement of the manuscript.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.GeneralAtomic

open PaperChronology.Theorem3_3.DiscreteSamples
open PaperChronology.Theorem3_3.ShiftedAtomic

/-- The exact generalized 2×2 determinant of the three-atomic moment sequence.
The indices are `n, n+i, n+j, n+i+j`. -/
theorem three_atom_general_minor_factor
    (a b c u v w : ℝ) (n i j : ℕ) :
    threeMoment a b c u v w (n + 0) *
        threeMoment a b c u v w (n + (i + j)) -
      threeMoment a b c u v w (n + i) *
        threeMoment a b c u v w (n + j) =
      a * b * (u * v) ^ n * ((u ^ i - v ^ i) * (u ^ j - v ^ j)) +
      a * c * (u * w) ^ n * ((u ^ i - w ^ i) * (u ^ j - w ^ j)) +
      b * c * (v * w) ^ n * ((v ^ i - w ^ i) * (v ^ j - w ^ j)) := by
  rw [threeMoment_shift a b c u v w n 0,
      threeMoment_shift a b c u v w n (i + j),
      threeMoment_shift a b c u v w n i,
      threeMoment_shift a b c u v w n j]
  simp only [threeMoment, pow_add, pow_zero, mul_pow, mul_one]
  ring

/-- Every order-two minor with increasing row and column indices is strictly
positive for any three *ordered positive* atomic locations, with positive masses.
The shifts and gaps are arbitrary natural numbers, not fixed to one. -/
theorem three_atom_general_minor_pos
    (a b c u v w : ℝ) (n i j : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (huv : u < v) (hvw : v < w)
    (hi : 0 < i) (hj : 0 < j) :
    0 < threeMoment a b c u v w (n + 0) *
          threeMoment a b c u v w (n + (i + j)) -
        threeMoment a b c u v w (n + i) *
          threeMoment a b c u v w (n + j) := by
  rw [three_atom_general_minor_factor]
  have hv : 0 < v := lt_trans hu huv
  have hw : 0 < w := lt_trans hv hvw
  have huw : u < w := lt_trans huv hvw
  have hi0 : i ≠ 0 := Nat.ne_of_gt hi
  have hj0 : j ≠ 0 := Nat.ne_of_gt hj
  have hUV_i : u ^ i < v ^ i := pow_lt_pow_left₀ huv hu.le hi0
  have hUV_j : u ^ j < v ^ j := pow_lt_pow_left₀ huv hu.le hj0
  have hUW_i : u ^ i < w ^ i := pow_lt_pow_left₀ huw hu.le hi0
  have hUW_j : u ^ j < w ^ j := pow_lt_pow_left₀ huw hu.le hj0
  have hVW_i : v ^ i < w ^ i := pow_lt_pow_left₀ hvw hv.le hi0
  have hVW_j : v ^ j < w ^ j := pow_lt_pow_left₀ hvw hv.le hj0
  have hUV : 0 < (u ^ i - v ^ i) * (u ^ j - v ^ j) :=
    mul_pos_of_neg_of_neg (sub_neg.mpr hUV_i) (sub_neg.mpr hUV_j)
  have hUW : 0 < (u ^ i - w ^ i) * (u ^ j - w ^ j) :=
    mul_pos_of_neg_of_neg (sub_neg.mpr hUW_i) (sub_neg.mpr hUW_j)
  have hVW : 0 < (v ^ i - w ^ i) * (v ^ j - w ^ j) :=
    mul_pos_of_neg_of_neg (sub_neg.mpr hVW_i) (sub_neg.mpr hVW_j)
  have hab : 0 < a * b * (u * v) ^ n *
        ((u ^ i - v ^ i) * (u ^ j - v ^ j)) :=
    mul_pos (mul_pos (mul_pos ha hb) (pow_pos (mul_pos hu hv) n)) hUV
  have hac : 0 < a * c * (u * w) ^ n *
        ((u ^ i - w ^ i) * (u ^ j - w ^ j)) :=
    mul_pos (mul_pos (mul_pos ha hc) (pow_pos (mul_pos hu hw) n)) hUW
  have hbc : 0 < b * c * (v * w) ^ n *
        ((v ^ i - w ^ i) * (v ^ j - w ^ j)) :=
    mul_pos (mul_pos (mul_pos hb hc) (pow_pos (mul_pos hv hw) n)) hVW
  exact add_pos (add_pos hab hac) hbc

/-- Strict log-convexity of every translated block of this positive
three-atomic moment sequence, now as a corollary of *all* 2×2 minors. -/
theorem three_atom_strict_logconvex
    (a b c u v w : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (huv : u < v) (hvw : v < w) :
    (threeMoment a b c u v w (n + 1)) ^ 2 <
      threeMoment a b c u v w (n + 0) *
        threeMoment a b c u v w (n + 2) := by
  have h := three_atom_general_minor_pos a b c u v w n 1 1
    ha hb hc hu huv hvw (by norm_num) (by norm_num)
  have hsum : n + (1 + 1) = n + 2 := by omega
  rw [hsum] at h
  have hmul : threeMoment a b c u v w (n + 1) *
      threeMoment a b c u v w (n + 1) =
      (threeMoment a b c u v w (n + 1)) ^ 2 := by ring
  rw [hmul] at h
  exact sub_pos.mp h

end PaperChronology.Theorem3_3.GeneralAtomic

#print axioms PaperChronology.Theorem3_3.GeneralAtomic.three_atom_general_minor_factor
#print axioms PaperChronology.Theorem3_3.GeneralAtomic.three_atom_general_minor_pos
#print axioms PaperChronology.Theorem3_3.GeneralAtomic.three_atom_strict_logconvex
