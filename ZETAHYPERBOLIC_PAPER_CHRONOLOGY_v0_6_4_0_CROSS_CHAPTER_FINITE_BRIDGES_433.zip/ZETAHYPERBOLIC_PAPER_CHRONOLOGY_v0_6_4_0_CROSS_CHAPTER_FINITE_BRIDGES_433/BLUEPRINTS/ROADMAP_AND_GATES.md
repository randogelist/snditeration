# Whole-paper proof obligations — chronological dependency graph

PDF: 52 pages, 51 numbered items (46 proof-relevant), 4 remarks, 1 conjecture.
Compiler source baseline: 105/105 USER PASS in v0.4.7.2. Another 8 from
v0.5.0 are candidate/pending final PASS. This release adds 7 blueprint
source modules without changing any of the original 113 Lean source files.

**Read `SECTION_02.md` through `SECTION_06.md` for each printed item, exact
unproved closure gate and chronological prerequisite.** The generated Lean
`PaperBlueprint.Inventory.inventory` mirrors the 51 rows.

## High-priority critical path

    Full §2 RatFunc domain normalization [independent]
      ↓
    §3.3 nonprincipal real-s total positivity + Carleman
      ↓
    §3.3 actual spectral inertia + §3.4 full Cauchy interlacing
      ↓
    §3.7 all-order Turan + §3.8 CD/Jacobi derivative
      ↓
    §4.1 corrected abstract arithmetic transfer
      ├─ §4.3 p-adic root-free disk
      ├─ §4.4 prime normalization / ϵ=1/2500 decay
      └─ §4.4 spectral ρ=11.411 estimate
                   ↓
             EffectiveWitness existence
                   ↓
          fixed conditional 25687 transfer (already in Lean)

    §5.1 actual double-integral identities
      ↓
    §5.2 uniform *infinite* Krein tail + both sign cones
      ↓
    §5.6 prime sums + §5.7 simultaneous double poles
      ↓
    §6.1–6.18 independent multiweight analytic/p-adic bridges

An unproved infinity-uniform statement cannot be disguised as a finite
`Certificate` field. A finite witness is acceptable only if a **terminating
checker and an already-proved unconditional universal transfer** are supplied.

## Known manuscript corrections / mathematical alerts

- Printed 3.5 J-fraction: invalid normalization, even at rank one; corrected theorem required.
- Printed 3.6: finite support implies zero higher-order Hankel determinants;
  'strictly positive all orders' cannot be the final theorem; inequality bounds need correction.
- 5.2(3) finite-mode elimination does not eliminate infinite negative tail.
- 4.10 zero pinching does not on its own prove a free-energy phase transition.
- 6.10 the ratio >581 calculation needs an upper (not lower) decay-rate control.
- Conjecture 4.11 remains labeled conjectural; it is not a mandatory proven theorem.

## Trust / scope

New `.lean` files contain Prop definitions for *selected* strong targets,
plus executable inventory of ALL 51 printed numbered items. A `def : Prop`
is NOT a proof of the proposition. Three downstream theorems in
`PaperBlueprint.All` restate previously proven conditional/generator cases;
they are not newly closed manuscript theorems. No local Lean compilation.
