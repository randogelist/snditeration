# CHAPTER 6 — PDF theorem-by-theorem formalization contract

Source: uploaded 52-page PDF dated 21 October 2026; statuses are from v0.5.0.6 source/PDF alignment review.
Blueprint declarations compile as names and unproved `Prop` goals; **compilation is not proof of those goals**.

| PDF | Printed item | Status | Existing Lean source | Remaining exact closure | Depends on |
|---|---|---|---|---|---|
| 6.1 | Theorem — Divided difference p-adic valuation | outstanding | None | Actual p-adic valuations of two-variable moments | 5.1 |
| 6.2 | Theorem — Simultaneous Beukers zeta6 zeta7 | outstanding | None | Mellin identity and quantitative denominator certificate | 5.1, 6.1 |
| 6.3 | Theorem — q-adic nonvanishing and positive cone | inProgress | Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7 | Full q-adic nonvanishing and infinite positive-cone realization | 5.2, 6.1 |
| 6.4 | Theorem — Character-Vandermonde beta4 cancellation | inProgress | Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4 | Full beta4 functional and character pole lattice | 3.9 |
| 6.5 | Theorem — beta4 q-adic nonvanishing | outstanding | None | Unconditional q-adic valuation of beta4 determinant | 6.4 |
| 6.6 | Theorem — General multiweight positive pencil | outstanding | None | General multiweight determinant and positivity | 3.1, 5.1 |
| 6.7 | Theorem — Multiweight Krein decomposition | outstanding | None | Full infinite analytic tail control | 6.6, 5.2 |
| 6.8 | Corollary — Three-term linear independence cone | outstanding | None | Simultaneous number theoretic conclusion | 4.5 |
| 6.9 | Theorem — Triple-pole multiweight Hankel | inProgress | Zetahyperbolic/Theorem_6_9_Triple_Pole_Hermite_Repair | Bridge finite Hermite identity to whole arithmetic theorem | 5.7 |
| 6.10 | Theorem — Universal potential-gap conservation | inProgress | Zetahyperbolic/Theorem_6_10_Finite_Determinant_Identity | Asymptotic potential identity and analytic growth | 4.1, 4.6, 5.1 |
| 6.11 | Theorem — Distribution growth / 2-adic obstruction | outstanding | None | Global algebraic and 2-adic proof | 6.1, 6.10 |
| 6.12 | Theorem — Full dimension sign-flip restoration | outstanding | None | Actual construction and positivity | 6.7 |
| 6.13 | Theorem — Central-factorial secant identity | outstanding | None | General differential identity | 2.2 |
| 6.14 | Theorem — Even-pole scaling and coupled pencils | outstanding | None | Full arbitrary-weight coupling | 6.13 |
| 6.15 | Theorem — Arithmetic transcendence/rank-one | outstanding | None | Full arithmetic and measure-theoretic conclusion | 6.14 |
| 6.16 | Theorem — Multiweight zeta-beta pencil | inProgress | Zeta5Merge/Theorem6_16 | Analytic identity/actual integral bridge | 6.6, 6.14 |
| 6.17 | Theorem — Two-variable zeta-beta Krein | inProgress | Zeta5Merge/Theorem6_17 | Analytic positivity and infinite modes | 6.7, 6.16 |
| 6.18 | Theorem — Principal-minor 2-adic integrality | inProgress | Zeta5Merge/Theorem6_18 | Global p-adic estimates, height | 6.16, 6.17 |

## Work order and proof contracts

1. **6.1–6.3:** complete 2D moment local valuations, simultaneous ζ6/ζ7 Mellin bridge, and uniform sign cones / q-adic determinant certificates.
2. **6.4–6.5:** full Dirichlet β character-Vandermonde positivity and q-adic nonvanishing.
3. **6.6–6.8:** multiweight positive pencils and entire infinite Krein modes; then prove the *actual* printed three-term independence cone.
4. **6.9–6.12:** complete triple-pole Hermite, energy conservation, distribution and 2-adic obstacles; audit 6.10 numerical ratio direction before attempting literal theorem.
5. **6.13–6.15:** central-factorial secant/differential identity, even-pole scale, and β(odd) transcendence, positive measure and rank-one Padé theorem.
6. **6.16–6.18:** genuine zeta-beta analytic pencil, two-variable Krein tails and full dyadic principal-minor law. The finite v0.5 lemma sources are only partial.
7. None of these are consequences of an unrelated weight-five finite Witness unless a **proved explicit transfer theorem** exists.

## Closing criterion

- Literal PDF proposition or mathematically corrected and explicitly marked replacement, fully expressed as a Lean theorem *type*.
- Proof without `sorryAx`, custom mathematical axioms, or hidden quantified hypotheses.
- Native Windows Lean 4.33 compiler PASS with exact source/import/toolchain stamps.
- Source theorem statement equivalence audit + independent arithmetical/analytical assumptions audited.
- Frozen certified modules reused unless dependencies truly invalidate them.
