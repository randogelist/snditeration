# CHAPTER 3 — PDF theorem-by-theorem formalization contract

Source: uploaded 52-page PDF dated 21 October 2026; statuses are from v0.5.0.6 source/PDF alignment review.
Blueprint declarations compile as names and unproved `Prop` goals; **compilation is not proof of those goals**.

| PDF | Printed item | Status | Existing Lean source | Remaining exact closure | Depends on |
|---|---|---|---|---|---|
| 3.1 | Theorem — Universal hyperbolicity and zero-free disk | nearComplete | MAIN_CHAIN_ASSEMBLED; Theorem_3_1_General_Odd_Weight_Endpoint | Exact agreement of every PDF normalization and root statement remains important | 2.5 |
| 3.2 | Proposition — Continuous hyperbolic pencil for all real s>1 | nearComplete | Proposition_3_2_Real_s_Moment_Integrability; Proposition_3_2_Continuous_Real_Weight_Pencil | Full printed odd-weight coincidence should be audited against exact definitions | 3.1 |
| 3.3 | Theorem — Total positivity, leading sign, universal signature | inProgress | Theorem_3_3_Actual_Continuous_Principal_Minors; Theorem_3_3_Actual_Diagonal_Sign_Counts; Theorem_3_3_Actual_Leading_Coefficient_Sign | All NONPRINCIPAL continuous Hankel minors; Carleman determinacy; spectral inertia multiplicity transfer | 3.2, 2.5 |
| 3.4 | Theorem — Root interlacing and Dodgson condensation | inProgress | Theorem_3_4_Actual_Principal_Pencil_Reality; Theorem_3_4_Dodgson_Four_By_Four; Theorem_3_4_Shifted_Dodgson_Jacobi | Full Cauchy interlacing of a compatible nested sequence; general-size Dodgson at actual polynomial roots | 3.1, 3.3 |
| 3.5 | Corollary — Stieltjes J-fraction | requiresCorrection | Corollary_3_5_Corrected_Schur_Fraction; PAPER_COUNTEREXAMPLES | Printed eq. (3.6) false at h=1; only corrected local Schur fraction candidate | 3.4 |
| 3.6 | Corollary — Reciprocal-root Stieltjes power sums | requiresCorrection | Corollary_3_6_Corrected_Finite_Atomic_Moments; Corollary_3_6_Reciprocal_Root_Moment_Bounds | Rank bound forces zero determinants above finite support; printed inequality reversed | 3.1 |
| 3.7 | Theorem — Turanian nonnegativity and Newton log concavity | inProgress | Theorem_3_7_All_Order_Turanian_Jets; Theorem_3_7_Real_Rooted_Polynomial_Turanian | Higher-derivative Wronskians; coefficient Newton equality cases and original Hankel polynomial | 3.1, 3.3 |
| 3.8 | Theorem — Christoffel-Darboux and Jacobi derivative | inProgress | Theorem_3_8_Actual_Christoffel_Darboux_Kernel | Weighted pole eigenvalue identity and analytic parameter derivative (3.8) | 3.1, 2.5 |
| 3.9 | Theorem — Hurwitz and Dirichlet hyperbolicity | inProgress | Zetahyperbolic/Section3Elementary | Full shifted positive measure and character-factorization for all listed conductors | 3.1 |
| 3.10 | Remark — Non-classicality of Hankel family | remark | None | Requires separate mathematical verification; not a theorem dependency | 3.4 |

## Work order and proof contracts

1. **3.3:** generalized Vandermonde positivity for arbitrary increasing row/column sets, then Andreief for the *actual* continuous weight; separately Stieltjes determinacy via a correct Carleman bound.
2. **3.3:** prove `actualSpectralSignature` from existing diagonal congruence with Sylvester inertia, including repeated eigenvalue multiplicities. No arithmetic Witness.
3. **3.4:** construct common Cholesky nested blocks, prove compatible Cauchy interlacing, then general-size Jacobi/Dodgson at actual pencil roots.
4. **3.5 & 3.6:** replace false printed claims: the finite J-fraction requires correct normalization and cyclicity; the reciprocal-root moment Hankel rank never exceeds its finite atom count; reverse the displayed bound.
5. **3.7:** transport all derivative orders and Newton coefficient/equality cases to the actual polynomial, not only the `m=1` polynomial jet.
6. **3.8:** prove weighted pole-kernel spectral equivalence and dominated differentiation in τ, i.e. the actual (3.8).
7. **3.9:** check every Hurwitz shifted density and Fekete factorization at conductor 3/4/5/8; certify exact correspondence with the rational functional.

## Closing criterion

- Literal PDF proposition or mathematically corrected and explicitly marked replacement, fully expressed as a Lean theorem *type*.
- Proof without `sorryAx`, custom mathematical axioms, or hidden quantified hypotheses.
- Native Windows Lean 4.33 compiler PASS with exact source/import/toolchain stamps.
- Source theorem statement equivalence audit + independent arithmetical/analytical assumptions audited.
- Frozen certified modules reused unless dependencies truly invalidate them.
