# CHAPTER 2 — PDF theorem-by-theorem formalization contract

Source: uploaded 52-page PDF dated 21 October 2026; statuses are from v0.5.0.6 source/PDF alignment review.
Blueprint declarations compile as names and unproved `Prop` goals; **compilation is not proof of those goals**.

| PDF | Printed item | Status | Existing Lean source | Remaining exact closure | Depends on |
|---|---|---|---|---|---|
| 2.1 | Definition — Order-s rational moment functional | nearComplete | Definition_2_1_Order_s_Rational_Moment_Functional; Zetahyperbolic/Section2Checked | Full RatFunc domain correspondence deserves continued audit | — |
| 2.2 | Lemma — Pullback identity | inProgress | Lemma_2_2_Pullback_Identity | Full arbitrary-rational-function presentation versus generator restrictions | 2.1 |
| 2.3 | Lemma — Reflection and difference identities | inProgress | Lemma_2_3_Reflection_And_Difference_Identities | Full statement domain and indexing match | 2.2 |
| 2.4 | Theorem — Canonical basis invariance | nearComplete | Theorem_2_4_Canonical_Basis_Invariance | No major mathematical gate identified in basis-invariance spine | 2.1 |
| 2.5 | Theorem — Lagrange pole diagonalization | nearComplete | Theorem_2_5_Lagrange_Pole_Diagonalization | No major gate identified for finite pencil factorization | 2.1, 2.4 |

## Work order and proof contracts

1. Prove the exact restricted-domain `RatFunc` normalization and uniqueness to transport generator algebra into the printed rational-function statement without changing the domain.
2. Check Definition 2.1 against actual coefficient functions on monomials and the negative-square pole lattice for all k and j.
3. Port and match Lemma 2.2 and 2.3 on the full allowed domain. The already-verified finite-decomposition theorems are isolated in `PaperBlueprint.Section02`.
4. Audit determinant `GL_h(ℚ)` and primitive normalization conventions for Theorems 2.4/2.5.

## Closing criterion

- Literal PDF proposition or mathematically corrected and explicitly marked replacement, fully expressed as a Lean theorem *type*.
- Proof without `sorryAx`, custom mathematical axioms, or hidden quantified hypotheses.
- Native Windows Lean 4.33 compiler PASS with exact source/import/toolchain stamps.
- Source theorem statement equivalence audit + independent arithmetical/analytical assumptions audited.
- Frozen certified modules reused unless dependencies truly invalidate them.
