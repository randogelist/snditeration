# CHAPTER 5 — PDF theorem-by-theorem formalization contract

Source: uploaded 52-page PDF dated 21 October 2026; statuses are from v0.5.0.6 source/PDF alignment review.
Blueprint declarations compile as names and unproved `Prop` goals; **compilation is not proof of those goals**.

| PDF | Printed item | Status | Existing Lean source | Remaining exact closure | Depends on |
|---|---|---|---|---|---|
| 5.1 | Theorem — Two-variable Beukers measure zeta7 | inProgress | Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7 | Actual 2D integral + diagonal/offdiagonal identities as printed | 2.1 |
| 5.2 | Theorem — Dual hyperbolicity and Krein-space decomposition | inProgress | Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil | Infinite tail and explicit rational-poly sign cones not proved from finite truncation alone | 5.1 |
| 5.3 | Proposition — Beta4 dual Beukers pencil | outstanding | None | Full beta4 integral and two-variable pencil | 5.1 |
| 5.4 | Theorem — Even pole pair cancellation | nearComplete | Theorem_5_4_Even_Pole_Pair_Cancellation | Simple-pole statement (5.5) matches verified algebraic endpoint | 2.2, 2.3 |
| 5.5 | Remark — Simple-pole limitation | remark | None | Scope clarification, not separate proof obligation | 5.4 |
| 5.6 | Theorem — Zeta7 prime sum integral/refinement | outstanding | None | Piecewise exact integration and p-adic refinement | 5.4 |
| 5.7 | Theorem — Double pole simultaneous zeta5/zeta6 | outstanding | None | q-adic nonvanishing and local valuation bound | 4.3 |

## Work order and proof contracts

1. **5.1:** prove absolute integrability, diagonal ζ(7)-harmonic and off-diagonal rational divided-difference identities for the actual `(0,1)²` measure.
2. **5.2:** prove positive CCT and real-rootedness, *infinite* Krein identity, uniform tail control, and both rational polynomial sign cones of all finite dimensions.
3. **5.3:** prove the β(4) positive 2D measure, exact moments and full dual pencil.
4. **5.4:** the already proved simple even-pole cancellation is exported by `PaperBlueprint.Section05`; do not generalize to higher pole order without additional definitions.
5. **5.6:** prove exact rational piecewise prime integral 453803/288000 and +1/3 inner valuation refinement.
6. **5.7:** prove q-adic nonvanishing and uniform local p-adic minors for the exact {1,ζ5,ζ6} double-pole determinant.

## Closing criterion

- Literal PDF proposition or mathematically corrected and explicitly marked replacement, fully expressed as a Lean theorem *type*.
- Proof without `sorryAx`, custom mathematical axioms, or hidden quantified hypotheses.
- Native Windows Lean 4.33 compiler PASS with exact source/import/toolchain stamps.
- Source theorem statement equivalence audit + independent arithmetical/analytical assumptions audited.
- Frozen certified modules reused unless dependencies truly invalidate them.
