# CHAPTER 4 — PDF theorem-by-theorem formalization contract

Source: uploaded 52-page PDF dated 21 October 2026; statuses are from v0.5.0.6 source/PDF alignment review.
Blueprint declarations compile as names and unproved `Prop` goals; **compilation is not proof of those goals**.

| PDF | Printed item | Status | Existing Lean source | Remaining exact closure | Depends on |
|---|---|---|---|---|---|
| 4.1 | Theorem — Spectral irrationality measure criterion | inProgress | Theorem_4_1_Spectral_Irrationality_Measure_Criterion; MAIN_CHAIN_IRRATIONALITY | Uniform index selection/bound quantifiers; theorem remains correctly conditional on actual sequence | 3.1 |
| 4.2 | Proposition — Algebraic degree-d transfer | outstanding | None | Resultant and height bounds for algebraic approximants | 4.1 |
| 4.3 | Proposition — p-adic ultrametric root-free disk | outstanding | None | Actual Cp/Zp polynomial transfer | 2.1 |
| 4.4 | Theorem — 11.411 norm bound and effective measure 25687 | inProgress | PAPER_WITNESS_ONLY; Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5 | Unconditional arithmetic decay witness AND spectral 11.411 estimate not established | 4.1, 3.1, 3.8 |
| 4.5 | Theorem — Linear forms b zeta5 + a zeta3 | outstanding | None | p-adic normalization; joint positive measure and 25687 quantitative bound | 4.1, 4.4 |
| 4.6 | Theorem — Two-sided determinants and coefficient heights | outstanding | None | Euler-Maclaurin; logarithmic equilibrium/Jensen; coefficient height | 3.1, 4.4 |
| 4.7 | Theorem — Macroscopic root collapse and separation | outstanding | None | Derive quantitative clustering from full 4.4 and 4.6 | 4.6, 4.4 |
| 4.8 | Proposition — Rational roots and cluster factor degree | outstanding | None | Depends on quantitative 4.4/4.7 and integer normalization | 4.4, 4.7 |
| 4.9 | Remark — Spectral variational bounds | remark | None | Requires asymptotic variational analysis | 4.4, 4.6 |
| 4.10 | Remark — Lee-Yang phase-transition claim | remark | None | Zero pinching alone does not establish free-energy nonanalyticity | 4.7 |
| 4.11 | Conjecture — Spectral variational limit | conjecture | None | Explicit conjecture; not a theorem to certify | 4.6 |

## Work order and proof contracts

1. **4.1:** prove all index-quantifier conditions of the abstract integer-polynomial transfer without requiring a special ζ(5) certificate.
2. **4.2/4.3:** formalize resultant height transfer and nonarchimedean polynomial root-free disk as independent theorems.
3. **4.4:** prove the exact arithmetic normalization/prime-sum decay and the **uniform** 11.411K spectral bound; these cannot be hidden as `EffectiveWitness` fields.
4. **4.5:** construct the coupled ζ(5)/ζ(3) positive density and p-adic normalization for all permitted a,b.
5. **4.6–4.8:** Euler–Maclaurin determinant profile, arcsine Jensen energy, heights, root collapse/separation and rational root exclusion.
6. Convert any *finite* witness into the universal family by a proved induction/exhaustion theorem and terminating checker; otherwise `Witness` existence remains unproved.
7. Remark 4.10 and Conjecture 4.11 are not silently certified. Root clustering alone does not prove nonanalytic free-energy limit.

## Closing criterion

- Literal PDF proposition or mathematically corrected and explicitly marked replacement, fully expressed as a Lean theorem *type*.
- Proof without `sorryAx`, custom mathematical axioms, or hidden quantified hypotheses.
- Native Windows Lean 4.33 compiler PASS with exact source/import/toolchain stamps.
- Source theorem statement equivalence audit + independent arithmetical/analytical assumptions audited.
- Frozen certified modules reused unless dependencies truly invalidate them.
