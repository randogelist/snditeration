import PAPER_CHRONOLOGICAL_EXTENSION_5
import Theorem_3_4_Actual_Principal_Pencil_Reality

/-!
# Exact PDF chronology: direct Theorems 3.3 and 3.4 (new manuscript layer)

This module imports the fully constructed continuous real-s and odd-weight
Hankel matrices. It proves all genuine principal Gram minors positive at all
orders, and ALL complex roots of all principal-minor determinant polynomials
real. No arithmetic witness or analytic positivity hypothesis is introduced.
The full all-index *nonprincipal* total positivity, and Cauchy interlacing of
successive minors, remain distinct open manuscript obligations.
-/

noncomputable section
namespace PaperChronology

/-- Theorem 3.3(1), actual continuous Hankel matrix: every finite-index
principal minor is strictly positive. -/
theorem paper_theorem_3_3_actual_principal_minors
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    0 < ((Proposition3_2.Gram.gram s p).submatrix choose choose).det :=
  Theorem3_3.ActualContinuousPrincipal.real_s_all_principal_minors_pos
    s p hs choose hinj

/-- Theorem 3.4(1), for all actual real-s principal determinant polynomials:
all of their complex roots have vanishing imaginary part. -/
theorem paper_theorem_3_4_actual_principal_roots_real
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Theorem3_4.ActualPrincipal.realSPrincipalPencil s p choose).detPolynomial = 0) :
    z.im = 0 :=
  Theorem3_4.ActualPrincipal.real_s_all_principal_minors_real_rooted
    s p hs choose hinj z hz

/-- The original odd-zeta version of the full principal-minor root theorem. -/
theorem paper_theorem_3_4_odd_zeta_actual_principal_roots_real
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Theorem3_4.ActualPrincipal.oddPrincipalPencil p choose).detPolynomial = 0) :
    z.im = 0 :=
  Theorem3_4.ActualPrincipal.odd_all_principal_minors_real_rooted
    p hp choose hinj z hz

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_actual_principal_minors
#print axioms PaperChronology.paper_theorem_3_4_actual_principal_roots_real
#print axioms PaperChronology.paper_theorem_3_4_odd_zeta_actual_principal_roots_real
