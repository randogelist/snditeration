import PAPER_CHRONOLOGICAL_EXTENSION_9
import Corollary_3_6_Actual_Reciprocal_Moment_Growth
import Theorem_3_7_Primitive_Scale_Turanian
import Theorem_3_8_Actual_Pole_Kernel_Determinant_Cyclic
import Theorem_3_8_Actual_Pole_Kernel_Zero_Locus
import Theorem_4_1_Actual_Pole_Kernel_Zero_Free

/-!
# Chronological extension 10: six file spectral-bridge jump

This file ensures every fresh mathematical source is imported together,
and no previously frozen source needs recompilation unless its imports
or toolchain change.  Newly established, subject to the user's compiler:
  * genuine finite reciprocal-root moment recurrence;
  * primitive scaling invariance of the all-degree Turan jet;
  * actual infinite-measure pole-kernel cyclic determinant identity;
  * exact correspondence of the genuine pencil and kernel zeros;
  * unconditional finite pole-kernel zero-free radius.

Still OPEN: full nonprincipal strict total positivity, Carleman uniqueness,
normalized eigenvalue sign multiplicities, higher-derivative Turan for the
actual polynomial, quantitative K-uniform gap, and arithmetic witness.
-/

#print axioms PaperChronology.Theorem3_8.ActualCyclicKernel.actual_pole_kernel_affine_det
#print axioms PaperChronology.Theorem3_8.ActualZeroLocus.actual_pencil_root_iff_kernel_zero
#print axioms PaperChronology.Theorem4_1.ActualKernelSeparation.actual_pole_kernel_zero_free
