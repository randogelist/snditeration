import PAPER_SECTION_02
import MAIN_CHAIN_ASSEMBLED
import Proposition_3_2_Continuous_Real_Weight_Pencil
import Proposition_3_2_Real_s_Weight_Finite_Layer
import Proposition_3_2_Real_s_Weight_Infinite_Series
import Proposition_3_2_Real_s_Gram_Measure
import Proposition_3_2_Real_s_Moment_Integrability
import Theorem_3_3_Spectral_Root_Sign_Correspondence
import Theorem_3_3_Pole_Signature_Counts

/-!
# Start of Section 3: Theorem 3.1 (general odd-weight spectral theorem)

Theorem 3.1 is already unconditional for every admissible k,m,N,K in the
assembled source: the analytic positive Gram representation is *constructed*.
The theorem includes full degree, invertible derivative, real roots excluding
ζ(2k+1), and an exact positive root-free radius. It does not claim distinct
roots, a uniform exp(-ρK) radius, or the later Section 3 assertions.

Proposition 3.2 now includes a proved positive and monotone finite series.
The infinite real-s series and density are now constructed and positive.
Its actual Gram measure is now constructed as a nonzero atomless measure.
The new integrability module proves this moment estimate from the two
verified odd-integer density families, giving an unconditional real-s Gram
positive-definiteness and spectral conclusion after user compilation. Theorem 3.3's spectral sign-to-root
correspondence is complete, while the alternating residue sign and exact
signature counts remain to be formalized.
-/

noncomputable section
namespace PaperChronology.Section3

/-- Theorem 3.1 of the paper for EVERY odd weight s=2k+1≥3. -/
theorem theorem_3_1_unconditional
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- The root-free disk has a root on its boundary and is not merely a bound
obtained from numerical experiments or an assumed spectral witness. -/
theorem theorem_3_1_exact_disk
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
        ¬ ManuscriptChain.General.ComplexRoot p z) ∧
      (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
        ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

/-- Full-rank derivative portion of PDF Proposition 3.2 for all real s. -/
theorem proposition_3_2_derivative_invertible
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    (PaperChronology.Proposition3_2.derivativeMatrix s p).det ≠ 0 :=
  PaperChronology.Proposition3_2.derivativeMatrix_det_ne_zero s p

/-- Spectral portion of PDF Proposition 3.2; A(s).PosDef is precisely the
pending infinite-weight integral bridge, not a premise on the MAIN_CHAIN. -/
theorem proposition_3_2_spectral_reduction
    (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) :
    ((PaperChronology.Proposition3_2.pencil s p A hA).detPolynomial).natDegree = p.h :=
  PaperChronology.Proposition3_2.exact_degree s p A hA hpos

/-- The finite real-s weight is positive without an analytic hypothesis. -/
theorem proposition_3_2_finite_weight_positive
    (s : ℝ) (N : ℕ) {y : ℝ} (hy : 0 < y) :
    0 < Proposition3_2.Analytic.shapeDensity s N y :=
  Proposition3_2.Analytic.shapeDensity_pos s N hy

/-- The complete real-s series is summable for each positive y and EVERY
real exponent s: analytic convergence of the exact PDF series is proved. -/
theorem proposition_3_2_series_converges
    (s : ℝ) {y : ℝ} (hy : 0 < y) :
    Summable (fun n => Proposition3_2.Analytic.exponentialTerm s n y) :=
  Proposition3_2.Analytic.summable_exponentialTerm s hy

/-- The normalized real-s weight of the PDF is strictly positive for s>1. -/
theorem proposition_3_2_infinite_weight_positive
    {s y : ℝ} (hs : 1 < s) (hy : 0 < y) :
    0 < Proposition3_2.Analytic.realWeight s y :=
  Proposition3_2.Analytic.realWeight_pos hs hy

/-- The PDF's prescribed real-s density and denominator ratio give a
nonzero moment measure, not a free analytic witness. -/
theorem proposition_3_2_actual_moment_measure_nonzero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    PaperChronology.Proposition3_2.Gram.momentMeasure s p ≠ 0 :=
  Proposition3_2.Gram.momentMeasure_nonzero s p hs

/-- The remaining integral estimate is stated locally; it is not imported
as a new premise into the unconditional manuscript chain. -/
theorem proposition_3_2_actual_gram_positive_of_integrable
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (hm : ∀ i j : Fin p.h,
      MeasureTheory.Integrable (fun t : ℝ => t ^ (i.val + j.val))
        (Proposition3_2.Gram.momentMeasure s p)) :
    (Proposition3_2.Gram.gram s p).PosDef :=
  Proposition3_2.Gram.gram_posDef_of_integrable s p hs hm

/-- PDF Proposition 3.2 — integrability of every moment of the actual
continuous real-s measure; no additional witness or hypothesis. -/
theorem proposition_3_2_all_moments_integrable
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (e : ℕ) :
    MeasureTheory.Integrable (fun t : ℝ => t ^ e)
      (Proposition3_2.Gram.momentMeasure s p) :=
  Proposition3_2.Integrability.integrable_momentMeasure s p hs e

/-- PDF Proposition 3.2 — ACTUAL real-s Hankel pencil: the Gram matrix is
strictly positive definite and its determinant has degree exactly h. -/
theorem proposition_3_2_unconditional_full_degree
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (Proposition3_2.Gram.gram s p).PosDef ∧
      (Proposition3_2.Gram.actualPencil s p).detPolynomial.natDegree = p.h := by
  exact ⟨Proposition3_2.Integrability.actualGram_posDef s p hs,
    Proposition3_2.Integrability.actualPencil_exact_degree s p hs⟩

/-- PDF Proposition 3.2 — all complex roots of the actual real-s determinant
are real, rather than roots of an arbitrary externally supplied Gram matrix. -/
theorem proposition_3_2_unconditional_real_rootedness
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Proposition3_2.Gram.actualPencil s p).detPolynomial = 0) :
    z.im = 0 :=
  Proposition3_2.Integrability.actualPencil_root_real s p hs z hz

/-- PDF Theorem 3.3: exact alternating-index counts in the weight-five
pole interval. Identifying the spectral inertia with these numbers requires
an additional *proof* of the pole-residue alternating signs (not an axiom). -/
theorem theorem_3_3_weight_five_pole_counts (n : ℕ) :
    Theorem3_3.PoleCounts.oddPoleCount (3 * n) (30 * n) = (27 * n) / 2 ∧
    Theorem3_3.PoleCounts.evenPoleCount (3 * n) (30 * n) = (27 * n + 1) / 2 :=
  Theorem3_3.PoleCounts.weightFive_pole_counts n

end PaperChronology.Section3

#check PaperChronology.Section3.theorem_3_1_unconditional
#check PaperChronology.Section3.theorem_3_1_exact_disk
#print axioms PaperChronology.Section3.theorem_3_1_unconditional

#check PaperChronology.Section3.proposition_3_2_derivative_invertible
#check PaperChronology.Section3.proposition_3_2_spectral_reduction
#check PaperChronology.Theorem3_3.root_below_iff_beta_pos
#check PaperChronology.Theorem3_3.root_above_iff_beta_neg
#print axioms PaperChronology.Section3.proposition_3_2_derivative_invertible
