# v0.5.0.4 — Exact pole-kernel matrix entries and cast fix

Compiler targets: `Theorem_3_8_Actual_Christoffel_Darboux_Kernel.lean`
and its import dependents. Previous successful modules are frozen; do not
recompile if the verified user-compiler source stamp is unchanged.

1. Replace the failed `conv_lhs` sum rearrangement with a three-step
   explicit `calc`: expand `Matrix.mul_apply`, distribute the finite sum
   by `Finset.sum_mul`, and commute the two indices with `Finset.sum_comm`.
2. Replace `rfl` for rational-power casting with `map_pow` and a
   `norm_cast` fallback in the pole-node evaluation-vector lemma.
3. No theorem statements, inputs, axioms, or frozen source modules modified.

Only your native Windows Lean 4.33.0 compiler is the authority. No Lean
compilation was performed locally; the new source is compiler-pending.
