import PAPER_CHRONOLOGICAL_EXTENSION
import Theorem_3_3_Shifted_Atomic_Gram_Minors
import Theorem_3_4_Dodgson_Four_By_Four

/-!
# Further unconditional Section 3 chronology

The preceding compilation checkpoint certified 86 modules (83 frozen,
three newly compiled). This module extends those results with translated
atomic Gram determinants and the exact order-four Dodgson sign law.
The single paper arithmetic witness remains confined to later conditional
endpoints. This extension assumes no witness.
-/

namespace PaperChronology

/-- Theorem 3.3 finite-atomic consequence: every translated order-three
Hankel determinant for three positive, distinct support points is positive. -/
theorem paper_theorem_3_3_shifted_three_atom_positive
    (a b c u v w : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (hv : 0 < v) (hw : 0 < w)
    (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
    0 < Theorem3_3.DiscreteSamples.hankelDet3
      (Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 0))
      (Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 1))
      (Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 2))
      (Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 3))
      (Theorem3_3.DiscreteSamples.threeMoment a b c u v w (n + 4)) :=
  Theorem3_3.ShiftedAtomic.three_atom_shifted_det_pos
    a b c u v w n ha hb hc hu hv hw huv huw hvw

/-- Theorem 3.4 finite order-four unconditional sign transfer. -/
theorem paper_theorem_3_4_dodgson_order_four
    (m0 m1 m2 m3 m4 m5 m6 : ℝ)
    (hcenter : 0 < m2 * m4 - m3 ^ 2)
    (hminor : Theorem3_4.Dodgson3.det3 m0 m1 m2 m3 m4 = 0) :
    Theorem3_4.Dodgson4.hankelDet4 m0 m1 m2 m3 m4 m5 m6 ≤ 0 :=
  Theorem3_4.Dodgson4.det4_nonpos_at_minor_root
    m0 m1 m2 m3 m4 m5 m6 hcenter hminor

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_shifted_three_atom_positive
#print axioms PaperChronology.paper_theorem_3_4_dodgson_order_four
