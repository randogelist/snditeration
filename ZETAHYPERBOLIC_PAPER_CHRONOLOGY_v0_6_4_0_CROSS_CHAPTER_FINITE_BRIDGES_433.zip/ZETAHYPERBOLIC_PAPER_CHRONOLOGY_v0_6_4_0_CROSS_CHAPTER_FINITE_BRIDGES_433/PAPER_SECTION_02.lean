import Definition_2_1_Order_s_Rational_Moment_Functional
import Lemma_2_2_Pullback_Identity
import Lemma_2_3_Reflection_And_Difference_Identities
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Zetahyperbolic.LagrangeBasis

/-!
# Section 2: all numbered PDF items, in their original order

Definition 2.1: the actual rational moment functional and the actual pencil.
Lemma 2.2: pullback on ALL finite polynomial + simple-pole decompositions.
Lemma 2.3: reflection/difference identities on each generator (thus linear span).
Theorem 2.4: change-of-basis invariance of primitive integer normalization.
Theorem 2.5: transformed affine pencil, its pole-diagonal slope and gamma ≠ 0.

All the conclusions below concern mathematical formulas *inside the actual
pencil*, not vacuous replacement structures. No witness is used in Section 2.
-/

noncomputable section
namespace PaperChronology.Section2

/-- The paper's Lagrange evaluation matrix is exactly the identity. -/
theorem theorem_2_5_lagrange_evaluation (N K : ℕ) :
    Zetahyperbolic.lagrangePoleEvaluationMatrix N K = 1 :=
  Zetahyperbolic.lagrangePoleEvaluationMatrix_eq_one N K

/-- Theorem 2.5 also forces the full-degree, nonzero determinant conclusion.
This implication holds for every index quadruple; admissibility is only needed
to connect its center to ζ(2k+1) in Theorem 3.1. -/
theorem theorem_2_5_exact_degree (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).natDegree = p.h ∧
      ManuscriptChain.Real.delta p ≠ 0 ∧
      (ManuscriptChain.Real.derivativeMatrix p).det ≠ 0 := by
  exact ⟨ManuscriptChain.PoleDiagonalization.delta_natDegree p,
    ManuscriptChain.PoleDiagonalization.delta_ne_zero p,
    ManuscriptChain.PoleDiagonalization.derivativeMatrix_det_ne_zero p⟩

end PaperChronology.Section2

#check PaperChronology.Section2.lemma_2_2_pullback
#check PaperChronology.Section2.lemma_2_3_all_generators
#check ManuscriptChain.BasisInvariance.theorem_2_4_constructed_for_manuscript
#check ManuscriptChain.PoleDiagonalization.theorem_2_5_lagrange_pole_diagonalization
#check PaperChronology.Section2.theorem_2_5_lagrange_evaluation
#check PaperChronology.Section2.theorem_2_5_exact_degree

#print axioms PaperChronology.Section2.theorem_2_5_exact_degree
