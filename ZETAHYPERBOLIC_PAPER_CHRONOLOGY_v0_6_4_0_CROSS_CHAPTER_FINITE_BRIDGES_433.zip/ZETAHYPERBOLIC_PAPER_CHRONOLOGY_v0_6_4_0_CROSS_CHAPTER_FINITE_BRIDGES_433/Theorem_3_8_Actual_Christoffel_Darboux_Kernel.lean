import Proposition_3_2_Real_s_Moment_Integrability
import Theorem_3_4_Actual_Principal_Pencil_Reality
import Mathlib.Tactic

/-!
# Theorem 3.8: the actual pole-lattice Christoffel-Darboux inverse Gram kernel

Define the kernel on the paper's EXACT negative-square pole Vandermonde
using the inverse of its ACTUAL positive real-s Gram matrix. Its matrix
factorization `Vᵀ G⁻¹ V` and its two-index finite sum are definitionally
proven for arbitrary h. There is no finite-atom substitution or new
moment hypothesis. The eigenvalue comparison is a separate bridge.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_8.ActualKernel
open PaperChronology.Proposition3_2

/-- Christoffel-Darboux finite matrix kernel on the actual pole lattice. -/
def poleKernel (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  (vandermonde p).transpose * (Gram.gram s p)⁻¹ * (vandermonde p)

/-- Precise double-index Christoffel-Darboux kernel identity. -/
theorem poleKernel_entries (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    (i j : Fin p.h) :
    poleKernel s p i j =
      ∑ a : Fin p.h, ∑ b : Fin p.h,
        vandermonde p a i * ((Gram.gram s p)⁻¹) a b * vandermonde p b j := by
  classical
  calc
    poleKernel s p i j =
        ∑ b : Fin p.h,
          (∑ a : Fin p.h,
            vandermonde p a i * ((Gram.gram s p)⁻¹) a b) *
            vandermonde p b j := by
              simp only [poleKernel, Matrix.mul_apply, Matrix.transpose_apply]
    _ = ∑ b : Fin p.h, ∑ a : Fin p.h,
          vandermonde p a i * ((Gram.gram s p)⁻¹) a b *
            vandermonde p b j := by
              simp only [Finset.sum_mul]
    _ = ∑ a : Fin p.h, ∑ b : Fin p.h,
          vandermonde p a i * ((Gram.gram s p)⁻¹) a b *
            vandermonde p b j := by
              exact Finset.sum_comm

/-- The actual kernel uses the evaluation vector at each negative square
pole; its `i`-th column is `(-a_i^2)^0,...,(-a_i^2)^(h-1)`. -/
theorem actual_pole_evaluation_vector
    (p : ManuscriptChain.Real.Parameters)
    (a i : Fin p.h) :
    vandermonde p i a =
      ((ManuscriptChain.PoleDiagonalization.poleNode p a : ℚ) ^ i.val : ℝ) := by
  change (Rat.castHom ℝ)
    (ManuscriptChain.PoleDiagonalization.poleNode p a ^ i.val) =
      ((ManuscriptChain.PoleDiagonalization.poleNode p a : ℝ) ^ i.val)
  first
  | simpa only [map_pow]
  | norm_cast

/-- Exact relative determinant identity for ANY nonsingular Gram matrix.
This is the first algebraic step in the determinant/Christoffel-Darboux
transfer of Theorem 3.8. -/
theorem det_affine_normalized {n : ℕ}
    (G M : Matrix (Fin n) (Fin n) ℝ)
    (hG : IsUnit G.det) (t : ℝ) :
    (G + t • M).det = G.det * (1 + t • (G⁻¹ * M)).det := by
  have hmat : G * (1 + t • (G⁻¹ * M)) = G + t • M := by
    rw [Matrix.mul_add, Matrix.mul_one]
    rw [Matrix.mul_smul, ← Matrix.mul_assoc]
    rw [Matrix.mul_nonsing_inv G hG]
    simp
  rw [← hmat, Matrix.det_mul]

/-- Apply the normalized determinant formula to the paper's actual
real-s positive Gram matrix, with no external condition. -/
theorem actual_relative_det (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (t : ℝ) :
    (Gram.gram s p + t • derivativeMatrix s p).det =
      (Gram.gram s p).det *
        (1 + t • ((Gram.gram s p)⁻¹ * derivativeMatrix s p)).det := by
  have hdet : (Gram.gram s p).det ≠ 0 :=
    ne_of_gt (PaperChronology.Proposition3_2.Integrability.actualGram_posDef
      s p hs).det_pos
  exact det_affine_normalized (Gram.gram s p) (derivativeMatrix s p)
    (isUnit_iff_ne_zero.mpr hdet) t

end PaperChronology.Theorem3_8.ActualKernel

#print axioms PaperChronology.Theorem3_8.ActualKernel.poleKernel_entries
#print axioms PaperChronology.Theorem3_8.ActualKernel.actual_relative_det
