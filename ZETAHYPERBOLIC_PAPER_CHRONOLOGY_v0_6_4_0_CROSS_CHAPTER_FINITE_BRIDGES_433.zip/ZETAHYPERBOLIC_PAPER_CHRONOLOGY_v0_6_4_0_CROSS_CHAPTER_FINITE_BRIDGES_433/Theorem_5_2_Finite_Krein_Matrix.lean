import Theorem_5_2_Finite_Krein_Pairing
import Mathlib.Tactic

/-!
# Theorem 5.2: full finite truncation of the actual rational Krein form

For every basis coefficient matrix, every finite cutoff M, every i,j:

  weightSevenTruncation(c,M)[i,j] =
     sum_{m<=M,nu<=2} binomial(5,nu)/1440 *
       (plus_i plus_j - minus_i minus_j).

This is a genuine exact finite matrix theorem, beyond a formal blueprint.
Crucially the unbounded sum over m>M is NOT dropped: the analytic
`WeightSevenTailBound` remains open, as do the all-dimension rational
positive and negative cones of the manuscript's Theorem 5.2(3).
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem5_2.FiniteKreinMatrix
open ManuscriptChain.Extensions
open PaperChronology.Theorem5_2.FiniteKrein

/-- Symmetric positive mode from the exact monomial Laplace moments. -/
def positiveMode {K : ℕ} (c : Fin (K + 1) → ℚ) (m ν : ℕ) : ℚ :=
  integralMom c m ν + integralMom c m (5 - ν)

/-- Antisymmetric negative mode paired against its 5-nu partner. -/
def negativeMode {K : ℕ} (c : Fin (K + 1) → ℚ) (m ν : ℕ) : ℚ :=
  integralMom c m ν - integralMom c m (5 - ν)

/-- Exactly the signed, FINITE version of the matrix expression (5.4). -/
def finiteKreinMatrix {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) :
    Matrix (Fin h) (Fin h) ℚ :=
  fun i j => ∑ m ∈ Finset.range (M + 1),
    ∑ ν ∈ Finset.range 3,
      (Nat.choose 5 ν : ℚ) / 1440 *
        (positiveMode (c i) m ν * positiveMode (c j) m ν -
         negativeMode (c i) m ν * negativeMode (c j) m ν)

/-- Exact finite Krein decomposition of the previously defined,
actual weight-seven rational truncated bilinear moment matrix. -/
theorem weightSevenTruncation_eq_finiteKreinMatrix {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) :
    weightSevenTruncation c M = finiteKreinMatrix c M := by
  ext i j
  unfold weightSevenTruncation finiteKreinMatrix
  apply Finset.sum_congr rfl
  intro m _
  simpa only [positiveMode, negativeMode] using
    (six_mode_pair (fun ν => integralMom (c i) m ν)
      (fun ν => integralMom (c j) m ν))

end PaperChronology.Theorem5_2.FiniteKreinMatrix

#print axioms PaperChronology.Theorem5_2.FiniteKreinMatrix.weightSevenTruncation_eq_finiteKreinMatrix
