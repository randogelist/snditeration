import Theorem_3_8_Actual_Christoffel_Darboux_Kernel
import Mathlib.Tactic

/-!
# Theorem 3.8: actual pole-kernel spectral determinant identity

The missing genuinely spectral part of the Christoffel-Darboux theorem
can be expressed WITHOUT guessing a list of eigenvalues.  The exact
finite matrices satisfy

  det(I+t G^{-1} M) = det(I+t diag(gamma) V^T G^{-1} V).

Here G is the paper's actual infinite-measure real-s Gram matrix, M is
its actual pole-diagonalized slope, and V is the actual negative-square
pole Vandermonde.  No new spectral or arithmetic Witness is postulated.
The proof is cyclic determinant similarity through the invertible matrix
G^{-1}V and works for EVERY finite h including h=0.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_8.ActualCyclicKernel
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualKernel

/-- Cyclic determinant identity with an EXPLICIT invertibility proof.
This form avoids an implicit unproved AB/BA spectral equivalence. -/
theorem det_one_add_cyclic_of_invertible {n : ℕ}
    (A B : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.det ≠ 0) (t : ℝ) :
    (1 + t • (A * B)).det = (1 + t • (B * A)).det := by
  have hmatrix :
      A * (1 + t • (B * A)) = (1 + t • (A * B)) * A := by
    calc
      A * (1 + t • (B * A)) = A + t • (A * (B * A)) := by
        rw [Matrix.mul_add, Matrix.mul_one, Matrix.mul_smul]
      _ = A + t • ((A * B) * A) := by
        rw [Matrix.mul_assoc]
      _ = (1 + t • (A * B)) * A := by
        rw [Matrix.add_mul, Matrix.one_mul, Matrix.smul_mul]
  have hdet := congrArg Matrix.det hmatrix
  rw [Matrix.det_mul, Matrix.det_mul] at hdet
  have hc :
      A.det * (1 + t • (B * A)).det =
        A.det * (1 + t • (A * B)).det := by
    calc
      _ = (1 + t • (A * B)).det * A.det := hdet
      _ = A.det * (1 + t • (A * B)).det := mul_comm _ _
  exact (mul_left_cancel₀ hA hc).symm

/-- A canonical nonsingular factor A=G^{-1}V for the actual pole lattice.
The nonsingularity is unconditional once s>1, using the existing real-s
moment integrability and positive-definiteness theorem. -/
theorem inverseGram_mul_vandermonde_det_ne_zero
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    (((Gram.gram s p)⁻¹) * vandermonde p).det ≠ 0 := by
  have hg : (Gram.gram s p).det ≠ 0 :=
    ne_of_gt (PaperChronology.Proposition3_2.Integrability.actualGram_posDef
      s p hs).det_pos
  -- Do not apply `Matrix.det_nonsing_inv` to an invertibility witness:
  -- in this Mathlib version it is already an unconditional *equality*.
  -- Instead, take determinants of the certified nonsingular inverse identity.
  have hunit : IsUnit (Gram.gram s p).det :=
    isUnit_iff_ne_zero.mpr hg
  have hproduct :
      (Gram.gram s p).det * ((Gram.gram s p)⁻¹).det = (1 : ℝ) := by
    calc
      (Gram.gram s p).det * ((Gram.gram s p)⁻¹).det =
          ((Gram.gram s p) * (Gram.gram s p)⁻¹).det := by
            rw [Matrix.det_mul]
      _ = 1 := by
        rw [Matrix.mul_nonsing_inv (Gram.gram s p) hunit]
        simp
  have hginv : ((Gram.gram s p)⁻¹).det ≠ 0 := by
    intro hzero
    rw [hzero, mul_zero] at hproduct
    exact zero_ne_one hproduct
  rw [Matrix.det_mul]
  exact mul_ne_zero hginv (vandermonde_det_ne_zero p)

/-- The full actual pole kernel has precisely the same normalized
characteristic determinant as the actual generalized-eigenvalue matrix.
No finite atomic Gram approximation is substituted. -/
theorem actual_pole_kernel_cyclic_det
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (t : ℝ) :
    (1 + t • ((Gram.gram s p)⁻¹ * derivativeMatrix s p)).det =
      (1 + t • (Matrix.diagonal (poleWeight s p) *
        poleKernel s p)).det := by
  let G := Gram.gram s p
  let V := vandermonde p
  let D : Matrix (Fin p.h) (Fin p.h) ℝ := Matrix.diagonal (poleWeight s p)
  let A := G⁻¹ * V
  let B := D * V.transpose
  have hA : A.det ≠ 0 :=
    inverseGram_mul_vandermonde_det_ne_zero s p hs
  have hAB : A * B = (Gram.gram s p)⁻¹ * derivativeMatrix s p := by
    change ((Gram.gram s p)⁻¹ * vandermonde p) *
        (Matrix.diagonal (poleWeight s p) * (vandermonde p).transpose) =
        (Gram.gram s p)⁻¹ *
          (vandermonde p * Matrix.diagonal (poleWeight s p) *
            (vandermonde p).transpose)
    simp only [Matrix.mul_assoc]
  have hBA : B * A = Matrix.diagonal (poleWeight s p) * poleKernel s p := by
    change (Matrix.diagonal (poleWeight s p) * (vandermonde p).transpose) *
        ((Gram.gram s p)⁻¹ * vandermonde p) =
        Matrix.diagonal (poleWeight s p) *
          ((vandermonde p).transpose * (Gram.gram s p)⁻¹ * vandermonde p)
    simp only [Matrix.mul_assoc]
  calc
    (1 + t • ((Gram.gram s p)⁻¹ * derivativeMatrix s p)).det =
        (1 + t • (A * B)).det := by rw [hAB]
    _ = (1 + t • (B * A)).det :=
      det_one_add_cyclic_of_invertible A B hA t
    _ = (1 + t • (Matrix.diagonal (poleWeight s p) *
            poleKernel s p)).det := by rw [hBA]

/-- The complete matrix determinant lemma for the ACTUAL Section 3
pencil, evaluated at an arbitrary real displacement t from zeta(s). -/
theorem actual_pole_kernel_affine_det
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (t : ℝ) :
    (Gram.gram s p + t • derivativeMatrix s p).det =
      (Gram.gram s p).det *
        (1 + t • (Matrix.diagonal (poleWeight s p) *
          poleKernel s p)).det := by
  calc
    _ = (Gram.gram s p).det *
        (1 + t • ((Gram.gram s p)⁻¹ * derivativeMatrix s p)).det :=
          actual_relative_det s p hs t
    _ = (Gram.gram s p).det *
        (1 + t • (Matrix.diagonal (poleWeight s p) * poleKernel s p)).det := by
          rw [actual_pole_kernel_cyclic_det s p hs t]

end PaperChronology.Theorem3_8.ActualCyclicKernel

#print axioms PaperChronology.Theorem3_8.ActualCyclicKernel.actual_pole_kernel_cyclic_det
#print axioms PaperChronology.Theorem3_8.ActualCyclicKernel.actual_pole_kernel_affine_det
