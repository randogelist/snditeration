import Mathlib.Tactic
import Mathlib.Analysis.Calculus.Deriv.Basic

/-!
# Theorem 3.7: UNIVERSAL ALL-ORDER Turan derivative-jet identity

For a finite list of real roots, multiply its polynomial by another
linear factor. Its exact (value, first derivative, second derivative)
jet transforms by the product rule. Algebra gives the SOS recurrence

  T_{new} = (x-a)^2 * T_{old} + (value_old)^2,
  T = (first)^2 - value * second.

Consequently T is nonnegative for EVERY finite number of real roots,
without eigenvalue or root-distinctness assumptions. The separate file
links these jets to actual analytic derivatives of the root product.
-/

noncomputable section
namespace PaperChronology.Theorem3_7.TuranJets

structure Jet where
  value : ℝ
  first : ℝ
  second : ℝ

/-- Derivative jet for the constant polynomial one. -/
def initialJet : Jet := ⟨1, 0, 0⟩

/-- Exact product-rule jet for multiplication by `(x-a)`. -/
def factorStep (x a : ℝ) (j : Jet) : Jet :=
  ⟨(x - a) * j.value,
   j.value + (x - a) * j.first,
   2 * j.first + (x - a) * j.second⟩

/-- General real-root product jet: arbitrary degree, arbitrary real roots. -/
def rootJet (x : ℝ) : List ℝ → Jet
  | [] => initialJet
  | a :: tail => factorStep x a (rootJet x tail)

/-- The real-rooted Turan expression for any formal derivative jet. -/
def turanian (j : Jet) : ℝ := j.first ^ 2 - j.value * j.second

/-- Universal polynomial SOS recursion, no restricted degree. -/
theorem factorStep_turanian (x a : ℝ) (j : Jet) :
    turanian (factorStep x a j) =
      (x - a) ^ 2 * turanian j + j.value ^ 2 := by
  unfold turanian factorStep
  ring

/-- Actual Turan nonnegativity at EVERY degree, with repeated roots
allowed, proved by induction on the list of real roots. -/
theorem rootJet_turanian_nonneg (x : ℝ) (roots : List ℝ) :
    0 ≤ turanian (rootJet x roots) := by
  induction roots with
  | nil =>
      norm_num [rootJet, initialJet, turanian]
  | cons a tail ih =>
      change 0 ≤ turanian (factorStep x a (rootJet x tail))
      rw [factorStep_turanian]
      exact add_nonneg
        (mul_nonneg (sq_nonneg _) ih) (sq_nonneg _)

/-- The zero-derivative component of the jet is the full root product. -/
def rootProduct (roots : List ℝ) (x : ℝ) : ℝ :=
  (roots.map fun a => x - a).prod

theorem rootJet_value_eq_rootProduct (x : ℝ) (roots : List ℝ) :
    (rootJet x roots).value = rootProduct roots x := by
  induction roots with
  | nil => simp [rootJet, initialJet, rootProduct]
  | cons a tail ih =>
      simp [rootJet, factorStep, rootProduct, ih]

end PaperChronology.Theorem3_7.TuranJets

#print axioms PaperChronology.Theorem3_7.TuranJets.factorStep_turanian
#print axioms PaperChronology.Theorem3_7.TuranJets.rootJet_turanian_nonneg
