import Zetahyperbolic.Section3Elementary
import Mathlib.Tactic

/-!
# Theorem 3.9: all five exact finite character numerator factorizations

These are the five *finite* Fekete-polynomial identities printed on
page 13 of the manuscript, and their strict positivity for 0 < z < 1.
The positivity proof invokes the independently certified, explicitly
factored sign lemma in Zetahyperbolic.Section3Elementary.

This does NOT yet prove the infinite Laplace weight identity or the
complete Hurwitz/Dirichlet spectral hyperbolicity theorem.
-/

noncomputable section
namespace PaperChronology.Theorem3_9.Fekete

def characterMinusThree (z : ℝ) : ℝ := z - z ^ 2

def characterMinusFour (z : ℝ) : ℝ := z - z ^ 3

def characterFive (z : ℝ) : ℝ := z - z ^ 2 - z ^ 3 + z ^ 4

def characterEight (z : ℝ) : ℝ := z - z ^ 3 - z ^ 5 + z ^ 7

def characterMinusEight (z : ℝ) : ℝ := z + z ^ 3 - z ^ 5 - z ^ 7

/-- The five exact character numerator polynomial factorizations. -/
theorem all_character_factors (z : ℝ) :
    characterMinusThree z = z * (1 - z) ∧
    characterMinusFour z = z * (1 - z ^ 2) ∧
    characterFive z = z * (1 - z) ^ 2 * (1 + z) ∧
    characterEight z = z * (1 - z ^ 2) * (1 - z ^ 4) ∧
    characterMinusEight z = z * (1 + z ^ 2) * (1 - z ^ 4) := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;>
    dsimp [characterMinusThree, characterMinusFour,
      characterFive, characterEight, characterMinusEight] <;> ring

/-- Simultaneous strict positivity of all five numerator polynomials on
0 < z < 1, with no added analytic premise. -/
theorem all_character_numerators_pos {z : ℝ}
    (hz0 : 0 < z) (hz1 : z < 1) :
    0 < characterMinusThree z ∧
    0 < characterMinusFour z ∧
    0 < characterFive z ∧
    0 < characterEight z ∧
    0 < characterMinusEight z := by
  obtain ⟨hp3, hp4, hp5, hp8, hpm8⟩ :=
    Zetahyperbolic.fekete_polynomial_positivity_basic hz0 hz1
  obtain ⟨hf3, hf4, hf5, hf8, hfm8⟩ := all_character_factors z
  rw [hf3, hf4, hf5, hf8, hfm8]
  exact ⟨hp3, hp4, hp5, hp8, hpm8⟩

end PaperChronology.Theorem3_9.Fekete

#print axioms PaperChronology.Theorem3_9.Fekete.all_character_factors
#print axioms PaperChronology.Theorem3_9.Fekete.all_character_numerators_pos
