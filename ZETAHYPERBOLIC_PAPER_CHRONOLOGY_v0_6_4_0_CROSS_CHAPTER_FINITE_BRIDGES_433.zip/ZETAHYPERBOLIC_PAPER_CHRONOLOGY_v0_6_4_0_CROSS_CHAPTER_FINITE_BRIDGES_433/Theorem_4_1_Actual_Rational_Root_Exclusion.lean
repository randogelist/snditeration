import Theorem_3_8_Actual_Pole_Kernel_Real_Argument
import Theorem_4_1_Actual_Pole_Kernel_Zero_Free
import Mathlib.Tactic

/-!
# Theorem 4.1: all nearby rational test points excluded by the actual kernel

The genuine real-s Hankel determinant cannot vanish at a/b sufficiently
near the distinguished zeta value: its own finite pole kernel supplies a
strict positive radius B^{-1}. The radius is not K-uniform and the proof
DOES NOT yield the effective irrationality measure or p-adic Witness.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem4_1.ActualRationalExclusion
open PaperChronology.Proposition3_2
open PaperChronology.Theorem3_8.ActualRealArgument
open PaperChronology.Theorem4_1.ActualKernelSeparation

/-- The true pencil excludes every rational inside its certified
local gap, with an arbitrary integer numerator and positive denominator. -/
theorem rational_points_in_local_gap_are_not_roots
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    ∃ B : ℝ, 0 < B ∧
      ∀ (a : ℤ) (b : ℕ), 0 < b →
        |(a : ℝ) / (b : ℝ) - (riemannZeta (s : ℂ)).re| < 1 / B →
        (Gram.actualPencil s p).detPolynomial.eval
          ((a : ℝ) / (b : ℝ)) ≠ 0 := by
  obtain ⟨B, hB, hkernel⟩ := actual_pole_kernel_zero_free s p hs
  refine ⟨B, hB, ?_⟩
  intro a b _ hnear
  have hnotroot := hkernel
    ((a : ℝ) / (b : ℝ) - (riemannZeta (s : ℂ)).re) hnear
  intro hroot
  have hk := (actual_pencil_root_iff_weighted_kernel_root s p hs
    ((a : ℝ) / (b : ℝ))).mp hroot
  exact hnotroot hk

/-- Real, not only rational, parameters inside the kernel disk are
excluded from the genuine polynomial zero locus. -/
theorem all_real_points_in_local_gap_are_not_roots
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    ∃ B : ℝ, 0 < B ∧
      ∀ x : ℝ, |x - (riemannZeta (s : ℂ)).re| < 1 / B →
        (Gram.actualPencil s p).detPolynomial.eval x ≠ 0 := by
  obtain ⟨B, hB, hkernel⟩ := actual_pole_kernel_zero_free s p hs
  refine ⟨B, hB, ?_⟩
  intro x hnear
  have hnotroot := hkernel (x - (riemannZeta (s : ℂ)).re) hnear
  intro hroot
  have hk := (actual_pencil_root_iff_weighted_kernel_root s p hs x).mp hroot
  exact hnotroot hk

end PaperChronology.Theorem4_1.ActualRationalExclusion

#print axioms PaperChronology.Theorem4_1.ActualRationalExclusion.rational_points_in_local_gap_are_not_roots
#print axioms PaperChronology.Theorem4_1.ActualRationalExclusion.all_real_points_in_local_gap_are_not_roots
