# v0.3.9.2: chronological Theorem 3.3 actual leading coefficient

Added `Theorem_3_3_Actual_Leading_Coefficient_Sign.lean` with proof candidates for:
- Exact non-conditional positivity of the product of the signed actual pole weights.
- Positive sign-normalized leading coefficient of the **actual** rational Hankel determinant polynomial using Theorem 2.5's exact determinant factorization.
- Signed strict positivity of each diagonal element in the congruence-normalized actual derivative matrix.

`PAPER_CHRONOLOGICAL_CHAIN.lean` imports and exports the leading-coefficient theorem.
All other previous Lean files remain unchanged.

**Status:** source-only, not locally Lean-compiled; awaits user's pinned native Lean 4.33.0, with prior pass-once modules frozen. Exact inertia and all-minor positivity remain separate. No added axioms, sorry, or witness requirements.
