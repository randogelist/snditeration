import Theorem_3_4_Actual_Principal_Pencil_Reality
import Mathlib.Tactic

/-!
# Theorem 3.4, actual principal-minor zero-free neighborhoods

For every positive-base symmetric affine pencil, including every *actual*
real-s or odd-zeta principal subpencil, construct an EXPLICIT positive
radius using the finite spectrum. No spectral bound, witness, or extra
analytic assumption is imported: the bound is obtained by summing all
absolute eigenvalues of the already-proved spectral factorization.
This proves a local gap; it does not claim Cauchy interlacing.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_4.ActualSpectralGap
open ManuscriptChain.Spectral
open PaperChronology.Theorem3_4.ActualPrincipal

private def spectrumBudget {n : ℕ} (beta : Fin n → ℝ) : ℝ :=
  1 + ∑ i : Fin n, |beta i|

private theorem spectrumBudget_pos {n : ℕ} (beta : Fin n → ℝ) :
    0 < spectrumBudget beta := by
  have hn : 0 ≤ ∑ i : Fin n, |beta i| := by
    apply Finset.sum_nonneg
    intro i _
    exact abs_nonneg _
  unfold spectrumBudget
  linarith

private theorem abs_beta_le_budget {n : ℕ} (beta : Fin n → ℝ)
    (i : Fin n) : |beta i| ≤ spectrumBudget beta := by
  have hn : |beta i| ≤ ∑ j : Fin n, |beta j| := by
    exact Finset.single_le_sum (fun j _ => abs_nonneg (beta j))
      (Finset.mem_univ i)
  unfold spectrumBudget
  linarith

private theorem factor_positive_near_center {n : ℕ}
    (beta : Fin n → ℝ) (center x : ℝ)
    (i : Fin n)
    (hx : |x - center| < 1 / spectrumBudget beta) :
    0 < 1 + (x - center) * beta i := by
  have hB : 0 < spectrumBudget beta := spectrumBudget_pos beta
  have hnear : |x - center| * spectrumBudget beta < 1 := by
    exact (lt_div_iff₀ hB).mp hx
  have hprod : |(x - center) * beta i| < 1 := by
    rw [abs_mul]
    calc
      |x - center| * |beta i| ≤
          |x - center| * spectrumBudget beta :=
        mul_le_mul_of_nonneg_left (abs_beta_le_budget beta i) (abs_nonneg _)
      _ < 1 := hnear
  have hlower := (abs_lt.mp hprod).1
  linarith

/-- An actual spectral factorization, with no derivative-rank hypothesis,
produces its own (finite, strictly positive) root-exclusion radius. -/
theorem zero_free_radius_of_posDef {n : ℕ}
    (p : SymmetricAffinePencil n) (hp : p.base.PosDef) :
    ∃ B : ℝ, 0 < B ∧
      ∀ x : ℝ, |x - p.center| < 1 / B →
        0 < p.detPolynomial.eval x := by
  obtain ⟨beta, hfactor⟩ :=
    factorization_without_direction_invertibility p hp
  refine ⟨spectrumBudget beta, spectrumBudget_pos beta, ?_⟩
  intro x hx
  have hprod : 0 < ∏ i : Fin n, (1 + (x - p.center) * beta i) := by
    apply Finset.prod_pos
    intro i _
    exact factor_positive_near_center beta p.center x i hx
  have heval : p.detPolynomial.eval x =
      Matrix.det p.base * ∏ i : Fin n, (1 + (x - p.center) * beta i) := by
    rw [hfactor]
    simp only [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_prod,
      ManuscriptChain.Spectral.eval_spectralFactor]
  rw [heval]
  exact mul_pos hp.det_pos hprod

/-- PDF Theorem 3.4, *actual real-s* principal minor: a genuine local
zero-free disk around zeta(s), extracted from its own finite spectrum. -/
theorem real_s_principal_zero_free
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    ∃ B : ℝ, 0 < B ∧
      ∀ x : ℝ, |x - (riemannZeta (s : ℂ)).re| < 1 / B →
        0 < (realSPrincipalPencil s p choose).detPolynomial.eval x := by
  exact zero_free_radius_of_posDef (realSPrincipalPencil s p choose)
    (PaperChronology.Theorem3_3.ActualContinuousPrincipal.real_s_principal_posDef
      s p hs choose hinj)

/-- The same result for the paper's ORIGINAL odd-zeta principal pencil. -/
theorem odd_principal_zero_free
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    ∃ B : ℝ, 0 < B ∧
      ∀ x : ℝ, |x - ManuscriptChain.Real.zeta p.weight| < 1 / B →
        0 < (oddPrincipalPencil p choose).detPolynomial.eval x := by
  exact zero_free_radius_of_posDef (oddPrincipalPencil p choose)
    (PaperChronology.Theorem3_3.ActualContinuousPrincipal.odd_weight_principal_posDef
      p hp choose hinj)

end PaperChronology.Theorem3_4.ActualSpectralGap

#print axioms PaperChronology.Theorem3_4.ActualSpectralGap.zero_free_radius_of_posDef
#print axioms PaperChronology.Theorem3_4.ActualSpectralGap.real_s_principal_zero_free
#print axioms PaperChronology.Theorem3_4.ActualSpectralGap.odd_principal_zero_free
