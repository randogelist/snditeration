# First extended reasoning foundation — v0.3.9.0

The paper's PDF order remains authoritative. The 73-module native Lean 4.33.0
baseline previously checked by the user's compiler is preserved wherever files
are unchanged. The two most recent experiments (moment integrability and Theorem
3.3 parity counts) have **no confirmed PASS** in the conversation. This package
must not claim a new full Proposition 3.2 or Theorem 3.3 pass prematurely.

## Source-proof additions

1. `Theorem_3_3_Leading_Sign_Parity.lean` — exact elementary power parity
   independent of the analytic weight and witness. It is a coefficient-sign
   sublemma, not the full leading coefficient result.
2. `Theorem_3_3_Signed_Pole_Products.lean` — source-faithful sign counting for
   the actual numerator D_N(-a²) and derivative D_tail'(-a²), without free
   signed-matrix assumptions. Next prove the odd-power residue sign using these.
3. `Theorem_3_4_Reciprocal_Root_Order.lean` — order preservation of
   x ↦ ξ - x⁻¹ on each half-line, to be combined later with the proper Cauchy
   interlacing theorem and compatible Cholesky principal blocks.
4. `Corollary_3_6_Corrected_Finite_Atomic_Moments.lean` — exact
   finite Vandermonde Gram factorization and support moment bounds, replacing
   the paper's invalid universal strict Hankel positivity assertion.
5. `Theorem_5_4_Even_Pole_Pair_Cancellation.lean` — source-faithful
   cancellation of all X-dependent terms for the x-even simple-pole pairs.
6. `Proposition_3_2_Real_s_Moment_Integrability.lean` — repaired candidate
   final majorant matching: explicitly name integrable pointwise sum before
   `Integrable.mono'`. Still compiler-pending.

## No hidden hypotheses

Every new theorem is either a closed algebraic/analytic fact or a lemma whose
explicit parameters are exactly those needed by its local mathematical
statement. These do not insert any new premise into the paper's irrationality
endpoint. The only eventual arithmetic input remains `PaperWitness.Witness`.

## Mathematical frontend corrections

The printed Corollaries 3.5 and 3.6 are not accepted verbatim; the previous
finite-dimensional counterexamples and correction ledger remain in the ZIP.
The full total-positivity, Cauchy interlacing, spectral residue-sign bridge,
and prime-sum/p-adic bounds remain proof tasks, not axioms.

## Compiler protocol

The user alone runs Lean. `run.cmd` is the only entry point and reuses
unchanged, previously certified modules. No local Lean compilation has been
performed. The next native compiler failure, if any, must be repaired before
any new theorem can be frozen as PASS.

## v0.3.9.1 (compiler pending)
Added an explicit proof candidate for the sign of the *actual* pole weights, from the signed numerator and denominator factors for m>0. It is independent of the arithmetic Witness and does not claim spectral inertia or total positivity. All formerly passed Lean source files are unchanged.
