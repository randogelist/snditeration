import PAPER_CHRONOLOGICAL_EXTENSION_7
import Theorem_3_3_Actual_Diagonal_Sign_Counts

/-!
# Chronological paper extension 8: exact actual inertia-coordinate counts

Theorem 3.3 has an unconditional finite diagonal-congruence certificate:
its actual positive and negative pole directions are counted for all
parameters and exactly for the weight-five family.  The conversion to
numbers of real generalized eigenvalues still requires the nontrivial
spectral Sylvester-inertia theorem; it is not an assumption here.
-/

noncomputable section
namespace PaperChronology

/-- Precise weight-five PDF pole-inertia data, without an additional
hypothesis or the Diophantine Witness. -/
theorem paper_theorem_3_3_actual_weight_five_diagonal_counts
    (n : ℕ) (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (hN : p.N = 3 * n) (hK : p.K = 30 * n) :
    Theorem3_3.ActualSignCounts.positiveMass p = (27 * n) / 2 ∧
    Theorem3_3.ActualSignCounts.negativeMass p = (27 * n + 1) / 2 := by
  exact Theorem3_3.ActualSignCounts.weightFive_actual_diagonal_sign_counts
    n p hm hN hK

/-- Full pole-coordinate inertia is nondegenerate, with its positive
and negative index counts adding to the true matrix dimension. -/
theorem paper_theorem_3_3_actual_diagonal_no_zero_directions
    (p : ManuscriptChain.Real.Parameters) :
    Theorem3_3.ActualSignCounts.positiveMass p +
      Theorem3_3.ActualSignCounts.negativeMass p = p.h :=
  Theorem3_3.ActualSignCounts.positiveMass_add_negativeMass p

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_actual_weight_five_diagonal_counts
#print axioms PaperChronology.paper_theorem_3_3_actual_diagonal_no_zero_directions
