# Chronological theorem proofs — native 4.33.0 milestone

Base: v0.6.0.8 PDF source/paragraph and native proof-link checkpoint.
All 62 pre-existing Lean source files are byte-for-byte unchanged and frozen.

New Lean proof modules (one active import chain):
- `Proposition03_02`: all-real-parameter symmetric-pencil degree,
  real-rootedness and center nonvanishing assuming the natural matrix input.
  **The concrete Gamma-integral construction remains open**.
- `Theorem03_03`: exact actual-paper signed Vandermonde congruence,
  nonvanishing leading coefficient, and genuine zeta-center spectral
  left/right classification of EVERY indexed root. **The complete
  universal signature count and continuous total positivity remain open**.
- `Theorem03_04`: exact 3x3 Dodgson condensation identity and sign at
  a 2x2 minor root. **Global interlacing is open**.
- `Checkpoint03_02_03_04`: exact theorem types and native axiom audit.

The two layers must not be conflated: proving the general transfer mechanism
is not automatically proving the paper's Gamma-weight analytic realization.
This release adds concrete mathematical propositions, not new hypotheses
at a paper endpoint or mere source-index wrappers. No new custom axioms,
`admit`, or `sorry` occur in the new sources.

Compilation is performed only on the user's native Windows Lean 4.33.0.
The `run.cmd checkpoint` command reuses previously frozen .olean artifacts,
and recompiles these four modules only when required. After the compiler
confirms `PRINCIPAL_PROOFS_3_2_TO_3_4=PASS` and the axiom audit passes,
record source-faithful PARTIAL links, not FULL theorem certification.
