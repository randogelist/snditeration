# Native paper-source bridge — v0.6.0.5

User Windows Lean 4.33.0 successfully compiled the 53-module paragraph checkpoint
(v0.6.0.4) with `PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS` and
`PARAGRAPH_LEAN_MODULES_FROZEN_REUSED=53`.

This package keeps those 53 files **unchanged** and adds three provenance-only
Lean modules. The complete 51-result index (Definitions through Theorem 6.18)
now has a typed source anchor for PDF page/block, original kind and source SHA-256.
The native checker compares every anchor against the actual Lean source blocks.

Important: this is source registration and provenance integrity, not closure of
any new mathematical theorem. The manuscript has known errata; no truth is
asserted merely because a paragraph exists in Lean. Section04's unrelated
missing `MainChain.indexDenominatorThreshold` declaration remains independent.

`run.cmd` preserves the persistent `PASS-ONCE` .olean cache. Only the three
new modules (plus any truly invalidated imports) are compiled by Windows Lean.

Expected results after native confirmation:
- `FROZEN_REUSED` for all 53 unchanged paragraph modules;
- `SOURCE_TO_THEOREM_ANCHOR_CROSSWALK=PASS`;
- `MATHEMATICAL_PROOFS_CLOSED=NOT_CLAIMED`.
