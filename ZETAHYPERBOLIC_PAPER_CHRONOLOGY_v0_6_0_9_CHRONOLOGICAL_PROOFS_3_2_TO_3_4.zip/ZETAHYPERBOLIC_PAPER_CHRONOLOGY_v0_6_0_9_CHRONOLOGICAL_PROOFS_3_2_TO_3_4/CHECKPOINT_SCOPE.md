# SOURCE PARAGRAPH CHECKPOINT (native Lean 4.33.0)

This package adds 1502 PDF body text blocks on pages 1-51, spanning the abstract,
introduction, Sections 2-6, and Discussion Section 7, as typed Lean `SourceBlock`
values with a stable ID, PDF page, chapter, current numbered-item anchor,
classification, SHA-256 of normalized extracted text, and full extracted text.
Page 52 and the bibliography on page 51 are excluded.

- Exactly 51 numbered source items (Definition 2.1 through Theorem 6.18,
  including remarks/conjecture) are anchored in the inventory.
- This is the deliberately *weak* milestone requested: paragraphs are now
  at least source-indexed inside valid Lean data, **not formally proved**.
- Source paragraphs are counted as PDF geometric text blocks, which are not
  necessarily natural-language paragraphs; equations may form separate blocks.
- No `True` statements are substituted for mathematical claims, and no
  `sorry`, `admit`, or new axioms are introduced in the new source modules.
- Printed manuscript inaccuracies remain marked unresolved in the source chain.
- This package is independent of the failing Section04 threshold bridge and
  does not claim that the older v0.6.0.1 Blueprint runner has passed.
- Lean compilation takes place only on the user's native Windows 4.33.0.
- PASS-ONCE cache artifacts are stored under `zetahyperbolic-paper-frozen-433`
  without rebuilding existing verified paper files.

Successful native run emits:
`PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS`
`PDF_BODY_TEXT_BLOCKS_INDEXED=1502`
`NUMBERED_SOURCE_ITEMS=51`
`MATHEMATICAL_PROOFS_CLOSED=NOT_CLAIMED`

This checkpoint does not promote PDF claims into proved theorems. Each source
paragraph must later be linked to a faithful typed proposition and closed proof.

