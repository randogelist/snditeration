@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "PACKAGE=ZETAHYPERBOLIC_PAPER_CHRONOLOGY_v0_6_0_9_CHRONOLOGICAL_PROOFS_3_2_TO_3_4"
set "ROOT=%~dp0"
set "CACHE=%USERPROFILE%\lean-native\zetahyperbolic-paper-frozen-433"
set "OUT=%CACHE%\lib"
set "FROZEN=%CACHE%\paragraph_source_snapshots"
set "MODLOG=%CACHE%\logs\paragraphs"
set "STAGE=%CACHE%\paragraph_build_stage"
set "TOOL=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN=%TOOL%\bin\lean.exe"
set "STD=%TOOL%\lib\lean"
set "TARGET=%USERPROFILE%\Downloads\ZETAHYPERBOLIC_PAPER_CHRONOLOGY_v0_6_0_1_SECTION03_DOC_PARSER_FIX_433"
set "LOG=%ROOT%PARAGRAPH_CHECKPOINT_NATIVE_LOG.txt"
set "ERRORS=0"
set "CORE_CHANGED=0"
set "PAGE_CHANGED=0"
set "FORCE=0"
set "CHECKPOINT_CHANGED=0"
set "BRIDGE_CHANGED=0"
set "ANCHOR_CHANGED=0"
set "PROVENANCE_CHANGED=0"
set "PROOF_SECTION2_CHANGED=0"
set "PROOF_SECTION3_CHANGED=0"
set "PROOF_SECTION4_CHANGED=0"
set "PROOF_SECTION5_CHANGED=0"
set "PROOF_DIR=%USERPROFILE%\lean-native\paper_chronological_fastcore_433\lib\lean"
set "MATHBASE=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
set "PROOF_SIG=%CACHE%\proof_link_dependencies.sig"
set "PROOF_NEWSIG=%CACHE%\proof_link_dependencies.new"
set "PROOF_DIRTY=0"
set "NEW=0"
set "REUSED=0"
set "LEAN_NUM_THREADS=1"
set "LEAN_JOBS=1"

>"%LOG%" echo PACKAGE=%PACKAGE%
>>"%LOG%" echo COMPILER=USER_NATIVE_LEAN_433
>>"%LOG%" echo MODE=PARAGRAPH_TO_NUMBERED_THEOREM_SOURCE_BRIDGE
>>"%LOG%" echo CMD_ECHO_SYNTAX_FIX=V0608
>>"%LOG%" echo EXISTING_FROZEN_LEAN_MODULES=UNTOUCHED
>>"%LOG%" echo COMPILATION=ONLY_NEW_OR_CHANGED_REGISTRY_FILES

echo PACKAGE=%PACKAGE%
echo MODE=PARAGRAPH_TO_THEOREM_SOURCE_CROSSWALK
echo CMD_ECHO_SYNTAX_FIX=V0608
if not exist "%LEAN%" goto missing
if not exist "%ROOT%PaperBlueprint\Paragraphs\Checkpoint.lean" goto missing
if not exist "%STD%\Lean\Elab\Command.olean" goto missing

rem Protect the shared PASS-ONCE cache against simultaneous writers.
set "ACTIVE=0"
for /F "tokens=1 delims=," %%P in ('"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq lean.exe" /FO CSV /NH 2^>nul') do (
  if /I "%%~P"=="lean.exe" set "ACTIVE=1"
)
if "!ACTIVE!"=="1" goto busy

for %%D in ("%OUT%\PaperBlueprint\Paragraphs" "%FROZEN%" "%MODLOG%" "%STAGE%\PaperBlueprint\Paragraphs") do (
  if not exist "%%~fD" mkdir "%%~fD" || goto fail
)
"%LEAN%" --version > "%MODLOG%\compiler_version.txt" 2>&1 || goto fail
findstr /C:"4.33.0" "%MODLOG%\compiler_version.txt" >nul || goto fail
set "LEAN_PATH=%OUT%;%STD%"

rem The new files import only Lean core; no Lake, downloads, WSL, or Mathlib rebuilds.
pushd "%ROOT%" || goto fail
call :compile PaperBlueprint\Paragraphs\Core
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "CORE_CHANGED=1"
for /L %%P in (1,1,51) do (
  set "N=0%%P"
  set "N=!N:~-2!"
  set "FORCE=!CORE_CHANGED!"
  call :compile PaperBlueprint\Paragraphs\Page!N!
  if errorlevel 1 goto compile_failed
  if "!DID_COMPILE!"=="1" set "PAGE_CHANGED=1"
)
set "FORCE=!PAGE_CHANGED!"
call :compile PaperBlueprint\Paragraphs\Checkpoint
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "CHECKPOINT_CHANGED=1"
if not exist "%OUT%\PaperBlueprint\Paragraphs\Checkpoint.olean" goto compile_failed
for %%F in ("%OUT%\PaperBlueprint\Paragraphs\Checkpoint.olean") do if %%~zF LEQ 0 goto compile_failed

rem Compiled extension of the source index to all 51 theorem/lemma labels.
rem If an imported source page was updated, invalidate affected bridge modules.
set "FORCE=!CORE_CHANGED!"
if "!PAGE_CHANGED!"=="1" set "FORCE=1"
if "!CHECKPOINT_CHANGED!"=="1" set "FORCE=1"
call :compile PaperBlueprint\Paragraphs\NumberedSourceBridge
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "BRIDGE_CHANGED=1"
set "FORCE=!BRIDGE_CHANGED!"
call :compile PaperBlueprint\Paragraphs\AnchorAudit
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "ANCHOR_CHANGED=1"
set "FORCE=!ANCHOR_CHANGED!"
call :compile PaperBlueprint\Paragraphs\ProvenanceCheckpoint
if errorlevel 1 goto compile_failed
if not exist "%OUT%\PaperBlueprint\Paragraphs\ProvenanceCheckpoint.olean" goto compile_failed
for %%F in ("%OUT%\PaperBlueprint\Paragraphs\ProvenanceCheckpoint.olean") do if %%~zF LEQ 0 goto compile_failed
if "!DID_COMPILE!"=="1" set "PROVENANCE_CHANGED=1"

rem Native Mathlib proof import bridge: use the already-certified PAPER branch
rem .olean artifacts read-only, never rebuild their sources in this package.
set "MATHTARGET=%MATHBASE%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean"
if not exist "!MATHTARGET!" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\S2_FullChain.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\S2_RationalEndpoint.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\S2_GlobalMomentLinearMap.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T2_5.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_1.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_2.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_3.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_4.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_5.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_6.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T3_7.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T4_1.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T5_4.olean" goto missing_proof_cache
if not exist "%PROOF_DIR%\PaperChronological\T5_6.olean" goto missing_proof_cache

rem SHA256 fingerprint direct imported math proofs; a changed compiled dependency
rem invalidates the new proof bridge even when its own source is unchanged.
>"%PROOF_NEWSIG%" echo BRIDGE=V0606_NATIVE_LEAN_433_PROOFS
for %%F in ("!MATHTARGET!" "%LEAN%" "%STD%\Lean\Elab\Command.olean" "%PROOF_DIR%\PaperChronological\S2_FullChain.olean" "%PROOF_DIR%\PaperChronological\S2_RationalEndpoint.olean" "%PROOF_DIR%\PaperChronological\S2_GlobalMomentLinearMap.olean" "%PROOF_DIR%\PaperChronological\T2_5.olean" "%PROOF_DIR%\PaperChronological\T3_1.olean" "%PROOF_DIR%\PaperChronological\T3_2.olean" "%PROOF_DIR%\PaperChronological\T3_3.olean" "%PROOF_DIR%\PaperChronological\T3_4.olean" "%PROOF_DIR%\PaperChronological\T3_5.olean" "%PROOF_DIR%\PaperChronological\T3_6.olean" "%PROOF_DIR%\PaperChronological\T3_7.olean" "%PROOF_DIR%\PaperChronological\T4_1.olean" "%PROOF_DIR%\PaperChronological\T5_4.olean" "%PROOF_DIR%\PaperChronological\T5_6.olean") do (
  >>"%PROOF_NEWSIG%" echo PATH=%%~fF
  "%SystemRoot%\System32\certutil.exe" -hashfile "%%~fF" SHA256 1>>"%PROOF_NEWSIG%" 2>nul
  if errorlevel 1 goto missing_proof_cache
)
if not exist "%PROOF_SIG%" set "PROOF_DIRTY=1"
if exist "%PROOF_SIG%" (
  fc /B "%PROOF_NEWSIG%" "%PROOF_SIG%" >nul 2>nul
  if errorlevel 1 set "PROOF_DIRTY=1"
)

rem Exact underlying Mathlib and independent cache environment used by the
rem upstream frozen branch. Required imported objects must already exist.
set "LEAN_PATH=%OUT%;%PROOF_DIR%;%STD%"
if exist "%MATHBASE%\.lake\build\lib\lean" (
  set "LEAN_PATH=!LEAN_PATH!;%MATHBASE%\.lake\build\lib\lean"
)
for /D %%P in ("%MATHBASE%\.lake\packages\*") do (
  if exist "%%~fP\.lake\build\lib\lean" (
    set "LEAN_PATH=!LEAN_PATH!;%%~fP\.lake\build\lib\lean"
  )
)

set "FORCE=0"
if "!PROVENANCE_CHANGED!"=="1" set "FORCE=1"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofLinks\Section02
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "PROOF_SECTION2_CHANGED=1"
set "FORCE=!PROOF_SECTION2_CHANGED!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofLinks\Section03
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "PROOF_SECTION3_CHANGED=1"
set "FORCE=!PROOF_SECTION3_CHANGED!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofLinks\Section04
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "PROOF_SECTION4_CHANGED=1"
set "FORCE=!PROOF_SECTION4_CHANGED!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofLinks\Section05
if errorlevel 1 goto compile_failed
if "!DID_COMPILE!"=="1" set "PROOF_SECTION5_CHANGED=1"
set "FORCE=!PROOF_SECTION5_CHANGED!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofLinks\NativeProofCheckpoint
if errorlevel 1 goto compile_failed
if not exist "%OUT%\PaperBlueprint\ProofLinks\NativeProofCheckpoint.olean" goto compile_failed

rem Conservative mathematical-versus-source reassessment: one new Lean inventory proof.
set "FORCE=!DID_COMPILE!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\Assessment\CurrentStanding
if errorlevel 1 goto compile_failed
if not exist "%OUT%\PaperBlueprint\Assessment\CurrentStanding.olean" goto compile_failed
findstr /I /C:"sorryAx" /C:"native_decide.ax_" "%MODLOG%\PaperBlueprint\Assessment\CurrentStanding.log" >nul 2>nul
if not errorlevel 1 goto untrusted_axioms

rem The audit must not depend on Lean's sorry or proof-computation axioms.
findstr /I /C:"sorryAx" /C:"native_decide.ax_" "%MODLOG%\PaperBlueprint\ProofLinks\NativeProofCheckpoint.log" >nul 2>nul
if not errorlevel 1 goto untrusted_axioms
move /Y "%PROOF_NEWSIG%" "%PROOF_SIG%" >nul 2>nul || goto compile_failed

rem Additional genuine theorem proofs, in exact manuscript order.
rem Only new/changed proof files and import-dependency-invalidated files run.
rem All previously frozen paragraph, proof-link, and Section-2 modules are kept.
set "FORCE=!PROOF_DIRTY!"
call :compile PaperBlueprint\ProofTheorems\Proposition03_02
if errorlevel 1 goto compile_failed
set "FORCE=!DID_COMPILE!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofTheorems\Theorem03_03
if errorlevel 1 goto compile_failed
set "FORCE=!DID_COMPILE!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofTheorems\Theorem03_04
if errorlevel 1 goto compile_failed
set "FORCE=!DID_COMPILE!"
if "!PROOF_DIRTY!"=="1" set "FORCE=1"
call :compile PaperBlueprint\ProofTheorems\Checkpoint03_02_03_04
if errorlevel 1 goto compile_failed
if not exist "%OUT%\PaperBlueprint\ProofTheorems\Checkpoint03_02_03_04.olean" goto compile_failed
findstr /I /C:"sorryAx" /C:"native_decide.ax_" "%MODLOG%\PaperBlueprint\ProofTheorems\Checkpoint03_02_03_04.log" >nul 2>nul
if not errorlevel 1 goto untrusted_axioms
>>"%LOG%" echo PRINCIPAL_PROOFS_3_2_TO_3_4=PASS
>>"%LOG%" echo PROP_3_2_ANALYTIC_GAMMA_WEIGHT=OPEN
>>"%LOG%" echo THEOREM_3_3_FULL_TOTAL_POSITIVITY_AND_INERTIA=OPEN
>>"%LOG%" echo THEOREM_3_4_ALL_DIMENSION_INTERLACING=OPEN

rem Optional noninvasive mirror into the old v0.6.0.1 source tree:
rem install ONLY if the user's destination module does not already exist.
if exist "%TARGET%\PaperBlueprint" (
  if not exist "%TARGET%\PaperBlueprint\Paragraphs" mkdir "%TARGET%\PaperBlueprint\Paragraphs" >nul 2>nul
  for %%F in ("%ROOT%PaperBlueprint\Paragraphs\*.lean") do (
    if not exist "%TARGET%\PaperBlueprint\Paragraphs\%%~nxF" (
      copy /B "%%~fF" "%TARGET%\PaperBlueprint\Paragraphs\%%~nxF" >nul 2>nul
    )
  )
  echo SOURCE_TREE_MIRROR=INSTALLED_WHERE_MISSING
) else (
  echo SOURCE_TREE_MIRROR=ORIGINAL_V0601_NOT_PRESENT
)

>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo STATUS=PASS
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo PACKAGE=%PACKAGE%
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo LEAN=4.33.0
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo PDF_BODY_TEXT_BLOCKS_INDEXED=1502
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo NUMBERED_SOURCE_ITEMS=51
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo MATHEMATICAL_PROOFS_CLOSED=NOT_CLAIMED
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo EXACT_ANCHORS_51=CHECKED_FROM_SOURCE_BLOCKS
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo SOURCE_TO_THEOREM_BRIDGE_0_6_0_5=PASS
>>"%CACHE%\PARAGRAPH_SOURCE_CHECKPOINT.txt" echo PROOF_LINKS_V0606=PASS

echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS
echo PRINCIPAL_PROOFS_3_2_TO_3_4=PASS
echo MATHEMATICAL_PROOF_LINKS=PASS
echo REASSESSMENT_SOURCE_INDEXED=51_OF_51
echo ASSESSMENT_REPORT=REASSESSMENT_2026_10_24.md
echo REASSESSMENT_PROOF_LINKED_UNCONDITIONAL_ANCHORS=7
echo REASSESSMENT_PROOF_LINKED_CONDITIONAL_ANCHORS=1
echo REASSESSMENT_PARTIAL_COMPONENT_ANCHORS=6
echo REASSESSMENT_SOURCE_ONLY_ANCHORS=37
echo FULL_PAPER_MATHEMATICAL_PROOF=NOT_ESTABLISHED
echo NATIVE_REASSESSMENT_CHECKPOINT=PASS
>>"%LOG%" echo NATIVE_REASSESSMENT_CHECKPOINT=PASS
echo LINKED_PROVEN_RESULTS=SECTION_2_AND_3_1_AND_5_4
echo CONDITIONAL_MATHEMATICAL_TRANSFER=4_1
echo PARTIAL_COMPONENTS=3_3_TO_3_7_AND_5_6
echo SOURCE_TO_THEOREM_ANCHOR_CROSSWALK=PASS
echo FROZEN_PARAGRAPH_BASELINE=V0604_CERTIFIED_REUSED_WHEN_UNCHANGED
echo PDF_BODY_TEXT_BLOCKS_INDEXED=1502
echo NUMBERED_SOURCE_ITEMS=51
echo MATHEMATICAL_PROOFS_CLOSED=NOT_CLAIMED
echo PARAGRAPH_LEAN_MODULES_NEW_OR_CHANGED=!NEW!
echo PARAGRAPH_LEAN_MODULES_FROZEN_REUSED=!REUSED!
echo FULL_PAPER_PROOF=NOT_CLAIMED
echo CLAIM_CORRECTION_AND_MATHEMATICAL_PROOFS=SEPARATE_OPEN_FRONTIER
>>"%LOG%" echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS
echo PRINCIPAL_PROOFS_3_2_TO_3_4=PASS
>>"%LOG%" echo MATHEMATICAL_PROOF_LINKS=PASS
>>"%LOG%" echo REASSESSMENT_SOURCE_INDEXED=51_OF_51
>>"%LOG%" echo REASSESSMENT_PROOF_LINKED_UNCONDITIONAL_ANCHORS=7
>>"%LOG%" echo REASSESSMENT_PROOF_LINKED_CONDITIONAL_ANCHORS=1
>>"%LOG%" echo REASSESSMENT_PARTIAL_COMPONENT_ANCHORS=6
>>"%LOG%" echo REASSESSMENT_SOURCE_ONLY_ANCHORS=37
>>"%LOG%" echo FULL_PAPER_MATHEMATICAL_PROOF=NOT_ESTABLISHED
>>"%LOG%" echo NATIVE_REASSESSMENT_CHECKPOINT=PASS
>>"%LOG%" echo AXIOM_AUDIT=NO_SORRYAX_IN_NATIVE_PROOF_LINKS
>>"%LOG%" echo SOURCE_TO_THEOREM_ANCHOR_CROSSWALK=PASS
echo SOURCE_TO_THEOREM_ANCHOR_CROSSWALK=PASS
echo FROZEN_PARAGRAPH_BASELINE=V0604_CERTIFIED_REUSED_WHEN_UNCHANGED
>>"%LOG%" echo PDF_BODY_TEXT_BLOCKS_INDEXED=1502
>>"%LOG%" echo NUMBERED_SOURCE_ITEMS=51
>>"%LOG%" echo PARAGRAPH_LEAN_MODULES_NEW_OR_CHANGED=!NEW!
>>"%LOG%" echo PARAGRAPH_LEAN_MODULES_FROZEN_REUSED=!REUSED!
popd
exit /b 0

:compile
set "DID_COMPILE=0"
set "MODULE=%~1"
set "SOURCE=%ROOT%%MODULE%.lean"
set "OLEAN=%OUT%\%MODULE%.olean"
set "TMP=%STAGE%\%MODULE%.olean"
set "FREEZESRC=%FROZEN%\%MODULE%.lean"
set "ONELOG=%MODLOG%\%MODULE%.log"
for %%D in ("%FREEZESRC%" "%ONELOG%" "%TMP%" "%OLEAN%") do if not exist "%%~dpD" mkdir "%%~dpD" >nul 2>nul
if not exist "%SOURCE%" (
  echo ERROR=MISSING_%MODULE%.lean
  exit /b 1
)
set "SKIP=0"
if "%FORCE%"=="0" (
  if exist "%OLEAN%" if exist "%FREEZESRC%" (
    fc /B "%SOURCE%" "%FREEZESRC%" >nul 2>nul
    if not errorlevel 1 (
      for %%F in ("%OLEAN%") do if %%~zF GTR 0 set "SKIP=1"
    )
  )
)
if "%SKIP%"=="1" (
  set /a REUSED+=1
  echo FROZEN_REUSED=%MODULE%
  >>"%LOG%" echo FROZEN_REUSED=%MODULE%
  exit /b 0
)
if exist "%TMP%" del /F /Q "%TMP%" >nul 2>nul
echo CHECK=%MODULE%
>>"%LOG%" echo CHECK=%MODULE%
"%LEAN%" -j 1 -o "%TMP%" "%SOURCE%" 1>"%ONELOG%" 2>&1
if errorlevel 1 (
  echo CHECK_FAIL=%MODULE%
  type "%ONELOG%"
  >>"%LOG%" echo CHECK_FAIL=%MODULE%
  exit /b 1
)
if not exist "%TMP%" (
  echo OLEAN_NOT_CREATED=%MODULE%
  exit /b 1
)
for %%F in ("%TMP%") do if %%~zF LEQ 0 (
  echo OLEAN_EMPTY=%MODULE%
  exit /b 1
)
move /Y "%TMP%" "%OLEAN%" >nul 2>nul || exit /b 1
copy /B "%SOURCE%" "%FREEZESRC%" >nul 2>nul || exit /b 1
set "DID_COMPILE=1"
set /a NEW+=1
echo CHECK_PASS=%MODULE%
>>"%LOG%" echo CHECK_PASS=%MODULE%
exit /b 0

:missing_proof_cache
echo ERROR=PRIOR_MATHEMATICAL_PROOF_CACHE_MISSING
>>"%LOG%" echo ERROR=PRIOR_MATHEMATICAL_PROOF_CACHE_MISSING
goto fail
:untrusted_axioms
echo ERROR=PROOF_LINK_AUDIT_CONTAINS_SORRYAX
>>"%LOG%" echo ERROR=PROOF_LINK_AUDIT_CONTAINS_SORRYAX
goto fail
:missing
echo ERROR=LEAN_433_OR_PACKAGE_NOT_FOUND
>>"%LOG%" echo ERROR=LEAN_433_OR_PACKAGE_NOT_FOUND
goto fail
:busy
echo ERROR=ANOTHER_LEAN_BUILD_IS_ACTIVE
>>"%LOG%" echo ERROR=ANOTHER_LEAN_BUILD_IS_ACTIVE
goto fail
:compile_failed
popd
echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=FAIL
echo NATIVE_LOG=%LOG%
>>"%LOG%" echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=FAIL
exit /b 1
:fail
echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=FAIL
echo NATIVE_LOG=%LOG%
>>"%LOG%" echo PARAGRAPH_SOURCE_INDEX_CHECKPOINT=FAIL
exit /b 1
