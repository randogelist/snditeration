# Native v0.6.0.6 — mathematical source-to-proof links

The previous 56 PDF paragraph modules (1502 source body blocks / 51 indexed
results) are byte-for-byte unchanged and remain PASS-ONCE frozen.

This package adds five **mathematical** proof-link modules using exact theorem
types from the separate, previously compiler-passed PAPER_CHRONOLOGICAL_FASTCORE
branch. No imported module is automatically recompiled. Its `.olean` must be
present in the established cache, or the runner aborts with an explicit error.

The new `NativeProofCheckpoint` independently audits imported declarations with
`#print axioms`, and rejects `sorryAx` and `native_decide.ax_` in that audit.
The runner reports `MATHEMATICAL_PROOF_LINKS=PASS` *only after native compilation*
of all five new modules and successful axiom inspection. This checks linkage;
it does not imply full original-paper proof or resolve known manuscript errata.

For the numbered PDF anchors: Section 2 algebraic and rational-domain bridges,
Theorem 3.1's actual positive Gram spectral theorem, Theorem 4.1's conditional
transfer, Theorem 5.4's simple-pole cancellation, and selected finite components
of Theorems 3.3-3.7/5.6. See `PROOF_LINKS_LEDGER.csv` for the precise scope.

The imported proof cache is **read-only** here, and its immutable `.olean`
dependency fingerprints are checked before PASS-ONCE reuse. This is a separate
checkpoint from the paragraph-only v0.6.0.5 build. All Lean execution remains
on the user's native Windows 4.33.0 compiler.
