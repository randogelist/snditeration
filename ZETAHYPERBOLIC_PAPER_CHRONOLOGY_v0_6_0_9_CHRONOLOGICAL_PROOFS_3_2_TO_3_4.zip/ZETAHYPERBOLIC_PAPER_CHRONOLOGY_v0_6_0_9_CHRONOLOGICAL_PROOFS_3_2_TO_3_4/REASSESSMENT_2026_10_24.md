# Status against the 52-page source paper — 2026-10-24

## Scope of this assessment

This is a **conservative assessment of the v0.6.0.6 NATIVE_PROOF_LINKS checkpoint**, cross-checked against its `PROOF_LINKS_LEDGER.csv`, exact Lean theorem types, the 51-item source registry, and the native compiler transcript provided by the user. It is **not** a global theorem-coverage verdict across every other ZIP or branch. Additional already-compiled lemmas outside this checkpoint are not automatically counted as complete paper theorems.

| Layer | Evidence | What I can claim | What I cannot claim |
|---|---|---|---|
| PDF source registration | 1,502 geometric body-text blocks; 51 numbered source anchors; pages 1–51 | **100% of the chosen source-index inventory is Lean-integrated** | 1,502 natural-language paragraphs, or 100% mathematical formalization |
| Anchor provenance | `SOURCE_TO_THEOREM_ANCHOR_CROSSWALK=PASS` | Every indexed item is linked to its PDF page/block and hash | That the page's mathematical assertion is proved |
| Native imports | `MATHEMATICAL_PROOF_LINKS=PASS`, 61 cached/reused Lean modules, and exact `#check`/`#print axioms` | Selected genuine mathematical theorems are type-checked through the previous PASS-ONCE proof cache | 61 independent theorem proofs or 61 of 51 items completed |
| Full paper | `MATHEMATICAL_PROOFS_CLOSED=NOT_CLAIMED`, `FULL_PAPER_PROOF=NOT_CLAIMED` | **The full paper remains open** | An unconditional full-paper proof, or a single-Witness complete paper reduction |

## Proof-linked anchor inventory (this checkpoint only)

**7/51 (13.7%)** are associated with **unconditional mathematical proof links**: **2.1–2.5**, **3.1**, **5.4**.  Their linking theorems are genuine formal statements: Section 2 finite algebraic and rational-moment chains, the Section 3.1 admissible-parameter spectral result, and Section 5.4 simple-pole cancellation. **This count is a link count, not proof that every subclaim in the printed 7 statements has been checked word-for-word.**

**1/51 (2.0%)** is linked as a **proved conditional transfer**: **Theorem 4.1**. Its logical implication is formalized, but its required quantitative sequence/witness input is not supplied by the source-index checkpoint.

**6/51 (11.8%)** carry **only partial finite components or errata**: **3.3, 3.4, 3.5, 3.6, 3.7, 5.6**. Among these, 3.5 and 3.6 need corrected manuscript statements; the printed claims are not certified. Theorem 5.6 has a rational sum calculation, not the complete analytic integral and valuation claim.

**37/51 (72.5%)** are **source-indexed without an approved proof link in this checkpoint**. This classification does NOT rule out useful proofs in other Lean packages; it means no complete mathematical link is established by this checkpoint.

The 51 anchored items include definitions, lemmas, remarks and a conjecture, not 51 independent theorems; therefore `13.7%` is an **anchor-link ratio**, *not* a rigorous percentage of the paper's mathematics proved.

## Section-by-section conservative reading

- **Section 2:** the most substantive area; formal source-linked global rational moment and Lagrange/Vandermonde structures. One must still compare *each printed statement and its domain* to the Lean types before declaring five of five manuscript claims closed.
- **Section 3:** Theorem 3.1 has a real source-linked result. Theorem 3.3 (leading coefficient), 3.4 (3×3 Dodgson), 3.5 (corrected rank-one), 3.6 (finite-support rank obstruction), 3.7 (quadratic Turán) are *partial*. 3.2, 3.8, 3.9 and 3.10 have no approved proof links in this checkpoint.
- **Section 4:** Theorem 4.1 conditional transfer, but no discharge of the paper's effective integrality/height/root-gap bounds for Theorem 4.4, the linear-form endpoint 4.5, or the subsequent asymptotics. Other branches may contain independent certified sublemmas.
- **Section 5:** Theorem 5.4 simple-pole cancellation has a source-linked proof; 5.6 has an exact finite rational sum only. Two-variable Beukers integration, Krein decomposition and the p-adic double-pole argument remain to be linked and audited here.
- **Section 6:** indexed but no mathematical proof link in this checkpoint. At least Theorem 6.4 also has a known sign/formula erratum that must be resolved before faithful certification.

## Recommended formal milestone (not yet achieved)

For each indexed source claim create (a) a precisely typed Lean proposition matching the **corrected** printed mathematics; (b) a compiled proof or one explicit `Witness` *only for an authentic missing mathematical input*; (c) an axiom audit proving no `sorryAx`; (d) a map from every significant proof step to its source anchor. Promote an item to `FULL_STATEMENT_CERTIFIED` **only after** checking all four and native compiler PASS. Do not infer certification from source paragraphs, module counts, or an imported theorem with a weaker conclusion.

**Strongest defensible summary:** the source-provenance framework is complete for the 51-item inventory and imports genuine mathematics; full source-faithful theorem closure is not established. Quantify source-index coverage as 100%, mathematical linked-anchor coverage as 8/51 including the conditional transfer (15.7%), and **avoid assigning a single full-paper proof percentage** until exact theorem-statement matching is audited.

## Provenance of the classification

The unconditional/conditional/partial mapping follows `PROOF_LINKS_LEDGER.csv` in the v0.6.0.6 source. The last native transcript shows `MATHEMATICAL_PROOF_LINKS=PASS` and 61 unchanged modules reused. It does not prove a complete 51-item mathematical theorem chain. All actual Lean execution remains on the user's Windows Lean 4.33.0.
