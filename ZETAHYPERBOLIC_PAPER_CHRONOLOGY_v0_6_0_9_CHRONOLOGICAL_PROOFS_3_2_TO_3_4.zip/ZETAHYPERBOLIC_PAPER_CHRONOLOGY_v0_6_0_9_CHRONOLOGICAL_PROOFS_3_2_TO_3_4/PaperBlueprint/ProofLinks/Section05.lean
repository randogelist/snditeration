import PaperBlueprint.ProofLinks.Section04
import PaperChronological.T5_4
import PaperChronological.T5_6

/-!
# Source-to-proof links — Section 5

Theorem 5.4's actual simple-pole cancellation and the exact finite rational
piece-sum component of Theorem 5.6 are proved. The analytic identification of
the paper's piecewise integrand remains a distinct mathematical obligation.
-/

noncomputable section
open PaperBlueprint.Paragraphs

namespace PaperBlueprint.ProofLinks

theorem section05_source_labels_indexed :
    (["5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7"] : List String).all
      (fun s => sourceAnchorIds.contains s) = true := by decide

/-- Printed Theorem 5.4 for simple poles (the domain the paper uses). -/
theorem THEOREM_5_4_EVEN_POLE_CANCELLATION_LINK
    (k j : ℕ) (hj : 1 <= j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (((j : ℚ) ^ (2 * k + 1))⁻¹) :=
  PaperChronological.THEOREM_5_4_EVEN_POLE_PAIR k j hj

/-- The exact tabulated rational total in Theorem 5.6, not an unproved
integral identification. -/
theorem THEOREM_5_6_AFFINE_TOTAL_COMPONENT :
    (223/1920 : ℚ) + 2177/115200 + 10527/320000 +
      48359/160000 + 53/1152 + 259/7200 + 1929/12800 +
      10469/38400 + 37/120 - 111/1600 + 289/800 = 453803/288000 :=
  PaperChronological.THEOREM_5_6_OUTER_RATIONAL_SUM

end PaperBlueprint.ProofLinks
