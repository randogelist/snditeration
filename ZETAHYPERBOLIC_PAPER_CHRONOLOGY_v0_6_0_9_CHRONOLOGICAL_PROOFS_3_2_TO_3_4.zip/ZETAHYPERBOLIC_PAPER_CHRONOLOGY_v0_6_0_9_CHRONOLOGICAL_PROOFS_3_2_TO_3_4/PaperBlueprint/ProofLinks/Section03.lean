import PaperBlueprint.ProofLinks.Section02
import PaperChronological.T3_1
import PaperChronological.T3_3
import PaperChronological.T3_4
import PaperChronological.T3_5
import PaperChronological.T3_6
import PaperChronological.T3_7

/-!
# Source-to-proof links — paper Section 3

Theorem 3.1 is imported with its actual odd-zeta positivity and hyperbolicity
hypotheses. Later results below are individual proven *components*; the full
printed Theorems 3.3--3.9 are not certified merely by this bridge.
Corollaries 3.5 and 3.6 require the manuscript errata documented elsewhere.
-/

noncomputable section
open PaperBlueprint.Paragraphs

namespace PaperBlueprint.ProofLinks

theorem section03_source_labels_indexed :
    (["3.1", "3.2", "3.3", "3.4", "3.5", "3.6", "3.7", "3.8", "3.9"] : List String).all
      (fun s => sourceAnchorIds.contains s) = true := by decide

/-- Paper Theorem 3.1: the actual odd-zeta Hankel-pencil theorem, not merely
an abstract real-rooted polynomial. Admissibility is its parameter domain. -/
theorem THEOREM_3_1_ACTUAL_ZETA_PROOF
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  PaperChronological.THEOREM_3_1_UNIVERSAL_HYPERBOLICITY p hp

/-- One of the printed Theorem 3.3 claims: nonvanishing of leading coefficient.
The all-minor total positivity assertion is a separate obligation. -/
theorem THEOREM_3_3_LEADING_COEFFICIENT_COMPONENT
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).coeff p.h ≠ 0 :=
  PaperChronological.THEOREM_3_3_LEADING_COEFF_NONZERO p

/-- Explicit symmetric 3 x 3 Dodgson identity (component of 3.4). -/
theorem THEOREM_3_4_DODGSON_COMPONENT
    (a b c d e f : ℝ) :
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2)*a =
       (a*d - b^2)*(a*f - c^2) - (a*e - b*c)^2 :=
  PaperChronological.THEOREM_3_4_DODGSON_THREE_BY_THREE a b c d e f

/-- The printed Corollary 3.5 has an erratum; this is the corrected rank-one
identity only, with the genuine normalizing factor retained. -/
theorem COROLLARY_3_5_CORRECTED_COMPONENT
    (g m xi x : ℝ) (hg : g ≠ 0) :
    g * (1 + (x - xi) * (m/g)) = g + (x - xi) * m :=
  PaperChronological.COROLLARY_3_5_CORRECTED_ONE_BY_ONE g m xi x hg

/-- Corollary 3.6 cannot be strictly positive at all Hankel sizes for a
finite-atomic measure; the rank-one identity is a genuine obstruction. -/
theorem COROLLARY_3_6_FINITE_SUPPORT_OBSTRUCTION (u : ℝ) :
    (1 : ℝ) * u^2 - u*u = 0 :=
  PaperChronological.COROLLARY_3_6_RANK_ONE_OBSTRUCTION u

/-- A valid quadratic Turan component; the all-degree result is not claimed. -/
theorem THEOREM_3_7_QUADRATIC_COMPONENT (x r s : ℝ) :
    0 <= (2*x - r - s)^2 - 2*(x-r)*(x-s) :=
  PaperChronological.THEOREM_3_7_QUADRATIC_TURAN x r s

end PaperBlueprint.ProofLinks
