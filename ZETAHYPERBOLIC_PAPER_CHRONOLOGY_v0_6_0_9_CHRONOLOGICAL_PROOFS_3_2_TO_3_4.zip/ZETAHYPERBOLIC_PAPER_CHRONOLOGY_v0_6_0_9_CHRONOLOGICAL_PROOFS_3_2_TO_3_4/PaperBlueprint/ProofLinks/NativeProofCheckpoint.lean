import PaperBlueprint.ProofLinks.Section05

/-!
# NATIVE proof-linked manuscript checkpoint

On the user's compiler, this verifies source location and exact theorem types
in one environment. This DOES NOT conclude that all 51 numbered manuscript
statements are proved. In particular the paper's analytic, archimedean,
valuation and indefinite Krein-space obligations remain open where explicit.

Axiom audit below checks the actual imported proof dependencies, not the
mere source-block wrappers. Any `sorryAx` in the compiler output is a FAIL.
-/

namespace PaperBlueprint.ProofLinks

theorem PDF_SOURCE_INDEX_STILL_VERIFIED :
    PaperBlueprint.Paragraphs.numberedSourceAnchors.all
      PaperBlueprint.Paragraphs.sourceAnchorMatches = true :=
  PaperBlueprint.Paragraphs.SOURCE_CHECKPOINT_ALL_ITEM_BLOCKS

#check SECTION02_ALGEBRAIC_PROOF
#check SECTION02_RATIONAL_PROOF
#check SECTION02_MOMENT_LINEARITY_PROOF
#check THEOREM_2_5_DERIVATIVE_LINK
#check THEOREM_3_1_ACTUAL_ZETA_PROOF
#check THEOREM_3_3_LEADING_COEFFICIENT_COMPONENT
#check THEOREM_3_4_DODGSON_COMPONENT
#check COROLLARY_3_5_CORRECTED_COMPONENT
#check COROLLARY_3_6_FINITE_SUPPORT_OBSTRUCTION
#check THEOREM_3_7_QUADRATIC_COMPONENT
#check THEOREM_4_1_TRANSFER_LINK
#check THEOREM_5_4_EVEN_POLE_CANCELLATION_LINK
#check THEOREM_5_6_AFFINE_TOTAL_COMPONENT

#print axioms SECTION02_ALGEBRAIC_PROOF
#print axioms SECTION02_RATIONAL_PROOF
#print axioms SECTION02_MOMENT_LINEARITY_PROOF
#print axioms THEOREM_2_5_DERIVATIVE_LINK
#print axioms THEOREM_3_1_ACTUAL_ZETA_PROOF
#print axioms THEOREM_3_3_LEADING_COEFFICIENT_COMPONENT
#print axioms THEOREM_3_4_DODGSON_COMPONENT
#print axioms COROLLARY_3_5_CORRECTED_COMPONENT
#print axioms COROLLARY_3_6_FINITE_SUPPORT_OBSTRUCTION
#print axioms THEOREM_3_7_QUADRATIC_COMPONENT
#print axioms THEOREM_4_1_TRANSFER_LINK
#print axioms THEOREM_5_4_EVEN_POLE_CANCELLATION_LINK
#print axioms THEOREM_5_6_AFFINE_TOTAL_COMPONENT

end PaperBlueprint.ProofLinks
