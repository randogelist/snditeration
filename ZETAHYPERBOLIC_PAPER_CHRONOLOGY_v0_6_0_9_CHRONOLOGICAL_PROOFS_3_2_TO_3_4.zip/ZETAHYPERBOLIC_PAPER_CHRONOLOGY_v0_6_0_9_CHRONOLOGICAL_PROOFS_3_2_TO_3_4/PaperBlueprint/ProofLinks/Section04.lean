import PaperBlueprint.ProofLinks.Section03
import PaperChronological.T4_1

/-!
# Actual mathematical proof link — Theorem 4.1

This is a mathematical transfer theorem with explicit inputs. It does NOT
establish the missing uniform denominator / determinant / spectral bounds,
nor the actual paper's claimed numerical exponent, without those inputs.
-/

noncomputable section
open PaperBlueprint.Paragraphs

namespace PaperBlueprint.ProofLinks

theorem section04_source_labels_indexed :
    (["4.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8"] : List String).all
      (fun s => sourceAnchorIds.contains s) = true := by decide

/-- The verified finite Diophantine transfer, with every required analytic
and arithmetic estimate carried as an explicit named parameter. -/
theorem THEOREM_4_1_TRANSFER_LINK
    {Q : ℕ → Polynomial ℤ} {xi : ℝ} {radius budget : ℕ → ℝ}
    {n0 mu b0 : ℕ}
    (comparison : ManuscriptChain.RealTransfer.LocalComparison Q xi radius n0)
    (decay : ManuscriptChain.RealTransfer.Decay Q xi budget n0)
    (index : ManuscriptChain.RealTransfer.IndexBudget Q radius budget n0 mu b0) :
    ManuscriptChain.RealTransfer.RationalMeasure xi mu b0 :=
  PaperChronological.THEOREM_4_1_SPECTRAL_TRANSFER comparison decay index

end PaperBlueprint.ProofLinks
