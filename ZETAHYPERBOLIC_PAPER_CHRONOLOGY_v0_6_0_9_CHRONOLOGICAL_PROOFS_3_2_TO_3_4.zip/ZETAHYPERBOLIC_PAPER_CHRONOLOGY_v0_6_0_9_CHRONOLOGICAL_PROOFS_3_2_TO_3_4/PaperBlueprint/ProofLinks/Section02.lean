import PaperBlueprint.Paragraphs.ProvenanceCheckpoint
import PaperChronological.S2_RationalEndpoint
import PaperChronological.S2_GlobalMomentLinearMap
import PaperChronological.T2_5

/-!
# Actual mathematical proofs linked to the numbered PDF source — Section 2

This imports the previously native-verified chronological Mathlib proof branch
from the user's PASS-ONCE .olean cache. It does NOT construct a new axiom or
convert a source-text paragraph into a mathematical proof. The mathematical
content is inherited, with exact types, from checked theorem declarations.

The underlying proofs here are unconditional finite algebraic results. This
file does not assert that all analytic claims in the paper are closed.
-/

noncomputable section
open scoped BigOperators
open PaperBlueprint.Paragraphs

namespace PaperBlueprint.ProofLinks

/-- The five Section 2 labels are present in the SHA-checked manuscript index. -/
theorem section02_source_labels_indexed :
    (["2.1", "2.2", "2.3", "2.4", "2.5"] : List String).all
      (fun s => sourceAnchorIds.contains s) = true := by decide

/-- All source blocks referenced by Section 2 also pass the full 51-item
PDF body-block crosswalk. This is a source audit, not a math theorem. -/
theorem section02_pdf_provenance :
    numberedSourceAnchors.all sourceAnchorMatches = true :=
  PaperBlueprint.Paragraphs.SOURCE_CHECKPOINT_ALL_ITEM_BLOCKS

/-- Existing unconditional Section 2 finite algebraic spine, including
basis invariance and the Vandermonde factorization. -/
theorem SECTION02_ALGEBRAIC_PROOF
    (p : ManuscriptChain.Real.Parameters) :
    PaperChronological.Section2.AlgebraicChain p :=
  PaperChronological.Section2.SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN p

/-- The same Section 2 proof including ordinary residues and genuine rational
function evaluation away from the poles. -/
theorem SECTION02_RATIONAL_PROOF
    (p : ManuscriptChain.Real.Parameters) :
    PaperChronological.Section2.RationalAlgebraicChain p :=
  PaperChronological.Section2.SECTION2_RATIONAL_ALGEBRAIC_CHAIN p

/-- Global Q-linearity of the rational moment on the directed-union quotient.
This is the actual functional, not a finite-cardinality placeholder. -/
theorem SECTION02_MOMENT_LINEARITY_PROOF :
    PaperChronological.Section2.GlobalMomentLinearityChain :=
  PaperChronological.Section2.SECTION2_GLOBAL_MOMENT_LINEARITY

/-- Exact X-derivative Vandermonde factorization, paper Theorem 2.5. -/
theorem THEOREM_2_5_DERIVATIVE_LINK
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p =
      ManuscriptChain.PoleDiagonalization.poleVandermonde p *
      Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
      (ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose :=
  PaperChronological.THEOREM_2_5_VANDERMONDE p

end PaperBlueprint.ProofLinks
