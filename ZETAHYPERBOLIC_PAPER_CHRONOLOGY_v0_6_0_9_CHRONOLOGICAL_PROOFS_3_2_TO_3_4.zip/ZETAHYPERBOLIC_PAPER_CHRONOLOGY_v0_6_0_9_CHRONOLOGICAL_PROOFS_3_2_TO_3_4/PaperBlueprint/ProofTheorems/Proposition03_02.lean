import PaperBlueprint.ProofLinks.NativeProofCheckpoint
import PaperChronological.T3_2

/-!
# Proposition 3.2 — genuine real-parameter spectral core

The paper's continuous-parameter argument separates cleanly into:
1. the positivity and nonsingularity inputs for the parameter-specific matrix;
2. the proved finite-dimensional hyperbolicity implication.

The theorems in this file formalize step 2 for ALL real s > 1, giving exact
polynomial degree, reality of every complex root, and center nonvanishing.
They DO NOT infer the concrete manuscript weight's integral identity from
positive definiteness; its explicit analytic identification remains open.
No manuscript conclusion has been hidden in the fields of this structure.
-/

noncomputable section
open scoped BigOperators

namespace PaperBlueprint.ProofTheorems

/-- A family of real symmetric matrix pencils for which the two required
pointwise matrix facts have been furnished. This records the exact logical
scope of the spectral reduction, not the paper's specific Gamma weight. -/
structure RealParameterPencils (n : ℕ) where
  pencil : ℝ → ManuscriptChain.Spectral.SymmetricAffinePencil n
  base_posDef : ∀ (s : ℝ), 1 < s → (pencil s).base.PosDef
  direction_nonsingular : ∀ (s : ℝ), 1 < s → (pencil s).direction.det ≠ 0

/-- Proposition 3.2's exact-degree and hyperbolicity mechanism at EACH real
parameter s > 1. The proof is a specialization of the already-proved,
unconditional symmetric-affine-pencil spectral theorem of §3.1. -/
theorem PROPOSITION_3_2_ALL_REAL_PARAMETERS
    {n : ℕ} (F : RealParameterPencils n) (s : ℝ) (hs : 1 < s) :
    (F.pencil s).detPolynomial.natDegree = n ∧
      ∀ z : ℂ,
        Polynomial.eval₂ (algebraMap ℝ ℂ) z (F.pencil s).detPolynomial = 0 →
          z.im = 0 := by
  exact PaperChronological.PROP_3_2_ABSTRACT_REAL_PENCIL
    (F.pencil s) (F.base_posDef s hs) (F.direction_nonsingular s hs)

/-- The spectral center is strictly outside the zero locus, again for every
real s > 1. This requires no quantitative norm bound or witness. -/
theorem PROPOSITION_3_2_NONVANISHING_AT_CENTER
    {n : ℕ} (F : RealParameterPencils n) (s : ℝ) (hs : 1 < s) :
    (F.pencil s).detPolynomial.eval ((F.pencil s).center) ≠ 0 :=
  (F.pencil s).center_nonvanishing_of_positive (F.base_posDef s hs)

/-- The derived pointwise matrix conclusion holds simultaneously for all
parameters in the whole interval (1, infinity). -/
theorem PROPOSITION_3_2_FAMILY_ENDPOINT
    {n : ℕ} (F : RealParameterPencils n) :
    ∀ (s : ℝ), 1 < s →
      (F.pencil s).detPolynomial.natDegree = n ∧
      (∀ z : ℂ,
        Polynomial.eval₂ (algebraMap ℝ ℂ) z (F.pencil s).detPolynomial = 0 →
          z.im = 0) ∧
      (F.pencil s).detPolynomial.eval ((F.pencil s).center) ≠ 0 := by
  intro s hs
  obtain ⟨hdegree, hroots⟩ := PROPOSITION_3_2_ALL_REAL_PARAMETERS F s hs
  exact ⟨hdegree, hroots, PROPOSITION_3_2_NONVANISHING_AT_CENTER F s hs⟩

end PaperBlueprint.ProofTheorems

#print axioms PaperBlueprint.ProofTheorems.PROPOSITION_3_2_ALL_REAL_PARAMETERS
#print axioms PaperBlueprint.ProofTheorems.PROPOSITION_3_2_FAMILY_ENDPOINT
