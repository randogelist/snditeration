import PaperBlueprint.ProofTheorems.Theorem03_03
import PaperChronological.T3_4

/-!
# Theorem 3.4 — sign of the exact Dodgson 3x3 specialization

The finite signed condensation at a root of the order-two principal minor
follows rigorously from the proven 3x3 determinant identity. This is a
strictly source-faithful small-dimensional instance of the printed equation
(3.5). It is NOT the paper's global all-dimension interlacing theorem.
-/

noncomputable section

namespace PaperBlueprint.ProofTheorems

/-- Exact condensation identity when the 2x2 leading principal minor
vanishes. -/
theorem THEOREM_3_4_CONDENSATION_AT_MINOR_ROOT
    (a b c d e f : ℝ) (hz : a * d - b ^ 2 = 0) :
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2)*a =
      -(a*e - b*c)^2 := by
  calc
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2)*a =
        (a*d - b^2)*(a*f - c^2) - (a*e - b*c)^2 :=
      PaperChronological.THEOREM_3_4_DODGSON_THREE_BY_THREE a b c d e f
    _ = -(a*e - b*c)^2 := by rw [hz]; ring

/-- The same condensation has nonpositive sign, including equality when the
mixed cofactor vanishes. No analytic positivity hypothesis is assumed. -/
theorem THEOREM_3_4_CONDENSATION_SIGN
    (a b c d e f : ℝ) (hz : a*d - b^2 = 0) :
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2)*a ≤ 0 := by
  rw [THEOREM_3_4_CONDENSATION_AT_MINOR_ROOT a b c d e f hz]
  exact neg_nonpos.mpr (sq_nonneg _)

end PaperBlueprint.ProofTheorems

#print axioms PaperBlueprint.ProofTheorems.THEOREM_3_4_CONDENSATION_AT_MINOR_ROOT
#print axioms PaperBlueprint.ProofTheorems.THEOREM_3_4_CONDENSATION_SIGN
