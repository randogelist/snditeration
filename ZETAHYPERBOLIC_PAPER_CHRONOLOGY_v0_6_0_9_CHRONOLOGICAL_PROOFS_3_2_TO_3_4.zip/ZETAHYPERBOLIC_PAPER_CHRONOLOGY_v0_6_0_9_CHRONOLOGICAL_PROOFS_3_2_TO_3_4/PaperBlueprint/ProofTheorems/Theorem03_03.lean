import PaperBlueprint.ProofTheorems.Proposition03_02
import PaperChronological.T2_5
import PaperChronological.T3_3
import MAIN_CHAIN_ASSEMBLED

/-!
# Theorem 3.3 — unconditional signed spectral reduction for the actual paper pencil

This module makes the root-side/sign logic explicit for the actual odd-weight
Hankel polynomial. The identification of the slope with the signed
Vandermonde/diagonal congruence and its nonsingularity are inherited from
§2.5. The eigenvalue sign/side equivalence is established below.

The PDF's stronger exact alternating inertia counts, Carleman determinacy,
and every non-principal total-positivity minor are still separate open claims.
-/

noncomputable section
open scoped BigOperators

namespace PaperBlueprint.ProofTheorems

/-- The manuscript's *actual* rational derivative matrix is exactly a
signed diagonal congruence, not a generic positive-semidefinite surrogate. -/
theorem THEOREM_3_3_ACTUAL_SLOPE_CONGRUENCE
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p =
      ManuscriptChain.PoleDiagonalization.poleVandermonde p *
      Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
      (ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose :=
  PaperChronological.THEOREM_2_5_VANDERMONDE p

/-- The manuscript's highest-degree coefficient cannot vanish. -/
theorem THEOREM_3_3_ACTUAL_LEADING_COEFF_NONZERO
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).coeff p.h ≠ 0 :=
  PaperChronological.THEOREM_3_3_LEADING_COEFF_NONZERO p

/-- Every indexed spectral root is BELOW the center iff its corresponding
nonzero real spectral parameter is positive. -/
theorem root_below_center_iff_beta_positive
    {n : ℕ} {p : ManuscriptChain.Spectral.SymmetricAffinePencil n}
    (c : ManuscriptChain.Spectral.RootFactorization p) (i : Fin n) :
    c.root i < p.center ↔ 0 < c.beta i := by
  unfold ManuscriptChain.Spectral.RootFactorization.root
  constructor
  · intro h
    have hinv : 0 < (c.beta i)⁻¹ := by linarith
    exact inv_pos.mp hinv
  · intro hb
    have hinv : 0 < (c.beta i)⁻¹ := inv_pos.mpr hb
    linarith

/-- Every indexed spectral root is ABOVE the center iff the spectral
parameter is negative. The zero case is excluded by derivative
nonsingularity; no analytic arithmetic witness appears. -/
theorem root_above_center_iff_beta_negative
    {n : ℕ} {p : ManuscriptChain.Spectral.SymmetricAffinePencil n}
    (c : ManuscriptChain.Spectral.RootFactorization p) (i : Fin n) :
    p.center < c.root i ↔ c.beta i < 0 := by
  have hbelow := root_below_center_iff_beta_positive c i
  constructor
  · intro hr
    rcases lt_trichotomy (c.beta i) 0 with hn | hz | hp
    · exact hn
    · exact False.elim ((c.beta_ne_zero i) hz)
    · have hl : c.root i < p.center := hbelow.mpr hp
      linarith
  · intro hn
    rcases lt_trichotomy (c.root i) p.center with hl | heq | hr
    · have hp : 0 < c.beta i := hbelow.mp hl
      linarith
    · exact False.elim ((c.root_ne_center i) heq)
    · exact hr

/-- Genuine odd-zeta polynomial: unconditional real spectral parameters,
and exact two-sided root classification around its actual center zeta(s).
This is one proved structural component of PDF Theorem 3.3. -/
theorem THEOREM_3_3_ACTUAL_ODD_ZETA_BILATERAL_ROOTS
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q) :
    ∃ beta : Fin q.h → ℝ,
      (∀ i, beta i ≠ 0) ∧
      (∀ i, ManuscriptChain.Real.zeta q.weight - (beta i)⁻¹ <
           ManuscriptChain.Real.zeta q.weight ↔ 0 < beta i) ∧
      (∀ i, ManuscriptChain.Real.zeta q.weight <
           ManuscriptChain.Real.zeta q.weight - (beta i)⁻¹ ↔ beta i < 0) := by
  let c := ManuscriptChain.General.factorization q
    (ManuscriptChain.GRAM_POSITIVE q hq)
  refine ⟨c.beta, c.beta_ne_zero, ?_, ?_⟩
  · intro i
    simpa only [ManuscriptChain.Real.manuscriptPencil_center,
      ManuscriptChain.Spectral.RootFactorization.root] using
      (root_below_center_iff_beta_positive c i)
  · intro i
    simpa only [ManuscriptChain.Real.manuscriptPencil_center,
      ManuscriptChain.Spectral.RootFactorization.root] using
      (root_above_center_iff_beta_negative c i)

end PaperBlueprint.ProofTheorems

#print axioms PaperBlueprint.ProofTheorems.THEOREM_3_3_ACTUAL_SLOPE_CONGRUENCE
#print axioms PaperBlueprint.ProofTheorems.THEOREM_3_3_ACTUAL_ODD_ZETA_BILATERAL_ROOTS
