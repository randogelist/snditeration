import PaperBlueprint.ProofTheorems.Theorem03_04

/-!
# Chronological proof milestone: 3.2 -> 3.3 -> 3.4

These are actual Lean mathematical theorems with source-accurate scope.
Do NOT promote 3.2, 3.3 or 3.4 to a full-paper claim: the continuous
Gamma-weight identification, full total positivity/signature, and global
interlacing still require separate mathematics.
-/

namespace PaperBlueprint.ProofTheorems

#check PROPOSITION_3_2_ALL_REAL_PARAMETERS
#check PROPOSITION_3_2_NONVANISHING_AT_CENTER
#check PROPOSITION_3_2_FAMILY_ENDPOINT
#check THEOREM_3_3_ACTUAL_SLOPE_CONGRUENCE
#check THEOREM_3_3_ACTUAL_LEADING_COEFF_NONZERO
#check THEOREM_3_3_ACTUAL_ODD_ZETA_BILATERAL_ROOTS
#check THEOREM_3_4_CONDENSATION_AT_MINOR_ROOT
#check THEOREM_3_4_CONDENSATION_SIGN

#print axioms PROPOSITION_3_2_ALL_REAL_PARAMETERS
#print axioms PROPOSITION_3_2_NONVANISHING_AT_CENTER
#print axioms PROPOSITION_3_2_FAMILY_ENDPOINT
#print axioms THEOREM_3_3_ACTUAL_SLOPE_CONGRUENCE
#print axioms THEOREM_3_3_ACTUAL_LEADING_COEFF_NONZERO
#print axioms THEOREM_3_3_ACTUAL_ODD_ZETA_BILATERAL_ROOTS
#print axioms THEOREM_3_4_CONDENSATION_AT_MINOR_ROOT
#print axioms THEOREM_3_4_CONDENSATION_SIGN

end PaperBlueprint.ProofTheorems
