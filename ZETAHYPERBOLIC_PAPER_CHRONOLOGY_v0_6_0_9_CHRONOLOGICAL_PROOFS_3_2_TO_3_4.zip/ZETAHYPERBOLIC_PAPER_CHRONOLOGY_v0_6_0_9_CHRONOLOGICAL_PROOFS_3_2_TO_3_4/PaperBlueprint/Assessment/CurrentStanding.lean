import PaperBlueprint.ProofLinks.NativeProofCheckpoint

/-!
Source-to-mathematics checkpoint for the 51 indexed manuscript items.
This module certifies the **inventory classification**, not the truth of any
unproved PDF theorem. Actual native mathematical links are imported from
`NativeProofCheckpoint`; no placeholder proposition is used as mathematics.
-/
namespace PaperBlueprint.Assessment

open PaperBlueprint.Paragraphs

def unconditionalLinked : List String := ["2.1", "2.2", "2.3", "2.4", "2.5", "3.1", "5.4"]
def conditionalLinked : List String := ["4.1"]
def componentLinked : List String := ["3.3", "3.4", "3.5", "3.6", "3.7", "5.6"]
def sourceOnly : List String := ["3.2", "3.8", "3.9", "3.10", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8", "4.9", "4.10", "4.11", "5.1", "5.2", "5.3", "5.5", "5.7", "6.1", "6.2", "6.3", "6.4", "6.5", "6.6", "6.7", "6.8", "6.9", "6.10", "6.11", "6.12", "6.13", "6.14", "6.15", "6.16", "6.17", "6.18"]

def classified : List String :=
  unconditionalLinked ++ conditionalLinked ++ componentLinked ++ sourceOnly

theorem unconditional_link_count : unconditionalLinked.length = 7 := by decide
theorem conditional_link_count : conditionalLinked.length = 1 := by decide
theorem component_link_count : componentLinked.length = 6 := by decide
theorem source_only_count : sourceOnly.length = 37 := by decide
theorem classified_count : classified.length = 51 := by decide
theorem no_duplicated_classifications : classified.Nodup := by decide
theorem all_classified_have_real_pdf_anchors :
    classified.all (fun s => sourceAnchorIds.contains s) = true := by decide

theorem original_inventory_count : numberedSourceAnchors.length = 51 :=
  PaperBlueprint.Paragraphs.SOURCE_CHECKPOINT_51

theorem original_body_block_count : indexedSourceBlocks = 1502 :=
  PaperBlueprint.Paragraphs.SOURCE_CHECKPOINT_1502

-- The actual mathematical assertions remain in the imported ProofLinks files:
#check PaperBlueprint.ProofLinks.SECTION02_RATIONAL_PROOF
#check PaperBlueprint.ProofLinks.THEOREM_3_1_ACTUAL_ZETA_PROOF
#check PaperBlueprint.ProofLinks.THEOREM_4_1_TRANSFER_LINK
#check PaperBlueprint.ProofLinks.THEOREM_5_4_EVEN_POLE_CANCELLATION_LINK

#print axioms original_inventory_count
#print axioms original_body_block_count
#print axioms all_classified_have_real_pdf_anchors

end PaperBlueprint.Assessment
