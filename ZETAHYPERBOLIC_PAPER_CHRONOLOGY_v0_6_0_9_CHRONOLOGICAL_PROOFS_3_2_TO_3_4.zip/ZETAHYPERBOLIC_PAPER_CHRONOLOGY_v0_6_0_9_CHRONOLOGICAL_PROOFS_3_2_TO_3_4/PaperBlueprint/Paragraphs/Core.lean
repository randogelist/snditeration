import Lean

/-!
# Theorem-faithful PDF source-block inventory (52-page manuscript, 21 Oct 2026)

This is *source integration*, not a proof of any theorem in the PDF.
Every entry stores text extracted from a body block of the original PDF,
its page and theorem/proposition anchor. Geometric PDF blocks need not coincide
with semantic paragraphs. Source errors and manuscript errata are NOT fixed here.
-/
namespace PaperBlueprint.Paragraphs

structure SourceBlock where
  sequence : Nat
  pdfPage : Nat
  pageBlock : Nat
  chapter : Nat
  anchor : String
  classification : String
  sourceSha256 : String
  sourceText : String
  deriving Inhabited, Repr

end PaperBlueprint.Paragraphs
