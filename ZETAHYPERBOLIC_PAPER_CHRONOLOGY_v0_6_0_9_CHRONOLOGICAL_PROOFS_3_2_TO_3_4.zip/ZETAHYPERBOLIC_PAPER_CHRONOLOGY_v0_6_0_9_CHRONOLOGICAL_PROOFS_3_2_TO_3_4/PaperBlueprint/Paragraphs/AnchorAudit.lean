import PaperBlueprint.Paragraphs.NumberedSourceBridge

/-!
Machine-checkable crosswalk from all 51 manuscript items to the 1502
PDF body blocks already present in Lean. This audits provenance only.
Explicitly not an unconditional proof of any of the numbered results.
-/

namespace PaperBlueprint.Paragraphs

set_option maxRecDepth 8192
set_option maxHeartbeats 4000000

-- The following requires the exact PDF-block location, anchor, and source
-- SHA-256 to match the actual Lean source data for all 51 printed items.
theorem every_numbered_item_has_exact_pdf_block :
    numberedSourceAnchors.all sourceAnchorMatches = true := by decide

-- An indexed paragraph is not a proved theorem. Deliberately there is no
-- coercion from NumberedSourceAnchor to Prop, and no fake `True` endpoint.

theorem source_crosswalk_item_count : sourceAnchorIds.length = 51 := by
  exact fifty_one_source_anchors

end PaperBlueprint.Paragraphs
