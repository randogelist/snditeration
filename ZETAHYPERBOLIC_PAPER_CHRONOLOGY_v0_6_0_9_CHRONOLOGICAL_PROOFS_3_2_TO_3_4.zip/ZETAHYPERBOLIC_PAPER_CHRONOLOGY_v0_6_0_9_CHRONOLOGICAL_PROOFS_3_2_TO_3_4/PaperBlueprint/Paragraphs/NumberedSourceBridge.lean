import PaperBlueprint.Paragraphs.Checkpoint

/-!
Source-to-numbered-result map for the 52-page odd-zeta manuscript.
These are manuscript SOURCE ANCHORS, not proofs of the printed claims.
Every entry carries the source PDF page/block plus the SHA-256 of the
corresponding PDF body block.  No mathematical theorem is asserted here.
-/

namespace PaperBlueprint.Paragraphs

structure NumberedSourceAnchor where
  number : String
  kind : String
  pdfPage : Nat
  pageBlock : Nat
  sourceSha256 : String
  deriving Inhabited, Repr

-- Exact correspondence with NUMBERED_SOURCE_ITEMS.csv.
def numberedSourceAnchors : List NumberedSourceAnchor := [
  { number := "2.1", kind := "Definition",
    pdfPage := 3, pageBlock := 8, sourceSha256 := "dc97a9b072ba74fa3cd82199d2a82f84af891ef2b4021aaef23c0c3e48db5308" },
  { number := "2.2", kind := "Lemma",
    pdfPage := 4, pageBlock := 21, sourceSha256 := "0a44cb65a5ee464135e51caaf5a5d5d761d4e749fdaf63a05758ca03d4da46d2" },
  { number := "2.3", kind := "Lemma",
    pdfPage := 5, pageBlock := 1, sourceSha256 := "5c5e1883b1b6df32bed2801ee2ce97ec9cac590ee5cc7f9e83b92d70508d13aa" },
  { number := "2.4", kind := "Theorem",
    pdfPage := 6, pageBlock := 1, sourceSha256 := "dec5f5c1424b75d1907be32771f546c6bbd4c7839a78a564557b63bba14619a6" },
  { number := "2.5", kind := "Theorem",
    pdfPage := 6, pageBlock := 10, sourceSha256 := "4eaa131149b74813667fbaac4da2dab3835703df332beb5eca181a235fb6d864" },
  { number := "3.1", kind := "Theorem",
    pdfPage := 7, pageBlock := 27, sourceSha256 := "dddbf57cb13d1585922253095339cca99ab0f069b249c2a0a6a405b0ffb317b7" },
  { number := "3.2", kind := "Proposition",
    pdfPage := 8, pageBlock := 9, sourceSha256 := "19cd1e56091657e9d68b0ee2ee5c0137185827fad1050ea4914d3b96c822c000" },
  { number := "3.3", kind := "Theorem",
    pdfPage := 8, pageBlock := 22, sourceSha256 := "652eb30edbc0f7cf6f878ebadafa8069175094a7ab59259a1e7a6bac722b1810" },
  { number := "3.4", kind := "Theorem",
    pdfPage := 9, pageBlock := 27, sourceSha256 := "455e577142380f17776be105d0935d5f6ccc8d0df48f38ebcd0a3ad310b8371a" },
  { number := "3.5", kind := "Corollary",
    pdfPage := 10, pageBlock := 4, sourceSha256 := "3069d70bffcaa40b95fa876cb1830a023975e7cb6d32d49b07f640a6cdf1521a" },
  { number := "3.6", kind := "Corollary",
    pdfPage := 11, pageBlock := 5, sourceSha256 := "1ff3eb5440cecd071350cda4a0c21bdfd276bd0456559e4b58bccc42fa30f908" },
  { number := "3.7", kind := "Theorem",
    pdfPage := 11, pageBlock := 16, sourceSha256 := "810065c6ff6d517848f9152feab7e04a7cc6c4a0771a4e39de03bd2644c3f744" },
  { number := "3.8", kind := "Theorem",
    pdfPage := 12, pageBlock := 23, sourceSha256 := "207eead81cf5f48a2e97e052e04dd9895edb50750b8e32f8afc4d1f90d2cdf1c" },
  { number := "3.9", kind := "Theorem",
    pdfPage := 13, pageBlock := 15, sourceSha256 := "50984680604c8c5ba5269bc2dfb8e8d7cb31ec60096bb3af2df70ff79c430656" },
  { number := "3.10", kind := "Remark",
    pdfPage := 14, pageBlock := 4, sourceSha256 := "995227135b610254d5740beb4868236b6b94824326da014e9086f7f1748b55bd" },
  { number := "4.1", kind := "Theorem",
    pdfPage := 14, pageBlock := 9, sourceSha256 := "880f883ae8a97eb06475ef58503d3790ef7d9d55ebb132a38718976bfe255bd1" },
  { number := "4.2", kind := "Proposition",
    pdfPage := 15, pageBlock := 19, sourceSha256 := "993a92e086f711bdcc653a97fdbe1f2c73e45ce93701b26afdf565e858b94675" },
  { number := "4.3", kind := "Proposition",
    pdfPage := 15, pageBlock := 34, sourceSha256 := "f3464d9f7b684b929939bf940824e629296a888bec8a8ef6c50fbb1f32f57e89" },
  { number := "4.4", kind := "Theorem",
    pdfPage := 16, pageBlock := 10, sourceSha256 := "ee72b0eb19b737bf9da7cd285d582ccd0304bde941111f489adcd8b60def5012" },
  { number := "4.5", kind := "Theorem",
    pdfPage := 18, pageBlock := 16, sourceSha256 := "be78a38edde9a10f7db9c829760fcaf89ef8eb0df267bedc934bb81211da2a6c" },
  { number := "4.6", kind := "Theorem",
    pdfPage := 19, pageBlock := 16, sourceSha256 := "dea7fabca521d805541990bcae4514aa617c6cca27fee38652420b63764bae12" },
  { number := "4.7", kind := "Theorem",
    pdfPage := 21, pageBlock := 2, sourceSha256 := "f7e91a1f1002bd2efc9aebe128d64a80fec143e3cb4e9646227d8ad609d3dba5" },
  { number := "4.8", kind := "Proposition",
    pdfPage := 21, pageBlock := 19, sourceSha256 := "440729f5d6378daad55c0426c5bfd51226f70a3e39e4d3571462a7064bd8970b" },
  { number := "4.9", kind := "Remark",
    pdfPage := 22, pageBlock := 3, sourceSha256 := "abe6daf77439cdfbf6f43dbc749087be220b3f8c2e972d67d4a649400a1752b6" },
  { number := "4.10", kind := "Remark",
    pdfPage := 22, pageBlock := 14, sourceSha256 := "c553195f869c5a115fa299b1980e58898b7101bfc747ea2ca4765a5e4b079823" },
  { number := "4.11", kind := "Conjecture",
    pdfPage := 22, pageBlock := 17, sourceSha256 := "6ce5940e76dca9172f63be46f5f8060e6d71d128ac040850f0aeaf893d52e45e" },
  { number := "5.1", kind := "Theorem",
    pdfPage := 22, pageBlock := 21, sourceSha256 := "49b9de2ddc71d9ab47f4e1956bcfd2c8eb887c9e5c976fd8f3b85619bcb6596c" },
  { number := "5.2", kind := "Theorem",
    pdfPage := 23, pageBlock := 25, sourceSha256 := "9ceaeaffb4e199063ca4586f9dd1336d0e786ee7af8688dde8c964012214c24f" },
  { number := "5.3", kind := "Proposition",
    pdfPage := 24, pageBlock := 18, sourceSha256 := "3bdb2a270b2511a6f2f4af66f951ad93b80efe7a1e9fe531f0d04a477bf1732a" },
  { number := "5.4", kind := "Theorem",
    pdfPage := 25, pageBlock := 18, sourceSha256 := "f0efa635a379c16a0b0ca80d5b44afae2481f44ce2390e0b4fd6c7da66d5e849" },
  { number := "5.5", kind := "Remark",
    pdfPage := 25, pageBlock := 34, sourceSha256 := "cf0a364aa40363df8a56485b62a51d5502b76c7cafc14f201450f92bf0725873" },
  { number := "5.6", kind := "Theorem",
    pdfPage := 26, pageBlock := 2, sourceSha256 := "cfbacb1952eb6096f904477a0ae0da35ec9f23f4543583294e0fdf7bd8048f69" },
  { number := "5.7", kind := "Theorem",
    pdfPage := 28, pageBlock := 2, sourceSha256 := "e2604f56682bcc8d5dac599a0aa03e1faf76561cc9dddeae03ed853391fcacf5" },
  { number := "6.1", kind := "Theorem",
    pdfPage := 29, pageBlock := 17, sourceSha256 := "25ffa99e0232eb92ff8f085e7e12a1f1aad18c1d154fe5286f668b29e5cca754" },
  { number := "6.2", kind := "Theorem",
    pdfPage := 31, pageBlock := 15, sourceSha256 := "8a753896217d0ff1cce95d65d79431e16305720668dd651936924e2ded28292a" },
  { number := "6.3", kind := "Theorem",
    pdfPage := 32, pageBlock := 8, sourceSha256 := "c43adac40578f746dd345f4c362f6f460ccf84d7a2c7c657632306f5cc3b2553" },
  { number := "6.4", kind := "Theorem",
    pdfPage := 33, pageBlock := 32, sourceSha256 := "f54c6075248ebc78493ee887ea90660c428bfa2304230731600167d4969fc941" },
  { number := "6.5", kind := "Theorem",
    pdfPage := 34, pageBlock := 41, sourceSha256 := "17b6ac32e721c065010ced3f29aafa398c520f19573795b83e17db70ad899e4b" },
  { number := "6.6", kind := "Theorem",
    pdfPage := 35, pageBlock := 20, sourceSha256 := "5068ad9d0d5f3c26589390de101229d40a619661445937b07b6ff40a1d5d9849" },
  { number := "6.7", kind := "Theorem",
    pdfPage := 37, pageBlock := 1, sourceSha256 := "a3ba5246c726210e7d70140d5f666f497417cc9dbf196ba243c5dab8c046b339" },
  { number := "6.8", kind := "Corollary",
    pdfPage := 38, pageBlock := 7, sourceSha256 := "63f8e03142f5ac99a2444ff42c9a4fbf7aa7d61162b818c2fa8956c59fae3237" },
  { number := "6.9", kind := "Theorem",
    pdfPage := 38, pageBlock := 13, sourceSha256 := "a56cf05e4626308420bf44813051e831783abd6c6460ab2475d0b49a2ec55848" },
  { number := "6.10", kind := "Theorem",
    pdfPage := 39, pageBlock := 9, sourceSha256 := "6423af50bbd37c6f4d03254b125d059e219f500eb2a49aea96d592745fd933f6" },
  { number := "6.11", kind := "Theorem",
    pdfPage := 40, pageBlock := 9, sourceSha256 := "3693b992f7cfcb7d2fbadda27af68a7ccefbe66ec7c208f0e4ea4818049a877a" },
  { number := "6.12", kind := "Theorem",
    pdfPage := 42, pageBlock := 10, sourceSha256 := "f3d4b5415fb150dd910bc625ef7099c08b22ce1b85b27ad41af12efb8c01681e" },
  { number := "6.13", kind := "Theorem",
    pdfPage := 43, pageBlock := 12, sourceSha256 := "4909ecaab8529c395c4421de5a0ae59744b57649a96f49f27fb5446e2f50bee7" },
  { number := "6.14", kind := "Theorem",
    pdfPage := 45, pageBlock := 2, sourceSha256 := "879674781b8f8bdae8dc66035f8dd0ced919b1f477de6f1b0ab5721a9a439c53" },
  { number := "6.15", kind := "Theorem",
    pdfPage := 46, pageBlock := 6, sourceSha256 := "cd2f46d59f9478e0fffd4e5e956c42734f9d8f74d0b597667c4180469db33a75" },
  { number := "6.16", kind := "Theorem",
    pdfPage := 47, pageBlock := 13, sourceSha256 := "ccc133044227a19bfad9bd72290c3ca2ac8e48e6dfe1625b0ac98b899e4df6a2" },
  { number := "6.17", kind := "Theorem",
    pdfPage := 48, pageBlock := 6, sourceSha256 := "d78c485f4bd4d9a3c5deb2aa67f0b8f04bc1ecf3caec0fcdb4cf25cc533a4971" },
  { number := "6.18", kind := "Theorem",
    pdfPage := 49, pageBlock := 28, sourceSha256 := "c8e7665557d71d80369df62321c2451bf91d6f5898964ad1799354b59d49782c" }
]

def sourceAnchorIds : List String := numberedSourceAnchors.map (·.number)

theorem fifty_one_source_anchors : numberedSourceAnchors.length = 51 := by rfl

-- This checks the *entire numbered-item inventory*, including remarks and
-- the conjecture, in its original source order, without claiming any proof.
theorem source_anchors_agree_with_checkpoint :
    sourceAnchorIds = numberedItemIds := by decide

theorem source_anchor_numbers_distinct : sourceAnchorIds.Nodup := by decide

theorem source_anchors_in_pdf_body :
    numberedSourceAnchors.all (fun it =>
      decide (1 <= it.pdfPage) && decide (it.pdfPage <= 51) && decide (0 < it.pageBlock)) = true := by decide

-- A positive match refers to an actual Lean-registered PDF source block.
-- It is NOT a proof of the associated mathematical assertion.
def sourceAnchorMatches (it : NumberedSourceAnchor) : Bool :=
  match sourcePages[it.pdfPage - 1]? with
  | none => false
  | some blocks =>
      blocks.any fun b =>
        b.pageBlock == it.pageBlock &&
        b.pdfPage == it.pdfPage &&
        b.anchor == it.number &&
        b.classification == "numbered-item" &&
        b.sourceSha256 == it.sourceSha256

end PaperBlueprint.Paragraphs
