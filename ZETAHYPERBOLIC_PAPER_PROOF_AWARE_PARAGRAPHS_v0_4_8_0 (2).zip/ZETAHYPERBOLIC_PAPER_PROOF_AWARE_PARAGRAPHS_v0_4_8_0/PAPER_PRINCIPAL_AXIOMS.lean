import PAPER_PRINCIPAL_ENDPOINT

/-! Strict inspection of the exact newly exported source-specific endpoints. -/
#print axioms PaperReconstruction.UNCONDITIONAL_CORE
#print axioms PaperReconstruction.PRINCIPAL_THEOREM
#print axioms PaperReconstruction.PRINCIPAL_THEOREM_FROM_PRIMITIVE
#print axioms PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
#print axioms PaperReconstruction.QUANTITATIVE_FROM_FULL_WITNESS
