# v0.4.7.0: mathematical milestone, not paper completion

User native Windows Lean 4.33.0 PASS on v0.4.6.4: 127 frozen compiler targets, 51 chronological checkpoints, 46 substantive theorem targets, all targets declared but only three full audited paper targets closed.

**New proofs awaiting user compilation:** 7 added targets, 3 source theorem modules, 3 check modules, one cross-chapter batch. Existing 127 unchanged modules are retained byte-for-byte; runner persistent verified cache reuses their compiler results.

1. **§3.8**: Full *finite parameter* Weinstein–Aronszajn characteristic-determinant equality for the monomial derivative operator and the pole-kernel operator. Together with previously compiled finite determinant nonvanishing and intertwining. Still needed: actual Gram inverse/CD-kernel identification and Jacobi derivative-under-integral.
2. **§5.1**: Strictly increasing rational finite harmonic sequence; strict positivity of every off-diagonal rational divided difference, and strict negativity of diagonal correction at positive indices. Still needed: full two-dimensional integral evaluation.
3. **§6.1**: Full rational parameterized 2x2 two-pole determinant `-a^2`; actual block identified and opposite-sign quadratic directions explicitly witnessed. Still needed: p-adic exact valuation/integrality and global determinant nonvanishing.

**Source theorem completion count is unchanged (3/46).** No `sorry`, additional global axioms, or fictional finite RH/irrationality witness. All new Lean proof sources are UNCOMPILED here; native Windows user Lean is sole authority.
