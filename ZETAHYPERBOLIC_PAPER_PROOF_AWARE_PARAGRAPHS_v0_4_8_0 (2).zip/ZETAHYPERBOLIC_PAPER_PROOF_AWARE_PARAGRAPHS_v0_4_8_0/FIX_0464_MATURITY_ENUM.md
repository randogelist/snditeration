# v0.4.6.4: Blueprint maturity constructors

User compiler checked and reused all earlier material through Chapter6; only the registry was blocked. Lean reserves `partial` and `open` as syntax keywords. This patch replaces the registry maturity constructors `partial` and `open` by non-keyword identifiers `inProgress` and `unresolved` and updates every entry and executable-count theorem accordingly. `proved`, `needsCorrection`, and `excluded` are unchanged.

Machine-counted source entries: 51 chronological, 46 substantive; proved 3, in-progress 22, unresolved 18, correction needed 3, excluded 5. Sections: 2:5, 3:10, 4:11, 5:7, 6:18. These are metadata, NOT proof of the manuscript.

No Lean compilation was performed here. Only the user's native Windows Lean 4.33.0 is the compiler authority. Retain reusable .olean from earlier passes, compile Register and Pipeline as newly affected targets.
