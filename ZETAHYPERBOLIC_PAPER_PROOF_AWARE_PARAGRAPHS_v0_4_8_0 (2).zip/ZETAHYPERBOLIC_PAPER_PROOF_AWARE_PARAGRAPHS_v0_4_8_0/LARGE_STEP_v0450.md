# v0.4.5.0 — Large chronological finite proof batch

## Repaired
- Theorem 4.1 spectral transfer: correct `Spectral.comparisonRadius` API.

## Added
- Section 4.1: signed zero-free spectral ball; normalized real/rational
  root exclusion; rational-measure threshold monotonicity and irrationality.
- Section 5.1–5.2: dual rational moment symmetry, quadratic scaling of Gram
  derivative, explicit full-rank coordinate Gram, finite Krein positive/negative
  cones.
- Section 6.1: leading rational pole block, invertibility and trivial kernel.
- Section 6.6/6.16: arbitrary nonnegative multiweight Gram form with strict
  positivity from one positive-weight injective component, coefficient monotonicity.
- Section 6.15: exact determinant-zero obstruction for 2x2 rank-one matrices.

The source-specific theorems are proposals awaiting **user-native** Lean
compilation. `BUILD=PASS` means every compiled target passed and its printed
axiom report did not reveal `sorryAx`, not that every PDF result is proved.

## Cache
- Preserve shared certified `.olean` files and their source snapshots.
- Rebuild only failed / new modules and their changed dependent closure.
- No compulsory full rebuild or offline dependency installation.
