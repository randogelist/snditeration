import PaperParagraphs.Types

/-!
# Paper source unit index: Chapter6

External layout extraction indexed 219 paragraph-like source units and
677 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.Chapter6

/-- The same 219 source records, split into small proof-evaluation chunks.
    Chunking avoids the `maxRecDepth` barrier of computing a single
    219-element concrete List in `by decide`. No source record is dropped. -/
private def sourceChunk0 : List PaperParagraphs.SourceUnit := [
  ⟨265, 29, 13, 1, 6, "", "6. Structural Barriers, Multi-Weight Couplings, and Further Diophantine Advances", "a95d840a975f84860783e18618b9e90f2f0765b8644d15891920844032d4568a"⟩,
  ⟨266, 29, 14, 1, 6, "", "In this section, we push the algebraic, analytic, and p-adic structure of both the one-variable and two-variable Hankel architectures ", "dc30d87fa4e46a760e5421cf90b3a1c1468309f9a53b6137ad178f033d0de7f2"⟩,
  ⟨267, 29, 15, 1, 6, "", "6.1. Weight seven, the divided-difference valuation law, and simultaneous ( (6), (7)) forms. Let d 7(x1, x2) = 1 720 ( log(x1x2))5", "e1fa9e09bf7649b67afd40b82d76595bb80ecf007de14b80c4c3220854a19f0c"⟩,
  ⟨268, 29, 16, 1, 6, "", "1 x1x2 dx1 dx2 denote the two-variable Beukers measure on (0, 1)2 introduced in Theorem 5.1. We begin by proving that although the off", "325e43876fa7d28e0ee8c989829e7a39ad6b184cfca8d618ece6287692744a58"⟩,
  ⟨269, 29, 17, 2, 6, "6.1", "Theorem 6.1 (Divided-difference p-adic valuation law and intrinsic p 6 barrier). Let M(7) r1,r2 :=", "912ebd3e17aab1e445b8b577d09bf265cf676c20e75444cea8da67b04f4c1602"⟩,
  ⟨270, 29, 19, 3, 6, "6.1", "(1) (Multiplicative fiber reduction) Under the change of variables x1 = uy, x2 = u1 y", "0ec1a0f37cb8ade20f4e747dd4c764c43adbd72dbd132fd03899cc7e1ccdb9f2"⟩,
  ⟨271, 30, 1, 10, 6, "6.1", "(0,1)2 A(x1)B(x2) d 7(x1, x2) = 1", "4dd24e8b3069c14efe731a70663a38ee136bd9243ea1946e8bd9d02f7ad128d0"⟩,
  ⟨272, 30, 11, 1, 6, "6.1", "(2) (Exact p-adic valuation of off-diagonal divided differences) Let p 11 be a prime in the outer range K/2 < p K. While every individ", "7bb45c6eed6c4b9f6d37cf56f207dc6e6219266a0cabfd7b372296c3ec50a930"⟩,
  ⟨273, 30, 12, 1, 6, "6.1", "has p-adic valuation vp(H(6) r ) 6, the off-diagonal moment M(7) r1,r2 = H(6) r1 H(6) r2 6(r1 r2) (r1 =", "1bb03d61a9928fe60631a713ec47f6d0b0915a4e42e7f418cbfdfb0e604dcdc9"⟩,
  ⟨274, 30, 13, 1, 6, "6.1", "r2) satisfies vp(M(7) r1,r2) = 7 whenever 0 r1 < p r2 K and r1 r2 (mod p). (3) (Non-degeneracy of the local pole obstruction) In every", "ddcfe7f7251752879b8a4671d88c6db119925dbad65fd662727327d105556bdd"⟩,
  ⟨275, 30, 14, 4, 6, "6.1", "0 l1,l2 1 at X Zp has exact p-adic pole denominator p 7 both on the diagonal (l1 = l2 = 1) and off the diagonal (l1 = 0, l2 = 1).", "7c07fd8a8da053e5d939edc42c3ed25745ea89890d20a1139b992f036daf1769"⟩,
  ⟨276, 30, 18, 5, 6, "6.1", "zero Zp-linear combination of columns inside class can simultaneously annihilate the p 7 pole on and off the diagonal.", "d13fc4fe2c9b9dc4b2734f5aa0f265b4f81fd15a2a7d8883e67a32005b996f05"⟩,
  ⟨277, 30, 23, 3, 6, "6.1", "y = u1 y log u. The Jacobian determinant is yuy 1 uy log u (1 y)u y u1 y log u", "ded6d93df7364db1ed6e9ded5cc0bcac4678557af4b0f13a23f6a09cc879e226"⟩,
  ⟨278, 30, 26, 6, 6, "6.1", "Thus dx1 dx2 = ( log u) du dy and ( log(x1x2))5 dx1 dx2 = ( log u)6 du dy. Integrating first over y (0, 1) gives MA,B(u) = 1 0 A(uy)B(", "951946369f6d807a8cf1e00a89dabba6ded82873416826a8784c470e1d725096"⟩,
  ⟨279, 30, 32, 4, 6, "6.1", "while for r1 = r2 = r the integral is 1 0 ur dy = ur, establishing (6.1). (2) Fix a prime p 11 with K/2 < p K, and let 0 r1 < p r2 K s", "34ed374355f8f1196d9190acf3610eb11027ed4faaecdfc6ec1247f3063c0dd5"⟩,
  ⟨280, 30, 36, 4, 6, "6.1", "Dividing H(6) r1 H(6) r2 p 6 (mod Zp) by 6(r1 r2) = 6lp (where 6l Z p since p 11 and 1 l < p) yields", "bd1c6794315dce7ca26a70d7c3dd072d67057daf07ad96d0dc844c434f738a73"⟩,
  ⟨281, 31, 1, 3, 6, "6.1", "p 7 ( 0 1/6 1/6 1", "c3a30bde8661a0e2a85ab33665a1c2454e474edb2059ca3ea4a7e2cc15bf7be4"⟩,
  ⟨282, 31, 4, 7, 6, "6.1", "which has exact p-adic valuation vp(M(7) r1,r2) = 7. (3) For any residue class with L = 2, the 2 2 submatrix of G(7) A (X) at X Zp on ", "315ead909d7b7a2c4e140e8897bd45eb35be0d3cf820822478dcb2f86593eddc"⟩,
  ⟨283, 31, 11, 3, 6, "6.1", "p 11. If a Zp-linear combination c0v0 + c1v1 of its columns vanishes modulo p 6Zp, then ( 0 1/6 1/6 1", "d1978ff77116b92940c449ff43990534eb5a0b9d3b409211f7f88a724cf31919"⟩,
  ⟨284, 31, 14, 1, 6, "6.1", "Although the p 7 pole valuation is intrinsic to symmetric evaluations on d 7, evaluating d 7(x1, x2) on shifted asymmetric pairs produ", "579ceb2efb211bf9c82b0cc8b03ad12b47b3162e900c27ad68523e963658518f"⟩,
  ⟨285, 31, 15, 7, 6, "6.2", "Theorem 6.2 (Simultaneous weight-(6, 7) Beukers functional with zero denominator over- head). Let d 7(x1, x2) = 1 720 ( log(x1x2))5", "58d3fd61bca0aad05fd2a8f4d3f390eaa3462d7671b44c7adbf70db2b79e0731"⟩,
  ⟨286, 31, 22, 25, 6, "6.2", "(2) For any polynomial A(x) = K r=0 crxr Z[x] and any integers , Z, the single integral", "0ff15c3fa4632d1899292d7def90c4408a60df424674a7ace35a2952e8316d84"⟩,
  ⟨287, 31, 47, 9, 6, "6.2", "satisfies 6d7 KRK( , ; A) Z with the exact same denominator 6d7 K as the pure (7) form.", "ca5ca1826b47da9a1ed8a40018d696f87012a74be7b6e794ef3addf19e96406d"⟩,
  ⟨288, 32, 1, 5, 6, "6.2", "(2) By Theorem 5.1 and (6.2), A(x1)A(x2) d 7 expands to K r=0 c2 r( (7) H(7) r ) +", "a7eddc7113a3cc1610fe39badb56261596a08a260031fde4f344a03b5a3abfbd"⟩,
  ⟨289, 32, 6, 1, 6, "6.2", "H(6) r ). Since d6 KH(6) r Z, d7 KH(7) r Z, and d7 K H(6) r H(6) s r s = d7 K max(r,s) m=min(r,s)+1 1 m6|r s| Z (as |r s| K divides dK", "e33ae03620bb25bce07d52bacc949c0763b546b99aeb051ab651053072607703"⟩,
  ⟨290, 32, 7, 1, 6, "6.2", "Next, we turn the non-degeneracy of the local p 7 block in Theorem 6.1(3) into an un- conditional q-adic non-vanishing theorem for the", "840f14d119fd0c5210e9ad0b99044c2d2717aa6674de3aeb65dc8947748fea8c"⟩,
  ⟨291, 32, 8, 2, 6, "6.3", "Theorem 6.3 (Unconditional q-adic non-vanishing and explicit positive-cone approximations for G(7) A (X)). Let G(7) A (X) be the two-v", "f6c76e913b0adfd6febcff8d724fd1f63ef5bbbf18cbe51ecef334c178f4f680"⟩,
  ⟨292, 32, 10, 3, 6, "6.3", "In particular, (7) Aq(0) = 0, and (7) Aq(a/b) = 0 for every rational a/b Q with q b. (2) (Explicit positive-cone basis with exponentia", "59d58b687ea45d2f39ccbbc3cfd1628f7ebe094f419b072dda4562e459eb5917"⟩,
  ⟨293, 32, 13, 1, 6, "6.3", "where m, (x) = xm(( log x) ( log x)5 ) is as in Theorem 5.2(2). Then dimQ V+ K", "d2d4880705464f04318350e607e66a505df4e204eab0255c921b4c969b95fdd5"⟩,
  ⟨294, 32, 14, 5, 6, "6.3", "h, and for any h-dimensional basis A(K) + = {A0(x), . . . , Ah 1(x)} V+ K normalized so that Ai(x) = xm0(1 x)hQi(x) has 4h 1 j=0 |[xj]", "04c1f8f55120fb9f1c9c2fb98419bc9071340cabfebf77927a245db5f5022c32"⟩,
  ⟨295, 32, 19, 1, 6, "6.3", "Proof. (1) For 0 , < q, the polynomial A (x) = x +x +q is supported in the single residue class (mod q). If = , then every r { , + q} ", "af468b78cd18aae06e7981622e324b6b9eaf7024c645d926cd5656279beffd4f"⟩,
  ⟨296, 32, 20, 5, 6, "6.3", "vq(M(7) r,s ) = vq ( H(6) r H(6) s 6(r s) ) 6. Thus vq(G(7) Aq(0) , ) 6 for all = . On the diagonal = {0, 1, . . . , q 1}, we have < q", "090a2dc99ca0367e98402608057707dbacd159797c88e4bcc2fe0708c2c7ea40"⟩,
  ⟨297, 32, 25, 6, 6, "6.3", "For = 0, H(7) 0 = H(6) 0 = 0, H(7) q = q 7+H(7) q 1 q 7 (mod Zq), and H(6) q = q 6+H(6) q 1 q 6", "d7cf4c4dd0511afd08c90b91f90a53d4227b1a51e59158887067219638c721eb"⟩,
  ⟨298, 33, 1, 2, 6, "6.3", "X = a/b Q has q b, then X Zq does not alter the q 7 terms, so vq( (7) Aq(a/b)) = 7q and", "c5a24b747c1760c2cee95f64b7e5c8eebc727f79e17fcfd67c1a47831e66d5cc"⟩,
  ⟨299, 33, 3, 2, 6, "6.3", "(2) Since 1 0 xr m, (x) dx = ! (r+m+1) +1 (5 )! (r+m+1)6 Q for every r, m 0, the 3h con- ditions P, m, = 0 (0 m < h, {0, 1, 2}) define", "2bcaa9c57784e9cf24c811428acee63f5b0bc30ce37d6c6af0a37a20717935e0"⟩,
  ⟨300, 33, 5, 5, 6, "6.3", "For each basis element Ai(x) = x2h(1 x)hQi(x) with 4h 1 j=0 |qi,j| 1, we have |Ai(x)| = xh [xh(1 x)h] |Qi(x)| 4 hxh on (0, 1) since su", "7f478ca7b6cc13cf52fb29e5c17b3d65a583c138da16854da96b6eb1a5623d94"⟩,
  ⟨301, 33, 10, 3, 6, "6.3", "Applying Hadamard s inequality det G h 1 i=0 Gi,i to the positive-definite matrix G(7)", "917e29f6f13f27b9fcac2707e086bd068b3c7b1c773275a280f7ef10c129e261"⟩
]

private theorem sourceChunk0_len : sourceChunk0.length = 37 := by decide
private theorem sourceChunk0_blocks : (sourceChunk0.map (·.bodyBlockCount)).sum = 145 := by decide

private def sourceChunk1 : List PaperParagraphs.SourceUnit := [
  ⟨302, 33, 13, 5, 6, "6.3", "6.2. The Dirichlet beta value (4) and character Vandermonde sign cancellation. Whereas Proposition 5.3 constructed a two-variable Beuk", "f4636d581abfbc27b0e774d4ce8c32f32884dc3bd6daa8d1014fd1094cc348ee"⟩,
  ⟨303, 33, 18, 6, 6, "6.3", "where E2e Z are the Euler numbers ( 1 cosh z = e=0 E2e (2e)!z2e, so E0 = 1, E2 = 1, E4 = 5, E6 = 61), and on simple poles (t + (2j + 1", "f9fc2ab33fbfd1abf2ff4ad825c58fb376eb59b27fb99cb260350124b68e5702"⟩,
  ⟨304, 33, 24, 8, 6, "6.3", "(6.4) where H( ,s) j := j 1 n=0( 1)n(2n + 1) s (H( ,s) 0 := 0). Set D(odd) m (t) := m 1 j=0 (t + (2j + 1)2) and, for K > N 0 (h = K N)", "13220933efb6642bc4f1a936b5552129e0826057dc00beb6170dd39b707853b6"⟩,
  ⟨305, 33, 32, 8, 6, "6.4", "Theorem 6.4 (Character Vandermonde sign cancellation and unconditional hyperbolicity for (4)). Fix integers K > N 0 (h = K N) and m 1.", "1d6bddcb4336dac76d2c87adcf86965f06feaf94a32377101a71920e77080258"⟩,
  ⟨306, 34, 1, 14, 6, "6.4", "dy3 + d dy yields the strictly positive single-variable weight", "b89725d3529e30635a6f179e5ecfc1a4368ef8979be3f49877a0350ea4dd0689"⟩,
  ⟨307, 34, 15, 5, 6, "6.4", "(2) In the Lagrange basis at the odd-square poles vj = (2j + 1)2 (N j < K), the X- derivative matrix M( (4)) K := [X]G( (4)) K (X) fac", "b2af3db84cb9cef033c060fce562f192318e224259f8820a6f880d54c27d4115"⟩,
  ⟨308, 34, 20, 2, 6, "6.4", "(3) Because the character sign 4(2j + 1) = ( 1)j, the Vandermonde derivative sign sgn ( D(odd) tail ( (2j + 1)2) ) = ( 1)j N, and the ", "96830ea7432c0d7020e8f372052a7e370f58c7adb7c5ae5f1251213efee35304"⟩,
  ⟨309, 34, 22, 1, 6, "6.4", "0 for every N j < K. Consequently, M( (4)) K is strictly positive definite, and all h roots of ( (4)) K (X) are unconditionally real.", "f923962a6090f64f214fc784436a2d3e1e75b13676145a2c8ffefd62f6afcfb2"⟩,
  ⟨310, 34, 23, 7, 6, "6.4", "Proof. (1) Integrating y2e against w (4)(y) by parts three times and applying Euler s inte-", "0be0e64ea29dce373102f528af37a81e4fc49ca20b5fbee6c49c4c8b5293b570"⟩,
  ⟨311, 34, 30, 3, 6, "6.4", "(4). For W + (y), setting z = y/2 > 0 and using ( 1 d2 dz2 ) (sech z) = 2 sech3 z gives", "156be96d88bf4dfdb32ac7b4b22a1e5e910fc168272dd5857c34dd1ef2f99903"⟩,
  ⟨312, 34, 33, 1, 6, "6.4", "dz2 ) (sech z) = 6 sech4 z sinh z > 0. (2) (3) Applying Theorem 2.5 to the nodes vj = (2j +1)2 (N j < K) cancels one factor of D(odd) ", "c65eb5c14d8caff51d78168880f5425288bcd3e3085702358934a700f12b6c17"⟩,
  ⟨313, 34, 34, 1, 6, "6.4", "each N j < K, the product D(odd) N ( (2j + 1)2)2m 1 = N 1 =0 ((2 + 1)2 (2j + 1)2)2m 1", "8148e5e08c71cb89820b1a6f34e6a3322d54832c4511bf0f067796ade110acdd"⟩,
  ⟨314, 34, 35, 2, 6, "6.4", "has N negative factors raised to the odd power 2m 1, giving sign ( 1)N. The denominator D(odd) tail ( (2j + 1)2) = N b<K, b =j((2b + 1", "0e596630e784fd1afae58ca5e746ab1bcc16c1f29b9e58f22090001aa529e50f"⟩,
  ⟨315, 34, 37, 1, 6, "6.4", "Since all ( (4)) j > 0 and det Vodd = N a<b<K((2a+1)2 (2b+1)2) = 0, Sylvester s law of iner-", "3a34683643486891a89da2626f5caf7602d0c27cdfefca4d5fdedc72536614d5"⟩,
  ⟨316, 34, 38, 2, 6, "6.4", "tia implies that M( (4)) K is real symmetric and strictly positive definite. Factoring G( (4)) K (X) = (M( (4)) K )1/2( AK+(X (4))Ih )", "3da22344c3ead488c7fdc350999ce76f0e86b9a8ce0ba7a45111cc640cf2a532"⟩,
  ⟨317, 34, 40, 1, 6, "6.4", "Because the Euler numbers E2e Z in (6.3) are integers, they have no odd-prime denomi- nators (in contrast to Bernoulli numbers). This ", "7f36f715a2ed0e86a62805cfb7b51c95a264add98c1847b96cf95130b0310c79"⟩,
  ⟨318, 34, 41, 3, 6, "6.5", "Theorem 6.5 (Unconditional q-adic non-vanishing for ( (4)) K (0)). Let q > 7 be a prime satisfying q 1 (mod 8), and set mq := q 1", "2aef62875e9993552a43d20589eebb7d10d159ebd39f931408f1c8489262cb25"⟩,
  ⟨319, 35, 1, 3, 6, "6.5", "8 , and 2m = 2 in G( (4)) K (X). Then at X = 0, the rational", "22eb3f0ea4401c5f9c79be40ec8c26c46960991e474cfbe8fefa922b1eb11aac"⟩,
  ⟨320, 35, 4, 2, 6, "6.5", "determinant ( (4)) K (0) = det G( (4)) K (0) Q satisfies the exact q-adic valuation", "f33627d1169f444c2214f352efbada04f400e9935ba9b4ec376ae413c62ad12b"⟩,
  ⟨321, 35, 6, 4, 6, "6.5", "In particular, ( (4)) K (0) = 0 unconditionally for every prime q 1 (mod 8) with q > 7.", "5e8e2a027adc6c5bb481247c6cb2ca759343fb3de944bbe4fe94aace30c3984e"⟩,
  ⟨322, 35, 10, 1, 6, "6.5", "2, the mq residues 4r2 (mod q) (0 r < mq) are pairwise incongruent modulo q. Hence the Vandermonde matrix Vodd on 4mq j < 5mq is Zq-un", "406c391ee24b0f4b4b4776b8867e767de9aa7f0271313e7a2ebe811857a0ba23"⟩,
  ⟨323, 35, 11, 1, 6, "6.5", "Consider the Lagrange-transformed matrix G( (4)) K (0) = V 1 oddG( (4)) K (0)(V T odd) 1. Since E2e Z and q is odd, every monomial mom", "cbbf9dd840e98b4f43da35089cf2b9e7c5ee24ac37434bef485d8080981c59c1"⟩,
  ⟨324, 35, 12, 3, 6, "6.5", "For r = 0 (j0 = 4mq, where 2j0 + 1 = q), every index 0 n < j0 has 1 2n + 1 q 2 < q, so H( ,4) 4mq Zq and vq ( D(odd) N ( q2) ) = 0. In", "ba3b5bd7c73931a9399a60042669f6cec7df650ceb32c31163683c2be3181517"⟩,
  ⟨325, 35, 15, 1, 6, "6.5", "2q, which has exact q-adic valuation 1, giving vq ( G( (4)) K (0)4mq,4mq ) = 1. For 1 r < mq (j = 4mq + r, where 2j + 1 = q + 2r Z q )", "940cbfa70dbbb2f2719633d4307ec4399e8af09a68e6f9cf9c11367d81b06773"⟩,
  ⟨326, 35, 16, 1, 6, "6.5", "the single q-divisible term n = 4mq (2n + 1 = q), so H( ,4) 4mq+r q 4 (mod Zq) and the", "b9161e820918f620c4d88ed93248c066203e34df9c7abb6706ed26d469f329b1"⟩,
  ⟨327, 35, 17, 1, 6, "6.5", "pole value in (6.4) at X = 0 has valuation 4. Meanwhile, in D(odd) N ( (2j + 1)2) = 4mq 1 =0 ((2 + 1)2 (q + 2r)2), the unique index [0", "af11f152d1859f337a444d88c7ddc816c326a60fa2285fab25c3da157c5b4a3c"⟩,
  ⟨328, 35, 18, 1, 6, "6.5", "Because every diagonal entry of G( (4)) K (0) has strictly negative q-adic valuation ( 1 at r = 0 and 3 for 1 r < mq) while all off-di", "013764f69e354be371915efbc3cfc3ad75d55a7e15b6b365a95d3142052e5b84"⟩,
  ⟨329, 35, 19, 1, 6, "6.5", "6.3. Generalized differential-shift coupling across arbitrary odd weights. We now extend the differential-shift coupling of Theorem 4.", "ed4a03105fc6c0ab410c77e7a27b630b4a9a7ee64d90cae96f1d43b0a328f4aa"⟩,
  ⟨330, 35, 20, 9, 6, "6.6", "Theorem 6.6 (Generalized multi-weight positive-definite pencil). Fix an integer k 1 and an integer tuple a = (a1, . . . , ak) Zk with ", "938e03d76edd4cb1728275b35664154034188c1d28ad945e199d6a32be7595bd"⟩,
  ⟨331, 36, 1, 8, 6, "6.6", "(1) At Xm = (2m + 1) (1 m k, so Z = a), every entry of G[a] K ( a) admits the exact integral representation", "b49a44099e66105a8b0a8aac51c1cd80f2b6b7866896d75ce4f59b690e6edf62"⟩,
  ⟨332, 36, 9, 4, 6, "6.6", "(2) Define the open positivity cone C+ k := {a Rk : Pa(l) > 0 for all l 1}. For every a C+ k Zk, the weight Wa(y) satisfies the unifor", "131136d922c96dcb3216604fde0096bbed4613fe997430df75e476b9f7d8d790"⟩,
  ⟨333, 36, 13, 5, 6, "6.6", "[Z]G[a] K (Z) = M(2k+1) K , and all h roots of [a] K (Z) := det G[a] K (Z) are unconditionally real, with signature ( h/2 , h/2 ) acro", "beaa83e99ace1767cd4d0f4a51ddf9b08b8c202436d03afb7100f7ccafe93cb9"⟩,
  ⟨334, 36, 18, 1, 6, "6.6", "and [a] K (Z) clears to Z[Z] with the exact same quadratic p-adic multiplier rate A(2k+1) M (up to eOa(K)) as the pure top-weight poly", "781ec1e9df4364d19064b43abbeb9526f6916561d9f3a4f7a5a8514e82a15991"⟩,
  ⟨335, 36, 19, 1, 6, "6.6", "Proof. (1) Multiplying Ri,j(t) by ( t)k m scales its residue at t = j2 (N < j K) by j2k 2m. Applying (2m+1) Xm via (2.2) (2.3) gives j", "da8e07e4804f403a2ff11cd935de783b93a0d859462e32868d6286f323106928"⟩,
  ⟨336, 36, 20, 1, 6, "6.6", "dent of Xm. Summing over 1 m k against am produces j2k(Z k m=1 amH(2m+1) j ) + k m=1 amrj,k,m, which is affine linear in Z = k m=1 amX", "2634cf4e0b6bd730d94cdb9d08e6893dbed07098d1b6e4d0dda0b76d1e3e22b7"⟩,
  ⟨337, 36, 21, 1, 6, "6.6", "(2 l)2k = ak > 0. On C+ k , Pa(l) > 0 for all l 1, so 0 < c1(a) c2(a) < and c1(a)w2k+1(y) Wa(y) c2(a)w2k+1(y) for all y > 0. This impl", "69460d3a864b446ad054fd9da1d07b8643a1ae47bba1947015c90977f21f2035"⟩,
  ⟨338, 36, 22, 1, 6, "6.6", "To remove the positivity cone restriction a C+ k completely, we pass to the two-variable Beukers architecture across arbitrary non-zer", "bf8d7c933e1bbc2cbbeb6157cb7106f92210696f349ceb4c237a0544b03025bb"⟩
]

private theorem sourceChunk1_len : sourceChunk1.length = 37 := by decide
private theorem sourceChunk1_blocks : (sourceChunk1.map (·.bodyBlockCount)).sum = 120 := by decide

private def sourceChunk2 : List PaperParagraphs.SourceUnit := [
  ⟨339, 37, 1, 5, 6, "6.7", "Theorem 6.7 (Universal multi-weight two-variable Beukers Krein decomposition). Fix any integer k 1 and any non-zero integer tuple a = ", "fc4818475b4a720111fa90b7e39951270a484dfe747ada32114361c71fe4b8c8"⟩,
  ⟨340, 37, 6, 15, 6, "6.7", "and for any h-dimensional subspace A = {A0(x), . . . , Ah 1(x)} Q[x] K with coefficient ma- trix C Mh (K+1)(Q), define the h h symmetr", "772db7474505529590aa008b977b9b51217b151d5af3eda17cff0dc458ae695e"⟩,
  ⟨341, 37, 21, 22, 6, "6.7", "(1) The Z-derivative matrix is [Z]G[a] A (Z) = CCT 0, and all h roots of [a] A (Z) are unconditionally real for every a Zk \\ {0}. (2) ", "e8c149260fa13b91aca7a9051f71e292606e53d848a34168b18d75186acabab2"⟩,
  ⟨342, 37, 43, 2, 6, "6.7", "yielding explicit h-dimensional subspaces A+, A Q[x] K such that G[a] A+( a) 0 (all", "832c160b4c8afef3cf14059da66e849bc52c1e4a2831a73732ea094bcfe4e0ae"⟩,
  ⟨343, 37, 45, 3, 6, "6.7", "(3) Let m := max{1 m k : am = 0}, and suppose k m=1 am (2m + 1) = c Z. For every prime q > max(|a1|, . . . , |ak|, 2m + 3), setting K ", "4a5e96f89cf91f30faf41468594279f5a3396cd3ffedb7a635ff1aea5564a33f"⟩,
  ⟨344, 37, 48, 2, 6, "6.7", "Proof. (1) Differentiating G[a] A (Z) with respect to Z gives [Z]G[a] A (Z) = CCT 0, and the proof of Theorem 5.2(1) yields real-roote", "990b2a683a67593fc8b98256af914928e574ad75f4a1ccd12ffe01cd949664cf"⟩,
  ⟨345, 37, 50, 1, 6, "6.7", "m am q (2m +1) for m 2 with m = 1, and 2a1q 3 for m = 1 with 1 = 2), strictly dominating all lower weights", "fd91538d607adef665fe121eb797afac9ac9c98a6ad7c7da6a08d949a378298b"⟩,
  ⟨346, 38, 1, 4, 6, "6.7", "m < m (which have valuation (2m 1)). Thus q2m +1G[a] Aq(c) reduces modulo qZq to an", "a014b764ad707d25f77b12382681551a5af7cb4a20b393f03127d92ace329ec8"⟩,
  ⟨347, 38, 5, 1, 6, "6.7", "gives unconditional real-rootedness, Krein subspaces A , and q-adic non-vanishing vq( [a,b] Aq (c)) = 5q < 0 for a,b = b (5) + a (3) a", "97fd308605396d6a633246c4a6b1e80bfee681d0ab70c4debd15a4c44e18ac3b"⟩,
  ⟨348, 38, 6, 1, 6, "6.7", "6.4. Inhomogeneous linear independence, multi-pole parity laws, and universal height conservation. We conclude this section by recordi", "08ff219b88417b7899fbda9a5f23e009a02cd796812952b1c9427be36d8f4da9"⟩,
  ⟨349, 38, 7, 1, 6, "6.8", "Corollary 6.8 (Unconditional three-term linear independence cone for {1, (3), (5)}). For every non-zero integer triple (c, a, b) Z3 \\ ", "63f8e03142f5ac99a2444ff42c9a4fbf7aa7d61162b818c2fa8956c59fae3237"⟩,
  ⟨350, 38, 8, 1, 6, "6.8", "3 , the linear form c + a (3) + b (5) is strictly non-zero. Furthermore, for any coprime integers (a0, b0) with b0 > 0 and a0 < 2", "d379ab1139c6ac81ec95a660c58504f8dfce09ff480865a8db73b3fdecd7f5be"⟩,
  ⟨351, 38, 9, 2, 6, "6.8", "3 b0, there exists an effectively computable Q0(a0, b0) > 0 such that for every integer q Q0(a0, b0) and every c Z, writing (a, b) = q", "a9524aec9b6583923446517d7c6f6abc103c611e3dd4ad13b879909de97859e6"⟩,
  ⟨352, 38, 11, 1, 6, "6.8", "Proof. If b = 0, c+a (3) = 0 by Ap ery s theorem [1]. If b = 0 and a/b < 2/3, set = sgn(b) { 1}, b = b > 0, and a = a < 2", "5466d5ea840e758ffb638fb264b48d80f96109dc9914204d668c9461cb568378"⟩,
  ⟨353, 38, 12, 1, 6, "6.8", "3 b. By Theorem 4.5, b (5) + a (3) / Q, so it cannot equal c Z. For (a, b) = q(a0, b0), multiplying |b0 (5)+a0 (3) ( c/q)| > q 25687 (", "2a7e96e947e9236f7817eaffc883d6f5d59580e6ac2d4bdbcaa708026b6521ba"⟩,
  ⟨354, 38, 13, 1, 6, "6.9", "Theorem 6.9 (Triple-pole and multi-weight Hankel determinants). (1) (Triple-pole Han-", "a56cf05e4626308420bf44813051e831783abd6c6460ab2475d0b49a2ec55848"⟩,
  ⟨355, 38, 14, 1, 6, "6.9", "kel architecture and consecutive-weight parity law) For n 1, let R(3) n (t) := ((6n)!)3 n j=1(t j+1)6 6n k=0(t+k)3 .", "c670296bee82964a8dff1f75ecbcc3eb59ce1e6ac6fbae4e8e1638acf38f1674"⟩,
  ⟨356, 38, 15, 1, 6, "6.9", "Under the polylogarithmic residue functional L(s) poly((t + k) r) := ( 1)r 1( s+r 2 r 1 ) ( (s +", "ac67b6104e72484350073f7763cbd81a5124a1b06f450f6ab3eb60e9906b2d66"⟩,
  ⟨357, 38, 16, 7, 6, "6.9", "r 1) H(s+r 1) k ) (r = 1, 2, 3), the Laurent expansion of R(3) n (t)P(t) (deg P < 6n) at t = k couples three consecutive weights {1, (", "62d9497fca30f177fd7dc1a36fda156fe1249b74f72ceed988eb7c5235ad83d2"⟩,
  ⟨358, 39, 1, 2, 6, "6.9", "and set J[s] n := det0 i,j<3n[L[s] n (ti+j)] Q. Then for every prime q > max(|a1|, . . . , |ad|, sd+ 5) satisfying q 1 (mod 9), settin", "6e83b7f92916cfd692598bc0ad851cbdf88f53d2dcd6d782c32be5586f4305b3"⟩,
  ⟨359, 39, 3, 1, 6, "6.9", "and in particular J[s] 2m = 0 (specifically vq(J[3,5,6] 2m ) = 36m < 0 for {1, (3), (5), (6)}).", "23b14cba74705c6f7bc3bd060ea372b7d3e8c86686744d405373effe807f153e"⟩,
  ⟨360, 39, 4, 4, 6, "6.9", "Proof. (1) Near t = k + , expanding (t + k)3R(3) n (t)P(t) gives the (t + k) 2 coefficient 6n k=0(C(2) n,kP( k) + C(3) n,kP ( k)), whi", "5184e147f6de455e8be9c9040351d408c8835a87c7cc2586bf736ee81dd3d231"⟩,
  ⟨361, 39, 8, 1, 6, "6.9", "Finally, we explain why the quadratic height bound height > in Theorem 4.6(2) is an exact potential-theoretic invariant of one-variabl", "a0b5366ee384d9245420732075bcb6a907f7816b79e61abf0f6cb1c80c250925"⟩,
  ⟨362, 39, 9, 1, 6, "6.10", "Theorem 6.10 (Universal potential-gap identity and vanishing of quadratic derivative growth in two variables", "6423af50bbd37c6f4d03254b125d059e219f500eb2a49aea96d592745fd933f6"⟩,
  ⟨363, 39, 10, 3, 6, "6.10", "(Potential-gap conservation law for one-variable Hankel pencils) Let G(s) K (X) = G(s) K ( (s))+ (X (s))M(s) K be a one-variable Hanke", "a5b7de1c1acccf68d4183648a61a20043e49d6d9f562cb8bb83aa5abb03c4669"⟩,
  ⟨364, 39, 13, 1, 6, "6.10", "where E( eq) is the minimum weighted logarithmic energy on [0, ) and Epoles( unif) is the logarithmic energy on the negative pole latt", "7cdab22dc12e53707d0f8734dfd972e1fb8574e21072c84512adab34b98678c9"⟩,
  ⟨365, 39, 14, 1, 6, "6.10", "IB(1), and any integer multiple QK(X) = cKP (5) K (X) Z[X] (cK Z>0) satisfies height + I(5) B 0.23310, whence height/ > 581 > 1. (2) (", "f7070011385bc8332fb9789fcfec65556622725f14080731917f3b4bab56ce11"⟩,
  ⟨366, 39, 15, 1, 6, "6.10", "1 x1x2 dx1 dx2 on (0, 1)2. Let h = K ( (0, 1)), and let AK = {A0(x), . . . , Ah 1(x)} Z[x] K be any sequence of h linearly indepen- de", "da1611911c6f6cb363996deda1de96b5a49c7a5d6f0d25e884510efd9fe9958a"⟩,
  ⟨367, 40, 1, 4, 6, "6.10", "bounded height maxi,r |Ci,r| KA (A 0 fixed). Then the X-derivative determinant M(s) AK = [X]G(s) AK(X) = CKCT K satisfies", "bffa43f2272ee566fddc787f349246c865cfc158e49fd7f4099c2d260c37569c"⟩,
  ⟨368, 40, 5, 1, 6, "6.10", "Proof. (1) Since QK(X) = QK( (s)) det(Ih + (X (s))B(s) K ), comparing the coefficient of Xh", "d0101c4dcae8ed9396c5f629670b0baa88d463523048053f5c07af0167ab7e4d"⟩,
  ⟨369, 40, 6, 1, 6, "6.10", "on both sides gives |[Xh]QK(X)| = QK( (s))| det B(s) K |. Taking K 2 log yields lead + = IB. By Andr eief s identity, limK K 2 log(SK ", "5c5388e1bfadd24d83be0d43ff9c18e8003580a46a5029704fff7f3891e82607"⟩,
  ⟨370, 40, 7, 1, 6, "6.10", "increasing K 2 log det G(s) K ( (s)) by at most 2 U P (t) d eq(t) by the extremal property of eq. For QK(X) = cKP (5) K (X), H( QK) |[", "27cd30ed2e44667c064338ec1cc79d79c4a310ad8cc22217411cd3586dbf6a02"⟩,
  ⟨371, 40, 8, 1, 6, "6.10", "6.5. Exact p-adic obstructions, sign-flip kernels, and central-factorial secant opera- tors for (2k). We now carry out the quantitativ", "d129ce94089189b55f8791b8fc79687f741927ad9f2cb15ee6bc1087791ee274"⟩,
  ⟨372, 40, 9, 1, 6, "6.11", "Theorem 6.11 (The p (2k 1) distribution growth law and 2-adic polynomial-quotient obstruc- tion for (2k)). Consider the single-variabl", "3693b992f7cfcb7d2fbadda27af68a7ccefbe66ec7c208f0e4ea4818049a877a"⟩,
  ⟨373, 40, 10, 2, 6, "6.11", "p) for every odd prime p 3 induces a local p-adic distribution relation with prefactor p (2k 1) across the residue classes 2r+1 2a+1 (", "8e8f1f634da5ecb5f1f305dc9750d769ea779cd9eecca95ae092fa14edf13234"⟩,
  ⟨374, 40, 12, 7, 6, "6.11", "l(odd) K (a) = 2x + O(1) poles of D(odd) K (t) and l(odd) N (a) = 2 x + O(1) roots of D(odd) N (t), with local half-weights shifted by", "578ba061dbcc71ce456071f5969112a641b330a542710ed674a769f8455e752b"⟩,
  ⟨375, 41, 1, 9, 6, "6.11", "Consequently, for fixed ( , 2m), the odd-prime denominator exponent A( ,2k) M grows strictly and linearly with k 1:", "ce745e9e0d267e854dc6a9273c02a362e58e7b548da0c03537292d350e416832"⟩
]

private theorem sourceChunk2_len : sourceChunk2.length = 37 := by decide
private theorem sourceChunk2_blocks : (sourceChunk2.map (·.bodyBlockCount)).sum = 114 := by decide

private def sourceChunk3 : List PaperParagraphs.SourceUnit := [
  ⟨376, 41, 10, 5, 6, "6.11", "whereas under the macroscopic scaling t = 4K2x (y = 2K x), the archimedean upper- bound rate", "d13b2f05797ddf04799e9b9640023f2fb5462dcf4c7caa6a99a5efc4884a7e59"⟩,
  ⟨377, 41, 15, 7, 6, "6.11", "is independent of k. In particular, A( ,2k) M + U ( ,2k) + as k . (2) (The 2-adic polynomial-quotient obstruction at p = 2) Under the ", "b031b34e2a54514dc7a0ea45e687eec9891026cac6528b14602c50e10eb07b1f"⟩,
  ⟨378, 41, 22, 1, 6, "6.11", "Since E0 = 1 and E2r 1 (mod 2) for all r 1, we have ( (2k),odd) X ((t + 1)e) = e r=0 ( e r ) ( (2k),odd) X (tr) E0 = 1 (mod 2) for all", "f96d5269c5547c254a743f6a9100f50cc84b6833dabd0d7cdbba55ec9e95ea22"⟩,
  ⟨379, 41, 23, 1, 6, "6.11", "2 (and at e = 0 for all k 1), so v2( ( (2k),odd) X (Qi,j(t))) = 0 whenever di,j = 0, preventing the pole factor 4(2m 1) K2 from dividi", "787e8b0934bf4a9ac6592c54f4af2483cae6c972d551a0e7df8f3f991375d59c"⟩,
  ⟨380, 41, 24, 1, 6, "6.11", "Proof. (1) Since gcd(2, p) = 1, as j runs over {0, 1, . . . , K 1}, the odd integers 2j + 1 {1, 3, . . . , 2K 1} traverse every residu", "4ba87dd9ee20358cee1debe67434b0bc887ee54562535435e44072c177ac4146"⟩,
  ⟨381, 41, 25, 3, 6, "6.11", "2 . Summing 2(w( ,2k) a,i w( ,2) a,i ) = (2k 2) over 0 i < La 2 x and 1 a (p 1)/2 subtracts 2(k 1) xp from in p , which adds 2(k 1) x", "accb3aa7075f8a17a9a7f648bba57f86e16618622bba4599455f8d990ffa0e95"⟩,
  ⟨382, 41, 28, 1, 6, "6.11", "3 + O(k/M) to A( ,2k) M . On the archimedean side, substituting ti = 4K2xi (yi = 2K xi) into Andr eief s identity factors out (4K2)h(h", "c9d89500aee74c0abc36424c493ea75c15630224a215f99098c4301b4a457634"⟩,
  ⟨383, 41, 29, 1, 6, "6.11", "2 yi = e K xi and y2k 1 i = (2K xi)2k 1 = eO(kK log K) = eo(K2), giving the k-independent rate U ( )( , 2m). (2) Substituting t = 4w 1", "b9e89f3be97127b067ed4aeeeb6852caae9430eaa9c81cbd77ee6c1c0f3895ab"⟩,
  ⟨384, 42, 1, 8, 6, "6.11", "Pi,j(w) = Qi,j(w) DK(w) + Ri,j(w) with Qi,j(w) = wdi,j + di,j 1 e=0 qi,j;ewe Z[w] monic. Multiplying by 42mN+i+j and substituting w = ", "6fcfbeaa88d87408685782325d287b99ca0b06e91d0bdee8b96bce7f3924d5e9"⟩,
  ⟨385, 42, 9, 1, 6, "6.11", "6 0.98305). We next prove that inserting a single rational linear factor (t r2 0) restores strict positive definiteness at X = (4) in ", "35e553e3da1b9f8cc543cb139c68171659a30a4001a42c02666e3f17d5ff7133"⟩,
  ⟨386, 42, 10, 4, 6, "6.12", "Theorem 6.12 (Full-dimension sign-flip restoration of positive definiteness and q-adic non vanishing for pure (4)). Let w (4)(u) = 24u", "3137d742e07bf5ce865942ea2742e428ff941ee61c71108bc5fd1afcf156cf8c"⟩,
  ⟨387, 42, 14, 7, 6, "", "6. For any rational number r0 Q>0, define the full-dimension h h modified Hankel matrix pencil (h = K N)", "09105371e4648b9a5854aa519cbba98d957c14e5b9a48d35147b056a953d6e00"⟩,
  ⟨388, 42, 21, 3, 6, "", "(1) (Preservation of character Vandermonde sign cancellation and hyperbolicity for all r0 Q>0) In the Lagrange basis at vj = j2 (N < j", "81907d3e36a19f3d59c42dc91bcf0d4808cb355465b21e77a9d48e628b7d6f0e"⟩,
  ⟨389, 42, 24, 2, 6, "", "where ( (4)) j > 0 for all N < j K by Theorem ??(3). Consequently, M( (4),r0) K 0", "7e3a0bff97d77d7e7b3f161567a91033c849c3a31f100e096aca535f244014cf"⟩,
  ⟨390, 42, 26, 1, 6, "", "is strictly positive definite, and all h roots of ( (4),r0) K (X) are unconditionally real for every r0 Q>0. (2) (Full-dimension posit", "691b549cebddda28c51ecf30253fe2f732aa4ea1f1b539f9e6db80cab330a449"⟩,
  ⟨391, 42, 27, 2, 6, "", "and the full-dimension h h evaluation matrix G( (4),rK) K ( (4)) is strictly positive def- inite (G( (4),rK) K ( (4)) 0). Consequently", "b68738c978ed197a4a25cf15520106a3bc1fbd5a3db5524b3993eba348627801"⟩,
  ⟨392, 42, 29, 1, 6, "", "(3) (Preservation of unconditional q-adic non-vanishing) Under the hypotheses of Theo- rem ?? (q 5 with q 1 (mod 4), mq = (q 1)/4, N =", "851fd5bba7f178916acd94f74aeab922b27d7592fcb2a35ece5ebb2e266647f8"⟩,
  ⟨393, 42, 30, 1, 6, "", "and on D(odd) K ( t) at q 1 (mod 8) (q > 7, m q = (q 1)/8, q (r2 0 + 4r2) for 0 r <", "e4af38a41a1a9ec63068cd7adbc991a55bf6d6938c4e1c8a38b5258785244525"⟩,
  ⟨394, 42, 31, 1, 6, "", "m q) satisfies vq( ( (4),odd,r0) K (0)) = (3m q 2) < 0. In particular, ( (4),r0) K (0) = 0 unconditionally.", "87ee8cc8ecaf0b3e865bfa4927c21b0e8e10594177117d8b3ec386bf940e5007"⟩,
  ⟨395, 43, 1, 1, 6, "", "Proof. (1) Multiplying DN(t)2m by (t r2 0) evaluates at each negative pole t = j2 (N < j K) to (j2 + r2 0) < 0, which multiplies each ", "846d6871f83c520e3848ceb56cee1fd396e33ae5e14849a787ee527234998d92"⟩,
  ⟨396, 43, 2, 2, 6, "", "Theorem ??(2) (3) by (j2 + r2 0) < 0. By Sylvester s law of inertia, M( (4),r0) K 0 is strictly positive definite, and real-rootedness", "cc7e79d4cad46c6fb88ea5a16537ec73d8c0722eedad986ecb9d9cabb4e96ceb"⟩,
  ⟨397, 43, 4, 3, 6, "", "6, the continuous function Wu0(u) := (u2 u2 0)w (4)(u) is strictly positive for all u (0, )\\{u0}, because both u2 u2 0 and cosh2( u) 6", "f82e0f20719ce5d0b0e944bb39ee3330aae1eca964b818ebb1285cffd5e1769d"⟩,
  ⟨398, 43, 7, 1, 6, "", "sure on (0, ) and therefore has strictly positive minimum eigenvalue min(G( (4),u0) K ( (4))) > 0. Since the matrix-valued map r G( (4", "2a27cff07f3f60c23bb2d9c34bb3e0ec42ed67eea8183ad2b8208ef689c07d9c"⟩,
  ⟨399, 43, 8, 4, 6, "", "leaves the diagonal valuation 3 of Theorem ?? unchanged, giving vq( ( (4),r0) K (0)) = 3mq < 0 (and similarly (3m q 2) < 0 on D(odd) K", "b3ba635bba73d239b364cb31712f1da80ad1525c6da2d442e1a33d38e37b4937"⟩,
  ⟨400, 43, 12, 9, 6, "6.13", "Theorem 6.13 (Central-factorial secant differential identity, Laplace mode annihilation, and unilateral (h, 0) root signature for all ", "d32e098e5a48d16b651ed3724e43511d6b7d79ddedfc9c0e29fabe497cd1be46"⟩,
  ⟨401, 43, 21, 10, 6, "6.13", "(1) (Exact closed-form positivity and Laplace mode annihilation for all k 1) For all z > 0,", "0eda8be49c82c3837c1b9974f721a572ce6c7e8c0c2b4512f0bc70e01d87526e"⟩,
  ⟨402, 43, 31, 2, 6, "6.13", "(6.5) In particular, the first k 1 Laplace modes l = 0, 1, . . . , k 2 vanish identically, and the strictly positive weight W + k (u) ", "de02a05eae7fbf490d82e1ddde0073d1402d2446e88c7e6818f89ebc70104a02"⟩,
  ⟨403, 43, 33, 3, 6, "6.13", "at the accelerated exponential rate O ( u2k 1e (2k 1) u) . (2) (Simultaneous positive definiteness of GK and MK and unilateral (h, 0) ", "0312c1f136a9ad69990e5de57308e3242f88f261be23561a924154d5fb255d2d"⟩,
  ⟨404, 44, 1, 8, 6, "6.13", "DK(t) (0 i, j < h), define the coupled h h Hankel matrix pencil", "5cf4b2fefb8fba9804796d0ff05a81acff136749c246cbef1628088739dca3a0"⟩,
  ⟨405, 44, 9, 2, 6, "6.13", "and set k := k m=1 ck,m (2m). Then at Xm = (2m) (Z = k), both the evaluation matrix G(k) K ( k) = [ 0 Ri,j(u2)W + k (u) du ]", "9a7fa592cd3dda50db310c0b304fdcc604689d21c86b78d2220d8d503499dbda"⟩,
  ⟨406, 44, 11, 2, 6, "6.13", "[Z]G(k) K (Z) = M( (2k)) K 0 are simultaneously strictly positive definite. Consequently: (i) The relative matrix B(k) K := G(k) K ( k", "5de00aa110329a3dc17149ee9dba87b7d96b3a22acef46bdb4fd96de02825709"⟩,
  ⟨407, 44, 13, 1, 6, "6.13", "(iii) In the shifted variable Y = Z k, all h+1 Taylor coefficients of det G(k) K ( k+Y ) = h m=0 emY m are strictly positive (em > 0 f", "f6a4139b25c71f4c84e42792f942f0cdd2d4a052741fcbafc7facbfd32393939"⟩,
  ⟨408, 44, 14, 3, 6, "6.13", "Proof. (1) We first prove by induction on k 1 that k 1 r=1 ( (2r 1)2 d2 dz2 ) ( 1 2 cosh z ) = (2k 2)! 2 cosh2k 1 z. For k = 1, the em", "842a5e659474f7a1ae253da2f2f54a8329a23ccd5c37e57028b4be74339bd119"⟩,
  ⟨409, 44, 17, 2, 6, "6.13", "dz2 ) f2k 1(z) = (2k 1)(2k)(cosh z) (2k+1), which multiplies (2k 2)! 2 cosh2k 1 z by", "f3d5e444db4384b3040f57ce1fc3a355b6f9cc4c84238ce2e786b03f20123284"⟩,
  ⟨410, 44, 19, 2, 6, "6.13", "cosh2 z = (2k)! (2k 2)! cosh2 z, completing the induction. Differentiating (2k 2)! 2 cosh2k 1 z with respect to", "453081b060de8b3d20f2eca7476a219e730d1ca9c5df0917d0d1c618e75dcb26"⟩,
  ⟨411, 44, 21, 3, 6, "6.13", "2 cosh2k z > 0 for all z > 0. Expanding 1 2 cosh z = l=0( 1)le (2l+1)z term by term,", "3be48efcae11081ed911c826b95ebdd5da54100cdf91b8e6b94a5928664ee595"⟩
]

private theorem sourceChunk3_len : sourceChunk3.length = 36 := by decide
private theorem sourceChunk3_blocks : (sourceChunk3.map (·.bodyBlockCount)).sum = 109 := by decide

private def sourceChunk4 : List PaperParagraphs.SourceUnit := [
  ⟨412, 44, 24, 1, 6, "6.13", "dz2 acts as multiplication by (2r 1)2 (2l + 1)2, which vanishes for l = 0, 1, . . . , k 2 (at r = l + 1), establishing (6.5). Setting ", "22bd8a4e1818a00b98e7fdec8189a9e1dae7bae2eaed52ae6ce9744b1ce26e5f"⟩,
  ⟨413, 44, 25, 1, 6, "6.13", "H( ,2m) j ). Summing against ck,m gives [Z]G(k) K (Z) = M( (2k)) K , which is strictly positive def-", "876da7867fe4326bb4ff3af85099c68375a14d226eff0589ea2bc196c3b660c3"⟩,
  ⟨414, 44, 26, 3, 6, "6.13", "inite by Theorem ??(3). At Xm = (2m), G(k) K ( k) is the Gram matrix of the strictly", "d93bfa1c2cb33a615ac74a77280453c7b8d76d533050ab68bade0ced41244fe9"⟩,
  ⟨415, 44, 29, 1, 6, "6.13", "B(k) K = G(k) K ( k) 1/2M( (2k)) K G(k) K ( k) 1/2 0 has all h eigenvalues 1, . . . , h > 0. By The- orem 3.1, the roots of det G(k) K", "fec4bd39d7079f9f40e7502d193605762bcfa1f7183584c1f5ee398f895588e4"⟩,
  ⟨416, 44, 30, 1, 6, "6.13", "det G(k) K ( k) h j=1(1 + jY ) has em = det G(k) K ( k)em( 1, . . . , h) > 0 for all 0 m h, and", "56c42c34a94e3ba77dc1c0cd3639ab0f51e6554e63589399d4d668bfb7c5bedb"⟩,
  ⟨417, 44, 31, 1, 6, "6.13", "Newton s inequality for positive real numbers j > 0 (not all equal since B(k) K is not a scalar multiple of Ih for h 2) yields strict ", "ec3ff52a369390037c33b73589a5175012fb1419d22107c643bf6856debff9b5"⟩,
  ⟨418, 44, 32, 1, 6, "6.13", "6.6. Dirichlet parity duality for (2k + 1) and multi-weight Zeta Beta couplings. We next establish the complete arithmetic and spectra", "ea607ec40813426c12177c98f0e3edd50bcbf8c975ae1e4d499011985bbeb41d"⟩,
  ⟨419, 45, 1, 1, 6, "6.13", "joining arbitrary odd Riemann zeta values (2m + 1) with arbitrary even Dirichlet beta values (2r).", "8cfa154efdcc4c77fa5b0f389ae24b8167e9206b3e4518d12aaf9f5655dd0115"⟩,
  ⟨420, 45, 2, 7, 6, "6.14", "Theorem 6.14 (Even-pole scaling via cosh(2 v) and coupled positive-definite pencils for b (5) + a (4) and b (5) a (2)). For each integ", "74fe4753f2fd470905e928d7b0bd2525c02cab8a69cc9bc00c150a137cdcbe0b"⟩,
  ⟨421, 45, 9, 11, 6, "6.14", "(1) (Constant +1 sign at integer-square poles t = j2) For every integer e 0, every positive integer j 1, and every rational function R", "9dd618e1d65f6a4fbf6ff249aa355e679ed503f730111308039875e1ee8a0939"⟩,
  ⟨422, 45, 20, 1, 6, "6.14", "plying 41 r ( (2r)) Y to ( t)k+1 rR(t) produces at every pole t = j2 (1 j K) the residue +j2k(Y H( ,2r) 2j ) + rj,k,r with constant +1", "9b8658c1abc99b03fa95c90bd094e301721491c3b32357a0de673d8fd995c14e"⟩,
  ⟨423, 45, 21, 5, 6, "6.14", "j2k identical to (2k+1) X ((t + j2) 1), while every monomial moment has zero odd-prime denominators (vp = 0 for all odd primes p 3). (", "ac41fc20d1e27cec71d9dd2b71bca23b6d4ebe393ced21161a5e9251c21c55b1"⟩,
  ⟨424, 45, 26, 3, 6, "6.14", "(i) For all integers (a, b) Z2 with b > 0 and |a| < (4/C4)b, the coupled functional b (5) X (R(t))+ a", "ee45e75cfa5a883cb897e6285b278e35d67d6b90769ee2ed8b61e3c932bb14d4"⟩,
  ⟨425, 45, 29, 1, 6, "6.14", "matrix pencil in Z := bX + aY with derivative [Z]GK(Z) = M(5) K , strictly positive weight bw5(v) + a", "3496402b754bc5f3d6f313aa8cb8b3fdc8d6b2be09cc571df111ee9c846e43e1"⟩,
  ⟨426, 45, 30, 1, 6, "6.14", "4v2 w (4)(v) > 0 on (0, ), unconditional real-rootedness of all h roots, signature ( h/2 , h/2 ), and exponential zero-free disk |rj (", "5a92103caf0bca57307824aebad5fb54d1c2c8dc67bd34b80eda57b02cac9e6a"⟩,
  ⟨427, 45, 31, 3, 6, "6.14", "Proof. (1) Substituting u = 2v (du = 2 dv, u2 = 4v2) into Theorem ??(1) gives ( (2r)) (2r) (R(4t)) = 2 0 R(4v2)w (2r)(2v) dv = 0 R(v2)", "f42f51a3502b68e0d7308e3c60d561a50e2d63864247b24b385598e359fdaeed"⟩,
  ⟨428, 45, 34, 5, 6, "6.14", "als te, ( (2r)) Y (4ete) = 4e ( (2r)) Y (te)Wait: in R(4t) with R(t) = te, wait: let us write ( (2r)) Y (R(t)) := 4 ( (2r)) Y ( R(u2))", "953c326a6ea84663648a4a0db64da1526ff24bcccd2ca3276bd8ef302b3a3276"⟩,
  ⟨429, 45, 39, 1, 6, "6.14", "8 ( (2r)) (2r) ((t+(2j)2) 1). By (??) at the even integer 2j (where ( 1)2j 1 = 1), ( (2r)) Y ((t+", "e1700131ca83625911c7d8e43e5409ede896669e95e9137a28be2854b26f155f"⟩,
  ⟨430, 46, 1, 3, 6, "6.14", "(2j)2) 1) = (2j)2r 2(Y H( ,2r) 2j ) r( ,2r) 2j (up to the normalization factor 1/2, which we ab-", "17e50556360e69f7592bd1995aa9f7faa05437a5b633a47e7a0652c7474543cc"⟩,
  ⟨431, 46, 4, 1, 6, "6.14", "multiplies the residue by (j2)k+1 r, giving j2k+2 2r(2j)2r 2 = 4r 1j2k. (2) Since w5(v) 6 2 > 0 as v 0+ and w5(v) (2 )4", "4d9c569655848749b07c33c83b7ac94af8076891ff0ae18238a0214b14c166b1"⟩,
  ⟨432, 46, 5, 1, 6, "6.14", "12 v5e 2 v as v , whereas v2 w (4)(v) = O(v6) as v 0+ and O(v5e 2 v) as v (and similarly v4 w (2)(v) = O(v6) as v 0+ and O(v5e 2 v) as", "d637a1725f3cd09823b44fdfc8983ff56ba8c81064f453f4daba62e427d64f0e"⟩,
  ⟨433, 46, 6, 3, 6, "6.15", "Theorem 6.15 (Arithmetic transcendence, strictly positive one-variable measure, and rank-one Pad e pencil for (2k + 1) across all k 0)", "2d447d125cede9ac6161a982dd1b0e87d4254b9dc9ee8b64593e546772827f6f"⟩,
  ⟨434, 46, 9, 7, 6, "6.15", "(1) (Unconditional transcendence, Q-linear independence, and effective irrationality mea- sure) For every k 0, (2k + 1) is transcenden", "05fbe68122dd4e8304d764f02649831247fa55d9f4605fc15e275a7fa4501316"⟩,
  ⟨435, 46, 16, 4, 6, "6.15", "where (s) = (1 21 s) (s) and H( ,s) r := r n=1( 1)n 1n s. Consequently, for any integers K > N 0 (h = K N), defining the h h Hankel ma", "898ee7b9b4955c37fd533e41c4faf44d59b5304b5dcbff7b1bc0aa61208d6de1"⟩,
  ⟨436, 46, 20, 1, 6, "6.15", "0 i,j<h 0 is strictly totally positive of all orders for every k 0. (ii) The X-derivative matrix M( (2k+1)) K := [X]G( (2k+1)) K (X) =", "a4efc19857fb6b2981f4929212ef877784e9e838f104b253ca8f26b94343f989"⟩,
  ⟨437, 46, 21, 1, 6, "6.15", "Proof. (1) Since ( 1)kE2k = 2(2k)! ( /2)2k+1 (2k + 1) > 0 for all k 0, every Euler number E2k is a non-zero integer, so (2k + 1) = qk ", "a4b199802546d7e06ad35a385847d9adb63a4e2e58f66b1b615507c392c2ecda"⟩,
  ⟨438, 47, 1, 1, 6, "6.15", "(2) Expanding u2r 1+u2 = n=r( 1)n ru2n on (0, 1) and integrating term by term against", "8ad3c73f696d2c304e1b775fead2c06a87bed53e0bbf1db4d59d6e39769e52ee"⟩,
  ⟨439, 47, 2, 3, 6, "6.15", "1 (2k)!( log u)2k using 1 0 u2n( log u)2k du = (2n+1) (2k+1) yields ( 1)r( (2k+1) H( ,2k+1) r ).", "dec9cc2f3239720e86f2bd5c93b4ca2a32d15f67e983919856b91d9c048f7132"⟩,
  ⟨440, 47, 5, 1, 6, "6.15", "2) (2k+1) = 2 (2k+1)(n+1) (2k+1) yields 2 (2k+1)( 1)r( (2k+1) H( ,2k+1) r ). Since d 2k+1(u) > 0 on (0, 1) and {u2i}i 0 is a strictly ", "31c9b300d3c6c0deecf264f2400d4c635cfde54bfb131a32cab3d864167c1f6d"⟩,
  ⟨441, 47, 6, 2, 6, "6.15", "( (2k+1)) K (X) = det G( (2k+1)) K ( (2k+1)) ( 1+( 1)N( X (2k+1) ) vT G( (2k+1)) K ( (2k+1)) 1v ) ,", "4e4df09322d48aff5348c27799df95466287f650cf232f8f44ddc3edad0da02a"⟩,
  ⟨442, 47, 8, 3, 6, "6.15", "which is affine linear in X with unique root rK = (2k + 1) ( 1)N(vT G 1 K v ) 1. Changing variables to t = u2 (0, 1), the extremal rep", "310b3c39486218c5c96ea07707bda4d49bc77697194dfa58968fd8256f35a135"⟩,
  ⟨443, 47, 11, 2, 6, "6.15", "is governed by the conformal map of C \\ [0, 1] evaluated at t = 1, where |2( 1) 1| = 3 and R( 1) = 3 +", "78e0d78ce2c64e6a9843e76751122ac77b77680e994eb320cea54f14540a3ba7"⟩,
  ⟨444, 47, 13, 9, 6, "6.16", "Theorem 6.16 (Generalized multi-weight Zeta Beta positive-definite pencil). Fix an integer k 1 and integer tuples b = (b1, . . . , bk)", "507e31eef876d1d317d453668524ada64e826346cb3005ea12ed0e99c5be845e"⟩,
  ⟨445, 47, 22, 1, 6, "6.16", "where Z := k m=1 bmXm + k r=1 arYr, and set b,a := k m=1 bm (2m + 1) + k r=1 ar (2r). Then:", "cdff68c5677703ff0a6179aab5d2721b56f9890680f0c0ee94bb05110402ac13"⟩,
  ⟨446, 47, 23, 13, 6, "6.16", "(1) (Exact integral representation and Z-derivative) The matrix G[b,a] K (Z) is affine linear in the single indeterminate Z with Z-der", "65a00e2c0a1ab05880270b629bf92714bf5ef5cf35426ab19ee8e9a3d607aa0c"⟩,
  ⟨447, 47, 36, 1, 6, "6.16", "(2) (Universal hyperbolicity, bilateral signature, and zero-free disk on the positivity cone) For every pair of tuples (b, a) Zk Zk su", "089c055356ff5a371e700fdee6db581f7acf0fb8e2385bc6cc355d36b71833db"⟩
]

private theorem sourceChunk4_len : sourceChunk4.length = 36 := by decide
private theorem sourceChunk4_blocks : (sourceChunk4.map (·.bodyBlockCount)).sum = 105 := by decide

private def sourceChunk5 : List PaperParagraphs.SourceUnit := [
  ⟨448, 48, 1, 1, 6, "6.16", "and all harmonic sums H( ,2r) 2j have p-adic valuation 2r > (2k + 1), so adding k r=1 ar (2r) incurs zero odd-prime denominator penalt", "f3f841e84b9cf233f252d2200487c8a550e60a182a443d4912cda16659b8ea00"⟩,
  ⟨449, 48, 2, 1, 6, "6.16", "Proof. (1) By Theorem 6.6(1) and Theorem 6.14(1), at each pole t = j2 (N < j K), ( ( j2))k+1 r41 r(2j)2r 2 = +j2k, so the coefficient ", "154c8d6006eee0114fe1ebf52f7f50b650ef0996f93092a62ff55a9eb6d0a17c"⟩,
  ⟨450, 48, 3, 2, 6, "6.16", "2k+1 > 0 while all lower-weight terms m < k and all (2r) terms (1 r k) vanish like O(v2). Since limv Wb,a(v)/w2k+1(v) > 0 and Wb,a(v) ", "21f045b55329b2cd837948bd2ccba978348f7da6341c7f382cc2473304881b00"⟩,
  ⟨451, 48, 5, 1, 6, "6.16", "K, which is dominated by the top-weight Riemann zeta pole valuation (2k + 1) and distribution prefactor p 2k.", "46e725c3523e6f6de29626c64fd09fc7764cb584c24f2c114036d3ffbd479d94"⟩,
  ⟨452, 48, 6, 9, 6, "6.17", "Theorem 6.17 (Universal two-variable Beukers Zeta Beta pencil, Krein decomposition, and q-adic non-vanishing). Fix any integer k 1 and", "039c827f3bcc88a6b7dccc292178a0fd572458be1d918d14449b154539699331"⟩,
  ⟨453, 48, 15, 13, 6, "6.17", "For any h-dimensional polynomial subspace A = {A0(x4), . . . , Ah 1(x4)} Q[x4] 4K with coefficient matrix C Mh (K+1)(Q), define the h ", "6302258885db59d480a1d1d735eebe10bdf7eaf45d5d0705dd84865894607339"⟩,
  ⟨454, 48, 28, 1, 6, "6.17", "where H[b,a] n,l := k m=1 bm 2m ( H(2m) n H(2m) l ) + k r=1 ar 4(2r 1) ( H( ,2r 1) 2n H( ,2r 1) 2l ) . Set b,a := k m=1 bm (2m + 1) + ", "e28e464768c347537353b78ac9c603a2631aa305ed961b3832e4683af900a864"⟩,
  ⟨455, 48, 29, 1, 6, "6.17", "(1) (Universal hyperbolicity and zero quadratic derivative growth) For every (b, a) = (0, 0), [Z]G[b,a] A (Z) = CCT 0 is strictly posi", "dd0884148f73edd7d301651c816c4b0fdcca7ef26d30e320fc6e0f666b3bb128"⟩,
  ⟨456, 48, 30, 1, 6, "6.17", "limK K 2 log det([Z]G[b,a] AK (Z)) = 0. (2) (Krein-space decomposition and positive/negative subspaces A ) At Z = b,a, the bilinear fo", "e8c79a6263e8ccabeda52ee0f82d1d6a1e96e388d5f237f58edf35416a2057dd"⟩,
  ⟨457, 48, 31, 1, 6, "6.17", "(0,1)2 f(x4 1)f(x4 2) d ( , ) b,a (x1, x2) decomposes into an infinite-rank Krein difference of squares, yielding explicit h-dimension", "8e424ca8b98632438c87d33e7668c5fd34d349721422653259b01f2633a1f51d"⟩,
  ⟨458, 49, 1, 2, 6, "6.17", "(i) If s = 2m + 1 is odd (bm = 0), setting K = 2q 1, h = q, and Aq := {x4 + m x4( +q) : 0 < q} ( m = 1 for m 2 and 1 = 2) gives the ex", "b013413098494dbbee62e16391d63a211d3e89edec2a97e9d2164d6fd08a497b"⟩,
  ⟨459, 49, 3, 8, 6, "6.17", "(ii) If s = 2r is even (ar = 0), setting K = q 1, h = (q 1)/2, and A( ) q := {x4 + 2x4( +(q+1)/2) : 0 < (q 1)/2} gives the exact q-adi", "7573550a66c31fcf4543126010dd3bd9c470061b6d5af92be5b9f2394ef996bd"⟩,
  ⟨460, 49, 11, 1, 6, "6.17", "Proof. (1) (2) Changing variables to xi = x4 i (0, 1) in the first sum reduces it to d k,b( x1, x2) of Theorem 6.7, while Proposition ", "3261bada7e7c85524215959888e4f36724a48ef0527badb3b10bd0c7be8f6f98"⟩,
  ⟨461, 49, 12, 1, 6, "6.17", "2r 2m , so vq(H( ,2r) 2n ) 2r 2m > (2m + 1) and vq(H( ,2r 1) 2n H( ,2r 1) 2l n l ) 2r 2m . Thus all (2r) terms have valuation 2m and v", "144bf46875effac9ccde74899296d67b0a00625fd6593b51c15f7a86932d630d"⟩,
  ⟨462, 49, 13, 5, 6, "6.17", "m 2 m )bm q (2m +1) diagonal entry of Theorem 6.7(3), giving vq( [b,a] Aq (c)) = (2m + 1)q < 0. In case (ii) (s = 2r even, so all acti", "0a36e4cfa7443eccaf0192f473734674ccb20d5890ef579f3f046231301fcd49"⟩,
  ⟨463, 49, 18, 1, 6, "6.17", "all active zeta harmonic sums H(2m+1) n contain no multiple of q and hence lie in Zq. For the beta harmonic sums, 2n0 q 3 < q implies ", "869da9f4e8e9cbb1a477c5829580365a058fc85e5022cfeff2bf04e5c63d500c"⟩,
  ⟨464, 49, 19, 4, 6, "6.17", "2q 2 implies that H( ,2r ) 2n1 = 2n1 1 =0 ( 1) (2 + 1) 2r contains the unique q-divisible odd", "eed7177f9c69d8a3ca6484bb342067cc626517356ca6077d4a3930bf77b02873"⟩,
  ⟨465, 49, 23, 5, 6, "6.17", "2 Z q is coprime to q, so the off-diagonal divided difference H( ,2r 1) 2n1 H( ,2r 1) 2n0 n1 n0 has valuation (2r 1) > 2r , and for = ", "647929ff6b5c9e75d6359c2d09bace1db6e2dc5f20a8d5b3cd4906ab6b6701ac"⟩,
  ⟨466, 49, 28, 1, 6, "6.18", "Theorem 6.18 (Principal-minor 2-adic integrality law, dyadic height bounds for Zeta Beta pencils, and multi-weight effective measures)", "c8e7665557d71d80369df62321c2451bf91d6f5898964ad1799354b59d49782c"⟩,
  ⟨467, 49, 29, 1, 6, "6.18", "(1) (Exact 2-adic disappearance of Euler-number denominators in the sub-threshold prin- cipal minors) Let rmin := min{1 m k : am = 0}.", "b575b4df31139c8ef28610971896109bd50f8cf5ebb7740d1a3d4a92542673ee"⟩,
  ⟨468, 49, 30, 2, 6, "6.18", "2 (and for the full h h matrix whenever 2MN +2h 2+k rmin < K), every shifted rational function ( t)k+1 mRi,j(t) (0 i, j < r, rmin m k)", "4fabdea2a75ecd05fea8575476b36c2663b8f2f22e403165f9170bbeef3c6d32"⟩,
  ⟨469, 50, 1, 2, 6, "6.18", "(ii) Because every alternating odd harmonic sum H( ,2m) 2j = 2j 1 n=0 ( 1)n(2n+1) 2m Z2 has exclusively odd denominators, the (2m) pol", "fff9a637d10cae8c03ffbfd2511aa8fed2a6eff57aee391d5244f13a842c4390"⟩,
  ⟨470, 50, 3, 1, 6, "6.18", "free of 16 e Euler-number denominators. For the full 27n 27n determinant [b,a] K (Z)", "24b8b8aee5667502c2587d91c0bb5c3671bc4782f1ff10acb204c14f7a4a3d32"⟩,
  ⟨471, 50, 4, 1, 6, "6.18", "of Theorem 6.14(2), the odd-prime multiplier m(5),odd K,M := 3 p 2h p L(5) p (K,M) clears", "9bc6e9c38baa8b5abab1db2e28ad2f89e83e459fcc97217325e2960969aa8062"⟩,
  ⟨472, 50, 5, 2, 6, "6.18", "all odd-prime denominators of S(5) K [b,a] K (Z) into the dyadic ring Z[1/2][Z] with the ex- act same odd-prime quadratic exponent as ", "275cfd3eda06ca1fde1783a378ad6ec3eb36faa4a1bb15de2b3e635363e9526c"⟩,
  ⟨473, 50, 7, 2, 6, "6.18", "27n 27n normalized determinant Q[a,b] K (Z) Z[Z] is an integer polynomial satisfying 0 < Q[a,b] K (b (5)+a (3)) e 0.0004K2+O(K) and |r", "60b9c4d93ccdf4e08b10eb507c2dbd759db3bd41ed416dd567cf6207121391a1"⟩,
  ⟨474, 50, 9, 1, 6, "6.18", "2 and rmin m k, we have deg(( t)k+1 mDN(t)2Mti+j) = 2MN + i + j + k + 1 m 2MN + 2r 2 + k + 1 rmin K 1 < K = deg DK(t). Thus Euclidean ", "4d6411519d2eff5c4235b1458ddb6e269b15eadae7fe44bcc8ef3b88dabc471f"⟩,
  ⟨475, 50, 10, 1, 6, "6.18", "integer 2n + 1 (0 n < 2j0) is odd, (2n + 1) 2m Z 2 , so H( ,2m) 2j0 Z2 has non-negative", "0589c71a0721413b007cad67df41b8b37c4d18b6266e92e1a87e7ad5a7f7209c"⟩,
  ⟨476, 50, 11, 1, 6, "6.18", "2-adic valuation for every j0 1. Moreover, since G[b,a] K,r ( b,a) is the leading r r principal", "e8445b6235048fd935cd9f95768015398481403d5ae923d44c57893e3b73d647"⟩,
  ⟨477, 50, 12, 2, 6, "6.18", "submatrix of G[b,a] K ( b,a) 0, it is strictly positive definite, and by Theorem 3.4(1) its roots are real and interlace those of G[b,", "f82217a7d2bb14a34b5136a0f882138ea79423b2a5600c6c13593e8c2570f589"⟩,
  ⟨478, 50, 14, 1, 6, "6.18", "2 = 6n, giving r = 6n. For the full 27n 27n matrix, Theorem 6.16(3) shows that at every odd prime p 3, both the polynomial moments ( (", "f50427ee8b6e370cc7fe99cf8ce7b8cfe2a6f7cfabe22d1a98a14de3ddfa9929"⟩,
  ⟨479, 50, 15, 1, 6, "6.18", "p 4Zp satisfy the local p-adic valuation bounds of (5) X , so m(5),odd K,M S(5) K [b,a] K (Z) Z[1/2][Z]. At p = 2, the monomial moment", "f4d080c62d7304aa0a01444543cb890c484301c7da611495c853a24a746a9195"⟩,
  ⟨480, 51, 1, 1, 6, "6.18", "7. Discussion and Open Problems", "5481e60dbbb32e3c0953e101a5f4355906582f18fad7d65bc339789f1f21232d"⟩,
  ⟨481, 51, 2, 1, 6, "6.18", "We conclude by summarizing the structural bottlenecks identified by our analysis and out- lining three problems for future research.", "5d565099d8f9b17e58c1554e7016dd60b7c86dedcfb43d0b6c375df73f659a2e"⟩,
  ⟨482, 51, 3, 3, 6, "6.18", "(1) Closing the gap between 5 and var 5 : In Theorem 4.4, retaining the concave potential (u) of the residue weights |rj| on the singl", "46b49522e37da1a5496def2dc77424548aaf8d95365e09bad7e28c73bd42f1a7"⟩,
  ⟨483, 51, 6, 2, 6, "6.18", "barrier for (7) alone. Three mechanisms developed in Sections 5 and 6 provide concrete paths forward: first, the asymmetric weight-(6,", "47050223716afc36be8afdffb6beaea8c9ff7196ce29e0d4f048ff6c22978ce9"⟩
]

private theorem sourceChunk5_len : sourceChunk5.length = 36 := by decide
private theorem sourceChunk5_blocks : (sourceChunk5.map (·.bodyBlockCount)).sum = 84 := by decide

/-- Original ordered Chapter 6 source records, with exact original fields. -/
def units : List PaperParagraphs.SourceUnit :=
  sourceChunk0 ++
  sourceChunk1 ++
  sourceChunk2 ++
  sourceChunk3 ++
  sourceChunk4 ++
  sourceChunk5

/-- Every indexed source unit appears exactly once (checked against full data). -/
theorem unit_count : units.length = 219 := by
  simp only [units, List.length_append,
    sourceChunk0_len, sourceChunk1_len, sourceChunk2_len, sourceChunk3_len, sourceChunk4_len, sourceChunk5_len]

/-- Every indexed PDF body-block is covered once (from the embedded ranges). -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 677 := by
  simp only [units, List.map_append, List.sum_append,
    sourceChunk0_blocks, sourceChunk1_blocks, sourceChunk2_blocks, sourceChunk3_blocks, sourceChunk4_blocks, sourceChunk5_blocks]

end PaperParagraphs.Chapter6
#print axioms PaperParagraphs.Chapter6.unit_count
#print axioms PaperParagraphs.Chapter6.block_count
