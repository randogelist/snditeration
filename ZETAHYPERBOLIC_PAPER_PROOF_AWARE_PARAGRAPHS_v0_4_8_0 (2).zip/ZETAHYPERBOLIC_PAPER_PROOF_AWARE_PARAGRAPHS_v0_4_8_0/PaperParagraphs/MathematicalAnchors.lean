import PaperParagraphs.Checkpoint
import PaperChronology.Section3ReciprocalMomentBounds
import PaperChronology.Section6SquareGramProof
import PaperChronology.Section6CentralFactorialModes

/-!
# Actual proof-bearing, manuscript-scoped paragraph anchors

Unlike the previous PDF paragraph inventory, an entry below carries
both a precise mathematical proposition and a Lean proof term.
Each entry is a *scoped lemma* associated to its SOURCE unit, never an
assertion that the full parent manuscript theorem has been proved.
The SHA-256/page/id matching to the original PDF text inventory is checked
by the package's static source audit, not by Lean parsing PDF bytes.

Four anchored source units:
* 88  (p.11), 3.6 finite reciprocal-moment maximum inequality
* 212 (p.24), 5.2 finite Gram determinant formula
* 368 (p.40), 6.10 finite Gram determinant positivity
* 402 (p.43), 6.13 central-factorial Laplace mode annihilation

These are mathematical integration of *parts* of 4 source units,
not proof of 4 additional complete PDF theorems.
-/

noncomputable section
namespace PaperParagraphs.MathematicalAnchors

/-- A real certified mathematical fragment tied to a PDF source unit.
The source unit index is metadata; evidence itself is a Lean proof term. -/
structure ScopedProofAnchor where
  sourceUnitId : Nat
  sourcePdfPage : Nat
  sourceResult : String
  exactScope : String
  fullManuscriptTheoremProved : Bool
  proposition : Prop
  evidence : proposition

/-- An elementary but exact part of the reciprocal-root power-sum proof. -/
def momentSqueezeAnchor : ScopedProofAnchor := {
  sourceUnitId := 88
  sourcePdfPage := 11
  sourceResult := "3.6"
  exactScope := "nonnegative finite moments: max^r <= sum <= h max^r"
  fullManuscriptTheoremProved := false
  proposition := ∀ (h : ℕ) (u : Fin h → ℝ)
    (hu : ∀ i, 0 ≤ u i) (M : ℝ) (hM : ∀ i, u i ≤ M)
    (i : Fin h) (hi : u i = M) (r : ℕ),
      M ^ r ≤ PaperChronology.Section3ReciprocalMomentBounds.unweightedMoment u r ∧
      PaperChronology.Section3ReciprocalMomentBounds.unweightedMoment u r ≤
        (h : ℝ) * M ^ r
  evidence := by
    intro h u hu M hM i hi r
    exact PaperChronology.Section3ReciprocalMomentBounds.finite_moment_squeeze
      u hu M hM i hi r
}

/-- The dual pencil's FINITE determinant identity, not its Krein expansion. -/
def dualGramAnchor : ScopedProofAnchor := {
  sourceUnitId := 212
  sourcePdfPage := 24
  sourceResult := "5.2"
  exactScope := "square coefficient Gram determinant with arbitrary diagonal weights"
  fullManuscriptTheoremProved := false
  proposition := ∀ (n : ℕ) (C : Matrix (Fin n) (Fin n) ℚ)
      (w : Fin n → ℚ),
    (PaperChronology.Section6SquareGramProof.weightedGram C w).det =
      C.det ^ 2 * ∏ i, w i
  evidence := by
    intro n C w
    exact PaperChronology.Section6SquareGramProof.weightedGram_det C w
}

/-- Strict determinant positivity in the *finite square* case is distinct
from the full potential-gap/large-K limit of Section 6.10. -/
def potentialFiniteAnchor : ScopedProofAnchor := {
  sourceUnitId := 368
  sourcePdfPage := 40
  sourceResult := "6.10"
  exactScope := "positive determinant for nondegenerate square weighted Gram"
  fullManuscriptTheoremProved := false
  proposition := ∀ (n : ℕ) (C : Matrix (Fin n) (Fin n) ℚ)
      (w : Fin n → ℚ),
      (∀ i, 0 < w i) → C.det ≠ 0 →
      0 < (PaperChronology.Section6SquareGramProof.weightedGram C w).det
  evidence := by
    intro n C w hw hC
    exact PaperChronology.Section6SquareGramProof.weightedGram_det_pos C w hw hC
}

/-- First (and exactly typed) finite part of 6.13(1). -/
def laplaceModeAnchor : ScopedProofAnchor := {
  sourceUnitId := 402
  sourcePdfPage := 43
  sourceResult := "6.13"
  exactScope := "first k-1 Laplace modes vanish in finite central-factorial product"
  fullManuscriptTheoremProved := false
  proposition := PaperBlueprint.Chapter6.source_6_13_mode_annihilation
  evidence := PaperChronology.Section6CentralFactorialModes.first_modes_vanish
}

/-- A list of 4 genuinely proof-bearing SOURCE paragraphs, not 485 proofs. -/
def certifiedScopedAnchors : List ScopedProofAnchor :=
  [momentSqueezeAnchor, dualGramAnchor, potentialFiniteAnchor, laplaceModeAnchor]

theorem scoped_count : certifiedScopedAnchors.length = 4 := by rfl

theorem none_is_full_manuscript_theorem :
    certifiedScopedAnchors.map (fun a => a.fullManuscriptTheoremProved) =
      [false, false, false, false] := by rfl

/-- This is not promotion of source indexing to mathematical completeness. -/
theorem retains_source_index_rung :
    PaperParagraphs.Checkpoint.attainedRung =
      .sourceIndexed := rfl

end PaperParagraphs.MathematicalAnchors
#print axioms PaperParagraphs.MathematicalAnchors.scoped_count
#print axioms PaperParagraphs.MathematicalAnchors.none_is_full_manuscript_theorem
#print axioms PaperParagraphs.MathematicalAnchors.retains_source_index_rung
