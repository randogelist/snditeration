import PaperParagraphs.Types

/-!
# Paper source unit index: FrontBack

External layout extraction indexed 11 paragraph-like source units and
13 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.FrontBack

/-- Source segmentation data; theorem numbers are cross-reference labels only. -/
def units : List PaperParagraphs.SourceUnit := [
  ⟨1, 1, 1, 2, 1, "", "SPECTRAL THEORY AND DIOPHANTINE BOUNDS FOR HANKEL DETERMINANTS OF ODD ZETA VALUES", "f56fb88650ea4878eb11c23c8a309817eae1f6ef85bd7aa7991492f441bbb95f"⟩,
  ⟨2, 1, 3, 2, 1, "", "Abstract. We study the zero locus and arithmetic properties of integer polynomials P (s) K (X) Z[X] arising from Hankel determinants a", "076d4f13b77865a0f6b7ff10930ef6d54456239d08181bde2f08d18171e3af76"⟩,
  ⟨3, 1, 5, 1, 1, "", "Ever since Ap ery [1] established that (3) is irrational, a central problem in Diophantine approximation has been to understand the ar", "43ae2d180098481bc431195982908cead21071030dee40db40173ab2a583b2ac"⟩,
  ⟨4, 1, 6, 1, 1, "", "measure on (0, ), its determinant (5) K ( (5)) is strictly positive, while Andr eief s integration identity [8] reduces the archimedea", "f83b95e44a499dde49609ea71009a0e801077d643255d7c745f22a78378811ab"⟩,
  ⟨5, 1, 7, 1, 1, "", "Date: 21 October 2026. 2020 Mathematics Subject Classification. Primary 11J82, 11M06; Secondary 42C05, 15B05, 30C15. Key words and phr", "7d2a5f6ac52fdf7d09d89ff6b63e3d6a436e44ed3acbcbbed63ce4b8e8075ebc"⟩,
  ⟨6, 2, 1, 1, 1, "", "from the triangle inequality, because Ln(X) has degree one and vanishes only at the single rational point bn/an. By contrast, clearing", "93b5013bce329edaea07bf3f59cf5e79ff80d77de3da099499ec4a0574c940ef"⟩,
  ⟨7, 2, 2, 1, 1, "", "Outline of the paper. In Section 2, we define the order-s rational moment functional (s) X and the Hankel matrix G(s) K (X). We prove ", "cb6b5afe442f1bfda8b70cc4d1aa401fffba9f3731eafd22ed51f609c3d73915"⟩,
  ⟨8, 2, 3, 1, 1, "", "B(s) K = G 1/2M(s) K G 1/2. Using Carleman s criterion, Andr eief s identity, and Sylvester s law of inertia, we prove that G(5) K ( (", "24b747843b20478e254717cb4b51d0602cef78de430ad9db04594046d2573b32"⟩,
  ⟨9, 3, 1, 1, 1, "", "and 4.3). To bound B(5) K sharply, we combine a Legendre-polynomial Remez inequality on [a, b] = [1/18, 1/3] with the exact concave St", "a7a7abd3b28d1206de2b8112c2dd18ddc76e3096c0d40439b8329159a6744e24"⟩,
  ⟨484, 51, 8, 1, 0, "", "[1] R. Ap ery, Irrationalit e de (2) et (3), Ast erisque 61 (1979), 11 13. [2] K. Ball and T. Rivoal, Irrationalit e d une infinit e d", "8002c90700b41065f1352c6078705455882f6ad2c3df522e00c608aceff3c367"⟩,
  ⟨485, 52, 1, 1, 0, "", "[7] S. Fischler, J. Sprang, and W. Zudilin, Many odd zeta values are irrational, Compos. Math. 155 (2019), no. 5, 938 952. [8] P. J. F", "aff2dae15d9fb835e1e910d51ca49d7fe5f7aadc2c1b31e4e43fdae3506beaec"⟩
]

/-- The inventory size is a kernel-checked fact about the embedded Lean data. -/
theorem unit_count : units.length = 11 := by decide

/-- The original PDF body-block count is checked against the displayed ranges. -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 13 := by decide

end PaperParagraphs.FrontBack
#print axioms PaperParagraphs.FrontBack.unit_count
#print axioms PaperParagraphs.FrontBack.block_count
