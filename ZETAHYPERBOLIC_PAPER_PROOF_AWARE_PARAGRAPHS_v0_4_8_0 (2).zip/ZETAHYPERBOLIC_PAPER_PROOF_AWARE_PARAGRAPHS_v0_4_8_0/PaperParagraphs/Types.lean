import PaperBlueprint.Pipeline

/-!
# Manuscript paragraph/source-block checkpoint: indexing is not a proof.

The original 52-page PDF is partitioned externally by PyMuPDF into body text
blocks. A layout-heuristic groups them into paragraph-like source units, including
formula blocks. A SHA-256 digest identifies the *full source text* of each unit;
Lean itself does not parse or verify the PDF bytes or interpret the formulas.

A link to a theorem identifier merely points to its existing Lean GOAL
blueprint; it does not establish that every sentence or equation is formalized.
The preexisting Registry retains its separate proved/partial/open/correction audit.
-/
namespace PaperParagraphs

structure SourceUnit where
  serial : Nat
  pdfPage : Nat
  firstBodyBlock : Nat
  bodyBlockCount : Nat
  chapter : Nat
  associatedTheorem : String
  preview : String
  sourceDigest : String
  deriving Repr

/-- 52 printed pages in the PDF. -/
def sourcePdfPageCount : Nat := 52
/-- Hash of the embedded source PDF, recorded externally for traceability. -/
def sourcePdfSha256 : String := "935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c"

end PaperParagraphs
