import PaperParagraphs.Types

/-!
# Paper source unit index: Chapter4

External layout extraction indexed 79 paragraph-like source units and
290 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.Chapter4

/-- Source segmentation data; theorem numbers are cross-reference labels only. -/
def units : List PaperParagraphs.SourceUnit := [
  ⟨120, 14, 7, 1, 4, "", "4. Diophantine Approximation, Heights, and Root Collapse for (5)", "116a1263afb78fce6343d34b125dc2653d2e77b90de9f201e30c8886cd1a1f21"⟩,
  ⟨121, 14, 8, 1, 4, "", "We now turn to the quantitative arithmetic consequences of our spectral framework at weight five. We begin with the root-geometric tra", "8bfc6fbecbac2ff02b08121147e44b0f6b0856fb66bdfddbca0467db03f06f8c"⟩,
  ⟨122, 14, 9, 14, 4, "4.1", "Theorem 4.1 (Spectral irrationality measure criterion). Let R, let d0 Z>0 and , , > 0, and suppose {QK(X)}K d0Z>0 Z[X] is a sequence o", "2c562b781e2615249c3f307d9ac1bdd65649228d6e1a53565a7542cd7196c9e6"⟩,
  ⟨123, 15, 1, 12, 4, "4.1", "Suppose that a Z satisfies |a/b | b , and set := a/b . By hypothesis (2) and K c log b, for every 1 j dK we have", "b083b776af6344000d5c1f4e00ac9f0c72563f1c3f6647502b52ef2f83c7c181"⟩,
  ⟨124, 15, 13, 5, 4, "4.1", "and similarly |QK(a/b)/QK( )| (1 o(K 1)) K 1/2 > 0 for all sufficiently large b. In particular, QK(a/b) = 0. Since QK(X) Z[X] has degr", "a2ac6f5f9740f687571ef482ad2486c0ed36cf9fd96e598f8ae73f206d185b19"⟩,
  ⟨125, 15, 18, 1, 4, "4.1", "c < 0, the right-hand side is strictly less than 1 for all sufficiently large K, a contradiction.", "7314758b6137601cbd4ce87b7044eeeb1aa2e4f49e6fa64451bf1101a7ffacab"⟩,
  ⟨126, 15, 19, 1, 4, "4.2", "Proposition 4.2 (Transfer criterion for algebraic approximations of degree d 1). Under the hypotheses of Theorem 4.1, suppose further ", "993a92e086f711bdcc653a97fdbe1f2c73e45ce93701b26afdf565e858b94675"⟩,
  ⟨127, 15, 20, 7, 4, "4.2", "there exists B0( d) such that | | > H( ) d for all algebraic numbers Q of degree [Q( ) : Q] d and naive height H( ) B0( d).", "f6b57cdeae22138bfa86eb84299c54b8ed9ed89cc88654d5d05eae6472d6aa33"⟩,
  ⟨128, 15, 27, 7, 4, "4.2", "then c d < 0 implies | 1 |e K = o(K 1), so 0 < |QK( 1)| 2e K2 as in Theorem 4.1. Since f is irreducible and QK( 1) = 0, we have gcd(QK", "76704958952a95036c9edfe49c375d62117a8ea071dc69f8c19138cbcaa278a5"⟩,
  ⟨129, 15, 34, 1, 4, "4.3", "Proposition 4.3 (Ultrametric zero-free disk over Qp). Let p be a prime, let p Zp, and let Q(X) Z[X] be any integer polynomial with Q( ", "f3464d9f7b684b929939bf940824e629296a888bec8a8ef6c50fbb1f32f57e89"⟩,
  ⟨130, 15, 35, 1, 4, "4.3", "Proof. Expanding Q( p + W) = deg Q m=0 cmW m with cm = 1 m!Q(m)( p) = r m ( r m ) ar r m p Zp, we have |cm|p 1 for all m 1. For | p|p ", "6d90ef38c01bc4ef14f85203c83d794128e3dfa10452e9cce84a5dd4d22ad425"⟩,
  ⟨131, 16, 1, 3, 4, "4.3", "We now specialize to (5) with K = 30n, N = 3n, h = 27n ( = 1/10, = 9/10) and 2m = 6, and define", "5ba4a889caa7f3c335a27d8a4ad534000cfbce0dec55a3dfd0ba199ff82e8b01"⟩,
  ⟨132, 16, 4, 1, 4, "4.3", "By the prime-sum and logarithmic-energy estimates of Fauzan [5] (with cutoff M = 100000),", "b9bbf5ada20bc03453a410f5ac1da2552a35d77229230576eea98f0635119df8"⟩,
  ⟨133, 16, 5, 4, 4, "4.3", "there exist positive rational multipliers m(5) K,M = p 2h p L(5) p (K,M) such that Q(5) K (X) :=", "0a92571f2a97c60436565e4c709dbd41c00078fac7a8fed309e671bfc1e57982"⟩,
  ⟨134, 16, 9, 1, 4, "4.3", "where limK K 2 log m(5) K,M = A(5) M 2.32425 and lim supK K 2 log F (5) K ( (5)) U (5) = 2.32380.", "20b0bfd17a93742d6e0f369a3fc2b12695d4e6145710931b9de3fc6f2769c041"⟩,
  ⟨135, 16, 10, 5, 4, "4.4", "Theorem 4.4 (Sharpened spectral bound and effective irrationality measure for (5)). For all sufficiently large K 30Z>0, the relative m", "3a2e9dc613d8a762f4d0c82d38f895e33981d03404b720acf852ae74e4527820"⟩,
  ⟨136, 16, 15, 2, 4, "4.4", "Consequently, there exists an effectively computable positive integer b0 such that for every a Z and every integer b b0, (5) a", "b516253b1f69e3380c510595abe246201069d36b9fdde78fb3ecec178fbdc051"⟩,
  ⟨137, 16, 17, 9, 4, "4.4", "Proof. Let q(t) = h 1 i=0 citi R[t] be a non-zero polynomial, and put p(t) := q(K2t). Fix 0 < a < b 1. Keeping only the l = 1 term in ", "855d6a0d0b526d91ca7a7fc2b1f1eb0d812d507eff058dfd9cb777595ccabb4b"⟩,
  ⟨138, 16, 26, 13, 4, "4.4", "b + log(1 + b) 6 log a, since DN(K2t)6 (K2a)6N and DK(K2t) K2K(1 + b)K on [a, b]. Next, setting uj := j/K ( , 1] for N < j K, Theorem ", "9b62efb50562857c85dd9d7e6a2e11a9af11818824e0c6bd85447bf92d9608e9"⟩,
  ⟨139, 16, 39, 1, 4, "4.4", "where ( h 1 j N 1 ) 2h 1 cancels 2 (h 1); at (a, b) = (1/18, 1/3), this decoupled bound already", "6dd8fa7d5516f87cda0462bc8411a1121e893c58e61fc667afc5d941e1e0bd3b"⟩,
  ⟨140, 16, 40, 3, 4, "4.4", "gives B(5) K e13.84K and | (5) a/b| > b 31155. To sharpen the exponent to (4.4) (4.5), we retain the exact factorial profile of rj cou", "4d8751c338df189ea060c846d08a9f3d93a3c7534ba5ad2c911b19e464e7f427"⟩,
  ⟨141, 17, 1, 3, 4, "4.4", "(with um = m/K), and tracking the sign ( 1)N+(j 1 N) = ( 1)j 1 from the N factors u2 l u2 j < 0 and the j 1 N factors u2 k u2 j < 0 at", "43fc360520c9386d11c9a77173afe6c9b3d74a364311f26cb5e8169ae12c05e5"⟩,
  ⟨142, 17, 4, 3, 4, "4.4", "Indeed, the degree 2h 6 10N of K arises as 2(h 1) 4 10N (from the scaling u2 k u2 j (k2 j2)/K2 over k = j, and u4 j j4/K4), while the ", "4a3121084dd4e0634dd7e0189759667705774d604671fab0856a14869d769b80"⟩,
  ⟨143, 17, 7, 21, 4, "4.4", "since + = N/K + h/K = 1 (equivalently, 12 2 = (2h 10N)/K; note the correct identity involves 2h, not h). The linear m terms from Stirl", "00115beb73d5ef7b9ab62e3edd5df5ee45ed91b07d4726e3d32a308e31ce121b"⟩,
  ⟨144, 17, 28, 11, 4, "4.4", "ca(b a) exp ( K ( F5(a, b) + max u [ ,1] a,b(u) ) ) , a,b(u) := (u) + 2 log R(u).", "99ef1ff531424429013a1b5e47ecb0c42082a3dadcb2c89786712db1ed635c84"⟩,
  ⟨145, 17, 39, 1, 4, "4.4", "For u (1/54)1/4 0.3689, all three terms of a,b(u) are negative; for u (0.1, 0.3689), the third term is bounded above by its value at u", "77cf3049fdfb02215a093c5ffb1d0325291f7f940a40d2fb886a3e91d419f214"⟩,
  ⟨146, 18, 1, 3, 4, "4.4", "Evaluating a,b(u) at u = 0.973 and u+ = 0.974 gives a,b(0.973) = +0.0259 > 0 and a,b(0.974) = 0.0125 < 0, so the unique global maximum", "8e5a62182ea8a37b7d033c48e022e452f1d139dfaf370d164e3ffbcf5498942d"⟩,
  ⟨147, 18, 4, 9, 4, "4.4", "5 = 8.2297472, R(0.974) = 16.398501..., 1.8 log R(0.974) = 5.035267... < 5.03527, and F5(1/18, 1/3) = 2", "fa3f8592072f532627bd8f65293bef7b2043a890c41f3eb48bcbe85206e61218"⟩,
  ⟨148, 18, 13, 1, 4, "4.4", ") + max u [0.1,1] 1/18,1/3(u) < 5.64951 + 0.72533 + 5.03527 = 11.41011 < 11.411 = 5.", "7ca9ea13e232b57f394d42223ab265ff2c05491342b639fe1693a866fe15b9a7"⟩,
  ⟨149, 18, 14, 1, 4, "4.4", "The margin 11.411 11.41011 = 0.00089 > 0 absorbs the polynomial prefactor for all large K, proving (4.4). Applying Theorem 4.1 with d0", "cd4e8fe32a58d76c4ebe48fe34a2d913146076b8198a506748550f3fb7b4f27d"⟩,
  ⟨150, 18, 15, 1, 4, "4.4", "By coupling the weight-five functional (5) X (R(t)) with the shifted weight-three functional (3) Y (tR(t)) over the same denominator D", "2ad83e695a07adf8e6a10c6eaf3d86841fcd06260094aa108e848a8c4dc9402a"⟩,
  ⟨151, 18, 16, 2, 4, "4.5", "Theorem 4.5 (Irrationality and effective measure for b (5) + a (3)). Let a, b Z be integers satisfying b > 0 and a < 2", "45917a7f5a32f136db26a41c6a57af65b5f11ddcde0d3796fb2adb1bfcf2aad2"⟩,
  ⟨152, 18, 18, 2, 4, "4.5", "3 b 3.2898b. Then the real number a,b := b (5)+a (3) is irrational, and there exists an effectively computable integer q0(a, b) such t", "4543cd9e620180f46b363d0937ad8a402e9c4dffe65b0b2a9a21782660409533"⟩,
  ⟨153, 18, 20, 1, 4, "4.5", "Proof. For K = 30n, N = 3n, h = 27n, consider the rational functions Ri,j(t) := DN(t)6ti+j", "c58adade5d8b5da863c1c0d43b415e06c065f39a299136c687257f385b7c29d6"⟩,
  ⟨154, 18, 21, 1, 4, "4.5", "DK(t) (0 i, j < h). At each pole t = j2 (N < j K) with residue ci,j;j := Rest= j2 Ri,j(t), we", "3d087351de14caa3190e7d1c782811ff70754ce6b8d4f28effe2a1d003178968"⟩,
  ⟨155, 18, 22, 16, 4, "4.5", "have Rest= j2(tRi,j(t)) = j2ci,j;j. Applying b (5) X (Ri,j(t)) a (3) Y (tRi,j(t)) via (2.3) gives the pole contribution", "98ad2f8fde9dcd55818586e2019d6d021d89db6b50f7e3771185e4173d6fef20"⟩,
  ⟨156, 18, 38, 1, 4, "4.5", "Thus every entry of the h h matrix G[a,b] K (Z) := [ b (5) X (Ri,j(t)) a (3) Y (tRi,j(t)) ]", "c887a0c93ca1c53fe6a0f15a5f84ba8c350c44f00b4e6e7b711d51ee8bc6c976"⟩,
  ⟨157, 18, 39, 9, 4, "4.5", "0 i,j<h is an affine linear polynomial in the single indeterminate Z := bX + aY , with Z-derivative matrix [Z]G[a,b] K (Z) = M(5) K id", "d95700a5da70a164298ca15630d5cb7e379ddc80f6b24ae4a5faf47b30917f16"⟩,
  ⟨158, 19, 1, 8, 4, "4.5", "2 > 0, we have c1(a, b)w5(y) Wa,b(y)", "83428c52badaded0f1c818b5483f55062e17502a9504c6e385165b8674fde91c"⟩,
  ⟨159, 19, 9, 1, 4, "4.5", "c2(a, b)w5(y) for all y > 0. Consequently, G[a,b] K ( a,b) is symmetric positive definite with c1(a, b)G(5) K ( (5)) G[a,b] K ( a,b) c", "4b9d1f8e42ac27091620f9cc5b7b6fac54512a67a99e9c75d69b2fdeeb421c0c"⟩,
  ⟨160, 19, 10, 2, 4, "4.5", "U (5) = 2.32380 and B[a,b] K c1(a, b) 1 B(5) K e11.411K+O(log K) for large K. On the p-adic side, by Lemma 2.2, b (5) X (R) a (3) Y (t", "b47e02b14bdec76aae1bbde0da6bc529ecdef18381d7c8da349853ada6854f54"⟩,
  ⟨161, 19, 12, 1, 4, "4.5", "5 K +2 < 9(p 1). By the von Staudt Clausen theorem, (3)(te+1) = ( 1)e+1B2e+4(2e+5)/2 can fail to be p-integral only when 2e + 4 = k(p ", "b74ebaa0aad1fa756346d182b2a537cae62596ada055e0b2eb4c4a9345b4c43d"⟩,
  ⟨162, 19, 13, 1, 4, "4.5", "bound of [5] loses at most Ch a,b = eO(K). Hence multiplying by d14 K Ch a,bm(5) K,MS(5) K yields integer", "6fc480e8ea56a65a9aa72ba7fd0c36175d7a60c7d9cd98e17ac9bfd94028688e"⟩,
  ⟨163, 19, 14, 1, 4, "4.5", "polynomials Q[a,b] K (Z) Z[Z] of degree h satisfying 0 < Q[a,b] K ( a,b) e 0.0004K2+O(K) and root gap |rj a,b| e 11.411K. Theorem 4.1 ", "37c8e237a3bca282d25da2c5c14c58d0d94f525d47e96de2997a2a0d26fe4133"⟩,
  ⟨164, 19, 15, 1, 4, "4.5", "We now establish two-sided quadratic bounds on log | det B(5) K |, coefficient height bounds, and macroscopic root clustering at (5).", "58ae530acbcc6766a98bc107edc96806fa10cf1d1122d1157c438eaec70b8dc6"⟩,
  ⟨165, 19, 16, 4, 4, "4.6", "Theorem 4.6 (Two-sided determinant bounds and coefficient heights). For all sufficiently large K 30Z>0:", "5c213721f8681c2ce5c4978d979af8c9f813524c06fc58d59032988d0059ecdc"⟩,
  ⟨166, 19, 20, 2, 4, "4.6", "(2) The normalized polynomial Q(5) K (X) Z[X] and primitive polynomial P (5) K (X) Z[X] satisfy", "ede8a9975548cc7802ca95ed26c507f4130f719fe0a08ed3cee28b6649ff33d9"⟩,
  ⟨167, 19, 22, 1, 4, "4.6", "and the decay rate P := lim supK ( K 2 log P (5) K ( (5)) ) satisfies 0.0004 P", "4661545d602f59dadaaba617469eb0fc74973d6d1362ad7bffab181b70a43ea7"⟩,
  ⟨168, 19, 23, 1, 4, "4.6", "3.73980. Moreover, writing Q(5) K (X) = cKP (5) K (X) with cK = contZ(Q(5) K ) Z>0 and K := K 2 log cK 0, we have log H(P (5) K ) (0.2", "16e687baf1d39ca0d4c44fe8e493f43872d0ec0d7aed71a1dba1ff1f8fbcf24b"⟩,
  ⟨169, 19, 24, 5, 4, "4.6", "Proof. (1) By (3.4) with k = 2 and 2m 1 = 5, we have | det M(5) K | = K a=N+1 a4 ( (a+N)! (a N 1)!a ) 5 .", "4dd7644befe2a41a79a149de2fd73f346d3b6c9888abcd36e45c503397102294"⟩,
  ⟨170, 20, 1, 9, 4, "4.6", "[ (1 + )2 log(1 + ) (1 )2 log(1 ) (2 )2 log(2 ) ] 15", "218fac128148d8d8690b2cac78003bf32b08dfb6e1a1c6d8ba5d57f5c5b969a5"⟩,
  ⟨171, 20, 10, 1, 4, "4.6", "From (4.2) and Stirling s formula, log S(5) K = 10 K2 log K + C(5) K2 + o(K2) with C(5) = 2 + 12 (1 log ) + 3 2 2 2 log(2 ) = 3.244587", "cdf7865cf5e996185c9949b0419290f11a2246722a089429297f2b6afde2a37b"⟩,
  ⟨172, 20, 11, 3, 4, "4.6", "lim K 1 K2 log ( S(5) K | det M(5) K | ) = 3.244587... 0.687388... = +2.557199... (4.14)", "2eafc61d38f3db33760fc9209bdbe5ccf08d6caa69150048c8f9fa6bccdd5f86"⟩,
  ⟨173, 20, 14, 2, 4, "4.6", "tracting gives the lower bound lim infK K 2 log | det B(5) K | 2.557199 2.32380 > 0.23310. To prove the upper bound in (4.11) without ", "0bca568c9dceaa1da01863bb1435347c012851a7338ac5cf80539997cade791e"⟩,
  ⟨174, 20, 16, 6, 4, "4.6", "the Andr eief integral for (5) K ( (5)) (scaled by yi = K ti) to (0, L)h and applying Jensen s inequality", "59be1a44328926994d2ea715442bec504a3d2092bf46e4b1a629d637b1389572"⟩,
  ⟨175, 20, 22, 1, 4, "4.6", "t + J1(t) 6J0.1(t) with Ja(t) = a 0 log(t + u2) du, and I( L) = log(L/4) = log 16 = 2.7725887.... By Fubini s theorem and the exact ar", "ed0eb77e9b1c30261627bc9b5b660d7f8962d929412d194beaadaec2d3f97264"⟩,
  ⟨176, 20, 23, 12, 4, "4.6", "L) + log(L/4) for u > 0, integrating in u (0, a) yields the closed- form identity L", "7483b5ea7d83db2f3b4d3f3712174369ddfddb87f50daacd3af58c715826920a"⟩,
  ⟨177, 20, 35, 1, 4, "4.6", "1.25+0.5) log 16 = 1.121387..., and 6 1/4 0 J0.1(t) d 1/4(t) = 6[2(0.1 arsinh(0.2)", "7f8f658228cf9737fdee55fb58453202bf594f59f2a11f86ce2bde6007b52ae2"⟩,
  ⟨178, 20, 36, 1, 4, "4.6", "0.26 + 0.5) 0.1 log 16] = +1.545150.... Summing gives 1/4 0 V5(t) d 1/4(t) = 2.423763..., whence", "a810fce9c8d7f7632bfc7a4c69d9fd8a9445a81ef69280ecbabdfad4adc8c7e4"⟩,
  ⟨179, 20, 37, 1, 4, "4.6", "lim inf K 1 K2 log F (5) K ( (5)) 0.81( 2.772589) 0.9(2.423763) + 3.244587 = 1.182597...", "33997f235b76e0c446bed8acd688320c614ad7af5a581f6e128e3a530d06600f"⟩,
  ⟨180, 20, 38, 1, 4, "4.6", "Subtracting this from (4.14) yields lim supK K 2 log | det B(5) K | 2.557199 ( 1.182597) = 3.739796 < 3.73980. (2) Using | j| B(5) K e", "635d983b8a4a33aeb51ff44538fac1cc8806b8479ba4485b722f6f95d4780365"⟩,
  ⟨181, 20, 39, 1, 4, "4.6", "H ( P (5) K ) H ( Q(5) K ) e 0.0004K2( 1+3e11.411K) 0.9K exp ( (0.9 11.411 0.0004)K2+O(K) ) < e10.27K2.", "642005c011d702b4b38e458c0b60c193dd6a2b09dfda76b973753f52ecd7e99d"⟩,
  ⟨182, 21, 1, 1, 4, "4.6", "Since |[Xh]P (5) K (X)| = P (5) K ( (5))| det B(5) K | 1, we have log P (5) K ( (5)) log | det B(5) K |, so P 3.73980. Finally, limK K", "d12382cbb913a1cf9999c45877ee63c2e6648cb0d868dd1134baeb329229bd92"⟩,
  ⟨183, 21, 2, 1, 4, "4.7", "Theorem 4.7 (Macroscopic exponential root collapse and root separation). For all sufficiently large K 30Z>0:", "f7e91a1f1002bd2efc9aebe128d64a80fec143e3cb4e9646227d8ad609d3dba5"⟩,
  ⟨184, 21, 3, 1, 4, "4.7", "(1) At least Nclust 0.0140h > 12 1000K real roots rj of P (5) K (X) satisfy rj (5) e 0.10K, (4.15)", "96b14e81477439ecae176c2bdd3219c44bd2d743c0b368ca7ad80a0491e48e75"⟩,
  ⟨185, 21, 4, 3, 4, "4.7", "while the closest root satisfies e 11.411K min1 j h |rj (5)| e K/2250, and the arithmetic mean of the roots satisfies 1", "c742055f4de672b3f21bf1477f97fcbfd6f06e699a741d7d51deb90ff3d1dd47"⟩,
  ⟨186, 21, 7, 10, 4, "4.7", "(2) Any two roots r < (5) < r+ of P (5) K (X) straddling (5) satisfy r+ r 2e 11.411K, and any two roots ria = rib belonging to the sam", "69347a81f4e2280142d7b0a4a407d2b562b2595521954e6eecdac841caf55f74"⟩,
  ⟨187, 21, 17, 2, 4, "4.7", "|aK,h| j | (5) rj| = P (5) K ( (5)) e 0.0004K2 and rj (5) = 1 j . (2) For r < (5) < r+, Theorem 4.4 gives r+ r = (r+ (5)) + ( (5) r ) ", "f2100837e24d45608957d3655ad76033d8135d19bc73c83382f43d9015ad54e2"⟩,
  ⟨188, 21, 19, 4, 4, "4.8", "Proposition 4.8 (Rational root exclusion and degree bounds for cluster factors). Let K 30Z>0 be sufficiently large, and let F(X) = cF ", "f839c2ee3e727eec4a7c8226eda3d4a8002b3a1fe29417cb568cbdf961351691"⟩,
  ⟨189, 21, 23, 2, 4, "4.8", "and if all roots of F(X) lie in the cluster disk |rjm (5)| e K ( > 0), then d also satisfies the upper bound d log |cF | log |F( (5))|", "958d8c54a9f4c97b011b474b6ab696aa0d98b029f02754a2d2961bb232ba8ece"⟩,
  ⟨190, 21, 25, 1, 4, "4.8", "Proof. (1) By Theorem 4.4, if a/b Q is a root of P (5) K (X) in |X (5)| e K, then for b b0 we have b 25687 < |a/b (5)| e K (while for ", "61b9dd11e4e92fbba5bb0083722640a92c287af4fa3f57ebdf1fe5243ccf4a8b"⟩,
  ⟨191, 21, 26, 1, 4, "4.8", "for large K since (5) / Q), forcing b e( /25687)K. Taking = 11.411 (which holds for all roots of P (5) K by Theorem 4.4) gives b eK/22", "bc9f1051c1368ed905e5b16feb21b5dd955185404214155d62988f89fab365b5"⟩,
  ⟨192, 22, 1, 2, 4, "4.8", "(2) By Theorem 4.4, every root of P (5) K (X) satisfies | (5) rjm| e 5K with 5 = 11.411. Thus |F( (5))| = |cF | d m=1 | (5) rjm| |cF |", "2ccd8d5d06befe8b10cae17b1a3706bfa5598ca02b00c0ccfd27f27d9185d749"⟩,
  ⟨193, 22, 3, 3, 4, "4.9", "Remark 4.9 (Spectral bounds and variational conjecture for 5). Combining Theorem 4.4 and Theorem 4.6(1) with | det B(5) K | B(5) K h y", "2998fb765aee5d6d359b142a0a1f74cb11452d5b1f9c28ee1411a2fb1b099873"⟩,
  ⟨194, 22, 6, 6, 4, "4.9", "where var 5 denotes the two-sided logarithmic potential supremum over positive measures on C of mass at most = 9/10:", "1609a6dc9381d0d4d48d5e384eff9d21d50845466dd468cb39631b33e55ae0fe"⟩,
  ⟨195, 22, 12, 2, 4, "4.9", "Notice also that since (1) = 6(1.1) log(1.1) 6(0.9) log(0.9) 2 log 2 + 0.8 = 0.6083... and the equilibrium measure eq 5 of V5(t) on [0", "e61bbef83f622cb32c38e5e230b34abd5eff6fa9211e75733a748cc8f3d45d06"⟩,
  ⟨196, 22, 14, 2, 4, "4.10", "Remark 4.10 (Lee Yang phase transition at (5)). Define the partition function ZK(X) := P (5) K (X), viewed as the canonical partition ", "ad1ed15906433932f8334836011608190452155625703b78b5831f3f71c79c78"⟩,
  ⟨197, 22, 16, 1, 4, "4.10", "at X = (5). The transition is accompanied by the exact two-sided spectral gap |r+ r | 2e 11.411K (Theorem 4.7(2)) for the closest pair", "9171b2085491aa080579866c0f5250af138a824adcd29549030fe8782d948a9b"⟩,
  ⟨198, 22, 17, 2, 4, "4.11", "Conjecture 4.11. The limit 5 := limK 1", "9cab1657ea77efad4b8265a9f13eb4a4339025ae24cfb67c89300fc2b4340268"⟩
]

/-- The inventory size is a kernel-checked fact about the embedded Lean data. -/
theorem unit_count : units.length = 79 := by decide

/-- The original PDF body-block count is checked against the displayed ranges. -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 290 := by decide

end PaperParagraphs.Chapter4
#print axioms PaperParagraphs.Chapter4.unit_count
#print axioms PaperParagraphs.Chapter4.block_count
