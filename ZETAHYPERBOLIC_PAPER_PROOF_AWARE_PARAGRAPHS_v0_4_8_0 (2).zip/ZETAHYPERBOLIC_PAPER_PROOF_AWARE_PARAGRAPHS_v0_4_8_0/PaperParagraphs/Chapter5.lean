import PaperParagraphs.Types

/-!
# Paper source unit index: Chapter5

External layout extraction indexed 66 paragraph-like source units and
229 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.Chapter5

/-- Source segmentation data; theorem numbers are cross-reference labels only. -/
def units : List PaperParagraphs.SourceUnit := [
  ⟨199, 22, 19, 1, 5, "", "5. Weight-Seven Integral Identities, Dual Pencils, and Double-Pole Systems", "dab9cee1a9f685a94326ea10c7515f3753082b5bdb34c3e91a80c0971bee35c0"⟩,
  ⟨200, 22, 20, 1, 5, "", "In this section, we establish the structural theorems governing weight seven and simultane- ous multi-pole Hankel determinants. We beg", "edb5b67f692a660526748d95ea3388655cd36e24ebda395821476a83fdc4ae43"⟩,
  ⟨201, 22, 21, 4, 5, "5.1", "Theorem 5.1 (Two-variable Beukers measure for (7)). Define the strictly positive measure on the unit square (x1, x2) (0, 1)2 by", "ca0499880273752a49ec22e5de85983f4b8e2fe1b2c59a52e204f7d1647e2e8e"⟩,
  ⟨202, 23, 1, 7, 5, "5.1", "Then for every pair of non-negative integers (r1, r2) Z2 0:", "03d4cb13ecf2c73f7d5ce665eca012f69014f7cef698d60ec7107f73c5d63632"⟩,
  ⟨203, 23, 8, 5, 5, "5.1", "Proof. Change variables on (0, 1)2 to u = x1x2 (0, 1) and x1 (u, 1), with Jacobian (x1,x2)", "391d440952c0933d5731658478cdba9cbaeabf1c0bacd4330cd25643771cf16a"⟩,
  ⟨204, 23, 13, 3, 5, "5.1", "If r1 = r2 = r, integrating over x1 (u, 1) gives 1 u x 1 1 dx1 = log u. Expanding (1 u) 1 = m=0 um and applying 1 0 ( log u)6un 1 du =", "1d4f63e816a4293d56288f6f053390db7b4e13002b7f5f9f540124008fdaec0b"⟩,
  ⟨205, 23, 16, 2, 5, "5.1", "n7 = (7) H(7) r . If r1 = r2, assume by symmetry that r1 > r2. Then 1 u xr1 r2 1 1 dx1 = 1 ur1 r2", "76d502d42e3b7729b86d45dd84c41ca6181ef156db0084a5de6a17d4d49d0da8"⟩,
  ⟨206, 23, 18, 6, 5, "5.1", "1 u = r1 1 m=r2 um, integrating term by term using 1 0 ( log u)5um du = 5! (m+1)6 =", "10d84d0c6795b9a1bf077087fb9fc5d37b2a6fb87914edb1a747d72131050323"⟩,
  ⟨207, 23, 24, 1, 5, "5.1", "Whereas the one-variable Hankel matrix G(s) K (X) has positive definite evaluation G(s) K ( (s)) 0 and indefinite derivative M(s) K , ", "de21c86204f2fd4b6782d3f3d90a51984af3fad1e9a5c03e874c8ad9a2179119"⟩,
  ⟨208, 23, 25, 11, 5, "5.2", "Theorem 5.2 (Dual hyperbolicity and Krein-space decomposition of the two-variable (7) pen- cil). Let K h 1 be integers, and let A = {A", "e101a69fc283bc6ce0d99d2f34544b3beabb35b88ff21b97586e77ee46088d8e"⟩,
  ⟨209, 23, 36, 10, 5, "5.2", "(1) The X-derivative matrix M(7) A := [X]G(7) A (X) = CCT is strictly positive definite, and (7) A (X) := det G(7) A (X) Q[X] has exac", "25323856b66823d08112d86681c17c000ed226c7bbbdb5ae2a05fbb2e329035f"⟩,
  ⟨210, 23, 46, 1, 5, "5.2", "(5.4) (3) For every integer h 1 and every truncation M h, there exist explicit h-dimensional polynomial subspaces A+, A Q[x] K such th", "001291276e072a312d9ce9128e68b1ba00e3b1a9a781ed7ea9100452190aeb2e"⟩,
  ⟨211, 23, 47, 1, 5, "5.2", "strictly less than (7)) and G(7) A ( (7)) 0 (all roots strictly greater than (7)).", "6d6ab82b57ae15a5db2ae7baf2aecbca59112e7329fc9bfb124b2cd819dddd58"⟩,
  ⟨212, 24, 1, 1, 5, "5.2", "Proof. (1) Differentiating (5.3) with respect to X gives [X]G(7) A (X)i,j = K r=0 Ci,rCj,r = (CCT )i,j. Since A0, . . . , Ah 1 are lin", "9e877343d6fee8c1e5bc3c519d77c77156eb9afeae7556789aa364eae48364ec"⟩,
  ⟨213, 24, 2, 1, 5, "5.2", "its eigenvalues 1, . . . , h are real, so all roots rj = (7) j of (7) A (X) are real. (2) Expanding (1 x1x2) 1 = m 0 xm 1 xm 2 and ( l", "77b16f5b288b6b36596e67831909966007bc5ab171572ec632fd107d90dd2112"⟩,
  ⟨214, 24, 3, 1, 5, "5.2", "2[(I + I5 )2 (I I5 )2] where I := 1 0 f(x)xm( log x) dx, gives (5.4) (the prefactor 1/1440 arises from 1 2 720 = 1 1440). (3) Linear i", "5b21a83d3824d8ead8ac21491d856b99483d0b3e23302ba69b6b35a20a38878c"⟩,
  ⟨215, 24, 4, 8, 5, "5.2", "and this change of basis is invertible on Span{xm( log x) , xm( log x)5 }. Construction of A+. Fix h 1 and truncation M := h 1 (so the", "0beca878f0314e695ea6ecfee8af7db1f3e6cb562e7115edb4a99f60a3fa3cd3"⟩,
  ⟨216, 24, 12, 2, 5, "5.2", "since the terms fi, m, fj, m, vanish by orthogonality for 0 m M. Thus the restricted h h matrix [ fi(x1)fj(x2) d 7 ]", "cb2aa3ff9792249132a5bf08557c13cd5e86fbd75875eaff5887e9dca1cfc331"⟩,
  ⟨217, 24, 14, 1, 5, "5.2", "positive semidefinite rank-one matrices, where u(m, ) i := fi, + m, . The m = 0, = 0 term", "7e02063c6ccd5b65f6d5262bd2630ab34e5b632234f2a7abcdd2ea567d1ba100"⟩,
  ⟨218, 24, 15, 1, 5, "5.2", "alone gives 1 1440u(0,0)(u(0,0))T with u(0,0) i = i,0 1 1440 + 0,0, + 0,0 > 0, and summing over m, gives a matrix of the form 1 1440(I", "043f8defbfab8f5d3cacf117e8e49f3dc5c4bb002697aed9987c5fd63eb30638"⟩,
  ⟨219, 24, 16, 2, 5, "5.2", "negative definite. Approximation by rational polynomials gives A Q[x] with G(7) A ( (7))", "9b8778427b79ac7f5856d6edf34ac084d9640b5d57bcac6b3931bb6d211edd2b"⟩,
  ⟨220, 24, 18, 3, 5, "5.3", "Proposition 5.3 (Two-variable Beukers measure and dual pencil for (4) = L(4, 4)). Define the positive measure d (4)(x1, x2) := 1", "43a48b8ad822453f2b84c116e20e3409db57b09e5e35748dab6d82269e9ca7db"⟩,
  ⟨221, 25, 1, 9, 5, "5.3", "(2n+1)s (H( ,s) 0 := 0). Then for all integers k1, k2 0:", "89c9fd4f503d555fb3616259b325cb829cffc45b88ba4b7bcaf4340f6ab1b9c1"⟩,
  ⟨222, 25, 10, 1, 5, "5.3", "Consequently, for any linearly independent subspace A Q[x4] 4K of dimension h, the induced symmetric matrix pencil G( (4)) A (X) has p", "e77cd71feb738d4366259f18c8ead7197edc8e66e8dcfa02982909a25c9b1af1"⟩,
  ⟨223, 25, 11, 1, 5, "5.3", "Proof. Setting u = x1x2 (0, 1) and x1 (u, 1) gives 1 u x 1 1 dx1 = log u when k1 = k2 =", "1180b8fc8f3c5ab474b8b8999f6d30f32d45258dfe14ca68e7fe1eda0c6d7814"⟩,
  ⟨224, 25, 12, 1, 5, "5.3", "k, and expanding u4k(1 + u2) 1 = n=2k( 1)nu2n yields (4) H( ,4) 2k . When k1 > k2, 1 u x4(k1 k2) 1 1 dx1 = 1 u4(k1 k2)", "70c714793a3395085f45497462ea1d8e6d65c3b0811a0def2f68c141715e26d4"⟩,
  ⟨225, 25, 13, 1, 5, "5.3", "4(k1 k2) , and since 1 + u2 divides 1 u4(k1 k2) in Q[u] with quotient 2k1 1 n=2k2( 1)nu2(n 2k2), integrating term by term against 1", "c26880629a28521d6e605509c689324709018fb48cd58c43e89cc5d5f53a1638"⟩,
  ⟨226, 25, 14, 1, 5, "5.3", "6( log u)2u4k2 gives H( ,3) 2k1 H( ,3) 2k2 12(k1 k2) Q. Real-rootedness follows as in Theorem 5.2(1).", "d525a58c22b1e11422a2a56bb0e37f5ac54cba8eb9bbb6a1b67d7d5bcfa3b1c9"⟩,
  ⟨227, 25, 15, 3, 5, "5.3", "Next, we establish the exact cancellation of higher zeta values on x-even pole pairs under the auxiliary functional X := (7) X of Lemm", "d861d486261d5aacb77bd0b6e53f86a5a7f0916971923237d14d4c2566fcd4aa"⟩,
  ⟨228, 25, 18, 2, 5, "5.4", "Theorem 5.4 (Cancellation of higher zeta values on even pole pairs). Let s = 2k + 1 3 and j 1. Under the reflection and difference ide", "f31caf661d4c8a5056c1697a4ad3749221cca501beabd35e015172c98b916142"⟩,
  ⟨229, 25, 20, 3, 5, "5.4", "Proof. Set h(x) := (x j) 1, which is regular at x = 0 since j 1. Then h(x + 1) = (x (j 1)) 1. Under x 1 x, the reflection identity of ", "7748425cb70893762b0cf66e3f31f51702026a2b538f7e27f0ab2920345b1486"⟩,
  ⟨230, 25, 23, 1, 5, "5.4", "(s) X ( Ej(x) ) = (s) X (h(x)) (s) X (h(x + 1)) = (s) X ( h(x + 1) h(x) ) .", "405ed07b14bcac7a798f3dfa024030ef0054c9235a32ec5e31aa6f90e7132d73"⟩,
  ⟨231, 25, 24, 10, 5, "5.4", "For j 2, the difference identity of Lemma 2.3 gives (s) X (h(x+1) h(x)) = j (2k+1), whence (s) X (Ej(x)) = j (2k+1). For j = 1: h(x + ", "034a0ca6fd03e7343108d4eadcc8df3c26e210db29f656e38014fe73a4da4895"⟩,
  ⟨232, 25, 34, 1, 5, "5.5", "Remark 5.5. The formula (5.5) is restricted to the simple-pole case r = 1 (poles (x j) 1 and (x+j) 1), which is the case used in the w", "cf0a364aa40363df8a56485b62a51d5502b76c7cafc14f201450f92bf0725873"⟩,
  ⟨233, 26, 1, 1, 5, "5.5", "We now record the exact evaluation of the prime-sum integrals for the one-variable weight- seven Hankel construction (K = 40n, N = 3n,", "6bbffaf6f32c10fc6570d3a513122435e5c03f3e1e745f3176e7f7b47448a0e8"⟩,
  ⟨234, 26, 2, 4, 5, "5.6", "Theorem 5.6 (Weight-seven prime-sum evaluation and pole-ordered refinement). Let = 3/40, = 37/40, and H = 1 + 3 = 49/40. For y [1/3, 3", "77129761b4acdb3e499910c93842a82dc3b4efe52a80d2449cad56dd13e391a0"⟩,
  ⟨235, 26, 6, 2, 5, "5.6", "9(1 y) 16 7 t(y) + min( r(y), y + u(y)), 1/3 y < 1/2, 9(1 y) 8 t(y) + min( r(y), y + u(y)), 1/2 y < 1, 0, 1 y 37/20,", "cdedf22f12fbd69464b447ea58386edd7d37ad0f29fad507a494f2db95573d2b"⟩,
  ⟨236, 26, 8, 6, 5, "5.6", "and define the outer prime-sum integrand T(y) := R(y) 2 1/y + 7 j=1(2 jy)+. For x 3 and z (0, 1/2), set l(x, z) := x z + x + z + 1, b(", "5929f9d8d70b4407ab8309f66fa302a385b7613b11c52c06d1599062b38758b5"⟩,
  ⟨237, 26, 14, 6, 5, "5.6", "(1) T(y) is continuous on [1/3, 1/2) and on [1/2, 1), and its exact integral over [1/3, 37/20] is", "9d134a78a39af8751295ad4bfdf85bdb085b91a3dde9b20335723a08f877f248"⟩,
  ⟨238, 26, 20, 1, 5, "5.6", "576000 0.05747222. (3) In the inner prime range K/M < p K/3 (mp = (p 1)/2), let ka,1 > ka,2 > > ka,sa (sa = lK(a) lN(a)) be the poles ", "ecad3a82095adbb0aef43edc78a539dcd8282b20a23ba2c5cbbe5749ec39c41a"⟩,
  ⟨239, 26, 21, 8, 5, "5.6", "by min(i,sa 2) =1 (t+k2 a, )(t+a2)max(0,i (sa 2)) upgrades the local half-weights from wa,i = i + 4lN(a) (lK(a) + 6)/2 to", "330be03eaaee5b7de2af7bce05c23bbb3dfbf8aac71f3a7e229c5ae369e61e73"⟩,
  ⟨240, 26, 29, 4, 5, "5.6", "increasing the inner determinant valuation bound in p = 2 mp a=0 La 1 i=0 wa,i by 6(p 1),", "d2b00dbc42ca6a13ba1542172e3da2133d79f8aa1a22bd82c898f2ef2b8105ab"⟩,
  ⟨241, 26, 33, 2, 5, "5.6", "Proof. (1) Partitioning [1/3, 37/20] at all branch points of 1/y , u(y), t(y), min( r, y + u), and (37/20 jy)+ yields 11 subintervals ", "bf4673737367513ef8b77206cefdd44f138e8f1699414f8c366d5e2642f5b2c0"⟩,
  ⟨242, 26, 35, 1, 5, "5.6", "288000. (2) Set f = {x}, g = { x}, = {2Hx}, = {2x}, = {2 x}, and d(u) = min(u, 1 u). Since l(x, z) 2x = (1z<d(f) 2d(f)) has zero mean ", "ca0fab32a713cecd79be0e689e4a9ac11a343ef8054aee8328805b26c58f8629"⟩,
  ⟨243, 27, 1, 2, 5, "5.6", "Table 1. Exact affine pieces of T(y) = b + cy on [1/3, 37/20].", "a5b61b98350acb8b6cfc2ebd3ceb6c7bfc6c9ada6044ed4b5dba899c71b85a19"⟩,
  ⟨244, 27, 3, 1, 5, "5.6", "[1/3, 43/120] 51/8 5 113/24 55/12 223/1920 [43/120, 29/80] 513/40 23 55/12 359/80 2177/115200 [29/80, 37/100] 571/40 27 359/80 857/200", "2a287e799e7b5dacc37fc64cddd3ec4dace3b4e58aedf67b191ce1e01c809488"⟩,
  ⟨245, 27, 4, 14, 5, "5.6", "[0, 1/8], expanding (x) and N(x) cancels the x2 terms and yields R(x) = xF(x)+Q(x), where F(x) = 6 + 2 f 16 g and", "89bfe6faad3a3178bbccc2c47ed2988f7d87c8e8c2f1132d4dd4da0639239378"⟩,
  ⟨246, 27, 18, 28, 5, "5.6", "27 G(g) where G(v) = v(1 v)(2v 1) (which satisfies C (x) = P(x) P and |C(x)| 1 6", "9d69f32d500b7ab9275426304bf9e0668042b4147cbf274f69d020fa1430efb6"⟩,
  ⟨247, 27, 46, 1, 5, "5.6", "(3) Since t + k2 a, t + a2 (mod p), the modified basis { Ea,i} is unitriangular modulo p relative to {Ea,i} and hence Zp-unimodular. F", "988535577ab14a44645f4dbe332d8b72db3f0037a437d0c9091db121f94542a6"⟩,
  ⟨248, 27, 47, 1, 5, "5.6", "local principal-part contribution p 6(H(7) 0 Y ) = p 6Y pZp[X] is p-integral without the 6 distribution loss. Thus, for each of the tw", "c5844e21ed2940348f95901fc340d2f4343c5b188e77b735f34f829f271206ab"⟩,
  ⟨249, 27, 48, 1, 5, "5.6", "2 6 = 6(p 1), which upon dividing by p increases (x) by +6 for all x 3 and reduces 3 R(x)x 3 dx by 3 6x 3 dx = 1/3.", "32fe4f8b8fa6397d2647af7718c79262307e8009cdf878188621ad7005ae10c6"⟩,
  ⟨250, 28, 1, 1, 5, "5.6", "Finally, following the double-pole Hankel architecture introduced by Lai [9], we prove the q- adic non-vanishing and local p-adic mino", "1986698f828fb02d8b02d001f2c0f000dfffd6386e892e1a1f303b3d91466be2"⟩,
  ⟨251, 28, 2, 2, 5, "5.7", "Theorem 5.7 (Simultaneous double-pole Hankel determinant for {1, (5), (6)}). Suppose a (5) + b (6) = c with a, b, c Z and b = 0. For n", "119a4ca39df0ef29358ed631db95d5dd3f84532b1841067ac16a6843b5b1da8e"⟩,
  ⟨252, 28, 4, 6, 5, "5.7", "For every polynomial P(t) Q[t] with deg P < 6n, deg(Rn(t)P(t)) n 3 4 has zero polynomial part and zero residue at t = , and its partia", "ee9fa4f74a07f2d68b12e222de91293e2f9a59665599ca36545c741019ecaf76"⟩,
  ⟨253, 28, 10, 3, 5, "5.7", "where An,k = ( 1)k( 6n k ) 2( n+k k ) 5n!, Bn,k = An,k(7H(1) k 2H(1) 6n k 5H(1) n+k), Uk = c aH(5) k", "1b2570b4efb1010ebdac847fe48059e13395f2d1dfae55331f37fa949f406ebc"⟩,
  ⟨254, 28, 13, 9, 5, "5.7", "(1) For every prime q > max(|b|, 11) satisfying q 1 (mod 9), set m = (q 1)/9 and n = 2m. Then vq(J2m) = 18n = 36m < 0; in particular, ", "137afb45b4254b73256931b131d97b8fba4a3e6096f7dfea25528f361b16e33c"⟩,
  ⟨255, 28, 22, 2, 5, "5.7", "Proof. Since deg Rn = 5n (12n + 2) = 7n 2, for any 0 i, j < 3n the polynomial P(t) = ti+j has degree i + j 6n 2 < 6n, so deg(Rn(t)ti+j", "380213230029807fbb5ab5d66fb73095df95fbc446826232000120992b3b8942"⟩,
  ⟨256, 28, 24, 1, 5, "5.7", "2q. For each of the 3m integers k = q + r (0 r < 3m) in [q, 6n], we have n + k = q + 2m + r < 5", "7eba403fdbbaf0f4a6401e57d5ad7ffbb3d430137a6a639d5eda001dac15cce6"⟩,
  ⟨257, 28, 25, 1, 5, "5.7", "3q < 2q, so vq( ( 6n q+r ) ) = 1 1 0 = 0 and vq( ( n+q+r q+r ) ) = 1 1 0 = 0, giving vq(An,q+r/n!) = 0. Moreover,", "30438f5737a27f383d975f29de01b3c9a616e2c5b9475b2e7eead19d103a0323"⟩,
  ⟨258, 28, 26, 1, 5, "5.7", "H(5) q+r q 5 + Zq and H(6) q+r q 6 + Zq, so Uq+r bq 6 (mod q 5Zq) with vq(Uq+r) = 6 since q > |b|. Let {P2r(t), P2r+1(t)}0 r<3m Zq[t]<", "d4fd505c698fe0de94d5687c7b49f9315d9620090e10142abda530b659c0805b"⟩,
  ⟨259, 28, 27, 1, 5, "5.7", "scaling matrix Dq := diag0 r<3m(q7/2, q5/2), and set M := DqMDq. Since vq(Vk) 7 and vq(Bn,kUk/n!) 7 for all q k 6n (with equality at k", "6baa4824d2fb8cb4530e8b530cd71489a3ba2c7371935d985a361378ae15d043"⟩,
  ⟨260, 29, 1, 8, 5, "5.7", "M<q M3n(Zq), every entry of M lies in Zq. Moreover, on the r-th diagonal 2 2 block,", "89b31491b1dee21c531368ef163238a935ae4c28259563ac3cb4413ddc4d15a0"⟩,
  ⟨261, 29, 9, 1, 5, "5.7", "while all off-block entries of M lie in q5Zq qZq. Reducing M modulo q yields a block-diagonal matrix over Fq with determinant 3m 1 r=0", "2a23b7bee7bf02c9cbb1eae8ca8825a09b658f9e094bc9114e10724bd387f5a7"⟩,
  ⟨262, 29, 10, 1, 5, "5.7", "6n, 6n] and {0, . . . , p 1}, pass to the unitriangular Taylor basis i, (t) := (t + )i via E = [ ( i j ) i j]. In the local matrix M m", "bab9fb01ab60f907caeef130cda2ec9c27ac6ea71217ea00f27288d79a7ac702"⟩,
  ⟨263, 29, 11, 1, 5, "5.7", "6n implies vp(k) 1, we have vp(Uk) 6, vp(Vk) 7, vp((Bn,k/An,k)Uk) 7, and vp(An,k/n!) p( ) by Legendre s formula. Factoring pi", "976ad9393d8aec1477ac9cd7657e2aa9c1c4d73e4f07acaa969f5a8891c92d21"⟩,
  ⟨264, 29, 12, 1, 5, "5.7", "from row i I and pj from column j J of an m m minor gives valuation at least i I i+ j J j +m ( p( ) 7) m (m 1+ p( ) 7). Multilinear de", "e7c5be2e827942a32e631c853f91d2dc6e03a51d63cc4fa45108bf2f74c88cee"⟩
]

/-- The inventory size is a kernel-checked fact about the embedded Lean data. -/
theorem unit_count : units.length = 66 := by decide

/-- The original PDF body-block count is checked against the displayed ranges. -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 229 := by decide

end PaperParagraphs.Chapter5
#print axioms PaperParagraphs.Chapter5.unit_count
#print axioms PaperParagraphs.Chapter5.block_count
