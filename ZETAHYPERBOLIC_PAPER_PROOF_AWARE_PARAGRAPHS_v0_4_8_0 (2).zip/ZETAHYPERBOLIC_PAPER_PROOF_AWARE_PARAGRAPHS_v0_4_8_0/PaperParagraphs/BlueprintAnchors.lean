import PaperBlueprint.Pipeline
import PAPER_BATCH_0470_CHAPTER_BRIDGES

/-!
# Chapter theorem declaration anchor checks

These elaboration checks ensure every substantive theorem entry retains a live
Lean mathematical target. They do NOT prove those targets or translate every
individual PDF paragraph into an equivalent Lean formula.
-/
#check PaperBlueprint.Chapter2.goal_2_1  -- manuscript 2.1
#check PaperBlueprint.Chapter2.goal_2_2  -- manuscript 2.2
#check PaperBlueprint.Chapter2.goal_2_3  -- manuscript 2.3
#check PaperBlueprint.Chapter2.goal_2_4  -- manuscript 2.4
#check PaperBlueprint.Chapter2.goal_2_5  -- manuscript 2.5
#check PaperBlueprint.Chapter3.goal_3_1  -- manuscript 3.1
#check PaperBlueprint.Chapter3.goal_3_2  -- manuscript 3.2
#check PaperBlueprint.Chapter3.goal_3_3  -- manuscript 3.3
#check PaperBlueprint.Chapter3.goal_3_4_repair  -- manuscript 3.4
#check PaperBlueprint.Chapter3.goal_3_5_repair  -- manuscript 3.5
#check PaperBlueprint.Chapter3.goal_3_6_corrected  -- manuscript 3.6
#check PaperBlueprint.Chapter3.goal_3_7  -- manuscript 3.7
#check PaperBlueprint.Chapter3.goal_3_8  -- manuscript 3.8
#check PaperBlueprint.Chapter3.goal_3_9  -- manuscript 3.9
#check PaperBlueprint.Chapter4.goal_4_1  -- manuscript 4.1
#check PaperBlueprint.Chapter4.goal_4_2  -- manuscript 4.2
#check PaperBlueprint.Chapter4.goal_4_3  -- manuscript 4.3
#check PaperBlueprint.Chapter4.goal_4_4  -- manuscript 4.4
#check PaperBlueprint.Chapter4.goal_4_5  -- manuscript 4.5
#check PaperBlueprint.Chapter4.goal_4_6  -- manuscript 4.6
#check PaperBlueprint.Chapter4.goal_4_7  -- manuscript 4.7
#check PaperBlueprint.Chapter4.goal_4_8  -- manuscript 4.8
#check PaperBlueprint.Chapter5.goal_5_1  -- manuscript 5.1
#check PaperBlueprint.Chapter5.goal_5_2  -- manuscript 5.2
#check PaperBlueprint.Chapter5.goal_5_3  -- manuscript 5.3
#check PaperBlueprint.Chapter5.goal_5_4  -- manuscript 5.4
#check PaperBlueprint.Chapter5.goal_5_6  -- manuscript 5.6
#check PaperBlueprint.Chapter5.goal_5_7  -- manuscript 5.7
#check PaperBlueprint.Chapter6.goal_6_1  -- manuscript 6.1
#check PaperBlueprint.Chapter6.goal_6_2  -- manuscript 6.2
#check PaperBlueprint.Chapter6.goal_6_3  -- manuscript 6.3
#check PaperBlueprint.Chapter6.goal_6_4  -- manuscript 6.4
#check PaperBlueprint.Chapter6.goal_6_5  -- manuscript 6.5
#check PaperBlueprint.Chapter6.goal_6_6  -- manuscript 6.6
#check PaperBlueprint.Chapter6.goal_6_7  -- manuscript 6.7
#check PaperBlueprint.Chapter6.goal_6_8  -- manuscript 6.8
#check PaperBlueprint.Chapter6.goal_6_9  -- manuscript 6.9
#check PaperBlueprint.Chapter6.goal_6_10  -- manuscript 6.10
#check PaperBlueprint.Chapter6.goal_6_11  -- manuscript 6.11
#check PaperBlueprint.Chapter6.goal_6_12  -- manuscript 6.12
#check PaperBlueprint.Chapter6.goal_6_13  -- manuscript 6.13
#check PaperBlueprint.Chapter6.goal_6_14  -- manuscript 6.14
#check PaperBlueprint.Chapter6.goal_6_15  -- manuscript 6.15
#check PaperBlueprint.Chapter6.goal_6_16  -- manuscript 6.16
#check PaperBlueprint.Chapter6.goal_6_17  -- manuscript 6.17
#check PaperBlueprint.Chapter6.goal_6_18  -- manuscript 6.18

#check PaperChronology.Batch0470.pole_spectral_zero_transfer
#check PaperChronology.Batch0470.offdiagonal_moment_positive
#check PaperChronology.Batch0470.two_pole_has_both_signs
