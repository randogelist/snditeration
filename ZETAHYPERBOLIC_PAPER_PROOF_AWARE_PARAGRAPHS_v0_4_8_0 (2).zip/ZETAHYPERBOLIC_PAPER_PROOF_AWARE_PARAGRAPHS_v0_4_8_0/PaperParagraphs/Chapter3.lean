import PaperParagraphs.Types

/-!
# Paper source unit index: Chapter3

External layout extraction indexed 76 paragraph-like source units and
219 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.Chapter3

/-- Source segmentation data; theorem numbers are cross-reference labels only. -/
def units : List PaperParagraphs.SourceUnit := [
  ⟨44, 7, 2, 1, 3, "", "3. Hyperbolicity, Total Positivity, and Spectral Structure", "e90d0b65fcd95b1b7353f02d01d297e045362ec2fb75836999a82a03d6013fd1"⟩,
  ⟨45, 7, 3, 15, 3, "", "We now connect the algebraic factorization of Section 2 with the archimedean integral rep- resentation at X = (s). For an odd integer ", "c55e3f95a8ccd45277c699d46136b1ee131faa47d39707cf49f0eb823c256010"⟩,
  ⟨46, 7, 18, 2, 3, "", "which matches (s) X (te) in (2.2) by Euler s formula (2e+2) = ( 1)eB2e+2(2 )2e+2/(2(2e+2)!). For simple poles, writing y2k+1", "e262be46f01aca84b7101c7fd61b221de8c30361f19b1a807062dbb2daa72674"⟩,
  ⟨47, 7, 20, 7, 3, "", "y2+j2 , the polynomial part has degree 2k 1 < 2k and vanishes after 2k differentiations. Integrating by parts 2k times on 0 ws(y) y2+j", "16e9213506ad2a6da78160aeee299dbe9806174173f54370bfe6f05c81e25618"⟩,
  ⟨48, 7, 27, 4, 3, "3.1", "Theorem 3.1 (Universal hyperbolicity and zero-free disk). For every odd integer s = 2k+1 3, every K > N 1 (h = K N), and every m 1, th", "5b7957530b7336ad1e709501b27d9ca025a059091019cee63e4480faf919225f"⟩,
  ⟨49, 7, 31, 6, 3, "3.1", "Proof. For any non-zero vector v = (v0, . . . , vh 1)T Ch\\{0}, the polynomial q(t) := h 1 i=0 viti", "4116f7892ee71c2387ab02f74e406cdc03b96ad5511b1a3993267a8dec76301e"⟩,
  ⟨50, 7, 37, 1, 3, "3.1", "so G is real symmetric and strictly positive definite. By Theorem 2.5, MK = V diag( (s) a )V T . Since the nodes va = a2 (N < a K) are", "33bbe75c5bff11d211c3c2e1a59194c94c0481fcd452189d8cdb13886dab0d84"⟩,
  ⟨51, 8, 1, 3, 3, "3.1", "[Xh] (s) K (X) = det MK = ( 1)h(h 1)/2 K", "cb2bd993da6bd47efeb940daf2b1cd53fba056a018eea2f93b83bac077bfe18f"⟩,
  ⟨52, 8, 4, 3, 3, "3.1", "so (s) K (X) has exact degree h. Write G(s) K (X) = G + (X )MK. If X C is a root of det G(s) K (X) = 0, there exists v Ch \\ {0} such t", "ae0f7bffdc60755fb223083a91555e365504199669d6b5ab8e9503c6f75916cb"⟩,
  ⟨53, 8, 7, 1, 3, "3.1", "Factoring G(s) K (X) = G1/2(I + (X )B(s) K )G1/2 shows that B(s) K is real symmetric with det B(s) K = (det G) 1 det MK = 0, so its ei", "58c12ebd3a3d8995e142334ea591e7b85806d9f2e0738b389e845da30510b120"⟩,
  ⟨54, 8, 8, 1, 3, "3.1", "Notice that the proof of Theorem 3.1 relies only on the positive definiteness of G(s) K ( ) and the symmetry and non-singularity of M(", "6ffce851e3b27c444fd8a7f5fcb203c100cbc54c36db71ac0c0fd8b96c091e0f"⟩,
  ⟨55, 8, 9, 10, 3, "3.2", "Proposition 3.2 (Continuous hyperbolic pencil for all real s > 1). For any real number s > 1, define the positive weight ws(y) := (2 )", "ce9787ed11c32a30046815226d068db367de94dc9788b477fc9a82972b2e12fd"⟩,
  ⟨56, 8, 19, 1, 3, "3.2", "Then for every real s > 1, G(s) K (X) coincides at odd integers s = 2k + 1 with (2.8), and (s) K (X) := det G(s) K (X) is a polynomial", "14887b4ec6ef8eb9911ec03bcc31a7a510572d12594fec842b970b0bb17f6198"⟩,
  ⟨57, 8, 20, 1, 3, "3.2", "Proof. For every real s > 1, ws(y) > 0 on (0, ) implies that A(s) is real symmetric positive definite, while as 1 > 0 implies that M(s", "f067ddb231ce18c9abf35a2361ecdffa830e319ec82f8c0f1c6595265c7782cc"⟩,
  ⟨58, 8, 21, 1, 3, "3.2", "We next establish strict total positivity of the moment matrix, the sign parity of the leading coefficient, and the exact bilateral si", "8784d3221b9ce11474e9d786fd9368e6059ec7b68564281acd5408f4aca03249"⟩,
  ⟨59, 8, 22, 5, 3, "3.3", "Theorem 3.3 (Total positivity, leading sign, and universal signature). Fix K > N 1 (h = K N), m 1, and an odd integer s = 2k + 1 3.", "271e3a2d61eb1c8400889fd27961ebbc415385e555da187dd3b4d6616dfe4f7d"⟩,
  ⟨60, 8, 27, 1, 3, "3.3", "is a determinate Stieltjes moment sequence on [0, ), and G(s) K ( (s)) is strictly totally positive of all orders: every r r minor det", "2bb4a571b0ab812fa930134286824c4f2a12eddf4d5ddc44029e82c831ab1814"⟩,
  ⟨61, 9, 1, 2, 3, "3.3", "(3) For every odd s 3 and 2m 2, the matrix B(s) K has signature ( h/2 , h/2 ) if N is even, and ( h/2 , h/2 ) if N is odd and h is odd", "128366ed96a72106bb1d2fe5ba58953ca63829af7271d4267ffc7227a49f2f16"⟩,
  ⟨62, 9, 3, 1, 3, "3.3", "Proof. (1) Since DN(t)2m/DK(t) CK for t 1 and ws(y) Csyse 2 y, we have (s) r C K,s 0 y2r+se 2 y dy = C K,s (2r+s)! (2 )2r+s+1 . By Sti", "ca21f401b7d68847a889ebe360527f97574af8d2cd39779193dc59b2d940f899"⟩,
  ⟨63, 9, 4, 6, 3, "3.3", "c > 0, so r=1( (s) r ) 1/(2r) = , which proves Stieltjes determinacy by Carleman s criterion. For any I = {i1 < < ir} and J = {j1 < < ", "67247e02baa43718b043b6526e34d0fc0e54065fa051b85eeb9242eb774f6b5c"⟩,
  ⟨64, 9, 10, 11, 3, "3.3", "because the monomials {ti}i 0 form a strictly totally positive Chebyshev system on (0, ). (2) By (3.4) with k = 2 and 2m 1 = 5, every ", "254f3ddce4b4bd23deaa1e8b5f53e4d7a5f3780eef278cf670e4843cff219dd4"⟩,
  ⟨65, 9, 21, 1, 3, "3.3", "(3) By Theorem 2.5(2) and Sylvester s law of inertia, B(s) K = (G 1/2V ) diag( (s) a )(G 1/2V )T", "4ed205c4f8dd2cd1b452a10cf08ae5d2c1301ed8f37bd38aab09fdac50d3ea43"⟩,
  ⟨66, 9, 22, 2, 3, "3.3", "has the same signature as diag( (s) a )N<a K. In (2.11), the numerator has sign ( 1)(2m 1)N, while the denominator b =a(b2 a2) has a N", "580287b2b5bead385eb7b8252859189a8aad09c761e96efa05208bff87c73bd5"⟩,
  ⟨67, 9, 24, 3, 3, "3.3", "independent of s and m. For N = 3n and h = 27n: if n is even, h is even and there are h 2 = h/2 = h/2 positive and negative signs; if ", "912146b7e30e52e18213adbf991fc6d9270cdab3bcda9d356ab110b2f3555dc5"⟩,
  ⟨68, 9, 27, 2, 3, "3.4", "Theorem 3.4 (Root interlacing and Dodgson condensation for principal minors). Fix K > N 1, and for 1 r h = K N, let (s) K,r(X) := det ", "0a69c545345b6eef009dd3a3b325a3b9180f6020aec4ce5b279c2e12b683040b"⟩,
  ⟨69, 9, 29, 1, 3, "3.4", "(1) The eigenvalues of B(s) K,r and B(s) K,r+1 satisfy Cauchy s interlacing inequalities (r+1) 1", "886ac70e3ea30cac0bf213a2b02dd5b5f7046e9027a133f0bfc0042da80f1479"⟩,
  ⟨70, 9, 30, 1, 3, "3.4", "(r) 1 (r+1) 2 (r) r (r+1) r+1 . Consequently, the roots of (s) K,r(X) and", "0d60a779c13a2d1bf583412e5772294dec0ad029c87dc314b66ea7dadf1dbb37"⟩,
  ⟨71, 9, 31, 1, 3, "3.4", "(s) K,r+1(X) interlace on ( , (s)) and on ( (s), + ), and min1 j r |r(r) j (s)| is non-increasing in r. (2) For every 2 r h and every ", "0b2c1d9756193d3952bfeab001e2747694bbd86845fb7e86f55414f0dc7d9d29"⟩,
  ⟨72, 9, 32, 1, 3, "3.4", "(s) K,r ( r(r 1) j ) (s) K,r 2 ( r(r 1) j ) = ( (s) K,r 1 ( r(r 1) j ) ) 2 0, (3.5)", "6d020517c9e840ee68ac0f12e5eebc06287a0b723294438761130458583f7486"⟩,
  ⟨73, 9, 33, 1, 3, "3.4", "where (s) K,0 := 1 and (s) K,r 1(X) is the (r 1) (r 1) minor of G(s) K,r(X) obtained by deleting row r 1 and column r 2.", "bd787c6543c75295738276a30fce3d10caebde041e627a6469f5cd3d180d95d9"⟩,
  ⟨74, 10, 1, 1, 3, "3.4", "Proof. (1) Let G = LLT be the lower-triangular Cholesky decomposition of G(s) K ( ). Its leading r r block Lr satisfies Gr = LrLT r , ", "eace454e45bdc6b40f73696b04a7718e48db14a0d3c27d5c2b8e300dbd4b6efa"⟩,
  ⟨75, 10, 2, 1, 3, "3.4", "(0, ) yields root interlacing and monotonicity of minj |r(r) j |. (2) By Dodgson s condensation identity (Jacobi s identity for determ", "fb0bc428be08bdee55d8403582e55b96a0931e5145299711166993d2cc2f030d"⟩,
  ⟨76, 10, 3, 1, 3, "3.4", "have (s) K,r(X) (s) K,r 2(X) = (s) K,r 1(X) (s) K,r 1(X) ( (s) K,r 1(X) ) 2. Evaluating at X = r(r 1) j where (s) K,r 1(r(r 1) j ) = 0", "2f49ece75eb08ade62f4f88dbaa598fd3fbcf834f14e664e84b02f086373bdc4"⟩,
  ⟨77, 10, 4, 1, 3, "3.5", "Corollary 3.5 (Stieltjes J-fraction from interlacing roots). Fix K > N 1 and X = (s). Let G := G(s) K ( (s)) = LLT be the lower-triang", "3069d70bffcaa40b95fa876cb1830a023975e7cb6d32d49b07f640a6cdf1521a"⟩,
  ⟨78, 10, 5, 9, 3, "3.5", "(1) For every X R with P (s) K (X) = 0, the ratio of consecutive principal-minor polynomials admits the exact finite Stieltjes continu", "74ea6c0cfa1c75f36ae3def50b809d75c7ca2685a8d084ad0a777f1af9738bff"⟩,
  ⟨79, 10, 14, 1, 3, "3.5", "the Bernoulli monomial moments (s) X (te), with no occurrence of (s) in its definition), while the closest root rmin = (s) 1 max satis", "346aef464d80ce7b5f495f72378052b07a8b9e8424dee8551d069154bbad92c5"⟩,
  ⟨80, 10, 15, 1, 3, "3.5", "(Theorem 4.7), so the spectral edge of the J-fraction converges to (s) at exponential rate.", "bb4a780fb213642fabb7feebfa5e06b9debac0f74c6eed8a40d0c0421fefff1b"⟩,
  ⟨81, 10, 16, 1, 3, "3.5", "Proof. (1) Since Gh = LhLT h with Lh lower-triangular, the principal submatrix identity Gr = LrLT r holds for every 1 r h. Thus Br := ", "0ab6c83b579bc1425d1cf177cecff36a5c62dfa63f23a81fc04c0ce7f23ba072"⟩,
  ⟨82, 10, 17, 1, 3, "3.5", "Lanczos algorithm applied to Bh with starting vector eh produces an orthogonal Q Oh(R) with QT eh = eh such that Th := QT BhQ is symme", "e02d1e09ad2f8a95a61f0be3d3bbcfb82d04813f27348b7875cb697fb6f65d89"⟩,
  ⟨83, 11, 1, 2, 3, "3.5", "(2) At X = 0, (s) K,r(0) = det G(s) K (0) involves only the monomial moments (s) 0 (te) =", "97eb6057d8a58b7b5e469860923c24cac57f9f2318ff232c87d92357fe812347"⟩,
  ⟨84, 11, 3, 2, 3, "3.5", "(2k)!(2e+2)! Q (Definition 2.1), so the ratio is rational. The spectral edge | max| 1", "5b816674b33c604750e3838a5d1a3873b5cf6f32bd628f7beade343dc7587cd6"⟩,
  ⟨85, 11, 5, 7, 3, "3.6", "Corollary 3.6 (Stieltjes reciprocal-root power sums). For any fixed K and any rational shift q0 Q with P (s) K (q0) = 0, define the ra", "1db7a952eaa4d8c9106933a0c017a27576c59e66119d067628822694d06fd594"⟩,
  ⟨86, 11, 12, 1, 3, "3.6", "Then {S2r(q0)}r 0 (S0(q0) := h) is a positive Stieltjes moment sequence with strictly positive Hankel determinants, and at each fixed ", "fe76b29784640ebfe4bec719076cea3a3b2198cbd0c5012bad3af4bf45e87a6e"⟩,
  ⟨87, 11, 13, 1, 3, "3.6", "min1 j h |rK,j q0| converges with factor 1 ( S2r(q0) ) 1/(2r)/dmin(K) h1/(2r) for all r 1.", "cdf9bc02d8a481ed7cb8e4ef8580caaaecdffcf531c705ad8bf339fcdf875b77"⟩,
  ⟨88, 11, 14, 1, 3, "3.6", "Proof. Since rK,1, . . . , rK,h R by Theorem 3.1, the squares uj := (rK,j q0) 2 > 0 are positive real numbers, so S2r(q0) = h j=1 ur j", "ddd7796d84716cfddbb30c4d9de0427566999bdb02262daa437c7ed306b8de63"⟩,
  ⟨89, 11, 15, 1, 3, "3.6", "The bilateral root split of Theorem 3.3(3) also implies Newton log-concavity of the co- efficients of P (s) K (X), with strict inequal", "6745ec0fa2f9bb291e1e292f8093e44d1d42d62029f57a133cfcae5c3b2bb993"⟩,
  ⟨90, 11, 16, 5, 3, "3.7", "Theorem 3.7 (Tur anian non-negativity and Newton log-concavity). Fix any odd integer s = 2k + 1 3 and integers K > N 1 with h = K N 2 ", "f71dcbb509cf75d233c858e6b0275a4a828a5f1b2472ebe8da24dd2b7f229c45"⟩,
  ⟨91, 11, 21, 6, 3, "3.7", "with strict inequality Tm(X) > 0 at every X R where dm 1 dXm 1 P (s) K (X) = 0. In partic-", "bd35d99c5411398dd03832878d7705634888e090496289081b8cbeeca084c8a7"⟩,
  ⟨92, 11, 27, 3, 3, "3.7", "(2) Newton s log-concavity a2 K,m aK,m 1 aK,m+1 holds for every 1 m h 1. Strict inequality a2 K,m > aK,m 1 aK,m+1 holds if and only if", "024c7139a89a6176e0419c92a09e7c056f38637167bed2999fe35fcb0e5b79a9"⟩,
  ⟨93, 11, 30, 1, 3, "3.7", "(s), and set em := em( 1, . . . , h)/ ( h m ) (with e0 := 1). Then e2 m em 1 em+1 for every 1 m h 1, with strict inequality whenever e", "800664ad6032267fa038195ca29136e647544a595488d20051be1a3c3ebb75f1"⟩,
  ⟨94, 11, 31, 1, 3, "3.7", "eigenvalues of B(s) K and, being a Hankel spectrum, are generically distinct, so em = 0 for all 1 m h 1 and the strict inequality e2 m", "e13b972a96decd73dbce81d8fd72673b5679d2f99d7b26c132bbe0607c417695"⟩,
  ⟨95, 12, 1, 1, 3, "3.7", "Proof. (1) By Theorem 3.1 and Rolle s theorem, for every 1 m h 1 the derivative Qm 1(X) := dm 1 dXm 1 P (s) K (X) has h m + 1 real roo", "49192abe6d731ef407aded4e6d7a198c85ec8add60c4b6f2da6450d2c483147e"⟩,
  ⟨96, 12, 2, 8, 3, "3.7", "Qm 1(X) = 0, differentiating the logarithmic derivative Q m 1(X) Qm 1(X) = h m+1 j=1 1 X j gives", "eaae9a80088d418cdd8445e14a7eaa93ade9ad73fdea7a5560ae64314c1bf16f"⟩,
  ⟨97, 12, 10, 1, 3, "3.7", "and by continuity Tm(X) 0 for all X R. At X = (s), since h 2 and j = ( (s) rj) 1", "02cecd265368896f8d76352dc2c85008c3e8d83b166f01197edbd06140adbf19"⟩,
  ⟨98, 12, 11, 6, 3, "3.7", "takes both positive and negative values by Theorem 3.3(3), the j are not all equal; Cauchy", "613d7e952d02774f70fd38575b10dde9eea5fc5d1ad88b74109f568257a46054"⟩,
  ⟨99, 12, 17, 1, 3, "3.7", "(2) Write P (s) K (X) = aK,h h j=1(X rj) with all roots rj R. Let k0 0 denote the multiplicity of X = 0 as a root (so aK,0 = = aK,k0 1", "64adfd1e257629fe1988747947571cf20df8f8e0769bdb587b59d2a30c51300a"⟩,
  ⟨100, 12, 18, 1, 3, "3.7", "If aK,m 1 aK,m+1 < 0: since a2 K,m 0 > aK,m 1 aK,m+1, strict inequality holds. If aK,m 1 aK,m+1 > 0: by Newton Maclaurin s strict ineq", "ee611b548e242b0fb1578b3eaaa1e7bdb099e7380acb20ad551a6017fdd20c5b"⟩,
  ⟨101, 12, 19, 3, 3, "3.7", "Combining, strict inequality holds iff aK,m 1 aK,m+1 = 0 or aK,m = 0, matching the statement.", "d6750e1f5211123cac735d3cd0b755f08c9dd8ddc16a680473d2b17cbba4dc8f"⟩,
  ⟨102, 12, 22, 1, 3, "3.7", "non-zero real roots yj = 1 j R \\ {0}, which are not all equal since j takes both signs by Theorem 3.3(3). Applying the same Newton Mac", "e8edb23da1276fdd9145f9892d08d273e42003dc84be8235be9956d9592b1251"⟩,
  ⟨103, 12, 23, 6, 3, "3.8", "Theorem 3.8 (Christoffel Darboux pole representation and Jacobi derivative identity). Let { r(t)}h 1 r=0 be the monic orthogonal polyn", "d96698d8b836f697b04f67dd13c34b9b7ae1e20a030cad6eb2cd681dda1168a6"⟩,
  ⟨104, 12, 29, 3, 3, "3.8", "r(t) r(u) 0 r(v)2 d (v) = (1, t, . . . , th 1)G(s) K ( ) 1(1, u, . . . , uh 1)T", "8bc2517779029bdc2597028b5926b90e0b15004f842055c41cfb1df33f0bb69f"⟩,
  ⟨105, 12, 32, 3, 3, "3.8", "(1) The non-zero eigenvalues 1, . . . , h of B(s) K coincide with the eigenvalues of the h h pole-kernel matrix [ (s) a Kh( a2, b2) ]", "34718c012a09deaba3c44a7ca34f3eb3329f0c93133cc964db04e583df92090e"⟩,
  ⟨106, 12, 35, 1, 3, "3.8", "(2k)! y2k+1 l=1 l2ke 2 l y ( > 0) applied to the weight, with the evaluation point = (s) held fixed, the deformed determinant", "ebf6fb7ffde29a10ea70ed94271c079c01f3d0486098d306511fdefbe8e6a86e"⟩,
  ⟨107, 13, 1, 6, 3, "3.8", "where the partial derivative / is taken with X = fixed.", "5b972a35dc9b2f4c8c1acf43ca9337a1cfe1c312b4ea1631924f9c8c67db212d"⟩,
  ⟨108, 13, 7, 6, 3, "3.8", "Proof. (1) Since MK = V diag( (s) a )V T where the a-th column of V is v(a) = (1, a2, . . . , ( a2)h 1)T , the matrix B(s) K = G 1/2V ", "1c31c7b4385cad1f983a6b5c0d36754c6f04284ba76f43af6e925e096fcf43ad"⟩,
  ⟨109, 13, 13, 2, 3, "3.8", "once is fixed). Summing h 1 i,j=0(G 1 K )j,iy2iy2j = Kh(y2, y2; ) yields (3.8).", "09d03c83af6d0e1f1418af1f843d0f901c77e764e25ea2124516a5f5000bec7e"⟩,
  ⟨110, 13, 15, 9, 3, "3.9", "Theorem 3.9 (Hyperbolicity for Hurwitz and Dirichlet Hankel determinants). (1) Let (0, 1] Q and s = 2k + 1 3. Set Dm, (t) := m 1 j=0 (", "8f0ecd40932b23f4bd51ba622a904d7db5ee08f9ddd0fccfda26516a9e0af65f"⟩,
  ⟨111, 13, 24, 5, 3, "3.9", "0 i,j<h has exact degree h and all its roots are real. (2) Let (mod q) be a primitive real Dirichlet character of conductor q {3, 4, 5", "290d7b11b9b1074ffb50d1602a4095a4f4c0e8e07d46eb5348f06e5c00a84ffc"⟩,
  ⟨112, 13, 29, 1, 3, "3.9", "Proof. (1) Since ws(y) > 0 and DN, (y2)2m/DK, (y2) > 0 on (0, ), the matrix G(s) K, ( (s, ))", "646d177f50d3f127145af419143c9a178dcb7032c78367470cb422fbc508314e"⟩,
  ⟨113, 13, 30, 1, 3, "3.9", "is real symmetric positive definite. The X-derivative matrix is M(s) K, = V diag( j, )V T , where V = (( (j + )2)i)0 i<h,N j<K is a Va", "25e68a41a7ea1c02c226867f3f84b6ed1c6e1d768b18e41ced770bbcb0921209"⟩,
  ⟨114, 13, 31, 4, 3, "3.9", "1 zq , where F (z) := q 1 a=1 (a)za. For q {3, 4, 5, 8}, F (z) factors explicitly as", "ed4fe09e8db0aad3c6f2d8b48951cbe6bea1b8d76b75940932d0a64efc991741"⟩,
  ⟨115, 14, 1, 1, 3, "3.9", "For every z (0, 1), each factor is strictly positive, so g (y) > 0 and s, (y) > 0 for all y > 0. Consequently, at X = , the matrix G(s", "84b329c7d12603290ee83e8cfbe3c0b7b1dda2cf33e675120dfb227e0f1d76e5"⟩,
  ⟨116, 14, 2, 2, 3, "3.9", "Moreover, because the poles of Dtail, (t) = K 1 r=N (t + j2 r) are simple and located at the h distinct negative squares vr = j2 r, th", "4fc5fd007e2d94675cb0b08658b8eca309df1a633528cd1049f3a774e00c54fe"⟩,
  ⟨117, 14, 4, 1, 3, "3.10", "Remark 3.10 (Non-classicality of the Hankel family). The primitive Hankel polynomials {P (s) K (X)}K>N are not a specialization of any", "995227135b610254d5740beb4868236b6b94824326da014e9086f7f1748b55bd"⟩,
  ⟨118, 14, 5, 1, 3, "3.10", "the principal-minor polynomials (s) K,r(X) satisfy minj |r(r) j (s)| = ( maxj | (r) j | ) 1, which is non-increasing in r: new roots a", "941d2699440216767b4337b2162ae4f33b3e918732d625eb46bd1113dbfda6d6"⟩,
  ⟨119, 14, 6, 1, 3, "3.10", "characteristic polynomials of the principal submatrices Br of Bh. These form an orthogonal polynomial family with respect to a positiv", "1184241dbaaf635a79ea4c7bdbe83d1bc3afc63486a2040cb830a7339973a680"⟩
]

/-- The inventory size is a kernel-checked fact about the embedded Lean data. -/
theorem unit_count : units.length = 76 := by decide

/-- The original PDF body-block count is checked against the displayed ranges. -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 219 := by decide

end PaperParagraphs.Chapter3
#print axioms PaperParagraphs.Chapter3.unit_count
#print axioms PaperParagraphs.Chapter3.block_count
