import PaperParagraphs.Types

/-!
# Paper source unit index: Chapter2

External layout extraction indexed 34 paragraph-like source units and
106 original PDF body blocks in this partition. Source snippets are
previews, not complete mathematical definitions. Every source unit's full text
and block range appear in the accompanying CSV.
-/
namespace PaperParagraphs.Chapter2

/-- Source segmentation data; theorem numbers are cross-reference labels only. -/
def units : List PaperParagraphs.SourceUnit := [
  ⟨10, 3, 2, 1, 2, "", "2. Algebraic Structure and Canonical Basis Invariance", "26d7708af2911c2455954508549c4421396a11ad848b7b2bcd35e3a6b80f2eaf"⟩,
  ⟨11, 3, 3, 4, 2, "", "Let K > N 1 be integers, set h := K N, and write := N/K and := h/K = 1 . For m 0, define the polynomial", "7bd9d9f8dc3dfe19fdb80778b39f68100e05c41bcf50792f0122ca002584383a"⟩,
  ⟨12, 3, 7, 1, 2, "", "For an integer s 1, let H(s) j := j =1 s (H(s) 0 := 0) denote the j-th harmonic number of weight s, and let (Br)r 0 denote the Bernoul", "d2ccf43d26d51388ef2ae053d573cbb7ea405340ccf91b4fa635b84348dd771f"⟩,
  ⟨13, 3, 8, 1, 2, "2.1", "Definition 2.1 (Order-s rational moment functional). For an odd integer s = 2k + 1 3, let (s) X be the Q-linear functional on the Q-ve", "dc97a9b072ba74fa3cd82199d2a82f84af891ef2b4021aaef23c0c3e48db5308"⟩,
  ⟨14, 4, 1, 12, 2, "2.1", "simple poles among { j2 : j 1}, defined on monomials te (e 0) by", "14959a89b1d7271a44fe1289e16c8717dbb7aeac989833f4744c0a9c94a837f6"⟩,
  ⟨15, 4, 13, 2, 2, "2.1", "extended to all such rational functions by polynomial division and partial fraction decomposi- tion.", "53064402ce3d850979b66cf64f8512efa9ff46a22efa25e6b6e83243b66094f4"⟩,
  ⟨16, 4, 15, 5, 2, "2.1", "In particular, for s = 3 (k = 1), s = 5 (k = 2), and s = 7 (k = 3), the pole values are (3) X ((t + j2) 1) = j2(X H(3) j ) + 1 2j 1", "b60828094aae0a9b95abe7c2b9702e5b71cffeae3b9d6657dc2176f7a5126189"⟩,
  ⟨17, 4, 20, 1, 2, "2.1", "To connect (s) X with p-adic analysis, we record its pullback representation in terms of a one-variable auxiliary functional (s) X on ", "d22fbc3a2bdb1c8224104e017d44f05c5691085e0cfbfcc27593f4a8e8b3bc34"⟩,
  ⟨18, 4, 21, 6, 2, "2.2", "Lemma 2.2 (Pullback identity). For an odd integer s = 2k + 1 3, let (s) X be the Q-linear functional on rational functions of x with s", "e7f426e29d57b9562fe9b767d7f74bc3dd9f1db67954eaaf3fee930f38ea4ee1"⟩,
  ⟨19, 4, 27, 3, 2, "2.2", "and on simple poles by (s) X ((x r) 1) := H(s) d(r) X (r Z). Then for every rational function", "6af10a1e002e6c222bdb1b93974edefd3d5aa495b1dccc4473f3e65a5baea81a"⟩,
  ⟨20, 4, 30, 1, 2, "2.2", "Proof. By Q-linearity, it suffices to verify (2.5) for R(t) = te (e 0) and R(t) = (t + j2) 1", "ffce7fa61c0abcf5ef893e60d060f1765db963417fc0527545c5cd0989543bb2"⟩,
  ⟨21, 4, 31, 12, 2, "2.2", "(j 1). For R(t) = te, we have x2k+1R( x2) = ( 1)ex2e+2k+1. Since d = 2e+2k+1 2k+1, (2.4) gives", "e2888507503476bfac3287170972fcc0b23abecbff067abf294a4af9010744ee"⟩,
  ⟨22, 4, 43, 9, 2, "2.2", "In the polynomial sum, the r = 1 term is x2k 1, while all terms with 2 r k have degree 2k + 1 2r 2k 3 < 2k 1 and map to zero under (s)", "9e7158398d09f880c06694d9480baeed53c06fbd05cf3ea980d91fea8651a703"⟩,
  ⟨23, 5, 1, 1, 2, "2.3", "Lemma 2.3 (Reflection and difference identities for (s) X ). The functional (s) X defined in Lemma 2.2 satisfies:", "5c5e1883b1b6df32bed2801ee2ce97ec9cac590ee5cc7f9e83b92d70508d13aa"⟩,
  ⟨24, 5, 2, 5, 2, "2.3", "(1) (Reflection identity) For every rational function g(x) in the Q-span of monomials {xd : d 0} and simple poles {(x r) 1 : r Z},", "f97982f20d896a4373ea20429920acd86ab30296ea62688d5ec84b8bd3e32500"⟩,
  ⟨25, 5, 7, 1, 2, "2.3", "By Q-linearity of (s) X , both identities extend to all rational functions in the Q-span of the stated basis elements.", "977fb64594aef0c12864d799c280dde8eff08183c7bf5a593887f346b09ad976"⟩,
  ⟨26, 5, 8, 1, 2, "2.3", "Proof. (1) Reflection. Since (s) X is Q-linear, it suffices to verify (2.6) on monomials xd and simple poles (x r) 1.", "03957c15b438b44ea0e7e853d812dcd903549f53d9159f99862eda78377e7f7e"⟩,
  ⟨27, 5, 9, 1, 2, "2.3", "For xd with 0 d < 2k 1: both (s) X (xd) = 0 and (s) X (( 1 x)d) = 0 (since deg(( 1 x)d) = d < 2k 1), so both sides vanish. For xd with", "4d7fe55f1388ab10bc9e7555cae5241a3b6673df400a630aec142b863c6e5489"⟩,
  ⟨28, 5, 10, 1, 2, "2.3", "(s) X ( (1 + x)d) = (s) X (xd) (the B1 = 1/2 contribution at i = 2k cancels between the", "776920e4280c191a02250665c3dacd8062147146300421d59863a3861bb6be7b"⟩,
  ⟨29, 5, 11, 2, 2, "2.3", "(1 + x)d and xd expansions). Hence (s) X ( ( 1 x)d) = ( 1)d (s) X (xd). Since s = 2k + 1 is odd, only odd d 2k 1 contribute (all Berno", "3595f0ae8533b850257cfe6eed5a732896b0e61e762a5829d57653374c65f20f"⟩,
  ⟨30, 5, 13, 7, 2, "2.3", "(2) Difference. For h(x) = (x r) 1 with r 2: h(x+1) = (x (r 1)) 1, so h(x+1) h(x) = (x (r 1)) 1 (x r) 1, and (s) X (h(x + 1) h(x)) = (", "6aa796e29d5c07edbce72e50c8a5c2e6603b5bbadc6a8a8e3c83a660fdaa5d9a"⟩,
  ⟨31, 5, 20, 3, 2, "2.3", "For any non-zero polynomial A(X) Q[X], let contQ(A) > 0 denote its rational content (the unique positive rational number such that A(X", "59839ab97aa21ec377ca0aa8f84282850145831341fae077dbeba90638a8f9e8"⟩,
  ⟨32, 6, 1, 6, 2, "2.4", "Theorem 2.4 (Canonical basis invariance). Let X be any Q[X]-valued linear functional on ra- tional functions of t, and fix W(t) = DN(t", "fdd2e89b7a0e54b279050ff727af5c2559c94a84eb0725bf695a4cab66588fd0"⟩,
  ⟨33, 6, 7, 1, 2, "2.4", "If K(X) = det GK(X) = 0, then the primitive integer polynomial PA,B(X) := A,B(X)/ contQ( A,B) Z[X] satisfies PA,B(X) = PK(X).", "ceb84335c0649146b3bf4c2bd5b0269fc841b52f24230e5fd595621daf280f07"⟩,
  ⟨34, 6, 8, 1, 2, "2.4", "Proof. Let MA, MB GLh(Q) be the invertible change-of-basis matrices satisfying Ai(t) = h 1 r=0(MA)i,rtr and Bj(t) = h 1 s=0(MB)j,sts f", "66caf1e0868caff51c9147741a6539dbde699a27e228518298498cd3e0993bd0"⟩,
  ⟨35, 6, 9, 1, 2, "2.4", "Theorem 2.4 implies that no change of polynomial basis in Q[t]<h (such as passing to Pochhammer, Jacobi, or Cauchy-type rational bases", "208ad05e9a244e751d558b9bf456b93a87453c183bc30501721ef80343c11166"⟩,
  ⟨36, 6, 10, 5, 2, "2.5", "Theorem 2.5 (Lagrange pole diagonalization). Set Dtail(t) := DK(t)/DN(t) = K c=N+1(t + c2), and let V := (vi a)0 i<h, N<a K be the h h", "c7838433117e038ea416ff679468c86bfcf7706582519d21f1d9f3ab49699ed4"⟩,
  ⟨37, 6, 15, 2, 2, "2.5", "Then the transformed matrix G(s) K (X) := V 1G(s) K (X)(V T ) 1 = [ (s) X (DN(t)2mLa(t)Lb(t)/DK(t)) ]", "d94e1b901201e1b665df2b08cc8bf275b3918ddb3391a8493202be8c5fda0984"⟩,
  ⟨38, 6, 17, 3, 2, "2.5", "(1) For all a = b, G(s) K (X)a,b Q is a constant rational number independent of X. (2) For a = b, G(s) K (X)a,a = (s) a (X H(s) a ) + ", "39017ab5240292258fbf8afd6c6b9d946db72750d99725455bbe18f51a86e79d"⟩,
  ⟨39, 6, 20, 1, 2, "2.5", "In particular, the X-derivative matrix M(s) K := [X]G(s) K (X) admits the exact factorization M(s) K = V diag( (s) a )N<a KV T .", "f095108484e48085789ba1e3e70f5bb18a3c7fbfcd42d4d9603a4b9c51ca6dfd"⟩,
  ⟨40, 6, 21, 3, 2, "2.5", "Proof. Since La(vb) = a,b, we have h 1 i=0 (V 1)a,ivi b = a,b, so the (a, b) entry of G(s) K (X) = V 1G(s) K (X)(V T ) 1 is (s) X (Ra,", "48c7f541a344fb199cea3c1308d47be620af9f99544154a81196cdc89d3f5e7a"⟩,
  ⟨41, 6, 24, 1, 2, "2.5", "(1) When a = b, the product (t + a2)(t + b2) divides Dtail(t) = K c=N+1(t + c2) in Q[t]. Thus", "7a56f3299a1f16899723e978eaa126c16dcab166f25852f9eb0c27d64d0f9253"⟩,
  ⟨42, 6, 25, 1, 2, "2.5", "Ra,b(t) is a polynomial in Q[t], so (s) X (Ra,b) Q is independent of X by (2.2). (2) When a = b, one factor of (t + a2) cancels from D", "14b342ad1e5d9ae00f5b48f40a215c3d5598e62ae7672651aa4d74c8ce4abc19"⟩,
  ⟨43, 7, 1, 1, 2, "2.5", "H(s) a ) + ra with ra Q. Differentiating G(s) K (X) = V 1G(s) K (X)(V T ) 1 with respect to X gives V 1M(s) K (V T ) 1 = diag( (s) a )", "2224ca842a34690db9f66ec12e582c2f25cfd8d7adaf99d5e6f82f7b29b5d0b5"⟩
]

/-- The inventory size is a kernel-checked fact about the embedded Lean data. -/
theorem unit_count : units.length = 34 := by decide

/-- The original PDF body-block count is checked against the displayed ranges. -/
theorem block_count : (units.map (·.bodyBlockCount)).sum = 106 := by decide

end PaperParagraphs.Chapter2
#print axioms PaperParagraphs.Chapter2.unit_count
#print axioms PaperParagraphs.Chapter2.block_count
