import PaperParagraphs.FrontBack
import PaperParagraphs.Chapter2
import PaperParagraphs.Chapter3
import PaperParagraphs.Chapter4
import PaperParagraphs.Chapter5
import PaperParagraphs.Chapter6
import PaperParagraphs.BlueprintAnchors

/-!
# PDF paragraph-integration (source-index) checkpoint

A completed runner can mark the lowest rung: every PDF text-body block is
registered by a paragraph-like grouping, and all 46 substantive mathematical
theorem targets are namechecked. This does NOT mean all 52 pages are
semantically formalized or proved. A coverage row is not a proof term.

The partition itself was computed with an external PDF parser, not within Lean.
Lean verifies the arithmetic totals and that the generated inventories exist.
-/
namespace PaperParagraphs.Checkpoint

/-- A mathematically honest, explicit checkpoint label. -/
inductive CoverageRung where
  | sourceIndexed
  | mathematicalStatementBlueprint
  | verifiedPartialProof
  | fullManuscriptProof
  deriving Repr, DecidableEq

/-- This package reaches source-index completeness only. -/
def attainedRung : CoverageRung := .sourceIndexed

def indexedUnits : Nat :=
  PaperParagraphs.FrontBack.units.length +
  PaperParagraphs.Chapter2.units.length +
  PaperParagraphs.Chapter3.units.length +
  PaperParagraphs.Chapter4.units.length +
  PaperParagraphs.Chapter5.units.length +
  PaperParagraphs.Chapter6.units.length

def indexedBodyBlocks : Nat :=
  (PaperParagraphs.FrontBack.units.map (·.bodyBlockCount)).sum +
  (PaperParagraphs.Chapter2.units.map (·.bodyBlockCount)).sum +
  (PaperParagraphs.Chapter3.units.map (·.bodyBlockCount)).sum +
  (PaperParagraphs.Chapter4.units.map (·.bodyBlockCount)).sum +
  (PaperParagraphs.Chapter5.units.map (·.bodyBlockCount)).sum +
  (PaperParagraphs.Chapter6.units.map (·.bodyBlockCount)).sum

/-- This is a count of inventory data, not theorem proofs. -/
theorem units_accounted : indexedUnits = 485 := by
  simp only [indexedUnits, PaperParagraphs.FrontBack.unit_count,
    PaperParagraphs.Chapter2.unit_count, PaperParagraphs.Chapter3.unit_count,
    PaperParagraphs.Chapter4.unit_count, PaperParagraphs.Chapter5.unit_count,
    PaperParagraphs.Chapter6.unit_count]

/-- Every source body block is represented in the extracted inventory. -/
theorem body_blocks_accounted : indexedBodyBlocks = 1534 := by
  simp only [indexedBodyBlocks, PaperParagraphs.FrontBack.block_count,
    PaperParagraphs.Chapter2.block_count, PaperParagraphs.Chapter3.block_count,
    PaperParagraphs.Chapter4.block_count, PaperParagraphs.Chapter5.block_count,
    PaperParagraphs.Chapter6.block_count]

/-- The theorem blueprints and the paragraph/source registry are different
maturity notions; this flag prevents promoting inventory into a paper proof. -/
def sourceIndexedNotFullProof : Prop :=
  attainedRung = .sourceIndexed

theorem actual_rung : sourceIndexedNotFullProof := rfl

end PaperParagraphs.Checkpoint
#print axioms PaperParagraphs.Checkpoint.units_accounted
#print axioms PaperParagraphs.Checkpoint.body_blocks_accounted
#print axioms PaperParagraphs.Checkpoint.actual_rung
