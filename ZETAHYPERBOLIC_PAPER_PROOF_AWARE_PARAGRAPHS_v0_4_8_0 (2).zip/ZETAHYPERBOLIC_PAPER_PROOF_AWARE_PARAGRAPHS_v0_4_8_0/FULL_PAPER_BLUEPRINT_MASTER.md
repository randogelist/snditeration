# Full-paper Lean blueprint master — v0.4.6.0

Source manuscript: ZETAHYPERBOLIC_PAPER_SECTION_STRUCTURE_v0_4_5_3_RECONCILED/SOURCE_PAPER.pdf, 52 pages.

This package adds **8 Lean modules** after all **119 existing ordered
compilation targets**. The 119 original targets and their source bytes remain
identical to the reconciled v0.4.5.3 archive; it preserves the user's
persistent compiler-verified cache and does not force recompilation.
New targets: `PaperBlueprint.Common`, `Chapter2`, `Chapter3`, `Chapter4`,
`Chapter5`, `Chapter6`, `Register`, `Pipeline`.

## What the run proves and does not prove

The new modules define explicit source-level **goal propositions**, the
per-chapter proof-completion interfaces, and a 51-checkpoint machine-verifiable
chronological registry. The registry proves *only its own counts* using `decide`.
No mathematical full-paper proof is asserted by the registry or the structure
fields. The code neither provides a new arithmetic witness nor asserts a
new p-adic, analytic or infinite-dimensional theorem. Existing proven finite
claims, principal conditional endpoints and exact corrected Stieltjes
finite-rank statement are imported and reexported by proved consequences.

Status at source audit: 3/46 paper items registered complete; 22 partial,
18 open, 3 correction required; 5 additional remarks/conjectures excluded.

## Plan by chronology

| Chapter | Full paper targets | Remaining precise proof cuts |
|---|---:|---|
| 2 | 5 | `RatFunc` semantics + functional uniqueness; the canonical determinant and diagonalization are existing full entries |
| 3 | 9 | real-s integral specialization; continuum all-minor positivity/inertia; corrected 3.4–3.6; full m-Turan, CD Jacobi, actual Hurwitz/Dirichlet moments |
| 4 | 8 | general asymptotic 4.1; resultant 4.2; p-adic 4.3; actual weight-five normalized quadratic-decay and 11.411 norm; mixed linear combination; heights, root collapse, exclusion |
| 5 | 6 | double integral evaluation; infinite Krein/deep polynomial cones; beta(4) integral; proven simple even pair; 5.6 floor integration + tail; double-pole q-adic |
| 6 | 18 | each source theorem has a named STILL UNINSTANTIATED analytic/arithmetic premise, to be replaced by the full typed statement; finite multigrames and pole-block witnesses are a starting point |

## Source corrections (must never be silently reintroduced)

* Thm 3.4: principal truncation may have zero slope eigenvalues/degree drop.
* Cor. 3.5: uncorrected Lanczos expression misnormalizes and assumes cyclicity.
* Cor. 3.6: finite atomic support has a nonzero annihilator; not strictly Hankel-positive for all orders.
* Prop. 3.2: gamma-density odd-integer normalization differs by pi/2; corrected formula is required.

## Independent witness chain

`PaperReconstruction.RawWitness -> PrincipalEndpoint`
 is already proved, but `RawWitness` is NOT yet constructed.
`PaperReconstruction.FullMeasureWitness -> QuantitativeZetaFive`
 is already proved and requires both quadratic decay and sharp norm.
`FullPaperBlueprintChecklist` is an *uninhabited interface checklist* and DOES NOT imply
 the entire PDF is solved simply by successful compilation.

## Run on USER machine

Native Windows Lean 4.33.0 and existing local Mathlib cache only;
one root `run.cmd`; no Lean compilation performed in this environment.
Use `run.cmd full` only on demand to force clean rebuild. Failure reports
`FAILED_MODULE` and prevents the final PASS marker.

## Source-typed additions for Section 6

In addition to 18 individually named theorem interfaces, the Lean project
contains source-exact typed subgoals `source_6_2_adjacent_moment`,
`source_6_2_zeta_six_moment`, `source_6_8_nonzero_cone`, and
`source_6_13_mode_annihilation`; all are explicitly required in the
Chapter 6 record. These are not asserted true.
