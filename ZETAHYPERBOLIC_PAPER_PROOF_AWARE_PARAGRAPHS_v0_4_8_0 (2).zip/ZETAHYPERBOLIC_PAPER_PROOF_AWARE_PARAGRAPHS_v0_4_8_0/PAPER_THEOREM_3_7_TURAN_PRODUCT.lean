import PAPER_COROLLARY_3_6_STIELTJES_SHIFTS_AXIOMS
import PaperChronology.Section3TuranProduct

/-!
# Theorem 3.7 -- first Turanian, full arbitrary real-split degree

This is a genuine finite algebraic extension of the source PDF's Theorem 3.7.
It proves m = 1 at arbitrary polynomial degree by the Turan product rule,
without requiring any irrationality or analytic witness. The all-derivative
and normalized Newton-coefficient claims remain separately open.
-/

#check PaperChronology.Section3TuranProduct.turanPoly_mul
#check PaperChronology.Section3TuranProduct.turan_monic_nonneg
#check PaperChronology.Section3TuranProduct.turan_monic_pos_of_eval_ne_zero
#check PaperChronology.Section3TuranProduct.turan_scaled_nonneg
#check PaperChronology.Section3TuranProduct.turan_scaled_pos
#check PaperChronology.Section3TuranProduct.split_turan_nonneg_and_strict
#check PaperReconstruction.PRINCIPAL_THEOREM
#check PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
