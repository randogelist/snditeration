import PaperChronology.Section3FiniteGram
import PaperChronology.Section3FiniteMomentRank
import PaperChronology.Section3ThreeAtomSharp
import PaperChronology.Section3TuranQuadratic
import PaperChronology.Section4FiniteRootGap
import PaperChronology.Section3ClosedSignature
import PaperChronology.Section5DualArithmetic
import PaperChronology.Section5PrimeSumCertificate
import PaperChronology.Section6PoleBlock
import PaperChronology.T6_18_Principal_minor_2_adic_integrality_law_and_dyadic_height_bounds
import PAPER_UNCONDITIONAL_CHAIN
import PAPER_ODD_WEIGHT_WITNESS
import PaperChronology.Section2Closure
import PaperChronology.Section3Continuous
import PaperChronology.Section3LeadingSign
import PaperChronology.Section3Signature
import PaperChronology.Section3StrictMinor
import PaperChronology.Section3PoleResidue

/-!
# Full-paper chronological entrypoint

All 51 numbered source entries are imported IN PAPER ORDER via the last
PaperChronology module. Each entry either checks an actually proved source
lemma or explicitly declares its precise open/correction status in comments.
Import closure is NOT proof of all PDF claims. In particular source
Proposition 3.2 and Theorem 3.4 / Corollaries 3.5-3.6 require revision.

The strongest unconditional endpoint is generalized odd-weight spectral
hyperbolicity. The general all-odd irrationality criterion takes AllOddWitness. That is
not a proof of simultaneous normalized decay at every weight.
-/

#check ManuscriptChain.PAPER_ALL_ODD_SPECTRAL
#check ManuscriptChain.PAPER_EXACT_DISK
#check PaperReconstruction.AllOddWitness
#check PaperReconstruction.ALL_ODD_IRRATIONAL_FROM_WITNESS
#check PaperChronology.even_pole_pair_generator
#check PaperChronology.even_pole_pair_for_positive_j
#check PaperChronology.LEMMA_2_2_FULL_DECOMPOSED_PULLBACK
#check PaperChronology.LEMMA_2_3_REFLECTION_FULL_FINITE_SPAN
#check PaperChronology.LEMMA_2_3_DIFFERENCE_ALL_ALLOWED_POLES
#check PaperChronology.pullback_simple_pole_value

-- New Section 3 proof frontier, chronological Proposition 3.2 then Theorem 3.3.
#check PaperChronology.Section3Continuous.proposition_3_2_printed_coefficient_at_odd
#check PaperChronology.Section3Continuous.realExponent_partial_sum_pos
#check PaperChronology.Section3Continuous.continuousPencil_degree
#check PaperChronology.Section3Continuous.continuousPencil_roots_real
#check PaperChronology.Section3LeadingSign.D_evaluation_sign
#check PaperChronology.Section3LeadingSign.residue_sign_exponent_cancellation

-- New finite Theorem 3.3 certificates: no full analytic total positivity claim.
#check PaperChronology.Section3Signature.signedRow_even
#check PaperChronology.Section3Signature.signedRow_odd
#check PaperChronology.Section3StrictMinor.two_atom_minor_exact
#check PaperChronology.Section3StrictMinor.two_atom_minor_pos

-- Corrected Corollary 3.6: finite spectral moment measures are PSD, not PD
-- at all orders; two atoms force a singular 3 x 3 Hankel matrix.
#check PaperChronology.Section3FiniteMomentRank.atomicPolynomialEnergy_nonneg
#check PaperChronology.Section3FiniteMomentRank.two_atom_quadratic_kernel
#check PaperChronology.Section3FiniteMomentRank.two_atom_moment_recurrence
#check PaperChronology.Section3FiniteMomentRank.two_atom_hankel_three_det_zero

-- Corrected Corollary 3.6: exact two/three-atom moment determinants,
-- sharp strict positivity and a cubic Gram-kernel witness.
#check PaperChronology.Section3ThreeAtomSharp.two_atom_hankel2_strict
#check PaperChronology.Section3ThreeAtomSharp.three_atom_moment_recurrence
#check PaperChronology.Section3ThreeAtomSharp.three_atom_cubic_kernel
#check PaperChronology.Section3ThreeAtomSharp.three_atom_hankel3_factor
#check PaperChronology.Section3ThreeAtomSharp.three_atom_hankel3_strict

-- Theorem 3.7: quadratic derivative Turan identity and strictness.
#check PaperChronology.Section3TuranQuadratic.turan_quadratic_identity
#check PaperChronology.Section3TuranQuadratic.turan_quadratic_strict

-- Theorem 4.1: finite spectral gap excludes a rational point from every root.
#check PaperChronology.Section4FiniteRootGap.rootFactorProduct_ne_zero

-- PDF Theorem 3.3: signed rational closed-product pole coefficient.
#check PaperChronology.Section3PoleResidue.lowerGap_pos
#check PaperChronology.Section3PoleResidue.upperGap_pos
#check PaperChronology.Section3PoleResidue.closedPoleWeight_alternating_sign

/-! Unconditional finite-paper certificates in chronological section order. -/
#check PaperChronology.Section3FiniteGram.energy_pos
#check PaperChronology.Section3ClosedSignature.signedEnergy_pos
#check PaperChronology.Section3DerivativeBridge.paper_poleWeight_alternating_sign
#check PaperChronology.Section5DualArithmetic.dividedDifference6_symm
#check PaperChronology.Section5DualArithmetic.dividedDifference6_adjacent
#check PaperChronology.Section5DualArithmetic.coefficientEnergy_nonneg
#check PaperChronology.Section5DualArithmetic.coefficientEnergy_pos_of_injective
#check PaperChronology.Section5PrimeSumCertificate.exact_table_sum
#check PaperChronology.Section6PoleBlock.localBlock_det
#check PaperChronology.Section6PoleBlock.localBlock_kernel_trivial


/-!
Theorem 3.3: official source coefficient bridge. These statements connect
an independently proved finite derivative to the actual Theorem 2.5
poleWeight used by the Hankel pencil. They do NOT import an unproved
inertia theorem or any analytic regularity assumption.
-/
namespace PaperChronology.Section3OfficialPole

/-- Identical rational source definitions; proof by kernel reduction. -/
theorem poleWeight_is_sourceWeight
    (p : ManuscriptChain.Real.Parameters) (i : Fin p.h) :
    ManuscriptChain.PoleDiagonalization.poleWeight p i =
      PaperChronology.Section3DerivativeBridge.paperPoleWeight p i := by
  rfl

/-- All actual source pole weights have the finite closed formula. -/
theorem poleWeight_eq_closed
    (p : ManuscriptChain.Real.Parameters) (hNK : p.N ≤ p.K)
    (i : Fin p.h) :
    ManuscriptChain.PoleDiagonalization.poleWeight p i =
      PaperChronology.Section3PoleResidue.closedPoleWeight
        p.N p.h i.val p.m p.k := by
  rw [poleWeight_is_sourceWeight p i]
  exact PaperChronology.Section3DerivativeBridge.paper_poleWeight_eq_closed p hNK i

/-- Actual Hankel derivative-pencil pole weight sign for EVERY tail pole. -/
theorem poleWeight_signed_positive
    (p : ManuscriptChain.Real.Parameters) (hNK : p.N ≤ p.K)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (p.N + i.val) *
      ManuscriptChain.PoleDiagonalization.poleWeight p i := by
  rw [poleWeight_eq_closed p hNK i]
  exact PaperChronology.Section3PoleResidue.closedPoleWeight_alternating_sign
    p.N p.h i.val p.m p.k hm

end PaperChronology.Section3OfficialPole

#print axioms PaperChronology.Section3OfficialPole.poleWeight_is_sourceWeight
#print axioms PaperChronology.Section3OfficialPole.poleWeight_eq_closed
#print axioms PaperChronology.Section3OfficialPole.poleWeight_signed_positive
