import PAPER_PRINCIPAL_ENDPOINT
import PaperChronology.Section3FiniteSupport

/-!
# Chronological corrected finite-support endpoint for PDF Corollary 3.6

Theorem 3.1 supplies real spectral roots for the manuscript's fixed-size
matrix.  The spectral reciprocal-root hierarchy of Corollary 3.6 therefore
has FINITE support at each K.  A finite spectral measure yields positive
semidefinite Hankel moments but has a nonzero annihilator polynomial, so
strict positive definiteness at ALL orders is mathematically impossible.

This extra proof module does not change, replace, or recompile the principal
single-witness theorem, and it does not claim complete paper formalization.
-/

#check PaperReconstruction.PRINCIPAL_THEOREM
#check PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
#check PaperChronology.Section3FiniteSupport.rootPolynomial_monic
#check PaperChronology.Section3FiniteSupport.rootPolynomial_eval_at_atom
#check PaperChronology.Section3FiniteSupport.finite_support_not_strictly_positive_definite
#check PaperChronology.Section3FiniteSupport.finite_moment_annihilator_relation
