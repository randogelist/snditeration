# Native Lean 4.33.0 import repair, v0.4.6.1

Failure: `PAPER_BATCH_CHAIN_v0450` referenced
`PaperChronology.Section4SpectralSign.determinant_base_sign_agrees`
without importing the module that declares it.

Repair: Added explicit `import PAPER_BATCH_SECTION4SPECTRALSIGN_AXIOMS` to
`PAPER_BATCH_CHAIN_v0450.lean`; this brings in the already user-verified
`PaperChronology.Section4SpectralSign` module. No theorem statement or proof
was changed.

- Previously verified modules remain untouched; the shared .olean cache reuses them.
- The changed chain and downstream blueprint modules are recomputed only as needed.
- Full paper claim remains not proved. Blueprint types are open checklists.
- User's native Windows Lean 4.33.0 is the compilation authority.
