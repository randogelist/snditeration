# v0.4.3.1: chronological correction of Corollary 3.6

Last certified user checkpoint: v0.4.3.0 principal endpoint, BUILD=PASS,
MODULES_COMPILED=2, MODULES_REUSED=45, 47 compiled targets.

The inherited 47 modules remain unchanged and reusable through the shared
verified .olean cache. The three new compilation targets in this ZIP are:

1. PaperChronology.Section3FiniteSupport
2. PAPER_COROLLARY_3_6_FINITE_SUPPORT
3. PAPER_COROLLARY_3_6_FINITE_SUPPORT_AXIOMS

Mathematics: for arbitrary finite real support u : Fin h -> Real, the
annihilator A(T) = product_i(T-u_i) is monic and nonzero but vanishes at
all atoms. The discrete Hankel polynomial energy therefore has a nontrivial
kernel; consequently it cannot be strictly positive definite on all
polynomial orders. With nonnegative weights the energy is nonnegative.
This corrects, rather than proves, the PDF's false universal strictness
statement in Corollary 3.6. The implication from the manuscript's actual
reciprocal-root power sums to the finite-atom abstraction is the natural
specialization and may be formalized as an additional bridge; it is not
claimed by this module.

New proof text contains no sorry/admit/custom axiom. New modules have NOT
been compiled locally. Your native Windows Lean 4.33.0 is the sole compiler.

RUN: call run.cmd
Do not use 'full' if preserving previously verified objects.
