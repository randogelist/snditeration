# v0.4.2 — reasoned finite spectral sharpness

This is an additive, uncompiled proof submission built from v0.4.1.
No user native compiler PASS has yet been provided for v0.4.0, v0.4.1,
or the new v0.4.2 modules. The last confirmed PASS remains v0.3.6.
The shared verified cache must NOT treat these newer unverified modules as
frozen until a native build passes with a clean axiom report.

## New unconditional finite mathematical targets

1. Corollary 3.6 corrected: exact two-atom size-two determinant
   w1*w2*(x-y)^2; exact size-three determinant for three atoms
   w1*w2*w3*(x-y)^2*(x-z)^2*(y-z)^2; explicit cubic Gram-kernel
   at order four and a third-order moment recurrence.
2. Theorem 3.7: exact degree-two Turan identity and positivity,
   strictly positive when two roots differ. General degree remains open.
3. Theorem 4.1: a finite rational point strictly inside all root gaps
   cannot equal a root; its entire finite root-factor product is nonzero.
   Integer normalization and asymptotic archimedean bounds remain open.

No existing paper theorem is promoted to fully proved based solely on
these general finite-algebra statements. Proofs are submitted to the
user's native Windows Lean 4.33.0; nothing is compiled locally.

# v0.4.1 finite moment rank: reasoning-only formalization

The first unverified checkpoint is v0.4.0; user has not supplied a native
compiler PASS for those new modules. This package therefore does NOT assert
v0.4.0 as frozen. It preserves all sources and adds one independent proof
candidate for the printed Corollary 3.6 correction, the exact two-atom
recurrence and 3 x 3 rank defect.

Native Lean 4.33.0 with the user's offline cached Mathlib remains the only
compilation authority. Default `run.cmd` uses the persistent verified cache;
`run.cmd full` is the manual recheck path.

## Source-correct mathematical scope

For a finite positive atomic measure, its polynomial Gram energy is
nonnegative, but cannot be positive definite at polynomial degrees
above its support size. For two atoms x,y the nonzero coefficient triple
(x*y, -(x+y), 1) yields (T-x)(T-y), so the 3x3 moment determinant is
identically zero. None of these finite statements proves an unestablished
analytic zeta identity or the entire source Corollary 3.6.

# Source-faithful Lean architecture, first reasoned baseline (v0.4.0)

**Build authority:** user native Windows Lean 4.33.0. No Lean compilation here.
**Starting checkpoint:** 124-module v0.3.6, independently reported `BUILD=PASS` by user.
**v0.3.13 error source:** not supplied; this package is a safe chronological fork
from the last verifiable source tree, not a claim of having repaired its lines 51/63/102.

## Invariants
1. There is ONE root-level `run.cmd` and ONE ZIP; default is persistent pass-once caching.
2. Previous modules are preserved bytewise except `PAPER_MAIN_CHAIN` and
   `PAPER_MAIN_CHAIN_AXIOMS` which add source-specific checks.
3. New proof files are small, mathematically noncircular, and print axioms;
   the runner refuses to mark a newly built module as verified when its
   output contains `sorryAx`.
4. The 51 PDF numbered checkpoints are chronological and must not be mistaken
   for 51 completed proofs.
5. Any PDF statement that is false as printed must be *corrected explicitly*
   instead of introduced as an axiom or bundled into an opaque witness.

## Logical path of the paper (NOT a claim that every arrow is proved)

    Section 2: finite rational functional and partial fractions
         --> basis independence
         --> Lagrange pole diagonalization
    Section 3: positive Gram integral + nonsingular slope
         --> hyperbolic det pencil + zero-free disk
         --> finite signed pole coefficients + inertia
         --> corrected interlacing, finite moment positivity
    Section 4: primitive polynomial + rational denominator clearance
         --> controlled spectral growth
         --> integer nonzero values and irrationality transfer
    Section 5: two-variable Beukers integral moments
         --> CC^T dual slope, Krein splitting
         --> prime-sum table and q-adic obstruction
    Section 6: cross-weight / zeta-beta and potential-gap transfer

## Only external arithmetic witness intended for the irrationality endpoint

`PaperReconstruction.AllOddWitness` is an explicit **parameter** of the
irrationality consequence; no `axiom` or instance should assert it. This
witness does **not** establish unrelated Section 3--6 analytic identities.
Those must be unconditional theorems of Lean if they are to be called proved.

## Section-by-section frontier after this package

**2.2, 2.3:** Finite formal representations done; independent `RatFunc`
quotient/uniqueness is not yet derived.

**3.3:** All-pole signed closed residues, finite diagonal energy, and official
derivative-defined pole coefficients have exact proof candidates.
Sylvester law transfer, Gram-integral total positivity and Stieltjes
Carleman bound remain distinct obligations.

**3.4:** The printed assertion that every principal minor has exactly r
finite roots is false: source-exact counterexample at N=1, K=5, s=3.
Correct degree is rank of restricted slope; zero eigenvalues must be omitted
or encoded as roots at infinity. A corrected interlacing proof must be
built against the rank-deficient case.

**3.5:** The printed J-fraction normalization and cyclicity claim are invalid
without correction. Its ratio needs Cholesky/slope normalizations and a
valid Krylov/Lanczos hypothesis.

**3.6:** A measure supported on <=h atoms has rank <=h; strict Hankel
positivity for ALL sizes is impossible. It is positive *semidefinite* at
all sizes, strictly positive up to number of distinct atoms (when applicable).

**3.7:** Turan derivative inequalities and Newton inequalities should be
proved from the actual real-rooted pencil, with correct strictness cases.

**5.1--5.2:** Finite divided differences, symmetry, and coefficient-energy
nonnegativity are separate from the *integral* identity and infinite Krein
series. The construction in the PDF discards m>M tail interactions: finite
orthogonality does not imply the full infinite tail vanishes. Explicit
uniform tail estimates or an alternative infinite-dimensional argument needed.

**5.6:** All eleven affine areas and their sum are now represented as exact
rational Lean proofs; the piecewise floor/min formula -> affine table bridge
remains open. The local q-adic improvement is also independent.

**6.1:** The local rational 2x2 block has det=-1/36. The q-adic congruence and
valuation law require their own formal arithmetic.

**6.2:** Adjacent moment rational identity is checked; two-variable integral
and 6*d_K^7 denominator clearance are not inferred from that identity alone.

**4,6 generally:** Do not treat a reused `#check` wrapper as a paper proof.

## Verification protocol

- `CHECK_PASS` + no `sorryAx` -> frozen .olean snapshot under same toolchain.
- Reuse when byte-identical source, unchanged transitive imports, and
  matching compiler/Mathlib cache stamp.
- Rebuild affected source and dependents only; `run.cmd full` is manual.
- No Lean was executed while generating this package.
