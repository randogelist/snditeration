# v0.4.3.4: arbitrary-degree first Turan theorem (new, native verification pending)

Chronological entry: PDF Theorem 3.7.

New formal algebra (not a restatement of an analytic premise):

    T(P) = (P')^2 - P P''
    T(P Q) = Q^2 T(P) + P^2 T(Q)
    T(X-r) = 1

For any finite product P(x) = c * product_i (x-r_i), with c real:

    for all x real, T(P)(x) >= 0.
    if c != 0 and there is at least one factor and P(x) != 0, T(P)(x) > 0.

The source also exposes an explicit `SplitPositiveDegree` factorization certificate.
This certificate is finite real polynomial algebra; the prior spectral
hyperbolicity theorem gives the mathematical reason it should apply to the
manuscript pencils, but the actual Lean bridge is not yet proved here.

This is ONLY m=1 of the PDF's Theorem 3.7. It does not establish the
inequalities for derivatives of all orders or the normalized Newton
coefficient inequalities, which remain open. We do not mark the full
paper theorem proved.

Previously verified 56 compilation targets are completely untouched.
3 new Lean modules appended to the frozen compile manifest.

No Lean compilation was performed here. Native Windows Lean 4.33.0 only.
No sorry/admit/custom axiom added in the new files.
One ZIP and one root-level run.cmd, persistent verified cache untouched.
