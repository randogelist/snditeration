# v0.3.5 new mathematical developments

* Checkpoint: v0.3.3 verified (`BUILD=PASS`, compiled 3, reused 116).
* v0.3.4 `Section3Continuous` verified per user compiler log.
* v0.3.4.4 `Section3LeadingSign` pending user compiler confirmation.
* v0.3.5: two new substantive Theorem 3.3 finite proof modules.
  * Even-length alternating signature signed imbalance zero.
  * Odd-length signed imbalance equal to first sign.
  * Exact Vandermonde/Andreief identity for two positive atoms.
  * Strict positivity of the 2x2 Hankel minor for positive distinct atoms.
* Do not infer full total positivity, full theorem 3.3 or any further
  statements of the PDF from `BUILD=PASS`; those are still open.
* No Lean compilation, Lake, network, Python, PowerShell or WSL required
  on the user's computer. The launcher is pure native Windows CMD.

The two new proof files are dependency-isolated from pending `Section3LeadingSign` and appear immediately after the verified `Section3Continuous` in the manifest.
