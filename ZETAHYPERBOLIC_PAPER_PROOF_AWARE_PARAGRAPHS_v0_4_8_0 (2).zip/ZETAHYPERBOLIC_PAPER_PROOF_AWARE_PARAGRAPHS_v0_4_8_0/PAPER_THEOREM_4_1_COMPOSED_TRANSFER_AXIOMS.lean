import PAPER_THEOREM_4_1_COMPOSED_TRANSFER

/-! The native runner rejects sorryAx in this certificate output. -/
#print axioms PaperChronology.Section4SpectralTransfer.rational_measure_from_pencils
#print axioms PaperChronology.Section4SpectralTransfer.irrational_from_pencils
