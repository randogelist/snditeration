# v0.4.7.2 — Chapter 6 chunked inventory proofs

## Exact failure repaired

`PaperParagraphs.Chapter6.lean` failed at `unit_count` and `block_count`
with `maximum recursion depth has been reached`, because `by decide`
reduced an entire 219-element source list in one proof.

## Repair

The 219 original `SourceUnit` records and their eight fields are retained
byte-for-byte inside the six chunk lists (apart from source whitespace).
Six small, independent `by decide` proofs establish individual chunk lengths
and block totals, followed by `List.length_append`, `List.map_append`,
and `List.sum_append` to establish the original public theorem statements.
The rest of the formalization is left unchanged and may reuse the
verified incremental cache. No local Lean compilation was done.

| Chunk | Source units | PDF body blocks |
|---|---:|---:|
| 0 | 37 | 145 |
| 1 | 37 | 120 |
| 2 | 37 | 114 |
| 3 | 36 | 109 |
| 4 | 36 | 105 |
| 5 | 36 | 84 |
| Total | 219 | 677 |

The 52-page source inventory is still 485 units / 1534 body blocks.
This is **source-index** verification, not proof of all the PDF's mathematics.
The mathematical status remains `PAPER_RESULTS_FULLY_PROVED=NO`.
