import PaperBlueprint.Pipeline
import PaperChronology.Section3PoleKernelCharacteristic
import PaperChronology.Section5DualMomentOrder
import PaperChronology.Section6TwoPoleSignature

/-!
# 0.4.7.0 substantive chapter-bridge checkpoint

The verified 51-checkpoint blueprint remains the master target.
This new batch adds only source-level finite mathematics:
* 3.8 characteristic determinants for coefficient/pole operators;
* 5.1 exact positive off-diagonal divided differences;
* 6.1 exact local two-pole inertia obstruction.

The full 52-page paper is NOT thereby proved; the actual analytic and
p-adic bridges and the strong weight-five witness remain unproved.
-/

namespace PaperChronology.Batch0470

/-- Zero sets coincide for the two finite characteristic pencils. -/
theorem pole_spectral_zero_transfer {n : ℕ}
    (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) (t : ℝ) :
    (PaperChronology.Section3PoleKernelCharacteristic.coefficientPencil
      H V gamma t).det = 0 ↔
    (PaperChronology.Section3PoleKernelCharacteristic.polePencil
      H V gamma t).det = 0 :=
  PaperChronology.Section3PoleKernelCharacteristic.parameter_zero_iff H V gamma t

/-- Exactly positive rational off-diagonal moment for all distinct nodes. -/
theorem offdiagonal_moment_positive (r t : ℕ) (h : r ≠ t) :
    0 < ManuscriptChain.Real.dualConstant 7 r t :=
  PaperChronology.Section5DualMomentOrder.dualConstant7_offdiag_pos r t h

/-- Explicit nontrivial positive and negative rational local directions. -/
theorem two_pole_has_both_signs :
    (∃ x y : ℚ, 0 <
      PaperChronology.Section6TwoPoleSignature.localEnergy x y) ∧
    (∃ x y : ℚ,
      PaperChronology.Section6TwoPoleSignature.localEnergy x y < 0) :=
  PaperChronology.Section6TwoPoleSignature.actual_local_form_indefinite

end PaperChronology.Batch0470
#print axioms PaperChronology.Batch0470.pole_spectral_zero_transfer
#print axioms PaperChronology.Batch0470.offdiagonal_moment_positive
#print axioms PaperChronology.Batch0470.two_pole_has_both_signs
