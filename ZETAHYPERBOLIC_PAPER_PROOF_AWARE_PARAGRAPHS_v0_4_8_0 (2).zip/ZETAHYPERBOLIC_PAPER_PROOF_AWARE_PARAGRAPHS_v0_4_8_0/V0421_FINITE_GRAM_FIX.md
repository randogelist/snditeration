# v0.4.2.1 Finite Gram repair — native Windows Lean 4.33.0

Source-only patch; compilation authority is the user's native Lean compiler.

`PaperChronology.Section3FiniteGram.energy_pos_at` previously applied `Finset.sum_pos`, which requires strict positivity at EVERY term, then gave a witness in a membership shape that did not fit the instantiated goal. A nonzero selected coordinate guarantees just ONE strictly positive summand, while all other summands are nonnegative.

The replacement uses the existing proof of nonnegativity for every weighted square, the selected strict positivity, and `Finset.single_le_sum` to prove the entire sum is positive. This is the exact desired mathematical implication and requires no new axioms, hypotheses, or proof escapes.

Only `PaperChronology/Section3FiniteGram.lean` changed among Lean files. Verified `.olean` source/cache snapshots remain external and are reused by `run.cmd` when unchanged. Affected import dependents rebuild automatically. No compiler was run while producing this ZIP.

Running `run.cmd` should now check `Section3FiniteGram` and dependent `Section3FiniteMomentRank`, `Section3ThreeAtomSharp`, `Section3ClosedSignature`, and main-chain checks as needed.
