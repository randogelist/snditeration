# Chronological Lean manuscript — evidence-based assessment (2026-10-24)

**Version audited:** `ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_BATCH_v0_4_5_1_DUAL_MOMENT_SYMMETRY_FIX` (source-based status carried forward as `ZETAHYPERBOLIC_PAPER_COVERAGE_STATUS_v0_4_5_2_AUDIT_ONLY`).
**User PDF:** `Zetahyperbolic (3)(5).pdf`. Its bytes are identical to the PDF inside this package (SHA-256 `935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`).
**No Lean compiler was run here.** The sole compilation authority is the user's native Windows Lean 4.33.0.

## Key outcome

- **51** chronological paper checkpoints, including **46** substantive numbered definitions, lemmas, theorems, propositions, and corollaries; plus **4** remarks and **1** conjecture.
- **3 / 46 = 6.52%** of substantive numbered entries are marked as **fully proved** in the manuscript register: Theorem 2.4, Theorem 2.5, Theorem 3.1. This is a *register-and-prior-build* status, not an independent full-paper audit of statement equivalence.
- **22 / 51** entries are partial or finite-construction results; their source sublemmas can be mathematically useful even when the stated entire PDF result is open.
- **18 / 51** explicitly open, **3 / 51** require printed-statement corrections, and **5 / 51** are remarks/conjectures rather than proof targets.
- **Loose mathematical-content estimate:** approximately **10–20%**, with significant uncertainty. This is not a count of checked propositions and is NOT implied by the amount of Lean code. The number of fully closed source results is only **3/46**.
- **Full-paper formalization:** NO. Even when all compilation targets pass, most theorem checkpoints are `#check` wrappers or limited finite subresults; compilation target counts do not equal theorem counts.

## Project size (counted from the actual source tree)

| Metric | Value |
|:--|--:|
| Lean files in archive | 208 |
| Physical Lean source lines | 14,348 |
| Lean source bytes | 613,991 |
| Modules in `compile-order.txt` | 119 |
| PDF numbered checkpoints | 51 |
| PDF pages | 52 |
| ZIP size (reported separately) | approximately 1.0 MB |

Note the **208 Lean files vs. 119 active compilation targets**. Files outside the active import/manifest closure are not newly verified by a single `BUILD=PASS`. Checkpoint files with only `#check` statements cannot substantiate complete theorem closure.

## Actual last native verification evidence

The last user-supplied **v0.4.5.0** compiler log showed success or cache reuse through the 100th compilation target, including Section 4's finite transfer consequences and Section 5's finite dual scaling and coordinate modules. It then **FAILED** on target 101, `PaperChronology.Section5DualMomentSymmetry`, specifically a negation/division equality in `dualConstant_swap`.

The **v0.4.5.1** source rewrites that proof using an explicit sign-cancellation calculation. As of this report **no subsequent compiler result for v0.4.5.1 is supplied**, so this revision and targets 101–119 remain *pending*, not passed. The runner preserves earlier verified `.olean` files and will compile only the invalidated dependency closure.

Crucially, being among the first 100 targets means a Lean *module/checkpoint* passed, not that the whole numbered paper theorem bearing that name is proved.

## Paper-by-paper section distribution

| Section | Fully proved | Partial/constructed | Open | Corrections | Remark or conjecture | Total |
|:--|--:|--:|--:|--:|--:|--:|
| 2 | 2 | 3 | 0 | 0 | 0 | 5 |
| 3 | 1 | 4 | 1 | 3 | 1 | 10 |
| 4 | 0 | 2 | 6 | 0 | 3 | 11 |
| 5 | 0 | 4 | 2 | 0 | 1 | 7 |
| 6 | 0 | 9 | 9 | 0 | 0 | 18 |

## Strongest genuine conditional endpoint

`PAPER_PRINCIPAL_ENDPOINT` has a verified previous build. Its source states, for the *actual* manuscript determinant family,

    RawWitness -> (UnconditionalCore ∧ Irrational (riemannZeta 5).re).

This is a conditional theorem with one external arithmetic witness, **not** a verified proof that the witness exists. The 25687 irrationality measure uses a *stronger* `FullMeasureWitness` containing both a decay and a spectral-norm estimate. The all-odd-zeta endpoint uses a separate `AllOddWitness` for every odd weight.

## Main frontiers by chronology

1. Section 2: formalize full `RatFunc` semantics and unique canonical partial fractions beyond finite canonical decompositions.
2. Theorem 3.3: complete continuum total positivity and inertia transfer. Theorem 3.4 and Corollaries 3.5/3.6 need corrected, source-faithful statements before full closure.
3. Section 3.9: the Dirichlet character / Hurwitz L-function analytic moment identification remains separate from the finite Fekete polynomial positivity identities.
4. Section 4: obtain independent normalized decay witness and sharp root-gap bound, then prove the complete asymptotic/Diophantine measures and algebraic/p-adic statements.
5. Section 5: upgrade finite dual moment/kernel symmetry to actual Beukers double-integral and infinite Krein-space assertions.
6. Section 6: prove remaining q-adic, prime-valuation, p-adic minor, multiweight analytic bridges and asymptotic potential-gap assertions.

This chronology is grounded in the PDF's theorem register, not a claim that proof fragments constitute full paper theorems.

## Freeze and build policy

This package changes **zero Lean source files** compared with v0.4.5.1. `run.cmd` preserves the persistent native verified cache, and is the single build entry point. Normal execution recompiles only new/edited/failed/transitively invalidated modules, and can retry the pending v0.4.5.1 proof. No local compilation was performed to prepare this assessment.
