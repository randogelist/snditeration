# Paragraph checkpoint (v0.4.7.1)

## Definition and limits

An **indexed source unit** is a paragraph-like group of consecutive textual PDF blocks from one printed page; formula fragments are included. The source parser automatically groups each body block exactly once. It is a layout-heuristic segmentation, not a semantic segmentation of every printed sentence or a proof.

This package has TWO independent layers:
1. **Structural/source indexing**: every body block from 52 PDF pages is covered by a Lean `SourceUnit` carrying page, block offset, short preview, source digest, and nearest active printed theorem label. This is a meaningful provenance checkpoint upon a successful native compiler run.
2. **Mathematical claims**: 46 existing Lean theorem blueprints are elaboration-checked, with paper-level proofs still at 3/46 from the frozen mathematical assessment. Associating a paragraph to a target does not mean its detailed assertion was encoded or proved.

A source index is NOT completion of the paper, the analytic bridge, the p-adic valuation, the finite arithmetic witness, or any individual unproved theorem. The runner unambiguously reports `PAPER_RESULTS_FULLY_PROVED=NO`.

## Counts

Source PDF SHA-256: `935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`.

| Partition | PDF source units | Extracted text body blocks |
|---|---:|---:|
| Introduction | 9 | 11 |
| Section 2 | 34 | 106 |
| Section 3 | 76 | 219 |
| Section 4 | 79 | 290 |
| Section 5 | 66 | 229 |
| Section 6 | 219 | 677 |
| References | 2 | 2 |
| **Total** | **485** | **1534** |

## Integration milestone

After native Windows Lean passes all new targets, `PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS` signifies *PDF source-index coverage* only; `PARAGRAPH_MATHEMATICAL_COVERAGE=PARTIAL` remains. The registry deliberately does not promote any theorem to proved. The indexed document contains assumptions, possibly invalid printed statements, and explanatory notes. The programmatic page/body partition is audited externally, not proved in Lean from PDF bytes.

## Native verification

Only user Windows Lean 4.33.0 is compilation authority. The previously passed 134 targets remain frozen and reusable. This package adds 10 Lean targets; no local Lean compilation was performed. The `_logs/BUILD_SUMMARY.txt` cache counts and statuses are authoritative after the user's run. The `run.cmd full` manual clean-build option remains available.

## v0.4.7.2 compilation retry

Chapter 6 uses finite chunks to avoid kernel recursion-depth exhaustion; user Windows Lean 4.33.0 remains the only compiler authority.
