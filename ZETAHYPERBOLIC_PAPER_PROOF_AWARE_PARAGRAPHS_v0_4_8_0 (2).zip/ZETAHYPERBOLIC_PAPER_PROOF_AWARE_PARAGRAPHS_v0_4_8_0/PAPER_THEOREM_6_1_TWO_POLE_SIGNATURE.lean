import PaperChronology.Section6TwoPoleSignature

/-! Theorem 6.1 exact 2x2 pole obstruction with both signature directions. -/
#print axioms PaperChronology.Section6TwoPoleSignature.twoPoleBlock_det
#print axioms PaperChronology.Section6TwoPoleSignature.actual_localBlock_eq
#print axioms PaperChronology.Section6TwoPoleSignature.actual_local_form_indefinite
