# v0.4.7.3 — Chapter 6 no-goals repair

User Windows Lean 4.33.0 showed both `simp only [...]` steps entirely closed the goals in
`PaperParagraphs.Chapter6.unit_count` and `PaperParagraphs.Chapter6.block_count`.
The subsequent `norm_num` invocations at former lines 284 and 290 therefore caused
`error: No goals to be solved`. Remove precisely those two redundant tactics.

The theorem statements (219 source units, 677 body blocks) and all source records
are unchanged. Recompile only Chapter6 and dependents; retain all prior successful
verified-cache targets. The ZIP is statically audited, not locally Lean-compiled.

`PARAGRAPH_SOURCE_INDEX_CHECKPOINT=PASS` on successful user compilation means source
inventory integration only; the mathematical paper remains incompletely proved.
