# v0.4.5.1 — Section 5 dual moment symmetry repair

The native Lean error in `Section5DualMomentSymmetry.dualConstant_swap` was an
unclosed rational sign cancellation, not a missing mathematical hypothesis.
The former `rw [hnum, hden]; simp` proof has been replaced by an explicit `calc`
with the two sign-reversal identities and `neg_div_neg_eq`, following the
already established proof pattern in `Section5DualArithmetic.dividedDifference6_symm`.

All theorem statements are unchanged. The script retains cross-version
verified `.olean` reuse. Only `Section5DualMomentSymmetry` and affected imports
are expected to rebuild. No local Lean compilation was performed.
The continued Section 5/6 modules remain proof candidates until the user's
native Lean compiler accepts them; BUILD=PASS is not full-paper closure.
