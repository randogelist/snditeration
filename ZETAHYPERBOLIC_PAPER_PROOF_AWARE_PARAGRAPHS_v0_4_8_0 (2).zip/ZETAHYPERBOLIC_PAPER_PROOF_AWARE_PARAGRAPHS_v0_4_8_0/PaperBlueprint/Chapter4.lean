import PaperBlueprint.Chapter3

/-!
# Section 4 blueprint: eight numbered, substantive theorems

The downstream rational-measure theorem and the conditional principal
irrationality result are PROVED. What is NOT proved is the actual Section 4.4
integer-normalization decay together with the independent sharp spectral
norm inequality. Algebraic/p-adic transfer, weight coupling, asymptotic
height and clustering are separately exposed, never silently assumed.
-/

noncomputable section
open Polynomial
namespace PaperBlueprint.Chapter4

/-- Quadratic decay of the *specified* integer-polynomial sequence; this
is the missing mathematical content of equation (4.3) when applied to the
paper's Q_K rather than to an arbitrary chosen polynomial. -/
def QuadraticDecay (Q : ℕ → Polynomial ℤ)
    (center epsilon : ℝ) (step : ℕ) : Prop :=
  0 < epsilon ∧ 0 < step ∧
  ∃ onset : ℕ, ∀ n : ℕ, onset ≤ n →
    0 < PaperBlueprint.evalInt (Q (step * n)) center ∧
    PaperBlueprint.evalInt (Q (step * n)) center ≤
      Real.exp (-epsilon * ((step * n : ℕ) : ℝ) ^ 2)

/-- Exact exponential complex-root disk quantified over ALL polynomial
roots (not a numerical sample of eigenvalues). -/
def ExponentialRootGap (Q : ℕ → Polynomial ℤ)
    (center rho : ℝ) (step : ℕ) : Prop :=
  0 < rho ∧ 0 < step ∧
  ∃ onset : ℕ, ∀ n : ℕ, onset ≤ n → ∀ z : ℂ,
    Polynomial.eval₂ (Int.castRingHom ℂ) z (Q (step * n)) = 0 →
    Real.exp (-rho * ((step * n : ℕ) : ℝ)) ≤ ‖z - (center : ℂ)‖

/-- Theorem 4.1: from quadratic decay, controlled polynomial degree and
complex root separation, every integer mu above λρ/ε is an admissible
rational irrationality exponent. Exact computable onset is a further target. -/
def goal_4_1 : Prop :=
  ∀ (Q : ℕ → Polynomial ℤ) (center lambda epsilon rho : ℝ)
    (step : ℕ) (mu : ℕ),
    0 < lambda →
    QuadraticDecay Q center epsilon step →
    ExponentialRootGap Q center rho step →
    (∃ start, ∀ n, start ≤ n →
      ((Q (step * n)).natDegree : ℝ) ≤ lambda * ((step * n : ℕ) : ℝ)) →
    lambda * rho / epsilon < (mu : ℝ) →
    PaperBlueprint.HasRationalMeasure center mu

/-- Theorem 4.2: resultant/height transfer needs a formally selected
algebraic number height and a uniform auxiliary-polynomial height bound.
This is a specific open interface (NOT the real-rational 4.1 criterion). -/
def goal_4_2 (AlgebraicHeightResultantTransfer : Prop) : Prop :=
  AlgebraicHeightResultantTransfer

/-- Theorem 4.3: extension of the unit-ball ultrametric polynomial Taylor
argument to the actual p-adic field and its full complex completion. -/
def goal_4_3 (PadicDiskLocalConstancy : Prop) : Prop :=
  PadicDiskLocalConstancy

/-- Theorem 4.4 source-specific missing input and its already-derived
conclusion. It does NOT assert either side is currently inhabited. -/
def goal_4_4 : Prop :=
  PaperReconstruction.FullMeasureWitness ∧
    PaperBlueprint.QuantitativeZetaFive

/-- Theorem 4.5: full mixed zeta(5),zeta(3) measure with the paper's
specified coefficient region. -/
def goal_4_5 : Prop :=
  ∀ a b : ℤ, 0 < b →
    (a : ℝ) < (Real.pi ^ 2 / 3) * (b : ℝ) →
      PaperBlueprint.HasRationalMeasure
        ((b : ℝ) * (riemannZeta 5).re + (a : ℝ) * (riemannZeta 3).re)
        25687

/-- Theorem 4.6: the genuine two-sided *asymptotic* determinant and
height estimates are a second independent quantitative frontier. -/
def goal_4_6 (SharpDeterminantAndHeightAsymptotics : Prop) : Prop :=
  SharpDeterminantAndHeightAsymptotics

/-- Theorem 4.7: at least 1.40 percent of the actual roots undergo
exponential cluster collapse; this cannot be obtained from a finite test. -/
def goal_4_7 (MacroscopicRootCollapse : Prop) : Prop :=
  MacroscopicRootCollapse

/-- Proposition 4.8: exclusion of rational roots and bounds on algebraic
cluster factor degrees, requiring the actual 4.4 and 4.6 estimates. -/
def goal_4_8 (RootExclusionAndFactorDegrees : Prop) : Prop :=
  RootExclusionAndFactorDegrees

/-- A formal conditional theorem that uses the EXISTING complete downstream
proof rather than restating or introducing an arithmetic axiom. -/
theorem original_4_4_from_full_witness
    (h : PaperReconstruction.FullMeasureWitness) :
    PaperBlueprint.QuantitativeZetaFive := by
  exact PaperBlueprint.afterFullMeasureWitness h

structure BlueprintCompletion
    (AlgebraicHeightResultantTransfer PadicDiskLocalConstancy : Prop)
    (SharpDeterminantAndHeightAsymptotics MacroscopicRootCollapse
      RootExclusionAndFactorDegrees : Prop) : Prop where
  rational_4_1 : goal_4_1
  algebraic_4_2 : goal_4_2 AlgebraicHeightResultantTransfer
  padic_4_3 : goal_4_3 PadicDiskLocalConstancy
  weight_five_4_4 : goal_4_4
  mixed_weight_4_5 : goal_4_5
  heights_4_6 : goal_4_6 SharpDeterminantAndHeightAsymptotics
  collapse_4_7 : goal_4_7 MacroscopicRootCollapse
  cluster_factors_4_8 : goal_4_8 RootExclusionAndFactorDegrees

end PaperBlueprint.Chapter4
#print axioms PaperBlueprint.Chapter4.original_4_4_from_full_witness
