import PaperBlueprint.Chapter4

/-!
# Section 5 blueprint: 6 substantive claims + one non-theorem remark

The Beukers 2D integral is kept separate from its finite divided-difference
identity. The finite Gram-energy lemmas and 11 affine prime-integral pieces
are not mistaken for the infinite Krein decomposition or the full q-adic
valuation theorem. Section 5.5 is an explanatory remark only.
-/

noncomputable section
open scoped BigOperators
namespace PaperBlueprint.Chapter5

/-- The genuine two-variable integral in equations (5.1)--(5.2).
Every index pair is covered, including both the diagonal zeta(7) tail
and the off-diagonal rational divided difference. -/
def beukersMoment (r t : ℕ) : ℝ :=
  ∫ x in (0 : ℝ)..1,
    ∫ y in (0 : ℝ)..1,
      x ^ r * y ^ t * (-Real.log (x * y)) ^ 5 /
        (720 * (1 - x * y))

/-- Theorem 5.1, with literal 2D moments; the integral evaluation itself
is still an analytic obligation. -/
def goal_5_1 : Prop :=
  ∀ r t : ℕ,
    beukersMoment r t =
      if r = t then
        PaperBlueprint.zetaValue 7 -
          (ManuscriptChain.Real.harmonic 7 r : ℝ)
      else
        (((ManuscriptChain.Real.harmonic 6 r -
          ManuscriptChain.Real.harmonic 6 t) /
          (6 * ((r : ℚ) - (t : ℚ))) : ℚ) : ℝ)

/-- Theorem 5.2: full Krein-positive and Krein-negative subspace existence plus
infinite-series identity, not just positivity of finite coefficient Gram. -/
def goal_5_2
    (InfiniteKreinDecomposition RationalPolynomialConeExistence : Prop) : Prop :=
  InfiniteKreinDecomposition ∧ RationalPolynomialConeExistence

/-- Proposition 5.3: analytic beta(4) Beukers realization and positive
X-derivative pencil on the x^(4r) monomial basis. -/
def goal_5_3 (BetaFourDoubleIntegralAndPencil : Prop) : Prop :=
  BetaFourDoubleIntegralAndPencil

/-- Theorem 5.4: simple even-pole rational cancellation with correct j>=1
and no unjustified claim about higher-order poles. -/
def goal_5_4 : Prop :=
  ∀ k j : ℕ, 1 ≤ k → 1 ≤ j → ∀ X : ℚ,
    PaperChronology.tauPolePositive k (j - 1) X -
      PaperChronology.tauPoleNegative k (j - 1) X =
      1 / ((j : ℚ) ^ (2 * k + 1))

theorem simple_even_pole_goal_proved : goal_5_4 := by
  intro k j hk hj X
  exact PaperChronology.THEOREM_5_4_SIMPLE_POLE_CANCELLATION k j hj X

/-- Theorem 5.6: affine integrand exactly equals the floor/min-defined
prime integrand, plus the infinite tail/valuation upgrade. -/
def goal_5_6
    (PrimeIntegrandPiecewiseIdentity InnerPrimeTailAndRefinement : Prop) : Prop :=
  PrimeIntegrandPiecewiseIdentity ∧ InnerPrimeTailAndRefinement

/-- Theorem 5.7: the q-adic nonzero determinant and local p-adic minor
valuation statement, not a finite rational surrogate. -/
def goal_5_7 (DoublePoleQAdicNonvanishingAndValuations : Prop) : Prop :=
  DoublePoleQAdicNonvanishingAndValuations

structure BlueprintCompletion
    (InfiniteKreinDecomposition RationalPolynomialConeExistence : Prop)
    (BetaFourDoubleIntegralAndPencil : Prop)
    (PrimeIntegrandPiecewiseIdentity InnerPrimeTailAndRefinement : Prop)
    (DoublePoleQAdicNonvanishingAndValuations : Prop) : Prop where
  moments_5_1 : goal_5_1
  krein_5_2 : goal_5_2 InfiniteKreinDecomposition RationalPolynomialConeExistence
  beta_5_3 : goal_5_3 BetaFourDoubleIntegralAndPencil
  even_pole_5_4 : goal_5_4
  prime_sum_5_6 : goal_5_6 PrimeIntegrandPiecewiseIdentity InnerPrimeTailAndRefinement
  double_pole_5_7 : goal_5_7 DoublePoleQAdicNonvanishingAndValuations

end PaperBlueprint.Chapter5
#print axioms PaperBlueprint.Chapter5.simple_even_pole_goal_proved
