import PaperBlueprint.Chapter2
import PaperChronology.Section3TuranProduct

/-!
# Section 3 blueprint: nine substantive checkpoints

Theorem 3.4 and Corollaries 3.5--3.6 require corrected formulations.
In particular a finite h-atomic moment measure has rank at most h,
so infinite-order strict Hankel positivity CANNOT be a target.
The paper's continuous integral, total positivity, spectral inertia, full
Jacobi derivative and Dirichlet-L bridges remain unproved obligations.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperBlueprint.Chapter3

/-- Theorem 3.1 is already closed in the source-specific previous chain. -/
def goal_3_1 : Prop := PaperReconstruction.UnconditionalCore

/-- Proposition 3.2: continuous-weight integral realization and the odd-
integer specialization of the whole Gram matrix (not only density modes).
`realGram` must be defined from the corrected Gamma-normalized integral. -/
def goal_3_2 (realGram : (s : ℝ) → (p : ManuscriptChain.Real.Parameters) →
    Matrix (Fin p.h) (Fin p.h) ℝ) : Prop :=
  (∀ s : ℝ, 1 < s → ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p → (realGram s p).PosDef) ∧
  (∀ k : ℕ, 0 < k → ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p → p.k = k →
      realGram (2 * (k : ℝ) + 1) p =
        ManuscriptChain.Real.gram p (PaperBlueprint.zetaValue p.weight))

/-- Theorem 3.3(1): strict total positivity of every minor of the ACTUAL
positive Gram matrix, with strictly increasing row/column index maps. -/
def goal_3_3 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
    ∀ r : ℕ, r ≤ p.h →
    ∀ I J : Fin r → Fin p.h,
      StrictMono I → StrictMono J →
      0 < Matrix.det (fun i j : Fin r =>
        ManuscriptChain.Real.gram p (PaperBlueprint.zetaValue p.weight)
          (I i) (J j))

/-- Theorem 3.4, corrected: the interlacing statement must distinguish
finite derivative eigenvalues from the possible zero derivative eigenvalues.
The original universal degree/nonzero-slope claim is false. The precise
conditional interlacing and Dodgson identity are a separate named input. -/
def goal_3_4_repair (CorrectedRootInterlacingAndDodgson : Prop) : Prop :=
  CorrectedRootInterlacingAndDodgson

/-- Corollary 3.5, corrected: the resolvent, normalization factors,
and possible Lanczos breakdown are part of the statement. No universal
cyclicity assumption is postulated. -/
def goal_3_5_repair (CorrectlyNormalizedFiniteJFraction : Prop) : Prop :=
  CorrectlyNormalizedFiniteJFraction

/-- Corollary 3.6 *corrected*: finite Stieltjes rank/strictness is exact
under pairwise-distinct atoms; the next theorem is already proved. -/
def goal_3_6_corrected : Prop :=
  ∀ h : ℕ, ∀ (w u : Fin h → ℝ),
    (∀ i, 0 < w i) → (∀ i, 0 < u i) →
    Function.Injective u →
    (∀ n : ℕ, ∀ P : Polynomial ℝ,
      P.natDegree < h → P ≠ 0 →
        0 < PaperChronology.Section3StieltjesShifts.shiftedEnergy w u n P) ∧
    (∀ n : ℕ, ∃ P : Polynomial ℝ,
      P ≠ 0 ∧ PaperChronology.Section3StieltjesShifts.shiftedEnergy w u n P = 0)

theorem corrected_3_6_is_proved : goal_3_6_corrected := by
  intro h w u hw hu hinj
  exact PaperChronology.Section3StieltjesShifts.shifted_stieltjes_sharp w u hw hu hinj

/-- Theorem 3.7: the higher-derivative Turan inequality for real-split
polynomials. Its first-derivative case is separately in the proved project. -/
def derivativeIterate : ℕ → Polynomial ℝ → Polynomial ℝ
  | 0, P => P
  | n + 1, P => (derivativeIterate n P).derivative

def goal_3_7 : Prop :=
  ∀ (P : Polynomial ℝ),
    PaperChronology.Section3TuranProduct.SplitPositiveDegree P →
    ∀ m : ℕ, 1 ≤ m → m ≤ P.natDegree →
    ∀ x : ℝ,
      0 ≤ ((derivativeIterate m P).eval x) ^ 2 -
        (derivativeIterate (m - 1) P).eval x *
          (derivativeIterate (m + 1) P).eval x

/-- Theorem 3.8: Christoffel--Darboux inverse-Gram pole spectrum
AND Jacobi's derivative-under-integral formula are two distinct tasks.
Neither is replaced by the trivial existence of a symmetric kernel. -/
def goal_3_8
    (ChristoffelDarbouxPoleSpectrum JacobiUnderIntegral : Prop) : Prop :=
  ChristoffelDarbouxPoleSpectrum ∧ JacobiUnderIntegral

/-- Theorem 3.9: five positive periodic character Laplace kernels have
finite algebra proofs; the complete statement additionally requires the
actual Hurwitz/Dirichlet-L integral identification. -/
def goal_3_9 (hurwitzMoment dirichletMoment : Prop) : Prop :=
  hurwitzMoment ∧ dirichletMoment

/-- A typed *roadmap* record; its fields are not constructors of full proofs.
In particular 3.4 and 3.5 are labelled repaired frontiers, and 3.8 is a
necessary kernel component, NOT a substitute for the full source theorem. -/
structure BlueprintCompletion
    (realGram : (s : ℝ) → (p : ManuscriptChain.Real.Parameters) →
      Matrix (Fin p.h) (Fin p.h) ℝ)
    (CorrectedRootInterlacingAndDodgson : Prop)
    (CorrectlyNormalizedFiniteJFraction : Prop)
    (ChristoffelDarbouxPoleSpectrum JacobiUnderIntegral : Prop)
    (hurwitzMoment dirichletMoment : Prop) : Prop where
  spectral_3_1 : goal_3_1
  continuous_3_2 : goal_3_2 realGram
  total_positive_3_3 : goal_3_3
  corrected_3_4 : goal_3_4_repair CorrectedRootInterlacingAndDodgson
  corrected_3_5 : goal_3_5_repair CorrectlyNormalizedFiniteJFraction
  finite_stieltjes_3_6 : goal_3_6_corrected
  turan_3_7 : goal_3_7
  cd_and_jacobi_3_8 : goal_3_8 ChristoffelDarbouxPoleSpectrum JacobiUnderIntegral
  character_3_9 : goal_3_9 hurwitzMoment dirichletMoment

end PaperBlueprint.Chapter3
#print axioms PaperBlueprint.Chapter3.corrected_3_6_is_proved
