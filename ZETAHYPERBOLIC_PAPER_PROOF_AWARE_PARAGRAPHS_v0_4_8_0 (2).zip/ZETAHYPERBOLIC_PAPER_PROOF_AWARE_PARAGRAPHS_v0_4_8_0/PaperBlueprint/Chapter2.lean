import PaperBlueprint.Common

/-!
# Section 2 blueprint: five numbered checkpoints, including two proved cores

The missing step is NOT another formal matrix identity: it is a representation
independence and unique extension of the paper's rational-function domain.

A map from a canonical finite decomposition into `RatFunc` and the substitution
maps remain explicit *parameters* to the target statements. This prevents a
synthetic representation from being silently equated with the paper domain.
-/

noncomputable section
open Polynomial
namespace PaperBlueprint.Chapter2

/-- Def 2.1: independence of the canonical rational-moment representation.
The `toRat` function must eventually be fixed to the actual embedding of the
finite polynomial/simple-square-pole domain in `RatFunc ℚ`. -/
def goal_2_1
    (toRat : Zetahyperbolic.RatMomentElem → RatFunc ℚ) : Prop :=
  ∀ k : ℕ, ∀ A B : Zetahyperbolic.RatMomentElem,
    toRat A = toRat B →
      Zetahyperbolic.muFunctionalPoly k A =
        Zetahyperbolic.muFunctionalPoly k B

/-- Lemma 2.2: transfer the established finite pullback to actual rational
functions via the still-to-be-instantiated x^(2k+1) R(-x²) substitution. -/
def goal_2_2
    (toRat : Zetahyperbolic.RatMomentElem → RatFunc ℚ)
    (pulledBack : ℕ → RatFunc ℚ → RatFunc ℚ)
    (tau : ℕ → RatFunc ℚ → Polynomial ℚ) : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ R : Zetahyperbolic.RatMomentElem,
    tau k (pulledBack k (toRat R)) =
      Zetahyperbolic.muFunctionalPoly k R

/-- Lemma 2.3: exact reflection and shift for the tau functional after
passing from finite generators to the rational-function domain. -/
def goal_2_3
    (tau : ℕ → RatFunc ℚ → Polynomial ℚ)
    (reflect shift : RatFunc ℚ → RatFunc ℚ)
    (pole : ℤ → RatFunc ℚ) : Prop :=
  (∀ k f, tau k (reflect f) = -(tau k f)) ∧
  (∀ k r, r ≠ 0 → r ≠ 1 →
    tau k (shift (pole r)) - tau k (pole r) =
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹))

/-- Theorem 2.4: a full symbolic determinant change-of-basis identity,
which is a prerequisite for primitive-sign normalization. The normalized
primitive polynomial itself is already in the verified source module. -/
def goal_2_4 : Prop :=
  ∀ n : ℕ, ∀ G : Matrix (Fin n) (Fin n) (Polynomial ℚ),
    ∀ A B : Matrix (Fin n) (Fin n) ℚ,
      (A.map Polynomial.C * G * (B.map Polynomial.C).transpose).det =
        Polynomial.C (A.det * B.det) * G.det

/-- Theorem 2.5: Vandermonde/diagonal derivative representation for the
ACTUAL manuscript pencil, including nonzero diagonal entries. -/
def goal_2_5 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
    ∃ (V : Matrix (Fin p.h) (Fin p.h) ℝ)
      (gamma : Fin p.h → ℝ),
      (∀ i, gamma i ≠ 0) ∧ Matrix.det V ≠ 0 ∧
      ManuscriptChain.Real.derivativeMatrix p =
        V * Matrix.diagonal gamma * V.transpose

/-- Chapter-completeness contract: all five exact source-level obligations
must be instantiated. Passing this file does NOT produce an inhabitant. -/
structure FullyCovered
    (toRat : Zetahyperbolic.RatMomentElem → RatFunc ℚ)
    (pulledBack : ℕ → RatFunc ℚ → RatFunc ℚ)
    (tau : ℕ → RatFunc ℚ → Polynomial ℚ)
    (reflect shift : RatFunc ℚ → RatFunc ℚ)
    (pole : ℤ → RatFunc ℚ) : Prop where
  definition_2_1 : goal_2_1 toRat
  lemma_2_2 : goal_2_2 toRat pulledBack tau
  lemma_2_3 : goal_2_3 tau reflect shift pole
  theorem_2_4 : goal_2_4
  theorem_2_5 : goal_2_5

end PaperBlueprint.Chapter2
