# v0.4.4.0 — Chronological large-step proof frontier

This bundle deliberately adds **four source-relevant theorem modules at once**, in
addition to repairing the previously failed finite character-series proof. It
only recompiles the previously failed character series and its audit wrappers,
then the new Section 3.9, Section 4.1, and Section 5.1–5.2 modules.

## Scope and status

* `Section3CharacterSeries`: exact finite periodic-block recurrence, geometric
  summation, five completed character series. The two failing rewritten lines
  are now explicit calculations; any remaining Lean mismatch is a compiler
  matter, not a new hypothesis.
* `Section3CharacterLaplace`: real-height substitution and all five strict
  kernel and series inequalities for y>0.
* `Section4FiniteSpectralBall`: universal no-real-root ball of radius 1/B
  whenever all spectral coefficients obey |beta_i|<=B.
* `Section4SpectralTransfer`: direct composition of the previously compiled
  spectral comparison and integer polynomial transfer. The decay, bound,
  normalization and index budget remain the genuine conditions.
* `Section5DualFinite`: exact rational two-variable pencil coefficient,
  Gram symmetry, finite squared-energy positivity and injective-map strictness.

The **51 manuscript checkpoints remain indexed**, but the fully proved count
is not increased based solely on partially covered theorems.

## Native Windows compilation

Run the ONE `run.cmd` at package root with no arguments for incremental reuse.
No local Lean compiler has been invoked during packaging. All new proofs are
proposals pending the user's native Lean 4.33.0 kernel/axiom audit.

Compiler failures produce `BUILD=FAIL`, not false positive passes.
