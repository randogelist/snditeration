import PaperChronology.Section5DualMomentOrder

/-! Theorem 5.1 rational divided-difference ordering (not integral evaluation). -/
#print axioms PaperChronology.Section5DualMomentOrder.harmonic_strictMono
#print axioms PaperChronology.Section5DualMomentOrder.dividedDifference6_pos_of_ne
#print axioms PaperChronology.Section5DualMomentOrder.dualConstant7_offdiag_pos
#print axioms PaperChronology.Section5DualMomentOrder.dualConstant7_diag_neg
