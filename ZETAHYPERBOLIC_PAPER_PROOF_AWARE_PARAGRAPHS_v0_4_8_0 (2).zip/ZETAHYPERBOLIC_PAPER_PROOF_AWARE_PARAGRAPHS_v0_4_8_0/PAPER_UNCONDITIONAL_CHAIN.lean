import Zetahyperbolic
import PAPER_CORRECTIONS

/-!
Only genuine unconditional mathematical conclusions are exported here.
The parameter condition is a proved decidable structural admissibility
property, not an analytic conjecture. The unconditional all-odd spectral
result is distinct from the still-conditional all-odd irrationality criterion.
-/

namespace ManuscriptChain

/-- Source Theorem 3.1, at every structurally admissible odd weight. -/
theorem PAPER_SPECTRAL_CHAIN (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p := MAIN_CHAIN_UNCONDITIONAL p hp

/-- Unconditional universal form of the same spectral result. -/
theorem PAPER_ALL_ODD_SPECTRAL :
    ∀ p : Real.Parameters, Real.Admissible p → General.GeneralStatement p :=
  fun p hp => MAIN_CHAIN_UNCONDITIONAL p hp

/-- Unconditional exact disk: its boundary contains a root. -/
theorem PAPER_EXACT_DISK (p : Real.Parameters) (hp : Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (Real.zeta p.weight : ℂ)‖ < radius →
        ¬ General.ComplexRoot p z) ∧
      (∃ z : ℂ, General.ComplexRoot p z ∧
        ‖z - (Real.zeta p.weight : ℂ)‖ = radius) :=
  EXACT_ZERO_FREE_DISK p hp

end ManuscriptChain

#check ManuscriptChain.PAPER_ALL_ODD_SPECTRAL
#check ManuscriptChain.PAPER_EXACT_DISK
#check ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational
#print axioms ManuscriptChain.PAPER_SPECTRAL_CHAIN
#print axioms ManuscriptChain.PAPER_ALL_ODD_SPECTRAL
#print axioms ManuscriptChain.PAPER_EXACT_DISK
