import PaperChronology.T2_1_Order_s_rational_moment_functional
import PaperChronology.PoleGenerators

/-!
# Lemma 2.2 — Pullback identity

SOURCE: Zetahyperbolic PDF; Section 2.
STATUS: PARTIAL
SOURCE MODULE: PaperChronology.PoleGenerators
SCOPE: Pole-generator arithmetic added; full rational-function pullback remains open.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperChronology.harmonic_succ

#check PaperChronology.pullback_simple_pole_value
