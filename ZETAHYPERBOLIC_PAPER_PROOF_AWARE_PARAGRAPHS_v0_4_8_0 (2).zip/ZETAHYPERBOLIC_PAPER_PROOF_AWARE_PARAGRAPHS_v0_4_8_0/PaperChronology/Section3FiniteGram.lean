import PaperChronology.Section3StrictMinor

/-!
# Theorem 3.3: unconditional finite positive-atom Gram certificates

The discrete-energy results are proved for *actual arbitrary finite weights*;
they are not a replacement for the manuscript's positive continuous measure.
The matrix rank and integral passage remain independently open.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3FiniteGram

/-- A positive weighted discrete quadratic energy. -/
def energy {h : ℕ} (w x : Fin h → ℚ) : ℚ :=
  ∑ a : Fin h, w a * (x a)^2

/-- Each finite weighted square is nonnegative. -/
theorem energy_nonneg {h : ℕ} (w x : Fin h → ℚ)
    (hw : ∀ a, 0 ≤ w a) : 0 ≤ energy w x := by
  unfold energy
  apply Finset.sum_nonneg
  intro a ha
  exact mul_nonneg (hw a) (sq_nonneg (x a))

/-- A single nonvanishing coordinate makes the finite form strictly positive. -/
theorem energy_pos_at {h : ℕ} (w x : Fin h → ℚ)
    (hw : ∀ a, 0 < w a) (a : Fin h) (hxa : x a ≠ 0) :
    0 < energy w x := by
  unfold energy
  have hterms :
      ∀ b ∈ (Finset.univ : Finset (Fin h)),
        0 ≤ w b * (x b)^2 := by
    intro b hb
    exact mul_nonneg (le_of_lt (hw b)) (sq_nonneg (x b))
  have hselected : 0 < w a * (x a)^2 :=
    mul_pos (hw a) (sq_pos_of_ne_zero hxa)
  have hselected_le :
      w a * (x a)^2 ≤ ∑ b : Fin h, w b * (x b)^2 :=
    Finset.single_le_sum hterms (Finset.mem_univ a)
  exact lt_of_lt_of_le hselected hselected_le

/-- Strict positive definiteness of a diagonal matrix with positive entries,
represented without any unproved analytic or spectral hypotheses. -/
theorem energy_pos {h : ℕ} (w x : Fin h → ℚ)
    (hw : ∀ a, 0 < w a) (hx : x ≠ 0) :
    0 < energy w x := by
  classical
  by_contra hn
  have hzero : ∀ a : Fin h, x a = 0 := by
    intro a
    by_contra hxa
    exact hn (energy_pos_at w x hw a hxa)
  apply hx
  funext a
  exact hzero a

end PaperChronology.Section3FiniteGram

#print axioms PaperChronology.Section3FiniteGram.energy_nonneg
#print axioms PaperChronology.Section3FiniteGram.energy_pos_at
#print axioms PaperChronology.Section3FiniteGram.energy_pos
