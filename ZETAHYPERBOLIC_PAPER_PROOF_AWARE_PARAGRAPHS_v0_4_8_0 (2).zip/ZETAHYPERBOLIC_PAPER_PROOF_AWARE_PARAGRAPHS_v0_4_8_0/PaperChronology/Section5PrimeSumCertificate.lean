import PaperChronology.Section5DualArithmetic
import Mathlib.Tactic.NormNum

/-!
# Theorem 5.6(1): exact rational integration of all 11 AFFINE TABLE PIECES

This is the complete exact rational arithmetic verification of Table 1
(pp.26--27). The step asserting that the floor/min expression of T(y)
equals these affine functions on the intervals is not smuggled in here;
it is the distinct, still-open piecewise-identity obligation.
-/

noncomputable section
namespace PaperChronology.Section5PrimeSumCertificate

/-- Exact integral of b+c*y from l to r, written as a rational primitive
difference to avoid floating-point approximations. -/
def affineArea (l r b c : ℚ) : ℚ :=
  b * (r-l) + c * (r^2-l^2)/2

-- The 11 records come verbatim from Table 1.
theorem p01 : affineArea (1/3) (43/120) (51/8) (-5) = 223/1920 := by
  norm_num [affineArea]
theorem p02 : affineArea (43/120) (29/80) (513/40) (-23) = 2177/115200 := by
  norm_num [affineArea]
theorem p03 : affineArea (29/80) (37/100) (571/40) (-27) = 10527/320000 := by
  norm_num [affineArea]
theorem p04 : affineArea (37/100) (37/80) (497/40) (-22) = 48359/160000 := by
  norm_num [affineArea]
theorem p05 : affineArea (37/80) (29/60) (41/10) (-4) = 53/1152 := by
  norm_num [affineArea]
theorem p06 : affineArea (29/60) (1/2) (53/20) (-1) = 259/7200 := by
  norm_num [affineArea]
theorem p07 : affineArea (1/2) (43/80) (7/2) 1 = 1929/12800 := by
  norm_num [affineArea]
theorem p08 : affineArea (43/80) (37/60) (121/10) (-15) = 10469/38400 := by
  norm_num [affineArea]
theorem p09 : affineArea (37/60) (37/40) (41/4) (-12) = 37/120 := by
  norm_num [affineArea]
theorem p10 : affineArea (37/40) 1 1 (-2) = -111/1600 := by
  norm_num [affineArea]
theorem p11 : affineArea 1 (37/20) (37/20) (-1) = 289/800 := by
  norm_num [affineArea]

/-- Exact sum of the eleven primitives, EQUATION (5.6)'s rational value. -/
theorem exact_table_sum :
    affineArea (1/3) (43/120) (51/8) (-5) +
    affineArea (43/120) (29/80) (513/40) (-23) +
    affineArea (29/80) (37/100) (571/40) (-27) +
    affineArea (37/100) (37/80) (497/40) (-22) +
    affineArea (37/80) (29/60) (41/10) (-4) +
    affineArea (29/60) (1/2) (53/20) (-1) +
    affineArea (1/2) (43/80) (7/2) 1 +
    affineArea (43/80) (37/60) (121/10) (-15) +
    affineArea (37/60) (37/40) (41/4) (-12) +
    affineArea (37/40) 1 1 (-2) +
    affineArea 1 (37/20) (37/20) (-1) =
      (453803 : ℚ)/288000 := by
  rw [p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11]
  norm_num

end PaperChronology.Section5PrimeSumCertificate

#print axioms PaperChronology.Section5PrimeSumCertificate.exact_table_sum
