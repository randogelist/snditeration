import PaperChronology.Section3ThreeAtomSharp

/-!
# Theorem 3.7 — degree-two Turan identity and strictness

This is the exact elementary real-rooted quadratic case of the paper's
Turán derivative expression. The finite algebra is proved independently;
the general degree-h real-rooted polynomial theorem remains separate.
-/

noncomputable section

namespace PaperChronology.Section3TuranQuadratic

/-- A monic polynomial of degree two with real roots a,b, evaluated at t. -/
def quadraticValue (a b t : ℚ) : ℚ := (t - a) * (t - b)

/-- Its first and second formal derivative values. -/
def quadraticFirst (a b t : ℚ) : ℚ := 2 * t - a - b

def quadraticSecond : ℚ := 2

/-- Exact Turán identity at quadratic degree. -/
theorem turan_quadratic_identity (a b t : ℚ) :
    (quadraticFirst a b t) ^ 2 -
      quadraticValue a b t * quadraticSecond =
        (t - a) ^ 2 + (t - b) ^ 2 := by
  unfold quadraticFirst quadraticValue quadraticSecond
  ring

/-- Nonnegativity requires only the real-root factorization. -/
theorem turan_quadratic_nonneg (a b t : ℚ) :
    0 ≤ (quadraticFirst a b t) ^ 2 -
      quadraticValue a b t * quadraticSecond := by
  rw [turan_quadratic_identity]
  exact add_nonneg (sq_nonneg _) (sq_nonneg _)

/-- Strict quadratic Turán inequality when the roots differ; it holds
at every rational evaluation point, not only away from the roots. -/
theorem turan_quadratic_strict (a b t : ℚ) (hab : a ≠ b) :
    0 < (quadraticFirst a b t) ^ 2 -
      quadraticValue a b t * quadraticSecond := by
  rw [turan_quadratic_identity]
  by_cases ht : t = a
  · rw [ht]
    simpa using (sq_pos_of_ne_zero (sub_ne_zero.mpr hab))
  · exact add_pos_of_pos_of_nonneg
      (sq_pos_of_ne_zero (sub_ne_zero.mpr ht)) (sq_nonneg _)

/-- The repeated-root case vanishes precisely at that common root. -/
theorem turan_repeated_at_root (a : ℚ) :
    (quadraticFirst a a a) ^ 2 -
      quadraticValue a a a * quadraticSecond = 0 := by
  rw [turan_quadratic_identity]
  ring

end PaperChronology.Section3TuranQuadratic

#print axioms PaperChronology.Section3TuranQuadratic.turan_quadratic_identity
#print axioms PaperChronology.Section3TuranQuadratic.turan_quadratic_nonneg
#print axioms PaperChronology.Section3TuranQuadratic.turan_quadratic_strict
