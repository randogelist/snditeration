import PaperChronology.Section3FiniteMomentRank

/-!
# Corollary 3.6 — finite Stieltjes rank, sharp at two and three atoms

These exact rational polynomial identities are unconditional finite algebra.
They correct the erroneous assertion of strictly positive Hankel minors of
arbitrary size for a finite spectral measure. The 2-atom Gram determinant
is positive at order 2 for positive weights and distinct support; at order 3
it vanishes. For three atoms, the 3 by 3 determinant is a squared
Vandermonde times positive masses; a nonzero cubic annihilates all three
nodes and produces a null direction at order 4.

There is no assumed RH, analytic moment identity, irrationality witness,
or tacit source theorem in this module.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3ThreeAtomSharp

open PaperChronology.Section3FiniteMomentRank

/-- Principal size-two Hankel determinant of a two-atom sequence. -/
def twoAtomHankel2 (w₁ w₂ x y : ℚ) : ℚ :=
  twoAtomMoment w₁ w₂ x y 0 * twoAtomMoment w₁ w₂ x y 2 -
    (twoAtomMoment w₁ w₂ x y 1) ^ 2

/-- Vandermonde-square formula, including the exact mass factors. -/
theorem two_atom_hankel2_factor (w₁ w₂ x y : ℚ) :
    twoAtomHankel2 w₁ w₂ x y = w₁ * w₂ * (x - y) ^ 2 := by
  unfold twoAtomHankel2 twoAtomMoment
  ring

/-- Sharp strict positivity at order two, under two distinct positive atoms. -/
theorem two_atom_hankel2_strict (w₁ w₂ x y : ℚ)
    (hw₁ : 0 < w₁) (hw₂ : 0 < w₂) (hxy : x ≠ y) :
    0 < twoAtomHankel2 w₁ w₂ x y := by
  rw [two_atom_hankel2_factor]
  exact mul_pos (mul_pos hw₁ hw₂)
    (sq_pos_of_ne_zero (sub_ne_zero.mpr hxy))

/-- When the two nodes coincide, the second-order determinant collapses. -/
theorem two_atom_hankel2_same_node (w₁ w₂ x : ℚ) :
    twoAtomHankel2 w₁ w₂ x x = 0 := by
  rw [two_atom_hankel2_factor]
  ring

/-- Moments of a three-point (possibly repeated) atomic measure. -/
def threeAtomMoment (w₁ w₂ w₃ x y z : ℚ) (n : ℕ) : ℚ :=
  w₁ * x ^ n + w₂ * y ^ n + w₃ * z ^ n

/-- Elementary symmetric coefficients of the monic cubic annihilator. -/
def cubicAnnihilator (x y z t : ℚ) : ℚ :=
  t ^ 3 - (x + y + z) * t ^ 2 +
    (x * y + x * z + y * z) * t - x * y * z

theorem cubic_annihilates_x (x y z : ℚ) :
    cubicAnnihilator x y z x = 0 := by
  unfold cubicAnnihilator
  ring

theorem cubic_annihilates_y (x y z : ℚ) :
    cubicAnnihilator x y z y = 0 := by
  unfold cubicAnnihilator
  ring

theorem cubic_annihilates_z (x y z : ℚ) :
    cubicAnnihilator x y z z = 0 := by
  unfold cubicAnnihilator
  ring

/-- Exact third-order recurrence for ALL moments of a three-point measure. -/
theorem three_atom_moment_recurrence (w₁ w₂ w₃ x y z : ℚ)
    (n : ℕ) :
    threeAtomMoment w₁ w₂ w₃ x y z (n + 3) -
      (x + y + z) * threeAtomMoment w₁ w₂ w₃ x y z (n + 2) +
      (x * y + x * z + y * z) *
        threeAtomMoment w₁ w₂ w₃ x y z (n + 1) -
      x * y * z * threeAtomMoment w₁ w₂ w₃ x y z n = 0 := by
  simp only [threeAtomMoment, pow_add, pow_one, pow_two, pow_succ]
  ring

/-- The quadratic-energy form associated with the first four monomials
has a nontrivial cubic null direction independent of the masses. -/
def threeAtomCubicEnergy
    (w₁ w₂ w₃ x y z c₀ c₁ c₂ c₃ : ℚ) : ℚ :=
  w₁ * (c₀ + c₁ * x + c₂ * x ^ 2 + c₃ * x ^ 3) ^ 2 +
  w₂ * (c₀ + c₁ * y + c₂ * y ^ 2 + c₃ * y ^ 3) ^ 2 +
  w₃ * (c₀ + c₁ * z + c₂ * z ^ 2 + c₃ * z ^ 3) ^ 2

/-- Nonzero coefficient vector (-(xyz), xy+xz+yz, -(x+y+z), 1)
is in the Gram-form kernel; in particular rank of the order-four Hankel
form is at most three. -/
theorem three_atom_cubic_kernel (w₁ w₂ w₃ x y z : ℚ) :
    threeAtomCubicEnergy w₁ w₂ w₃ x y z
      (-(x * y * z)) (x * y + x * z + y * z) (-(x + y + z)) 1 = 0 := by
  unfold threeAtomCubicEnergy
  ring

/-- Exact principal size-three determinant for three atomic masses. -/
def threeAtomHankel3 (w₁ w₂ w₃ x y z : ℚ) : ℚ :=
  let M := threeAtomMoment w₁ w₂ w₃ x y z
  M 0 * (M 2 * M 4 - M 3 ^ 2) -
    M 1 * (M 1 * M 4 - M 2 * M 3) +
    M 2 * (M 1 * M 3 - M 2 ^ 2)

/-- Gram-Vandermonde exact factorization in the three-atom case. -/
theorem three_atom_hankel3_factor (w₁ w₂ w₃ x y z : ℚ) :
    threeAtomHankel3 w₁ w₂ w₃ x y z =
      w₁ * w₂ * w₃ * (x - y) ^ 2 * (x - z) ^ 2 * (y - z) ^ 2 := by
  unfold threeAtomHankel3 threeAtomMoment
  ring

/-- Strict size-three positivity if and only if the three nodes are
pairwise distinct and all three masses are positive (forward implication
not needed for the transfer). -/
theorem three_atom_hankel3_strict (w₁ w₂ w₃ x y z : ℚ)
    (hw₁ : 0 < w₁) (hw₂ : 0 < w₂) (hw₃ : 0 < w₃)
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z) :
    0 < threeAtomHankel3 w₁ w₂ w₃ x y z := by
  rw [three_atom_hankel3_factor]
  have hm : 0 < w₁ * w₂ * w₃ := mul_pos (mul_pos hw₁ hw₂) hw₃
  have h1 : 0 < (x - y) ^ 2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hxy)
  have h2 : 0 < (x - z) ^ 2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hxz)
  have h3 : 0 < (y - z) ^ 2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hyz)
  exact mul_pos (mul_pos (mul_pos hm h1) h2) h3

end PaperChronology.Section3ThreeAtomSharp

#print axioms PaperChronology.Section3ThreeAtomSharp.two_atom_hankel2_factor
#print axioms PaperChronology.Section3ThreeAtomSharp.two_atom_hankel2_strict
#print axioms PaperChronology.Section3ThreeAtomSharp.three_atom_moment_recurrence
#print axioms PaperChronology.Section3ThreeAtomSharp.three_atom_cubic_kernel
#print axioms PaperChronology.Section3ThreeAtomSharp.three_atom_hankel3_factor
#print axioms PaperChronology.Section3ThreeAtomSharp.three_atom_hankel3_strict
