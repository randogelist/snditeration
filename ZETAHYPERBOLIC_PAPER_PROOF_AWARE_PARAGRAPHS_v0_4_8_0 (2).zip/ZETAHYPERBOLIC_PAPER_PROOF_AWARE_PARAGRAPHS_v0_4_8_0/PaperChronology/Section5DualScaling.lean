import PaperChronology.Section5DualFinite

/-!
# Theorems 5.2 and 6.7: functoriality of the finite dual Gram derivative
Column-basis scaling has exactly quadratic effect on coefficient matrix
and the row quadratic form. No analytic Krein-space tail is assumed.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section5DualScaling
open PaperChronology.Section5DualFinite

variable {h d : ℕ}

theorem gram_scale (C : Fin h → Fin d → ℚ) (a : ℚ)
    (i j : Fin h) :
    dualCoefficient (fun k r => a * C k r) i j =
      a ^ 2 * dualCoefficient C i j := by
  unfold dualCoefficient
  calc
    (∑ r : Fin d, (a * C i r) * (a * C j r)) =
      ∑ r : Fin d, a ^ 2 * (C i r * C j r) := by
        apply Finset.sum_congr rfl
        intro r _
        ring
    _ = a ^ 2 * ∑ r : Fin d, C i r * C j r := by
      rw [Finset.mul_sum]

theorem coefficient_energy_scale (C : Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) (a : ℚ) :
    coefficientEnergy (fun i r => a * C i r) v =
      a ^ 2 * coefficientEnergy C v := by
  unfold coefficientEnergy
  have hinner (r : Fin d) :
      (∑ i : Fin h, v i * (a * C i r)) =
        a * (∑ i : Fin h, v i * C i r) := by
    calc
      (∑ i : Fin h, v i * (a * C i r)) =
          ∑ i : Fin h, a * (v i * C i r) := by
            apply Finset.sum_congr rfl
            intro i _
            ring
      _ = a * ∑ i : Fin h, v i * C i r := by rw [Finset.mul_sum]
  calc
    (∑ r : Fin d, (∑ i : Fin h, v i * (a * C i r)) ^ 2) =
        ∑ r : Fin d, a ^ 2 * (∑ i : Fin h, v i * C i r) ^ 2 := by
          apply Finset.sum_congr rfl
          intro r _
          rw [hinner]
          ring
    _ = a ^ 2 * ∑ r : Fin d, (∑ i : Fin h, v i * C i r) ^ 2 := by
      rw [Finset.mul_sum]

end PaperChronology.Section5DualScaling
#print axioms PaperChronology.Section5DualScaling.gram_scale
#print axioms PaperChronology.Section5DualScaling.coefficient_energy_scale
