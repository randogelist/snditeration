import PaperChronology.Section5DualScaling

/-!
# Theorem 5.2: constructive finite-dimensional positive derivative
An explicit rational polynomial coefficient basis with identity coefficient
matrix has a strictly positive quadratic derivative for every nonzero vector.
This proves a concrete instance, not every rational polynomial subspace.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section5DualCoordinate
open PaperChronology.Section5DualFinite

variable {h : ℕ}

def identityCoefficients (i r : Fin h) : ℚ :=
  if i = r then 1 else 0

theorem coordinate_sum (v : Fin h → ℚ) (r : Fin h) :
    (∑ i : Fin h, v i * identityCoefficients i r) = v r := by
  simp [identityCoefficients, mul_ite]

theorem coordinate_energy (v : Fin h → ℚ) :
    coefficientEnergy identityCoefficients v =
      ∑ r : Fin h, (v r) ^ 2 := by
  unfold coefficientEnergy
  simp_rw [coordinate_sum]

theorem coordinate_row_injective
    (v : Fin h → ℚ)
    (hv : ∀ r : Fin h,
      (∑ i : Fin h, v i * identityCoefficients i r) = 0) :
    v = 0 := by
  funext r
  simpa only [coordinate_sum, Pi.zero_apply] using hv r

theorem coordinate_energy_strict (v : Fin h → ℚ) (hv : v ≠ 0) :
    0 < coefficientEnergy identityCoefficients v := by
  exact coefficientEnergy_positive_of_injective
    identityCoefficients coordinate_row_injective v hv

end PaperChronology.Section5DualCoordinate
#print axioms PaperChronology.Section5DualCoordinate.coordinate_energy
#print axioms PaperChronology.Section5DualCoordinate.coordinate_energy_strict
