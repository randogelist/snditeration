import PaperChronology.Section3FiniteGram
import PaperChronology.Section3PoleResidue

/-!
# Theorem 3.3: signed quadratic form on the actual closed residue products

The positive diagonal *closed coefficients* are fully arithmetic. An equality
with the derivative-defined source coefficient is a separate algebraic step;
the Gram integral and Sylvester inertia transfer are not asserted here.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3ClosedSignature

open PaperChronology.Section3PoleResidue
open PaperChronology.Section3FiniteGram

/-- A source-compatible diagonal whose entries are signed pole residues. -/
def signedWeight (N h m k : ℕ) (i : Fin h) : ℚ :=
  (-1 : ℚ) ^ (N + i.val) * closedPoleWeight N h i.val m k

/-- The closed negative-square pole sign cancels the alternating parity. -/
theorem signedWeight_pos (N h m k : ℕ) (hm : 0 < m) (i : Fin h) :
    0 < signedWeight N h m k i := by
  exact closedPoleWeight_alternating_sign N h i.val m k hm

/-- Finite positive signed energy; no assumptions on zeta. -/
theorem signedEnergy_pos (N h m k : ℕ) (hm : 0 < m)
    (v : Fin h → ℚ) (hv : v ≠ 0) :
    0 < energy (signedWeight N h m k) v := by
  exact energy_pos (signedWeight N h m k) v
    (signedWeight_pos N h m k hm) hv

end PaperChronology.Section3ClosedSignature

#print axioms PaperChronology.Section3ClosedSignature.signedWeight_pos
#print axioms PaperChronology.Section3ClosedSignature.signedEnergy_pos
