import PaperChronology.T5_3_Two_variable_Beukers_measure_and_dual_pencil_for_beta_4
import PaperChronology.PoleGenerators

/-!
# Theorem 5.4 — Cancellation of higher zeta values on even pole pairs

SOURCE: Zetahyperbolic PDF; Section 5.
STATUS: GENERATOR_PROVED
SOURCE MODULE: PaperChronology.PoleGenerators
SCOPE: For the paper-defined simple pole functional, telescoping rational cancellation is proved.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperChronology.even_pole_pair_for_positive_j
