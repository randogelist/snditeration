import PaperBlueprint.Chapter6

/-!
# Theorem 6.13(1): literal finite central-factorial Laplace mode annihilation

This file proves the ACTUAL preexisting source-level blueprint
`source_6_13_mode_annihilation`: the factor indexed by r = l + 1 vanishes
for 0 <= l <= k - 2. The PDF's further hyperbolic-secant differential
identity, positivity of the infinite Laplace expansion, and unilateral
root signature are NOT proved by this finite product lemma.

Source units 400-402, PDF p.43. No external assumptions or axioms.
-/

noncomputable section
namespace PaperChronology.Section6CentralFactorialModes

/-- The first k-1 central-factorial modes vanish, in exactly the
typed formulation used by the master Section 6 source blueprint. -/
theorem first_modes_vanish :
    PaperBlueprint.Chapter6.source_6_13_mode_annihilation := by
  intro k l hk hl
  unfold PaperBlueprint.Chapter6.centralFactorialMode
  have hmem : l + 1 ∈ Finset.Icc 1 (k - 1) :=
    Finset.mem_Icc.mpr ⟨by omega, by omega⟩
  apply Finset.prod_eq_zero hmem
  have hidx : 2 * (l + 1) - 1 = 2 * l + 1 := by omega
  simp [hidx]

end PaperChronology.Section6CentralFactorialModes
#print axioms PaperChronology.Section6CentralFactorialModes.first_modes_vanish
