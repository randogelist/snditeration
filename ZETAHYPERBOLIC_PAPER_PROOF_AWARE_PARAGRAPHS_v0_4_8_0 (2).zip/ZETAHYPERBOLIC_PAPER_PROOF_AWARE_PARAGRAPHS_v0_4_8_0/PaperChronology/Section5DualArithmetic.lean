import PaperChronology.Section3DerivativeBridge
import PaperChronology.PoleGenerators
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7

/-!
# Theorems 5.1, 5.2 and 6.2: finite two-variable moment arithmetic

The off-diagonal entries of the source's two-variable moment matrix are
rational divided differences.  Here their symmetry, finite adjacent-value
formula and the positive finite Gram energy are exposed directly.  The
underlying *integral* identity (5.2) remains independent analytic work.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section5DualArithmetic

open ManuscriptChain.Real

/-- Rational off-diagonal divided difference from (5.2). -/
def dividedDifference6 (r t : ℕ) : ℚ :=
  (harmonic 6 r - harmonic 6 t) / (6 * ((r : ℚ) - (t : ℚ)))

/-- Divided differences are symmetric although each numerator and
 denominator changes sign when the indices are exchanged. -/
theorem dividedDifference6_symm (r t : ℕ) :
    dividedDifference6 r t = dividedDifference6 t r := by
  unfold dividedDifference6
  -- Both signed differences flip simultaneously. Division is valid
  -- even when r = t: this is an identity in the totalized field ℚ.
  have hnum : harmonic 6 r - harmonic 6 t =
      -(harmonic 6 t - harmonic 6 r) := by ring
  have hden : (6 : ℚ) * ((r : ℚ) - (t : ℚ)) =
      -((6 : ℚ) * ((t : ℚ) - (r : ℚ))) := by ring
  calc
    (harmonic 6 r - harmonic 6 t) / (6 * ((r : ℚ) - (t : ℚ))) =
        (-(harmonic 6 t - harmonic 6 r)) /
          (-((6 : ℚ) * ((t : ℚ) - (r : ℚ)))) := by
            rw [hnum, hden]
    _ = (harmonic 6 t - harmonic 6 r) /
          (6 * ((t : ℚ) - (r : ℚ))) := by
            exact neg_div_neg_eq _ _

/-- Theorem 6.2(1), arithmetic part: the off-diagonal adjacent moment
 equals 1/(6(m+1)^6), a rational number. -/
theorem dividedDifference6_adjacent (m : ℕ) :
    dividedDifference6 m (m + 1) =
      1 / (6 * ((((m + 1 : ℕ) : ℚ)) ^ 6)) := by
  have hs := PaperChronology.harmonic_succ 6 m
  have hm : ((((m + 1 : ℕ) : ℚ)) ≠ 0) := by positivity
  have hdelta : (m : ℚ) - (((m + 1 : ℕ) : ℚ)) = -1 := by
    push_cast
    ring
  unfold dividedDifference6
  rw [hs, hdelta]
  field_simp [hm]
  ring

/-- The Section 5.1 dual moments are symmetric at all finite indices. -/
theorem dualConstant_seven_symmetric (r t : ℕ) :
    dualConstant 7 r t = dualConstant 7 t r := by
  by_cases h : r = t
  · subst t
    rfl
  · have ht : t ≠ r := Ne.symm h
    have hrt : dualConstant 7 r t = dividedDifference6 r t := by
      simp [dualConstant, dividedDifference6, h]
    have htr : dualConstant 7 t r = dividedDifference6 t r := by
      simp [dualConstant, dividedDifference6, ht]
    calc
      dualConstant 7 r t = dividedDifference6 r t := hrt
      _ = dividedDifference6 t r := dividedDifference6_symm r t
      _ = dualConstant 7 t r := htr.symm

/-- Theorem 5.2's derivative-form energy, expressed as an explicit finite
 sum of coefficient squares. -/
def coefficientEnergy {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) : ℚ :=
  ∑ r : Fin d, (∑ i : Fin h, v i * C i r)^2

/-- Every coefficient Gram energy is nonnegative, without any rank assumption. -/
theorem coefficientEnergy_nonneg {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) : 0 ≤ coefficientEnergy C v := by
  unfold coefficientEnergy
  apply Finset.sum_nonneg
  intro r hr
  exact sq_nonneg _

/-- Positivity whenever one coefficient is detected by the evaluation map.
The remaining strict positive-definite step is the *finite rank* fact
that a full row-rank matrix detects every nonzero vector. -/
theorem coefficientEnergy_pos_at {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) (r : Fin d)
    (hr : (∑ i : Fin h, v i * C i r) ≠ 0) :
    0 < coefficientEnergy C v := by
  unfold coefficientEnergy
  have hterms :
      ∀ t ∈ (Finset.univ : Finset (Fin d)),
        0 ≤ (∑ i : Fin h, v i * C i t)^2 := by
    intro t ht
    exact sq_nonneg _
  have hselected : 0 < (∑ i : Fin h, v i * C i r)^2 :=
    sq_pos_of_ne_zero hr
  have hselected_le :
      (∑ i : Fin h, v i * C i r)^2 ≤
        ∑ t : Fin d, (∑ i : Fin h, v i * C i t)^2 :=
    Finset.single_le_sum hterms (Finset.mem_univ r)
  exact lt_of_lt_of_le hselected hselected_le

/-- Source Theorem 5.2(1), the exact finite Gram-space mechanism.
An injective coefficient transpose map detects every nonzero vector;
consequently C*C^T has a strictly positive quadratic form. -/
theorem coefficientEnergy_pos_of_injective {h d : ℕ}
    (C : Fin h → Fin d → ℚ)
    (hC : ∀ v : Fin h → ℚ,
      (∀ r : Fin d, (∑ i : Fin h, v i * C i r) = 0) → v = 0)
    (v : Fin h → ℚ) (hv : v ≠ 0) :
    0 < coefficientEnergy C v := by
  classical
  by_contra hn
  have hzero : ∀ r : Fin d, (∑ i : Fin h, v i * C i r) = 0 := by
    intro r
    by_contra hr
    exact hn (coefficientEnergy_pos_at C v r hr)
  exact hv (hC v hzero)

end PaperChronology.Section5DualArithmetic

#print axioms PaperChronology.Section5DualArithmetic.coefficientEnergy_pos_of_injective
#print axioms PaperChronology.Section5DualArithmetic.dividedDifference6_symm
#print axioms PaperChronology.Section5DualArithmetic.dividedDifference6_adjacent
#print axioms PaperChronology.Section5DualArithmetic.dualConstant_seven_symmetric
#print axioms PaperChronology.Section5DualArithmetic.coefficientEnergy_nonneg
#print axioms PaperChronology.Section5DualArithmetic.coefficientEnergy_pos_at
