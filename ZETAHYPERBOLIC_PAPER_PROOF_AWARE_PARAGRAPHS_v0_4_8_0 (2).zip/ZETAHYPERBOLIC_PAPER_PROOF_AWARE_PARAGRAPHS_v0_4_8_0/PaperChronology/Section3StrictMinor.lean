import PaperChronology.Section3Signature

/-!
# Theorem 3.3: finite strict-total-positivity base case

For a positive discrete measure supported at two distinct real nodes,
the 2x2 Hankel determinant equals the positive weight product times the
squared node separation. This is an exact finite Vandermonde/Andreief
certificate, not a proof of the paper's full integral total positivity.

No analytic positivity hypothesis is silently attached to an actual zeta
weight. The source paper's Gram integral realization and higher minors
remain separate proof obligations.
-/

noncomputable section

namespace PaperChronology.Section3StrictMinor

/-- Zeroth, first and second moments of an arbitrary two-atom measure. -/
def moment0 (w₁ w₂ : ℝ) : ℝ := w₁ + w₂
def moment1 (w₁ w₂ x y : ℝ) : ℝ := w₁ * x + w₂ * y
def moment2 (w₁ w₂ x y : ℝ) : ℝ := w₁ * x ^ 2 + w₂ * y ^ 2

/-- Exact 2x2 Hankel/Vandermonde determinant identity. -/
theorem two_atom_minor_exact (w₁ w₂ x y : ℝ) :
    moment0 w₁ w₂ * moment2 w₁ w₂ x y -
      (moment1 w₁ w₂ x y) ^ 2 =
        w₁ * w₂ * (x - y) ^ 2 := by
  unfold moment0 moment1 moment2
  ring

/-- Strict 2x2 moment positivity for two distinct atoms of positive mass. -/
theorem two_atom_minor_pos (w₁ w₂ x y : ℝ)
    (hw₁ : 0 < w₁) (hw₂ : 0 < w₂) (hxy : x ≠ y) :
    0 < moment0 w₁ w₂ * moment2 w₁ w₂ x y -
      (moment1 w₁ w₂ x y) ^ 2 := by
  rw [two_atom_minor_exact]
  exact mul_pos (mul_pos hw₁ hw₂)
    (sq_pos_of_ne_zero (sub_ne_zero.mpr hxy))

end PaperChronology.Section3StrictMinor

#print axioms PaperChronology.Section3StrictMinor.two_atom_minor_exact
#print axioms PaperChronology.Section3StrictMinor.two_atom_minor_pos
