import PaperChronology.Section4SpectralTransfer

/-!
# Theorem 4.1: explicit consequences of a quantitative transfer certificate
These are consequences of an established RationalMeasure; they do not add
any hypothetical irrationality witness to the unconditional spectral core.
-/

noncomputable section
namespace PaperChronology.Section4MeasureConsequences
open ManuscriptChain.RealTransfer

theorem outside_all_forbidden_rational_balls
    {center : ℝ} {mu threshold : ℕ}
    (h : RationalMeasure center mu threshold)
    (a : ℤ) (b : ℕ) (hb : 0 < b) (hthreshold : threshold ≤ b) :
    ¬ |center - (a : ℝ) / (b : ℝ)| ≤ 1 / (b : ℝ) ^ mu := by
  exact not_le.mpr (h a b hb hthreshold)

theorem measure_persists_after_later_threshold
    {center : ℝ} {mu earlier later : ℕ}
    (h : RationalMeasure center mu earlier)
    (horder : earlier ≤ later) :
    RationalMeasure center mu later := by
  intro a b hb hlater
  exact h a b hb (le_trans horder hlater)

theorem quantitative_transfer_implies_irrationality
    {center : ℝ} {mu threshold : ℕ}
    (h : RationalMeasure center mu threshold) : Irrational center :=
  h.irrational

end PaperChronology.Section4MeasureConsequences
#print axioms PaperChronology.Section4MeasureConsequences.outside_all_forbidden_rational_balls
#print axioms PaperChronology.Section4MeasureConsequences.measure_persists_after_later_threshold
#print axioms PaperChronology.Section4MeasureConsequences.quantitative_transfer_implies_irrationality
