import PaperChronology.T2_3_Reflection_and_difference_identities_for_tau_X
import Theorem_2_4_Canonical_Basis_Invariance

/-!
# Theorem 2.4 — Canonical basis invariance

SOURCE: Zetahyperbolic PDF; Section 2.
STATUS: PROVED
SOURCE MODULE: Theorem_2_4_Canonical_Basis_Invariance
SCOPE: The basis-matrix determinant scaling and primitive normalization are proved.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check ManuscriptChain.BasisInvariance.theorem_2_4_canonical_basis_invariance
