import PaperChronology.T3_4_Root_interlacing_and_Dodgson_condensation_for_principal_minors
import PAPER_CORRECTIONS

/-!
# Corollary 3.5 — Stieltjes J-fraction from interlacing roots

SOURCE: Zetahyperbolic PDF; Section 3.
STATUS: CORRECTION_REQUIRED
SOURCE MODULE: PAPER_CORRECTIONS
SCOPE: Printed continued fraction is incorrectly scaled; cyclicity not established.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperCorrections.printed_fraction_sign_conflict
