import PaperChronology.Section6PoleBlockFinite

/-!
# Theorem 6.1: uniform two-pole determinant and signed quadratic cone

For any rational a != 0 and b, the symmetric 2x2 matrix
    [[0,a],[a,b]]
has determinant -a^2 < 0. Thus its two-dimensional quadratic form
has positive and negative directions. The concrete paper leading block
with a=1/6, b=-1 additionally has explicit rational witness vectors.
This is exact finite algebra, not the complete p-adic valuation theorem.
-/

noncomputable section
namespace PaperChronology.Section6TwoPoleSignature
open PaperChronology.Section6PoleBlockFinite

/-- The universal rational two-pole leading matrix. -/
def twoPoleBlock (a b : ℚ) : Matrix (Fin 2) (Fin 2) ℚ :=
  fun i j =>
    if i.val = 0 then
      if j.val = 0 then 0 else a
    else
      if j.val = 0 then a else b

/-- The exact determinant is independent of the diagonal parameter b. -/
theorem twoPoleBlock_det (a b : ℚ) :
    (twoPoleBlock a b).det = -(a ^ 2) := by
  simp [twoPoleBlock, Matrix.det_fin_two] <;> ring

/-- Every nonzero off-diagonal pole coupling gives negative determinant. -/
theorem twoPoleBlock_det_neg (a b : ℚ) (ha : a ≠ 0) :
    (twoPoleBlock a b).det < 0 := by
  rw [twoPoleBlock_det]
  have hsq : 0 < a ^ 2 := sq_pos_of_ne_zero ha
  linarith

/-- The manuscript's local block is exactly this universal matrix. -/
theorem actual_localBlock_eq :
    localBlock = twoPoleBlock (1 / 6) (-1) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [localBlock, twoPoleBlock]

/-- Quadratic energy of the *actual* two-pole rational leading block. -/
def localEnergy (x y : ℚ) : ℚ :=
  localBlock 0 0 * x ^ 2 +
    2 * localBlock 0 1 * x * y + localBlock 1 1 * y ^ 2

/-- A fully explicit positive direction in the local two-pole space. -/
theorem actual_positive_direction :
    0 < localEnergy 4 1 := by
  norm_num [localEnergy, localBlock]

/-- A fully explicit negative direction in the local two-pole space. -/
theorem actual_negative_direction :
    localEnergy 0 1 < 0 := by
  norm_num [localEnergy, localBlock]

/-- The leading local quadratic form has both signs with rational witnesses. -/
theorem actual_local_form_indefinite :
    (∃ x y : ℚ, 0 < localEnergy x y) ∧
    (∃ x y : ℚ, localEnergy x y < 0) := by
  exact ⟨⟨4, 1, actual_positive_direction⟩,
    ⟨0, 1, actual_negative_direction⟩⟩

end PaperChronology.Section6TwoPoleSignature
#print axioms PaperChronology.Section6TwoPoleSignature.twoPoleBlock_det
#print axioms PaperChronology.Section6TwoPoleSignature.actual_localBlock_eq
#print axioms PaperChronology.Section6TwoPoleSignature.actual_local_form_indefinite
