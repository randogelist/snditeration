import PaperChronology.Section3PoleKernel

/-!
# Theorem 6.1(3): exact leading two-pole rational block
The leading rational obstruction has determinant -1/36 and no nonzero
rational kernel. This is the finite algebraic part only, not the p-adic
valuation statement or a proof of nonvanishing of the full Hankel determinant.
-/

noncomputable section
namespace PaperChronology.Section6PoleBlockFinite

def localBlock : Matrix (Fin 2) (Fin 2) ℚ :=
  fun i j =>
    if i.val = 0 then
      if j.val = 0 then 0 else 1 / 6
    else
      if j.val = 0 then 1 / 6 else -1

theorem localBlock_det : localBlock.det = -(1 / 36 : ℚ) := by
  norm_num [localBlock, Matrix.det_fin_two]

theorem localBlock_det_ne_zero : localBlock.det ≠ 0 := by
  rw [localBlock_det]
  norm_num

theorem localBlock_kernel_trivial (x y : ℚ)
    (h0 : localBlock 0 0 * x + localBlock 0 1 * y = 0)
    (h1 : localBlock 1 0 * x + localBlock 1 1 * y = 0) :
    x = 0 ∧ y = 0 := by
  change (0 : ℚ) * x + (1 / 6 : ℚ) * y = 0 at h0
  change (1 / 6 : ℚ) * x + (-1 : ℚ) * y = 0 at h1
  constructor <;> linarith

end PaperChronology.Section6PoleBlockFinite
#print axioms PaperChronology.Section6PoleBlockFinite.localBlock_det
#print axioms PaperChronology.Section6PoleBlockFinite.localBlock_det_ne_zero
#print axioms PaperChronology.Section6PoleBlockFinite.localBlock_kernel_trivial
