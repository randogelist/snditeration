import PaperChronology.Section3TuranQuadratic

/-!
# Theorem 3.7: arbitrary-degree first Turan inequality

The exact identity T(P Q) = Q^2 T(P) + P^2 T(Q),
T(P) := (P')^2 - P P'', propagates nonnegativity from
real linear factors to every finite real-rooted polynomial.
For positive degree, T(P)(x) is strictly positive wherever P(x) is nonzero.
No derivative-real-rootedness theorem or zeta-specific analytic premise is used.
The m >= 2 statements and normalized-coefficient Newton inequalities in the
PDF are separate proof obligations.
-/

noncomputable section
open Polynomial

namespace PaperChronology.Section3TuranProduct

/-- Polynomial Turan operator, whose real evaluation equals
(P'(x))^2 - P(x) P''(x). -/
def turanPoly (P : Polynomial ℝ) : Polynomial ℝ :=
  (derivative P) ^ 2 - P * derivative (derivative P)

/-- The product rule implies an exact decomposition into two squares
multiplied by the factor Turanians. -/
theorem turanPoly_mul (P Q : Polynomial ℝ) :
    turanPoly (P * Q) = Q ^ 2 * turanPoly P + P ^ 2 * turanPoly Q := by
  unfold turanPoly
  simp only [derivative_mul, derivative_add]
  ring

/-- A constant polynomial has identically vanishing Turanian. -/
theorem turanPoly_constant (c : ℝ) : turanPoly (C c) = 0 := by
  simp [turanPoly]

/-- One real-root factor has identically unit Turanian. -/
def rootFactor (r : ℝ) : Polynomial ℝ := X + C (-r)

theorem turanPoly_rootFactor (r : ℝ) :
    turanPoly (rootFactor r) = 1 := by
  simp [rootFactor, turanPoly, derivative_add]

/-- Multiplying by a real constant scales the Turanian by a square. -/
theorem turanPoly_scale (c : ℝ) (P : Polynomial ℝ) :
    turanPoly (C c * P) = (C c) ^ 2 * turanPoly P := by
  rw [turanPoly_mul, turanPoly_constant]
  ring

/-- Finite, monic real-root product. -/
def monicRootProduct : List ℝ → Polynomial ℝ
  | [] => 1
  | r :: rs => rootFactor r * monicRootProduct rs

/-- All real-root products have nonnegative first Turanian, for all x. -/
theorem turan_monic_nonneg (rs : List ℝ) (x : ℝ) :
    0 ≤ (turanPoly (monicRootProduct rs)).eval x := by
  induction rs with
  | nil =>
      simp [monicRootProduct, turanPoly]
  | cons r rs ih =>
      change 0 ≤ (turanPoly (rootFactor r * monicRootProduct rs)).eval x
      rw [turanPoly_mul, turanPoly_rootFactor]
      simp only [Polynomial.eval_add, Polynomial.eval_mul,
        Polynomial.eval_pow, Polynomial.eval_one, mul_one]
      exact add_nonneg (sq_nonneg _) (mul_nonneg (sq_nonneg _) ih)

/-- Strict first Turan positivity for a product containing at least one
real factor, at every evaluation point away from all its real roots. -/
theorem turan_monic_pos_of_eval_ne_zero (r : ℝ) (rs : List ℝ) (x : ℝ)
    (hp : (monicRootProduct (r :: rs)).eval x ≠ 0) :
    0 < (turanPoly (monicRootProduct (r :: rs))).eval x := by
  have hq : (monicRootProduct rs).eval x ≠ 0 := by
    intro hz
    apply hp
    simp [monicRootProduct, Polynomial.eval_mul, hz]
  change 0 < (turanPoly (rootFactor r * monicRootProduct rs)).eval x
  rw [turanPoly_mul, turanPoly_rootFactor]
  simp only [Polynomial.eval_add, Polynomial.eval_mul,
    Polynomial.eval_pow, Polynomial.eval_one, mul_one]
  exact add_pos_of_pos_of_nonneg (sq_pos_of_ne_zero hq)
    (mul_nonneg (sq_nonneg _) (turan_monic_nonneg rs x))

/-- A scalar multiple of any finite real-root product has nonnegative Turanian. -/
theorem turan_scaled_nonneg (c : ℝ) (rs : List ℝ) (x : ℝ) :
    0 ≤ (turanPoly (C c * monicRootProduct rs)).eval x := by
  rw [turanPoly_scale]
  simp only [Polynomial.eval_mul, Polynomial.eval_pow, Polynomial.eval_C]
  exact mul_nonneg (sq_nonneg _) (turan_monic_nonneg rs x)

/-- Strict inequality for a real-split nonconstant polynomial with
nonzero leading coefficient at a point where it does not vanish. -/
theorem turan_scaled_pos (c r x : ℝ) (rs : List ℝ)
    (hc : c ≠ 0)
    (hp : (C c * monicRootProduct (r :: rs)).eval x ≠ 0) :
    0 < (turanPoly (C c * monicRootProduct (r :: rs))).eval x := by
  have hq : (monicRootProduct (r :: rs)).eval x ≠ 0 := by
    intro hz
    apply hp
    simp [Polynomial.eval_mul, hz]
  rw [turanPoly_scale]
  simp only [Polynomial.eval_mul, Polynomial.eval_pow, Polynomial.eval_C]
  exact mul_pos (sq_pos_of_ne_zero hc)
    (turan_monic_pos_of_eval_ne_zero r rs x hq)

/-- Exact correspondence with the derivative Turanian in Theorem 3.7. -/
theorem turan_eval (P : Polynomial ℝ) (x : ℝ) :
    (turanPoly P).eval x =
      ((derivative P).eval x) ^ 2 -
        P.eval x * (derivative (derivative P)).eval x := by
  simp [turanPoly, Polynomial.eval_sub, Polynomial.eval_mul,
    Polynomial.eval_pow]

/-- Mathematical certificate format for a real-split, nonconstant
polynomial, without assuming zeta or existence of an arithmetic witness. -/
def SplitPositiveDegree (P : Polynomial ℝ) : Prop :=
  ∃ (c r : ℝ) (rs : List ℝ), c ≠ 0 ∧
    P = C c * monicRootProduct (r :: rs)

/-- Complete first-order Turan consequence of the supplied finite
real-factorization certificate. -/
theorem split_turan_nonneg_and_strict (P : Polynomial ℝ)
    (hsplit : SplitPositiveDegree P) (x : ℝ) :
    (0 ≤ (turanPoly P).eval x) ∧
      (P.eval x ≠ 0 → 0 < (turanPoly P).eval x) := by
  rcases hsplit with ⟨c, r, rs, hc, hP⟩
  subst P
  constructor
  · exact turan_scaled_nonneg c (r :: rs) x
  · intro hne
    exact turan_scaled_pos c r x rs hc hne

end PaperChronology.Section3TuranProduct

#print axioms PaperChronology.Section3TuranProduct.turanPoly_mul
#print axioms PaperChronology.Section3TuranProduct.turanPoly_rootFactor
#print axioms PaperChronology.Section3TuranProduct.turanPoly_scale
#print axioms PaperChronology.Section3TuranProduct.turan_monic_nonneg
#print axioms PaperChronology.Section3TuranProduct.turan_monic_pos_of_eval_ne_zero
#print axioms PaperChronology.Section3TuranProduct.turan_scaled_nonneg
#print axioms PaperChronology.Section3TuranProduct.turan_scaled_pos
#print axioms PaperChronology.Section3TuranProduct.turan_eval
#print axioms PaperChronology.Section3TuranProduct.split_turan_nonneg_and_strict
