import PaperChronology.Section4FiniteSpectralBall

/-!
# Theorem 4.1 — compositional quantitative transfer

The paper's finite pencil factorization and integer-polynomial normalization
supply LocalComparison in the proved spectral transfer criterion. The *decay*,
*spectral growth* and *index budget* remain explicit premises. This theorem
provides an all-weight transfer and does not assert a new arithmetic witness.
-/

noncomputable section

namespace PaperChronology.Section4SpectralTransfer

open ManuscriptChain
open Polynomial

/-- Full conditional rational-measure implication, deriving local comparison
from the spectral factorization rather than assuming it separately. -/
theorem rational_measure_from_pencils
    (Q : ℕ → Polynomial ℤ) (center : ℝ) (dim : ℕ → ℕ)
    (pencil : ∀ j, Spectral.SymmetricAffinePencil (dim j))
    (bound scale budget : ℕ → ℝ) (onset μ b₀ : ℕ)
    (cert : ∀ j, onset ≤ j → Spectral.RootFactorization (pencil j))
    (hcenter : ∀ j, onset ≤ j → (pencil j).center = center)
    (hbound : ∀ j, onset ≤ j → 0 < bound j)
    (hbeta : ∀ j (hj : onset ≤ j) i, |(cert j hj).beta i| ≤ bound j)
    (hscale : ∀ j, onset ≤ j → scale j ≠ 0)
    (hnormalize : ∀ j, onset ≤ j → (pencil j).detPolynomial =
      Polynomial.C (scale j) * (Q j).map (algebraMap ℤ ℝ))
    (decay : RealTransfer.Decay Q center budget onset)
    (index : RealTransfer.IndexBudget Q (fun j =>
      Spectral.comparisonRadius (dim j) (bound j)) budget onset μ b₀) :
    RealTransfer.RationalMeasure center μ b₀ := by
  have comparison := Spectral.localComparison_of_spectral
    Q center dim pencil bound scale onset cert
    hcenter hbound hbeta hscale hnormalize
  exact RealTransfer.conditional_measure comparison decay index

/-- A single all-weight theorem also yields irrationality from the same
quantitative hypotheses, without an additional assumption. -/
theorem irrational_from_pencils
    (Q : ℕ → Polynomial ℤ) (center : ℝ) (dim : ℕ → ℕ)
    (pencil : ∀ j, Spectral.SymmetricAffinePencil (dim j))
    (bound scale budget : ℕ → ℝ) (onset μ b₀ : ℕ)
    (cert : ∀ j, onset ≤ j → Spectral.RootFactorization (pencil j))
    (hcenter : ∀ j, onset ≤ j → (pencil j).center = center)
    (hbound : ∀ j, onset ≤ j → 0 < bound j)
    (hbeta : ∀ j (hj : onset ≤ j) i, |(cert j hj).beta i| ≤ bound j)
    (hscale : ∀ j, onset ≤ j → scale j ≠ 0)
    (hnormalize : ∀ j, onset ≤ j → (pencil j).detPolynomial =
      Polynomial.C (scale j) * (Q j).map (algebraMap ℤ ℝ))
    (decay : RealTransfer.Decay Q center budget onset)
    (index : RealTransfer.IndexBudget Q (fun j =>
      Spectral.comparisonRadius (dim j) (bound j)) budget onset μ b₀) :
    Irrational center := by
  exact (rational_measure_from_pencils Q center dim pencil bound scale budget
    onset μ b₀ cert hcenter hbound hbeta hscale hnormalize decay index).irrational

end PaperChronology.Section4SpectralTransfer
