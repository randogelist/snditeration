import PaperChronology.Section3PoleKernel

/-!
# Theorem 3.8: exact finite pole-kernel characteristic identity

Let H be any real square matrix, V a pole-evaluation matrix and D the
(diagonal) pole derivative. The monomial coefficient operator
(V D Vᵀ)H and the pole operator D(Vᵀ H V) have not only equal
determinants but equal characteristic determinant pencils at every t:

  det(I + t (V D Vᵀ)H) = det(I + t D(Vᵀ H V)).

Here the parameter is inserted into one factor before multiplication.
The equality is the Weinstein-Aronszajn determinant identity.
No inverse Gram existence, analytic Christoffel-Darboux representation,
Jacobi differentiation or paper-level theorem closure is asserted.
-/

noncomputable section
namespace PaperChronology.Section3PoleKernelCharacteristic

open PaperChronology.Section3PoleKernel

variable {n : ℕ}

/-- The monomial-side finite characteristic pencil at real parameter t. -/
def coefficientPencil (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) (t : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  1 + V * (t • (Matrix.diagonal gamma * (V.transpose * H)))

/-- The dual pole-side finite characteristic pencil at the same parameter. -/
def polePencil (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) (t : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  1 + (t • (Matrix.diagonal gamma * (V.transpose * H))) * V

/-- Weinstein-Aronszajn: equality holds for *every* parameter and size. -/
theorem parameter_characteristic_det_eq
    (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) (t : ℝ) :
    (coefficientPencil H V gamma t).det =
      (polePencil H V gamma t).det := by
  unfold coefficientPencil polePencil
  exact Matrix.det_one_add_mul_comm V
    (t • (Matrix.diagonal gamma * (V.transpose * H)))

/-- Thus the zero locus of these finite characteristic pencils agrees. -/
theorem parameter_zero_iff
    (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) (t : ℝ) :
    (coefficientPencil H V gamma t).det = 0 ↔
      (polePencil H V gamma t).det = 0 := by
  rw [parameter_characteristic_det_eq]

/-- At t=1, the identity uses the *previously frozen* concrete
coefficientOperator and poleOperator, not newly defined surrogates. -/
theorem one_add_coefficient_det_eq_pole
    (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) :
    (1 + coefficientOperator H V gamma).det =
      (1 + poleOperator H V gamma).det := by
  simpa only [coefficientOperator, derivativeCoefficient,
    poleOperator, poleKernel, Matrix.mul_assoc] using
    (Matrix.det_one_add_mul_comm V
      (Matrix.diagonal gamma * (V.transpose * H)))

end PaperChronology.Section3PoleKernelCharacteristic
#print axioms PaperChronology.Section3PoleKernelCharacteristic.parameter_characteristic_det_eq
#print axioms PaperChronology.Section3PoleKernelCharacteristic.parameter_zero_iff
#print axioms PaperChronology.Section3PoleKernelCharacteristic.one_add_coefficient_det_eq_pole
