import PaperChronology.Section5DualFinite

/-!
# Theorem 5.2: the exact finite positive/negative cone algebra
At every finite truncation of a Krein expansion, the sign of the quadratic
form is controlled by its positive and negative square energies. This does
not truncate or assert the sign of the infinite Beukers remainder.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section5FiniteKrein

def signedSquareEnergy {hp hn : ℕ}
    (u : Fin hp → ℚ) (v : Fin hn → ℚ) : ℚ :=
  (∑ i : Fin hp, (u i) ^ 2) - (∑ j : Fin hn, (v j) ^ 2)

theorem positive_cone {hp hn : ℕ}
    (u : Fin hp → ℚ) (v : Fin hn → ℚ)
    (hv : ∀ j : Fin hn, v j = 0)
    (i : Fin hp) (hi : u i ≠ 0) :
    0 < signedSquareEnergy u v := by
  have hle : (u i) ^ 2 ≤ ∑ j : Fin hp, (u j) ^ 2 :=
    Finset.single_le_sum (fun j _ => sq_nonneg (u j)) (Finset.mem_univ i)
  have hpos : 0 < ∑ j : Fin hp, (u j) ^ 2 :=
    lt_of_lt_of_le (sq_pos_of_ne_zero hi) hle
  simpa [signedSquareEnergy, hv] using hpos

theorem negative_cone {hp hn : ℕ}
    (u : Fin hp → ℚ) (v : Fin hn → ℚ)
    (hu : ∀ i : Fin hp, u i = 0)
    (j : Fin hn) (hj : v j ≠ 0) :
    signedSquareEnergy u v < 0 := by
  have hle : (v j) ^ 2 ≤ ∑ i : Fin hn, (v i) ^ 2 :=
    Finset.single_le_sum (fun i _ => sq_nonneg (v i)) (Finset.mem_univ j)
  have hpos : 0 < ∑ i : Fin hn, (v i) ^ 2 :=
    lt_of_lt_of_le (sq_pos_of_ne_zero hj) hle
  have hneg : -(∑ i : Fin hn, (v i) ^ 2) < 0 := by linarith
  simpa [signedSquareEnergy, hu] using hneg

end PaperChronology.Section5FiniteKrein
#print axioms PaperChronology.Section5FiniteKrein.positive_cone
#print axioms PaperChronology.Section5FiniteKrein.negative_cone
