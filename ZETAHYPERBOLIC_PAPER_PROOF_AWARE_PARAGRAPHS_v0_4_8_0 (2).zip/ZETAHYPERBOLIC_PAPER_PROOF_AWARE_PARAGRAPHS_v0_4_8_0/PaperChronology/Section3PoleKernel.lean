import Zetahyperbolic.CoreLinearAlgebra

/-!
# Theorem 3.8 — finite pole-kernel linear-algebra bridge

The source paper's Christoffel–Darboux pole matrix is
  diag(gamma) * (V.transpose * G_inverse * V).

With H standing for an independently supplied matrix (subsequently the
actual inverse Gram matrix), this module proves finite structural identities:
  * the kernel is symmetric whenever H is symmetric;
  * the moment-space and pole-space operators intertwine through V;
  * their determinants agree and have the same explicit closed product;
  * nondegenerate H, V, and diagonal weights give nonzero determinant.

The spectral equivalence to the normalized symmetric operator B and the
analytic Christoffel–Darboux reproducing-kernel identification remain
separate bridges. No irrationality, decay, or RH premise is used.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3PoleKernel

variable {n : ℕ}

/-- The pole evaluation kernel built from a bilinear Gram inverse H and
    a matrix V of evaluation vectors in polynomial coefficient coordinates. -/
def poleKernel (H V : Matrix (Fin n) (Fin n) ℝ) :
    Matrix (Fin n) (Fin n) ℝ := V.transpose * H * V

/-- The derivative coefficient as the Lagrange congruence V diag(gamma) Vᵀ. -/
def derivativeCoefficient (V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  V * Matrix.diagonal gamma * V.transpose

/-- The operator in coefficient coordinates. -/
def coefficientOperator (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  derivativeCoefficient V gamma * H

/-- The operator in pole-value coordinates. -/
def poleOperator (H V : Matrix (Fin n) (Fin n) ℝ)
    (gamma : Fin n → ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  Matrix.diagonal gamma * poleKernel H V

/-- Symmetry of the finite reproducing-kernel matrix. -/
theorem poleKernel_transpose (H V : Matrix (Fin n) (Fin n) ℝ)
    (hH : H.transpose = H) :
    (poleKernel H V).transpose = poleKernel H V := by
  simp only [poleKernel, Matrix.transpose_mul,
    Matrix.transpose_transpose, hH, Matrix.mul_assoc]

/-- Exact, unconditional intertwining identity. Invertibility of V,
    available for distinct pole nodes, upgrades this to similarity. -/
theorem coefficient_pole_intertwine
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ) :
    coefficientOperator H V gamma * V =
      V * poleOperator H V gamma := by
  simp only [coefficientOperator, derivativeCoefficient, poleOperator,
    poleKernel, Matrix.mul_assoc]

/-- Closed determinant formula on the monomial-coefficient side. -/
theorem det_coefficientOperator
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ) :
    (coefficientOperator H V gamma).det =
      H.det * V.det ^ 2 * ∏ i, gamma i := by
  simp only [coefficientOperator, derivativeCoefficient,
    Matrix.det_mul, Matrix.det_diagonal, Matrix.det_transpose]
  ring

/-- Closed determinant formula on the pole-kernel side. -/
theorem det_poleOperator
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ) :
    (poleOperator H V gamma).det =
      H.det * V.det ^ 2 * ∏ i, gamma i := by
  simp only [poleOperator, poleKernel, Matrix.det_mul,
    Matrix.det_diagonal, Matrix.det_transpose]
  ring

/-- Equality of finite determinant invariants, without spectral assumptions. -/
theorem det_coefficient_eq_pole
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ) :
    (coefficientOperator H V gamma).det =
      (poleOperator H V gamma).det := by
  rw [det_coefficientOperator, det_poleOperator]

/-- Nonsingularity of the finite pole operator under the three
    explicit nonvanishing inputs. -/
theorem det_poleOperator_ne_zero
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ)
    (hH : H.det ≠ 0) (hV : V.det ≠ 0)
    (hgamma : ∀ i, gamma i ≠ 0) :
    (poleOperator H V gamma).det ≠ 0 := by
  rw [det_poleOperator]
  apply mul_ne_zero
  · exact mul_ne_zero hH (pow_ne_zero 2 hV)
  · apply Finset.prod_ne_zero_iff.mpr
    intro i hi
    exact hgamma i

/-- Corresponding coefficient-space nonsingularity. -/
theorem det_coefficientOperator_ne_zero
    (H V : Matrix (Fin n) (Fin n) ℝ) (gamma : Fin n → ℝ)
    (hH : H.det ≠ 0) (hV : V.det ≠ 0)
    (hgamma : ∀ i, gamma i ≠ 0) :
    (coefficientOperator H V gamma).det ≠ 0 := by
  rw [det_coefficient_eq_pole]
  exact det_poleOperator_ne_zero H V gamma hH hV hgamma

end PaperChronology.Section3PoleKernel

#print axioms PaperChronology.Section3PoleKernel.poleKernel_transpose
#print axioms PaperChronology.Section3PoleKernel.coefficient_pole_intertwine
#print axioms PaperChronology.Section3PoleKernel.det_coefficientOperator
#print axioms PaperChronology.Section3PoleKernel.det_poleOperator
#print axioms PaperChronology.Section3PoleKernel.det_coefficient_eq_pole
#print axioms PaperChronology.Section3PoleKernel.det_poleOperator_ne_zero
#print axioms PaperChronology.Section3PoleKernel.det_coefficientOperator_ne_zero
