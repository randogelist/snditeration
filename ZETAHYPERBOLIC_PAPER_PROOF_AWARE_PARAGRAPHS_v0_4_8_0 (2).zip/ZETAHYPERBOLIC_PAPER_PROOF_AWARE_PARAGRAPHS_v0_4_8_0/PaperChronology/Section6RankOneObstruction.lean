import PaperChronology.Section6PoleBlockFinite

/-!
# Theorem 6.15(2): exact rank-one obstruction in finite dimension two
A rank-one coefficient derivative cannot have nonzero determinant at 2x2.
This proves a concrete universal algebraic obstruction and does not assert
any transcendence or irrationality consequence for beta values.
-/

noncomputable section
namespace PaperChronology.Section6RankOneObstruction

def rankOne2 (u v : Fin 2 → ℚ) : Matrix (Fin 2) (Fin 2) ℚ :=
  fun i j => u i * v j

theorem rankOne2_det_zero (u v : Fin 2 → ℚ) :
    (rankOne2 u v).det = 0 := by
  simp only [rankOne2, Matrix.det_fin_two]
  ring

end PaperChronology.Section6RankOneObstruction
#print axioms PaperChronology.Section6RankOneObstruction.rankOne2_det_zero
