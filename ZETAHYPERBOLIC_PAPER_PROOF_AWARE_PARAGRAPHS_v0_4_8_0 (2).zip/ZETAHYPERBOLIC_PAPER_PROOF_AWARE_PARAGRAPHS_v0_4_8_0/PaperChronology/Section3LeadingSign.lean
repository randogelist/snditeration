import PaperChronology.Section3Continuous

/-!
# Theorem 3.3 -- finite sign computation (dependency-isolated revision)

The only import is the native-verified `PaperChronology.Section3Continuous`,
which already exposes the paper's polynomial definitions and the required
ring/positivity infrastructure. In particular this file does NOT import
`Theorem_2_5_Lagrange_Pole_Diagonalization`, `Mathlib.Tactic.Linarith`,
`Mathlib.Tactic.NormNum`, or `Mathlib.Tactic.Omega`.

It proves exactly the finite numerator-sign and exponent-parity statements,
not the full strict total positivity, Carleman, or inertia theorems.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology.Section3LeadingSign

/-- Positive factors controlling the numerator sign at a negative square pole. -/
def positiveNumeratorProduct (N a : ℕ) : ℚ :=
  ∏ j ∈ Finset.range N, ((a : ℚ) ^ 2 - ((j + 1 : ℕ) : ℚ) ^ 2)

/-- Every factor is positive if the pole index `a` exceeds `N`. -/
theorem positiveNumeratorProduct_pos (N a : ℕ) (ha : N < a) :
    0 < positiveNumeratorProduct N a := by
  unfold positiveNumeratorProduct
  apply Finset.prod_pos
  intro j hj
  have hjN : j < N := Finset.mem_range.mp hj
  have hjA : j + 1 < a :=
    lt_of_le_of_lt (Nat.succ_le_of_lt hjN) ha
  have hlt : (((j + 1 : ℕ) : ℚ)) < (a : ℚ) := by
    exact_mod_cast hjA
  have hjzero : (0 : ℚ) ≤ (((j + 1 : ℕ) : ℚ)) := Nat.cast_nonneg _
  have ha_pos : (0 : ℚ) < (a : ℚ) := lt_of_le_of_lt hjzero hlt
  have hdiff : 0 < (a : ℚ) - (((j + 1 : ℕ) : ℚ)) := sub_pos.mpr hlt
  have hsum : 0 < (a : ℚ) + (((j + 1 : ℕ) : ℚ)) :=
    add_pos_of_pos_of_nonneg ha_pos hjzero
  calc
    0 < ((a : ℚ) - (((j + 1 : ℕ) : ℚ))) *
        ((a : ℚ) + (((j + 1 : ℕ) : ℚ))) := mul_pos hdiff hsum
    _ = (a : ℚ) ^ 2 - (((j + 1 : ℕ) : ℚ)) ^ 2 := by ring

/-- Equation (2.11): exact evaluation of the source's denominator polynomial. -/
theorem D_evaluation_signed_product (N a : ℕ) :
    (ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2) =
      (-1 : ℚ) ^ N * positiveNumeratorProduct N a := by
  simp only [ManuscriptChain.Real.D, Polynomial.eval_prod, Polynomial.eval_add,
    Polynomial.eval_X, Polynomial.eval_C, positiveNumeratorProduct]
  calc
    (∏ j ∈ Finset.range N,
      (-(a : ℚ) ^ 2 + (((j + 1 : ℕ) : ℚ) ^ 2))) =
        ∏ j ∈ Finset.range N,
          ((-1 : ℚ) * ((a : ℚ) ^ 2 - (((j + 1 : ℕ) : ℚ) ^ 2))) := by
          apply Finset.prod_congr rfl
          intro j hj
          ring
    _ = (-1 : ℚ) ^ N *
        ∏ j ∈ Finset.range N,
          ((a : ℚ) ^ 2 - (((j + 1 : ℕ) : ℚ) ^ 2)) := by
          rw [Finset.prod_mul_distrib]
          simp

/-- The sign of `D_N(-a²)` is `(-1)^N` for every pole index `a>N`. -/
theorem D_evaluation_sign (N a : ℕ) (ha : N < a) :
    0 < (-1 : ℚ) ^ N *
      (ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2) := by
  rw [D_evaluation_signed_product]
  have hpow : (-1 : ℚ) ^ N * (-1 : ℚ) ^ N = 1 := by
    simpa using (mul_pow (-1 : ℚ) (-1 : ℚ) N).symm
  rw [← mul_assoc, hpow, one_mul]
  exact positiveNumeratorProduct_pos N a ha

/-- Elementary natural-number equalities needed for the exponent parity. -/
private theorem exponent_arithmetic (m N a : ℕ)
    (hm : 0 < m) (ha : N < a) :
    (2 * m - 1) * N + (a - N - 1) =
      2 * ((m - 1) * N) + (a - 1) := by
  have hm_ge : 1 ≤ m := Nat.succ_le_of_lt hm
  have hm1 : m - 1 + 1 = m := Nat.sub_add_cancel hm_ge
  have hmul : 2 * m = (2 * (m - 1) + 1) + 1 := by
    calc
      2 * m = 2 * (m - 1 + 1) := by rw [hm1]
      _ = (2 * (m - 1) + 1) + 1 := by ring
  have hm' : 2 * m - 1 = 2 * (m - 1) + 1 := by
    calc
      2 * m - 1 = ((2 * (m - 1) + 1) + 1) - 1 := by rw [hmul]
      _ = 2 * (m - 1) + 1 := by simp
  have hna : N ≤ a - 1 := Nat.le_pred_of_lt ha
  have hcomm : a - N - 1 = (a - 1) - N := by
    simp only [Nat.sub_sub]
    rw [Nat.add_comm N 1]
  have hsum : N + (a - N - 1) = a - 1 := by
    rw [hcomm, Nat.add_comm]
    exact Nat.sub_add_cancel hna
  calc
    (2 * m - 1) * N + (a - N - 1) =
        (2 * (m - 1) + 1) * N + (a - N - 1) := by rw [hm']
    _ = 2 * ((m - 1) * N) + (N + (a - N - 1)) := by ring
    _ = 2 * ((m - 1) * N) + (a - 1) := by rw [hsum]

/-- Sign of the residue coefficient is independent of `m` and `N`. -/
theorem residue_sign_exponent_cancellation (m N a : ℕ)
    (hm : 0 < m) (ha : N < a) :
    (-1 : ℚ) ^ ((2 * m - 1) * N + (a - N - 1)) =
      (-1 : ℚ) ^ (a - 1) := by
  rw [exponent_arithmetic m N a hm ha, pow_add, pow_mul]
  simp

end PaperChronology.Section3LeadingSign

#print axioms PaperChronology.Section3LeadingSign.positiveNumeratorProduct_pos
#print axioms PaperChronology.Section3LeadingSign.D_evaluation_signed_product
#print axioms PaperChronology.Section3LeadingSign.D_evaluation_sign
#print axioms PaperChronology.Section3LeadingSign.residue_sign_exponent_cancellation
