import Zetahyperbolic.CoreLinearAlgebra

/-!
# Corrected Corollary 3.6 — arbitrary finite spectral support

The paper's reciprocal-root moments are obtained from a FINITE atomic
measure at each fixed K.  Consequently, their Hankel forms are positive
semidefinite, but they cannot be strictly positive definite at every
matrix order.  This module constructs an explicit nonzero annihilating
polynomial for any finite real support, including repeated support points.

This is the general finite-support obstruction (not merely the earlier
2- and 3-atom examples).  No analytic continuation, prime estimate,
irrationality, RH, or arithmetic witness is assumed.

The unrestricted PDF Corollary 3.6 must be corrected: strictness of the
Hankel form can hold only below the support's effective cardinality,
and that strictness needs distinct atoms with positive masses.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperChronology.Section3FiniteSupport

/-- A monic polynomial that vanishes on an arbitrary list of real atoms. -/
def rootPolynomial {h : ℕ} (u : Fin h → ℝ) : Polynomial ℝ :=
  ∏ i : Fin h, (X + C (-(u i)))

/-- Evaluation is the product of the linear factors, without assuming that
    any of the spectral atoms are distinct. -/
theorem rootPolynomial_eval {h : ℕ} (u : Fin h → ℝ) (t : ℝ) :
    (rootPolynomial u).eval t = ∏ i : Fin h, (t - u i) := by
  classical
  simp [rootPolynomial, Polynomial.eval_prod, sub_eq_add_neg]

/-- One factor vanishes at every atom of the finite support. -/
theorem rootPolynomial_eval_at_atom {h : ℕ} (u : Fin h → ℝ) (i : Fin h) :
    (rootPolynomial u).eval (u i) = 0 := by
  rw [rootPolynomial_eval]
  exact Finset.prod_eq_zero (Finset.mem_univ i) (sub_self _)

/-- The annihilating polynomial is MONIC, so it is not the zero polynomial. -/
theorem rootPolynomial_monic {h : ℕ} (u : Fin h → ℝ) :
    (rootPolynomial u).Monic := by
  classical
  unfold rootPolynomial
  exact monic_prod_of_monic Finset.univ
    (fun i : Fin h => (X + C (-(u i)) : Polynomial ℝ))
    (by intro i hi; exact monic_X_add_C _)

/-- Even for empty or repeated support, the annihilator is nonzero. -/
theorem rootPolynomial_ne_zero {h : ℕ} (u : Fin h → ℝ) :
    rootPolynomial u ≠ 0 := (rootPolynomial_monic u).ne_zero

/-- The quadratic form of the Hankel moments expressed through evaluations
    of a polynomial at the support points. -/
def polynomialEnergy {h : ℕ} (w u : Fin h → ℝ)
    (P : Polynomial ℝ) : ℝ :=
  ∑ i : Fin h, w i * ((P.eval (u i)) ^ 2)

/-- Nonnegative masses give nonnegative Gram energy for EVERY polynomial. -/
theorem polynomialEnergy_nonneg {h : ℕ} (w u : Fin h → ℝ)
    (hw : ∀ i, 0 ≤ w i) (P : Polynomial ℝ) :
    0 ≤ polynomialEnergy w u P := by
  unfold polynomialEnergy
  apply Finset.sum_nonneg
  intro i hi
  exact mul_nonneg (hw i) (sq_nonneg _)

/-- The explicit nonzero annihilator is a null direction, regardless of the
    masses and regardless of whether any two nodes coincide. -/
theorem polynomialEnergy_annihilator_zero {h : ℕ} (w u : Fin h → ℝ) :
    polynomialEnergy w u (rootPolynomial u) = 0 := by
  simp [polynomialEnergy, rootPolynomial_eval_at_atom]

/-- Corrected finite-spectral-support theorem: even for strictly POSITIVE
    masses, a finite atomic Hankel quadratic form is never positive definite
    on the ENTIRE infinite-dimensional polynomial space. -/
theorem finite_support_not_strictly_positive_definite {h : ℕ}
    (w u : Fin h → ℝ) :
    ¬ (∀ P : Polynomial ℝ, P ≠ 0 → 0 < polynomialEnergy w u P) := by
  intro hpd
  have hp := hpd (rootPolynomial u) (rootPolynomial_ne_zero u)
  rw [polynomialEnergy_annihilator_zero] at hp
  exact (lt_irrefl (0 : ℝ)) hp

/-- A coordinate-free version of the finite-moment recurrence.  It is
    equivalent to annihilation of a shift of the discrete moment sequence,
    before coefficients of the monic polynomial are expanded. -/
theorem finite_moment_annihilator_relation {h : ℕ}
    (w u : Fin h → ℝ) (n : ℕ) :
    (∑ i : Fin h, w i * u i ^ n * (rootPolynomial u).eval (u i)) = 0 := by
  simp [rootPolynomial_eval_at_atom]

end PaperChronology.Section3FiniteSupport

#print axioms PaperChronology.Section3FiniteSupport.rootPolynomial_monic
#print axioms PaperChronology.Section3FiniteSupport.rootPolynomial_eval_at_atom
#print axioms PaperChronology.Section3FiniteSupport.polynomialEnergy_nonneg
#print axioms PaperChronology.Section3FiniteSupport.polynomialEnergy_annihilator_zero
#print axioms PaperChronology.Section3FiniteSupport.finite_support_not_strictly_positive_definite
#print axioms PaperChronology.Section3FiniteSupport.finite_moment_annihilator_relation
