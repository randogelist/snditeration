import PaperChronology.Section5DualFinite

/-!
# Theorems 6.6 and 6.16: unconditional finite multi-weight Gram energy
For a family of coefficient maps C_k and nonnegative scalar weights alpha_k,
their aggregate derivative quadratic form is semidefinite; one strictly
positive-weight full-row-rank component makes it strictly definite.
No external zeta or beta decay premise is used in this finite theorem.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section6MultiweightGram
open PaperChronology.Section5DualFinite

variable {s h d : ℕ}

def multiweightEnergy (alpha : Fin s → ℚ)
    (C : Fin s → Fin h → Fin d → ℚ) (v : Fin h → ℚ) : ℚ :=
  ∑ k : Fin s, alpha k * coefficientEnergy (C k) v

theorem multiweight_nonnegative
    (alpha : Fin s → ℚ) (C : Fin s → Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) (hα : ∀ k, 0 ≤ alpha k) :
    0 ≤ multiweightEnergy alpha C v := by
  unfold multiweightEnergy
  apply Finset.sum_nonneg
  intro k _
  exact mul_nonneg (hα k) (coefficientEnergy_nonnegative (C k) v)

theorem multiweight_positive_at
    (alpha : Fin s → ℚ) (C : Fin s → Fin h → Fin d → ℚ)
    (v : Fin h → ℚ)
    (hα : ∀ k, 0 ≤ alpha k)
    (k : Fin s) (hk : 0 < alpha k)
    (henergy : 0 < coefficientEnergy (C k) v) :
    0 < multiweightEnergy alpha C v := by
  have hle : alpha k * coefficientEnergy (C k) v ≤
      ∑ j : Fin s, alpha j * coefficientEnergy (C j) v :=
    Finset.single_le_sum
      (fun j _ => mul_nonneg (hα j) (coefficientEnergy_nonnegative (C j) v))
      (Finset.mem_univ k)
  exact lt_of_lt_of_le (mul_pos hk henergy) hle

theorem multiweight_positive_of_one_injective
    (alpha : Fin s → ℚ) (C : Fin s → Fin h → Fin d → ℚ)
    (v : Fin h → ℚ)
    (hα : ∀ k, 0 ≤ alpha k)
    (k : Fin s) (hk : 0 < alpha k)
    (hinj : ∀ w : Fin h → ℚ,
      (∀ r : Fin d, (∑ i : Fin h, w i * C k i r) = 0) → w = 0)
    (hv : v ≠ 0) :
    0 < multiweightEnergy alpha C v := by
  apply multiweight_positive_at alpha C v hα k hk
  exact coefficientEnergy_positive_of_injective (C k) hinj v hv

end PaperChronology.Section6MultiweightGram
#print axioms PaperChronology.Section6MultiweightGram.multiweight_nonnegative
#print axioms PaperChronology.Section6MultiweightGram.multiweight_positive_at
#print axioms PaperChronology.Section6MultiweightGram.multiweight_positive_of_one_injective
