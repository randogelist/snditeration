import PaperChronology.Section3TuranQuadratic

/-!
# Theorem 4.1 — finite rational root-gap exclusion

If a rational candidate q lies closer to xi than xi is to each root of
a finite list, q is not a root and the product of its root factors is
nonzero. This is the finite nonvanishing ingredient in the paper's
integer-polynomial transfer. No quadratic decay, degree asymptotics,
or irrationality measure is inferred here.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section4FiniteRootGap

/-- Strict separation from a root excludes coincidence. -/
theorem not_root_of_closer (xi q r : ℚ)
    (h : |q - xi| < |r - xi|) : q ≠ r := by
  intro heq
  subst q
  exact (lt_irrefl _) h

/-- Pointwise exclusion of a rational approximation from a finite root list. -/
theorem excludes_all_finite_roots {h : ℕ}
    (xi q : ℚ) (roots : Fin h → ℚ)
    (hgap : ∀ i, |q - xi| < |roots i - xi|) :
    ∀ i, q ≠ roots i := by
  intro i
  exact not_root_of_closer xi q (roots i) (hgap i)

/-- Finite product of rational root factors. -/
def rootFactorProduct {h : ℕ} (roots : Fin h → ℚ) (q : ℚ) : ℚ :=
  ∏ i : Fin h, (q - roots i)

/-- Spectral separation makes the whole factor product nonzero, not just
its individual factors. This is what the denominator-clearing step needs. -/
theorem rootFactorProduct_ne_zero {h : ℕ}
    (xi q : ℚ) (roots : Fin h → ℚ)
    (hgap : ∀ i, |q - xi| < |roots i - xi|) :
    rootFactorProduct roots q ≠ 0 := by
  classical
  unfold rootFactorProduct
  apply Finset.prod_ne_zero_iff.mpr
  intro i hi
  exact sub_ne_zero.mpr (excludes_all_finite_roots xi q roots hgap i)

end PaperChronology.Section4FiniteRootGap

#print axioms PaperChronology.Section4FiniteRootGap.not_root_of_closer
#print axioms PaperChronology.Section4FiniteRootGap.excludes_all_finite_roots
#print axioms PaperChronology.Section4FiniteRootGap.rootFactorProduct_ne_zero
