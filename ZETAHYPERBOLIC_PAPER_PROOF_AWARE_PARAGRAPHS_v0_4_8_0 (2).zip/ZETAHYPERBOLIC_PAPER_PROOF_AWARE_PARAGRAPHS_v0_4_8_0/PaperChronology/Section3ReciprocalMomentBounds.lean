import PaperChronology.Section3StieltjesShifts

/-!
# Manuscript Corollary 3.6, finite reciprocal-root squeeze

The manuscript's PDF source unit 88, p.11, uses the positive atomic
moment S_(2r) = sum_i u_i^r and compares it to the largest support node.
This is the exact FINITE inequality, here for arbitrary nonnegative atoms.
The original unbounded strict-Hankel-determinants claim is not reinstated.
No limit as r -> infinity or zeta-specific root estimate is asserted.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section3ReciprocalMomentBounds

/-- An unweighted finite atomic moment at nonnegative support. -/
def unweightedMoment {h : ℕ} (u : Fin h → ℝ) (r : ℕ) : ℝ :=
  PaperChronology.Section3StieltjesShifts.atomicMoment (fun _ => 1) u r

/-- Each nonnegative summand is bounded above by the whole moment. -/
theorem each_atom_power_le_moment {h : ℕ}
    (u : Fin h → ℝ) (hu : ∀ i, 0 ≤ u i)
    (r : ℕ) (i : Fin h) :
    (u i) ^ r ≤ unweightedMoment u r := by
  unfold unweightedMoment PaperChronology.Section3StieltjesShifts.atomicMoment
  simp only [one_mul]
  exact Finset.single_le_sum
    (fun j _ => pow_nonneg (hu j) r) (Finset.mem_univ i)

/-- The full moment is bounded by h times a common support bound. -/
theorem moment_le_card_mul_pow {h : ℕ}
    (u : Fin h → ℝ) (hu : ∀ i, 0 ≤ u i)
    (M : ℝ) (hM : ∀ i, u i ≤ M) (r : ℕ) :
    unweightedMoment u r ≤ (h : ℝ) * M ^ r := by
  unfold unweightedMoment PaperChronology.Section3StieltjesShifts.atomicMoment
  simp only [one_mul]
  calc
    (∑ i : Fin h, (u i) ^ r) ≤ ∑ _i : Fin h, M ^ r := by
      apply Finset.sum_le_sum
      intro i _
      exact pow_le_pow_left₀ (hu i) (hM i) r
    _ = (h : ℝ) * M ^ r := by simp

/-- The sharp elementary finite squeeze when M is an attained maximum.
No claim of strict positive-definiteness in ranks above the support size. -/
theorem finite_moment_squeeze {h : ℕ}
    (u : Fin h → ℝ) (hu : ∀ i, 0 ≤ u i)
    (M : ℝ) (hM : ∀ i, u i ≤ M)
    (i : Fin h) (hi : u i = M) (r : ℕ) :
    M ^ r ≤ unweightedMoment u r ∧
      unweightedMoment u r ≤ (h : ℝ) * M ^ r := by
  constructor
  · rw [← hi]
    exact each_atom_power_le_moment u hu r i
  · exact moment_le_card_mul_pow u hu M hM r

end PaperChronology.Section3ReciprocalMomentBounds
#print axioms PaperChronology.Section3ReciprocalMomentBounds.each_atom_power_le_moment
#print axioms PaperChronology.Section3ReciprocalMomentBounds.moment_le_card_mul_pow
#print axioms PaperChronology.Section3ReciprocalMomentBounds.finite_moment_squeeze
