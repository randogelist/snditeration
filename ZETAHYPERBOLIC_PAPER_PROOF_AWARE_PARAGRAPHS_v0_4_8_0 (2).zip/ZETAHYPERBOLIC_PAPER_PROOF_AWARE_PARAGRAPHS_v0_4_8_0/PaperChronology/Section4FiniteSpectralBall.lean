import Theorem_4_1_Spectral_Irrationality_Measure_Criterion

/-!
# Theorem 4.1 — finite spectral ball without a separate comparison hypothesis

If every real spectral coefficient is bounded by B>0, no determinant root
can lie at real distance <1/B from the center. This is the finite spectral
mechanism; it does not supply the paper's asymptotic B=exp(rho*K).
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section4FiniteSpectralBall

open ManuscriptChain.Spectral

variable {n : ℕ} {p : SymmetricAffinePencil n}

/-- A bounded real eigenvalue cannot cause a zero in the strict ball. -/
theorem factor_strict_pos (c : RootFactorization p) (B x : ℝ)
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hx : |x - p.center| < 1 / B) (i : Fin n) :
    0 < 1 + (x - p.center) * c.beta i := by
  have hBnz : B ≠ 0 := ne_of_gt hB
  have ha : |x - p.center| * |c.beta i| ≤ |x - p.center| * B :=
    mul_le_mul_of_nonneg_left (hbeta i) (abs_nonneg _)
  have hb : |x - p.center| * B < 1 := by
    calc
      |x - p.center| * B < (1 / B) * B :=
        mul_lt_mul_of_pos_right hx hB
      _ = 1 := by simpa only [one_div] using (inv_mul_cancel₀ hBnz)
  have habs : |(x - p.center) * c.beta i| < 1 := by
    rw [abs_mul]
    exact lt_of_le_of_lt ha hb
  have hleft : -1 < (x - p.center) * c.beta i := (abs_lt.mp habs).1
  linarith

/-- Real determinant nonvanishing in the exact coarse spectral disk. -/
theorem determinant_ne_zero (c : RootFactorization p) (B x : ℝ)
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hx : |x - p.center| < 1 / B) :
    p.detPolynomial.eval x ≠ 0 := by
  have hprod : 0 < ∏ i : Fin n, (1 + (x - p.center) * c.beta i) :=
    Finset.prod_pos (fun i _ => factor_strict_pos c B x hB hbeta hx i)
  rw [c.eval_eq]
  exact mul_ne_zero c.base_det_ne_zero (ne_of_gt hprod)

/-- Every real determinant root is outside the coarse spectral disk. -/
theorem root_distance_lower_bound (c : RootFactorization p) (B x : ℝ)
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hroot : p.detPolynomial.eval x = 0) :
    1 / B ≤ |x - p.center| := by
  by_contra hnot
  have hclose : |x - p.center| < 1 / B := lt_of_not_ge hnot
  exact (determinant_ne_zero c B x hB hbeta hclose) hroot

end PaperChronology.Section4FiniteSpectralBall
