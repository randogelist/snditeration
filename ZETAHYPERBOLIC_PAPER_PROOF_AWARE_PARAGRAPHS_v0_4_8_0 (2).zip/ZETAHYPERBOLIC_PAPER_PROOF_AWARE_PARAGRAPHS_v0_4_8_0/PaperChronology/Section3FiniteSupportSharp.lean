import PaperChronology.Section3FiniteSupport

/-!
# Corrected Corollary 3.6: exact finite-support positivity threshold

The manuscript's finite reciprocal-root Stieltjes sequence does not have
strictly positive Hankel matrices in all orders. Its atomic quadratic form
is semidefinite, with an explicit nonzero annihilator at sufficiently high
order (Section3FiniteSupport, frozen in v0.4.3.1).

This module proves the missing sharp complementary direction:
when h distinct real nodes have strictly positive weights, every nonzero
polynomial of degree less than h has strictly positive quadratic energy.
It also gives the exact finite kernel characterization, without assuming
distinctness, and shows that the annihilator has degree at least h when
the nodes are distinct.

No zeta-specific identity, analytic bridge, decay witness, or Riemann
hypothesis is being assumed or inferred by these finite theorems.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperChronology.Section3FiniteSupportSharp

open PaperChronology.Section3FiniteSupport

/-- At h distinct nodes, the only polynomial of degree below h that
    vanishes at every node is zero. This is the standard polynomial root
    bound, now stated in the exact finite spectral-support interface. -/
theorem polynomial_zero_of_h_distinct_eval_zero {h : ℕ}
    (u : Fin h → ℝ) (hu : Function.Injective u)
    (P : Polynomial ℝ) (heval : ∀ i : Fin h, P.eval (u i) = 0)
    (hdeg : P.natDegree < h) : P = 0 := by
  exact Polynomial.eq_zero_of_natDegree_lt_card_of_eval_eq_zero
    P hu heval (by simpa using hdeg)

/-- Any nonzero polynomial below the support cardinality is detected
    by at least one of the h distinct atoms. -/
theorem exists_atom_detecting_polynomial {h : ℕ}
    (u : Fin h → ℝ) (hu : Function.Injective u)
    (P : Polynomial ℝ) (hdeg : P.natDegree < h) (hp : P ≠ 0) :
    ∃ i : Fin h, P.eval (u i) ≠ 0 := by
  classical
  by_contra hn
  have heval : ∀ i : Fin h, P.eval (u i) = 0 := by
    intro i
    by_contra hi
    exact hn ⟨i, hi⟩
  exact hp (polynomial_zero_of_h_distinct_eval_zero u hu P heval hdeg)

/-- Positive mass at one node with nonzero evaluation forces the
    entire finite atomic quadratic form to be strictly positive. -/
theorem energy_pos_of_nonzero_at_atom {h : ℕ}
    (w u : Fin h → ℝ) (hw : ∀ i, 0 < w i)
    (P : Polynomial ℝ) (i : Fin h) (hi : P.eval (u i) ≠ 0) :
    0 < polynomialEnergy w u P := by
  unfold polynomialEnergy
  have hnonneg :
      ∀ j ∈ (Finset.univ : Finset (Fin h)),
        0 ≤ w j * (P.eval (u j)) ^ 2 := by
    intro j hj
    exact mul_nonneg (le_of_lt (hw j)) (sq_nonneg _)
  have hselected : 0 < w i * (P.eval (u i)) ^ 2 :=
    mul_pos (hw i) (sq_pos_of_ne_zero hi)
  have hbound :
      w i * (P.eval (u i)) ^ 2 ≤
        ∑ j : Fin h, w j * (P.eval (u j)) ^ 2 :=
    Finset.single_le_sum hnonneg (Finset.mem_univ i)
  exact lt_of_lt_of_le hselected hbound

/-- With positive weights, the finite atomic quadratic form has zero
    energy exactly for polynomials vanishing at every support atom.
    This statement does NOT require the support points to be distinct. -/
theorem energy_zero_iff_all_evaluations_zero {h : ℕ}
    (w u : Fin h → ℝ) (hw : ∀ i, 0 < w i)
    (P : Polynomial ℝ) :
    polynomialEnergy w u P = 0 ↔
      ∀ i : Fin h, P.eval (u i) = 0 := by
  constructor
  · intro hzero i
    by_contra hi
    have hpos := energy_pos_of_nonzero_at_atom w u hw P i hi
    rw [hzero] at hpos
    exact (lt_irrefl (0 : ℝ)) hpos
  · intro heval
    simp [polynomialEnergy, heval]

/-- Equivalently: the finite energy is strictly positive if and only if
    at least one evaluation on the support is nonzero. -/
theorem energy_pos_iff_exists_nonzero_evaluation {h : ℕ}
    (w u : Fin h → ℝ) (hw : ∀ i, 0 < w i)
    (P : Polynomial ℝ) :
    0 < polynomialEnergy w u P ↔
      ∃ i : Fin h, P.eval (u i) ≠ 0 := by
  constructor
  · intro hpos
    classical
    by_contra hn
    have heval : ∀ i : Fin h, P.eval (u i) = 0 := by
      intro i
      by_contra hi
      exact hn ⟨i, hi⟩
    have hzero := (energy_zero_iff_all_evaluations_zero w u hw P).mpr heval
    rw [hzero] at hpos
    exact (lt_irrefl (0 : ℝ)) hpos
  · rintro ⟨i, hi⟩
    exact energy_pos_of_nonzero_at_atom w u hw P i hi

/-- The SHARP missing half of the corrected Corollary 3.6:
    every nonzero polynomial of degree < h has strictly positive
    quadratic energy at h distinct atoms with positive masses. -/
theorem energy_strict_below_support_card {h : ℕ}
    (w u : Fin h → ℝ) (hw : ∀ i, 0 < w i)
    (hu : Function.Injective u) (P : Polynomial ℝ)
    (hdeg : P.natDegree < h) (hp : P ≠ 0) :
    0 < polynomialEnergy w u P := by
  obtain ⟨i, hi⟩ := exists_atom_detecting_polynomial u hu P hdeg hp
  exact energy_pos_of_nonzero_at_atom w u hw P i hi

/-- Conversely, h distinct roots force degree at least h for every
    nonzero polynomial that vanishes at all h support points. -/
theorem degree_at_least_card_of_all_evaluations_zero {h : ℕ}
    (u : Fin h → ℝ) (hu : Function.Injective u)
    (P : Polynomial ℝ) (hp : P ≠ 0)
    (heval : ∀ i : Fin h, P.eval (u i) = 0) :
    h ≤ P.natDegree := by
  by_contra hn
  have hdeg : P.natDegree < h := Nat.lt_of_not_ge hn
  exact hp (polynomial_zero_of_h_distinct_eval_zero u hu P heval hdeg)

/-- In particular, the explicit nonzero annihilator from the previously
    verified module has degree at least the number of distinct atoms. -/
theorem root_polynomial_degree_at_least_card {h : ℕ}
    (u : Fin h → ℝ) (hu : Function.Injective u) :
    h ≤ (rootPolynomial u).natDegree := by
  exact degree_at_least_card_of_all_evaluations_zero u hu
    (rootPolynomial u) (rootPolynomial_ne_zero u)
    (rootPolynomial_eval_at_atom u)

/-- Single finite theorem packaging both halves: strict positivity on
    all nonzero polynomials of degree < h AND an explicit nonzero kernel
    polynomial at unrestricted degree. This is finite algebra; it does not
    certify the paper's infinite-measure analytic realization. -/
theorem sharp_finite_atomic_positive_form {h : ℕ}
    (w u : Fin h → ℝ) (hw : ∀ i, 0 < w i)
    (hu : Function.Injective u) :
    (∀ P : Polynomial ℝ, P.natDegree < h → P ≠ 0 →
        0 < polynomialEnergy w u P) ∧
      (∃ P : Polynomial ℝ, P ≠ 0 ∧ polynomialEnergy w u P = 0) := by
  constructor
  · intro P hdeg hp
    exact energy_strict_below_support_card w u hw hu P hdeg hp
  · exact ⟨rootPolynomial u, rootPolynomial_ne_zero u,
      polynomialEnergy_annihilator_zero w u⟩

end PaperChronology.Section3FiniteSupportSharp

#print axioms PaperChronology.Section3FiniteSupportSharp.polynomial_zero_of_h_distinct_eval_zero
#print axioms PaperChronology.Section3FiniteSupportSharp.energy_pos_of_nonzero_at_atom
#print axioms PaperChronology.Section3FiniteSupportSharp.energy_zero_iff_all_evaluations_zero
#print axioms PaperChronology.Section3FiniteSupportSharp.energy_strict_below_support_card
#print axioms PaperChronology.Section3FiniteSupportSharp.root_polynomial_degree_at_least_card
#print axioms PaperChronology.Section3FiniteSupportSharp.sharp_finite_atomic_positive_form
