import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7

/-!
# Theorems 5.1 and 5.2 — rational dual moments and Gram derivative

Formalizes the finite polynomial-coefficient part of the PDF. For every
finite coefficient matrix C, the X-derivative of the two-variable dual pencil
is a Gram coefficient form C*C^T. Its quadratic energy is nonnegative and is
strictly positive under injectivity of the transposed coefficient map.

This does NOT prove the two-variable Beukers integral identity (5.2), the
infinite Krein-space decomposition, or a zeta(7) irrationality statement.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology.Section5DualFinite

open ManuscriptChain.Real

/-- The rational diagonal entry is the negative harmonic correction. -/
theorem diagonal_moment_correction (r : ℕ) :
    dualConstant 7 r r = -harmonic 7 r := by
  simp [dualConstant]

/-- Formula (5.2) for the off-diagonal rational coefficient only. -/
theorem off_diagonal_moment_correction (r t : ℕ) (hrt : r ≠ t) :
    dualConstant 7 r t =
      (harmonic 6 r - harmonic 6 t) / (6 * ((r : ℚ) - (t : ℚ))) := by
  simp [dualConstant, hrt]

/-- Explicit Gram coefficient of the X-derivative of the dual pencil. -/
def dualCoefficient {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (i j : Fin h) : ℚ :=
  ∑ r : Fin d, C i r * C j r

/-- The Gram coefficient matrix is symmetric for every finite matrix C. -/
theorem dualCoefficient_symmetric {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (i j : Fin h) : dualCoefficient C i j = dualCoefficient C j i := by
  unfold dualCoefficient
  apply Finset.sum_congr rfl
  intro r _
  ring

/-- The actual dual pencil is affine, and the coefficient of X is exactly
its Gram coefficient. This is definitional, not an additional assumption. -/
theorem dualEntry_affine_coefficient {h K : ℕ}
    (C : Fin h → Fin (K + 1) → ℚ) (i j : Fin h) :
    dualEntry 7 C i j =
      Polynomial.C
        (∑ r, ∑ t, C i r * C j t * dualConstant 7 r.val t.val) +
      Polynomial.C (dualCoefficient C i j) * Polynomial.X := by
  rfl

/-- Quadratic Gram energy: a sum of finite squares. -/
def coefficientEnergy {h d : ℕ} (C : Fin h → Fin d → ℚ)
    (v : Fin h → ℚ) : ℚ :=
  ∑ r : Fin d, (∑ i : Fin h, v i * C i r) ^ 2

theorem coefficientEnergy_nonnegative {h d : ℕ}
    (C : Fin h → Fin d → ℚ) (v : Fin h → ℚ) :
    0 ≤ coefficientEnergy C v := by
  unfold coefficientEnergy
  exact Finset.sum_nonneg (fun r _ => sq_nonneg _)

/-- A single nonzero detected coordinate forces strictly positive energy. -/
theorem coefficientEnergy_positive_at {h d : ℕ}
    (C : Fin h → Fin d → ℚ) (v : Fin h → ℚ) (r : Fin d)
    (hr : (∑ i : Fin h, v i * C i r) ≠ 0) :
    0 < coefficientEnergy C v := by
  unfold coefficientEnergy
  have hterms : ∀ t ∈ (Finset.univ : Finset (Fin d)),
      0 ≤ (∑ i : Fin h, v i * C i t)^2 := by
    intro t _
    exact sq_nonneg _
  have hselected : 0 < (∑ i : Fin h, v i * C i r)^2 :=
    sq_pos_of_ne_zero hr
  have hselected_le :
      (∑ i : Fin h, v i * C i r)^2 ≤
      ∑ t : Fin d, (∑ i : Fin h, v i * C i t)^2 :=
    Finset.single_le_sum hterms (Finset.mem_univ r)
  exact lt_of_lt_of_le hselected hselected_le

/-- Under full row rank, no nonzero v is invisible to the coefficient map.
This yields the positive definite Gram form in Theorem 5.2(1). -/
theorem coefficientEnergy_positive_of_injective {h d : ℕ}
    (C : Fin h → Fin d → ℚ)
    (hinj : ∀ v : Fin h → ℚ,
      (∀ r : Fin d, (∑ i : Fin h, v i * C i r) = 0) → v = 0)
    (v : Fin h → ℚ) (hv : v ≠ 0) :
    0 < coefficientEnergy C v := by
  classical
  by_contra hn
  have hzero : ∀ r : Fin d, (∑ i : Fin h, v i * C i r) = 0 := by
    intro r
    by_contra hr
    exact hn (coefficientEnergy_positive_at C v r hr)
  exact hv (hinj v hzero)

end PaperChronology.Section5DualFinite
