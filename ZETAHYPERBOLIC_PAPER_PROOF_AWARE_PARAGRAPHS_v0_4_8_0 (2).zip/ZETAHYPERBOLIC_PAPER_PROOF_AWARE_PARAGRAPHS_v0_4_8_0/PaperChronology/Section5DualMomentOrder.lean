import PaperChronology.Section5DualMomentSymmetry

/-!
# Theorem 5.1 / 6.2: strict order of rational dual Beukers moments

The exact off-diagonal moment coefficient is the divided difference
    (H_r^(6) - H_t^(6)) / (6 (r-t)).
The harmonic sequence is strictly increasing, hence this quotient is
strictly positive for all unequal indices. The *diagonal rational
correction*, in contrast, is strictly negative at positive indices.
These are exact statements in Q, not an analytic evaluation of the
Beukers double integral and not a zeta(7) irrationality proof.
-/

noncomputable section
namespace PaperChronology.Section5DualMomentOrder
open ManuscriptChain.Real
/-- The exact weight-six rational moment divided difference. -/
def dividedDifference6 (r t : ℕ) : ℚ :=
  (harmonic 6 r - harmonic 6 t) / (6 * ((r : ℚ) - (t : ℚ)))

/-- Every finite positive-power harmonic increment is strictly positive. -/
theorem harmonic_lt_succ (s n : ℕ) :
    harmonic s n < harmonic s (n + 1) := by
  have hs : harmonic s (n + 1) =
      harmonic s n + 1 / ((((n + 1 : ℕ) : ℚ)) ^ s) := by
    simp [harmonic, Finset.sum_range_succ]
  rw [hs]
  have hpos : (0 : ℚ) < 1 / ((((n + 1 : ℕ) : ℚ)) ^ s) := by
    positivity
  linarith

/-- Strict monotonicity for *all* finite harmonic sums of any weight. -/
theorem harmonic_strictMono (s : ℕ) :
    StrictMono (fun n : ℕ => harmonic s n) := by
  exact strictMono_nat_of_lt_succ (harmonic_lt_succ s)

/-- The off-diagonal coefficient is strictly positive when r < t. -/
theorem dividedDifference6_pos_of_lt (r t : ℕ) (hrt : r < t) :
    0 < dividedDifference6 r t := by
  have hnum : harmonic 6 r - harmonic 6 t < 0 := by
    exact sub_neg.mpr (harmonic_strictMono 6 hrt)
  have hcast : (r : ℚ) < (t : ℚ) := by
    exact_mod_cast hrt
  have hden : (6 : ℚ) * ((r : ℚ) - (t : ℚ)) < 0 := by
    linarith
  unfold dividedDifference6
  exact div_pos_of_neg_of_neg hnum hden

/-- Both signed factors of the quotient change sign on exchange. -/
theorem dividedDifference6_symm (r t : ℕ) :
    dividedDifference6 r t = dividedDifference6 t r := by
  unfold dividedDifference6
  have hnum : harmonic 6 r - harmonic 6 t =
      -(harmonic 6 t - harmonic 6 r) := by ring
  have hden : (6 : ℚ) * ((r : ℚ) - (t : ℚ)) =
      -((6 : ℚ) * ((t : ℚ) - (r : ℚ))) := by ring
  calc
    (harmonic 6 r - harmonic 6 t) / (6 * ((r : ℚ) - (t : ℚ))) =
        (-(harmonic 6 t - harmonic 6 r)) /
          (-((6 : ℚ) * ((t : ℚ) - (r : ℚ)))) := by rw [hnum, hden]
    _ = (harmonic 6 t - harmonic 6 r) /
        (6 * ((t : ℚ) - (r : ℚ))) := by
          exact neg_div_neg_eq _ _

/-- The off-diagonal coefficient is positive for *all distinct indices*. -/
theorem dividedDifference6_pos_of_ne (r t : ℕ) (hrt : r ≠ t) :
    0 < dividedDifference6 r t := by
  rcases lt_or_gt_of_ne hrt with hlt | hgt
  · exact dividedDifference6_pos_of_lt r t hlt
  · rw [dividedDifference6_symm]
    exact dividedDifference6_pos_of_lt t r hgt

/-- This is precisely the rational off-diagonal coefficient of (5.2). -/
theorem dualConstant7_offdiag_pos (r t : ℕ) (hrt : r ≠ t) :
    0 < dualConstant 7 r t := by
  rw [PaperChronology.Section5DualFinite.off_diagonal_moment_correction r t hrt]
  exact dividedDifference6_pos_of_ne r t hrt

/-- The diagonal *rational correction* has the opposite sign at r>0. -/
theorem dualConstant7_diag_neg (r : ℕ) (hr : 0 < r) :
    dualConstant 7 r r < 0 := by
  have hzero : harmonic 7 0 = 0 := by
    simp [harmonic]
  have hpos : 0 < harmonic 7 r := by
    rw [← hzero]
    exact harmonic_strictMono 7 hr
  rw [PaperChronology.Section5DualFinite.diagonal_moment_correction]
  linarith

end PaperChronology.Section5DualMomentOrder
#print axioms PaperChronology.Section5DualMomentOrder.harmonic_strictMono
#print axioms PaperChronology.Section5DualMomentOrder.dividedDifference6_pos_of_ne
#print axioms PaperChronology.Section5DualMomentOrder.dualConstant7_offdiag_pos
#print axioms PaperChronology.Section5DualMomentOrder.dualConstant7_diag_neg
