import Zetahyperbolic.CoreLinearAlgebra

/-!
# Sections 5.2 and 6.10: exact square Gram derivative determinant

If a square coefficient map C carries strictly positive diagonal
weights, its congruent Gram matrix has positive determinant exactly
when det C != 0. This is an algebraic part of the dual spectral pencils
and the determinant-growth analysis; it says nothing about the infinite
Beukers integral or its claimed asymptotic potential gap.

Uses a previously kernel-verified generic determinant identity.
-/

noncomputable section
namespace PaperChronology.Section6SquareGramProof

variable {n : ℕ}

/-- Weighted square Gram matrix of a coefficient map. -/
def weightedGram (C : Matrix (Fin n) (Fin n) ℚ) (w : Fin n → ℚ) :
    Matrix (Fin n) (Fin n) ℚ :=
  C * Matrix.diagonal w * C.transpose

/-- The actual finite determinant is the square of a determinant times
its diagonal weight product. -/
theorem weightedGram_det (C : Matrix (Fin n) (Fin n) ℚ)
    (w : Fin n → ℚ) :
    (weightedGram C w).det = C.det ^ 2 * ∏ i, w i := by
  exact Zetahyperbolic.det_conjugated_diagonal C w

/-- For positive weights and nondegenerate C, the derivative Gram
determinant is strictly positive. -/
theorem weightedGram_det_pos (C : Matrix (Fin n) (Fin n) ℚ)
    (w : Fin n → ℚ) (hw : ∀ i, 0 < w i)
    (hC : C.det ≠ 0) :
    0 < (weightedGram C w).det := by
  rw [weightedGram_det]
  exact mul_pos (sq_pos_of_ne_zero hC)
    (Finset.prod_pos (fun i _ => hw i))

/-- Rank deficiency kills the square weighted-Gram determinant. -/
theorem weightedGram_det_zero_of_singular
    (C : Matrix (Fin n) (Fin n) ℚ) (w : Fin n → ℚ)
    (hC : C.det = 0) :
    (weightedGram C w).det = 0 := by
  rw [weightedGram_det, hC]
  simp

end PaperChronology.Section6SquareGramProof
#print axioms PaperChronology.Section6SquareGramProof.weightedGram_det
#print axioms PaperChronology.Section6SquareGramProof.weightedGram_det_pos
#print axioms PaperChronology.Section6SquareGramProof.weightedGram_det_zero_of_singular
