import PaperChronology.Section6MultiweightGram

/-!
# Theorems 6.6 and 6.16: monotonicity of multiweight Gram certificates
Strengthening the nonnegative coefficients of a finite signed-family
construction preserves and improves its Gram quadratic-energy estimate.
-/

noncomputable section
namespace PaperChronology.Section6MultiweightOrder
open PaperChronology.Section6MultiweightGram
open PaperChronology.Section5DualFinite

variable {s h d : ℕ}

theorem multiweight_energy_monotone
    (alpha beta : Fin s → ℚ) (C : Fin s → Fin h → Fin d → ℚ)
    (v : Fin h → ℚ)
    (hαβ : ∀ k, alpha k ≤ beta k) :
    multiweightEnergy alpha C v ≤ multiweightEnergy beta C v := by
  unfold multiweightEnergy
  apply Finset.sum_le_sum
  intro k _
  exact mul_le_mul_of_nonneg_right (hαβ k)
    (coefficientEnergy_nonnegative (C k) v)

theorem strictness_survives_coefficient_increase
    (alpha beta : Fin s → ℚ) (C : Fin s → Fin h → Fin d → ℚ)
    (v : Fin h → ℚ)
    (hα : ∀ k, 0 ≤ alpha k)
    (hαβ : ∀ k, alpha k ≤ beta k)
    (k : Fin s) (hk : 0 < alpha k)
    (hinj : ∀ w : Fin h → ℚ,
      (∀ r : Fin d, (∑ i : Fin h, w i * C k i r) = 0) → w = 0)
    (hv : v ≠ 0) :
    0 < multiweightEnergy beta C v := by
  have hpositive :=
    multiweight_positive_of_one_injective alpha C v hα k hk hinj hv
  have hmonotone := multiweight_energy_monotone alpha beta C v hαβ
  exact lt_of_lt_of_le hpositive hmonotone

end PaperChronology.Section6MultiweightOrder
#print axioms PaperChronology.Section6MultiweightOrder.multiweight_energy_monotone
#print axioms PaperChronology.Section6MultiweightOrder.strictness_survives_coefficient_increase
