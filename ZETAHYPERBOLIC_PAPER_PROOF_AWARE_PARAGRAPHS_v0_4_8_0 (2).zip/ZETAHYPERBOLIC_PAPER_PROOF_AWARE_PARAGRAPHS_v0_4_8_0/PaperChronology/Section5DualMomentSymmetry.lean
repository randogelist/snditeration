import PaperChronology.Section5DualFinite

/-!
# Theorems 5.1 and 5.2: rational arithmetic symmetry of dual moments
The rational constant term of the two-variable moment pencil is symmetric
in its two indices. This is the finite arithmetic symmetry; the two-variable
integral realization is a separate analytic obligation.
-/

noncomputable section
namespace PaperChronology.Section5DualMomentSymmetry
open ManuscriptChain.Real

theorem dualConstant_diagonal (s r : ℕ) :
    dualConstant s r r = -harmonic s r := by
  simp [dualConstant]

theorem dualConstant_swap (s r t : ℕ) :
    dualConstant s r t = dualConstant s t r := by
  by_cases h : r = t
  · subst t
    rfl
  · have ht : t ≠ r := Ne.symm h
    simp only [dualConstant, if_neg h, if_neg ht]
    have hnum : harmonic (s - 1) r - harmonic (s - 1) t =
        -(harmonic (s - 1) t - harmonic (s - 1) r) := by ring
    have hden : ((s - 1 : ℕ) : ℚ) * ((r : ℚ) - (t : ℚ)) =
        -(((s - 1 : ℕ) : ℚ) * ((t : ℚ) - (r : ℚ))) := by ring
    calc
      (harmonic (s - 1) r - harmonic (s - 1) t) /
          (((s - 1 : ℕ) : ℚ) * ((r : ℚ) - (t : ℚ))) =
          (-(harmonic (s - 1) t - harmonic (s - 1) r)) /
            (-(((s - 1 : ℕ) : ℚ) * ((t : ℚ) - (r : ℚ)))) := by
              rw [hnum, hden]
      _ = (harmonic (s - 1) t - harmonic (s - 1) r) /
          (((s - 1 : ℕ) : ℚ) * ((t : ℚ) - (r : ℚ))) := by
            exact neg_div_neg_eq _ _

end PaperChronology.Section5DualMomentSymmetry
#print axioms PaperChronology.Section5DualMomentSymmetry.dualConstant_diagonal
#print axioms PaperChronology.Section5DualMomentSymmetry.dualConstant_swap
