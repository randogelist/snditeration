import PaperChronology.Section4SpectralSign

/-!
# Theorem 4.1: zero-free disks for the actual integer normalization
An equality of polynomial determinants transfers spectral nonvanishing to
an integer polynomial with no extra arithmetic assumptions.
-/

noncomputable section
open Polynomial
namespace PaperChronology.Section4NormalizedNoRoot
open ManuscriptChain
variable {n : ℕ} {p : Spectral.SymmetricAffinePencil n}

theorem normalized_polynomial_no_real_root
    (c : Spectral.RootFactorization p) (P : Polynomial ℤ)
    (scale B x : ℝ)
    (hscale : scale ≠ 0)
    (hnormalize : p.detPolynomial =
      C scale * P.map (algebraMap ℤ ℝ))
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hx : |x - p.center| ≤ Spectral.comparisonRadius n B) :
    RealTransfer.evalReal P x ≠ 0 := by
  exact (c.normalized_comparison_of_radius P scale B x
    hscale hnormalize hB hbeta hx).1

end PaperChronology.Section4NormalizedNoRoot
#print axioms PaperChronology.Section4NormalizedNoRoot.normalized_polynomial_no_real_root
