import PaperChronology.Section4FiniteSpectralBall

/-!
# Theorems 3.1 and 4.1: signed finite determinant under spectral bounds
The characteristic determinant retains the sign of its base Gram determinant
throughout the exact real spectral disk. This is stronger than zero exclusion;
no analytic, asymptotic, or arithmetic witness is used.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronology.Section4SpectralSign
open ManuscriptChain.Spectral

variable {n : ℕ} {p : SymmetricAffinePencil n}

theorem determinant_base_sign_agrees
    (c : RootFactorization p) (B x : ℝ)
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hx : |x - p.center| < 1 / B) :
    0 < p.base.det * p.detPolynomial.eval x := by
  have hprod : 0 < ∏ i : Fin n, (1 + (x - p.center) * c.beta i) :=
    Finset.prod_pos (fun i _ =>
      PaperChronology.Section4FiniteSpectralBall.factor_strict_pos c B x hB hbeta hx i)
  have hbase : 0 < p.base.det ^ 2 :=
    sq_pos_of_ne_zero c.base_det_ne_zero
  rw [c.eval_eq]
  calc
    p.base.det * (p.base.det * ∏ i : Fin n, (1 + (x - p.center) * c.beta i)) =
        p.base.det ^ 2 * ∏ i : Fin n, (1 + (x - p.center) * c.beta i) := by ring
    _ > 0 := mul_pos hbase hprod

end PaperChronology.Section4SpectralSign
#print axioms PaperChronology.Section4SpectralSign.determinant_base_sign_agrees
