import PaperChronology.Section4NormalizedNoRoot

/-!
# Theorem 4.1: finite radius transfer to rational evaluations
The normalized integer polynomial is nonzero at every rational point in
the spectral comparison disk. Denominator size plays no role at this stage.
-/

noncomputable section
open Polynomial
namespace PaperChronology.Section4FiniteRadiusTransfer
open ManuscriptChain
variable {n : ℕ} {p : Spectral.SymmetricAffinePencil n}

theorem no_rational_zero_in_comparison_disk
    (c : Spectral.RootFactorization p) (P : Polynomial ℤ)
    (scale B : ℝ) (a : ℤ) (b : ℕ) (hb : 0 < b)
    (hscale : scale ≠ 0)
    (hnormalize : p.detPolynomial =
      C scale * P.map (algebraMap ℤ ℝ))
    (hB : 0 < B) (hbeta : ∀ i, |c.beta i| ≤ B)
    (hx : |(a : ℝ) / (b : ℝ) - p.center| ≤
      Spectral.comparisonRadius n B) :
    RealTransfer.evalReal P ((a : ℝ) / (b : ℝ)) ≠ 0 := by
  exact PaperChronology.Section4NormalizedNoRoot.normalized_polynomial_no_real_root
    c P scale B ((a : ℝ) / (b : ℝ)) hscale hnormalize hB hbeta hx

end PaperChronology.Section4FiniteRadiusTransfer
#print axioms PaperChronology.Section4FiniteRadiusTransfer.no_rational_zero_in_comparison_disk
