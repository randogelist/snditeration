import Definition_2_1_Order_s_Rational_Moment_Functional
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity

/-!
# Section 2 pole-generator identities, used by Lemmas 2.2-2.3 and Theorem 5.4

This file works with exactly the prescribed Q-valued values of the paper's
auxiliary tau_X on simple integer poles. It proves the finite telescoping
identity and its reflected/shifted specializations. It DOES NOT assert the
pullback identity for the whole space of rational functions, nor the
Bernoulli-monomial part of Lemma 2.3.

For j=n+1 >= 1:
  tau_X((x-j)^(-1)) = H_j^(2k+1) - X
  tau_X((x+j)^(-1)) = H_(j-1)^(2k+1) - X.
-/

noncomputable section
namespace PaperChronology

/-- The exact functional value on the pole at x = n+1. -/
def tauPolePositive (k n : ℕ) (X : ℚ) : ℚ :=
  ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) - X

/-- The exact functional value on the pole at x = -(n+1). -/
def tauPoleNegative (k n : ℕ) (X : ℚ) : ℚ :=
  ManuscriptChain.Real.harmonic (2 * k + 1) n - X

/-- Finite harmonic increment; no analytic limit is involved. -/
theorem harmonic_succ (s n : ℕ) :
    ManuscriptChain.Real.harmonic s (n + 1) =
      ManuscriptChain.Real.harmonic s n +
        1 / (((n + 1 : ℕ) : ℚ) ^ s) := by
  simp [ManuscriptChain.Real.harmonic, Finset.sum_range_succ]

/-- Formula (5.5) on simple pole generators, with j=n+1. -/
theorem even_pole_pair_generator (k n : ℕ) (X : ℚ) :
    tauPolePositive k n X - tauPoleNegative k n X =
      1 / (((n + 1 : ℕ) : ℚ) ^ (2 * k + 1)) := by
  unfold tauPolePositive tauPoleNegative
  rw [harmonic_succ]
  ring

/-- The reflection x -> -1-x exchanges the relevant positive and negative
pole indices; the rational function itself acquires an additional minus. -/
theorem reflected_pole_index (k n : ℕ) (X : ℚ) :
    tauPolePositive k n X = tauPoleNegative k (n + 1) X := by
  rfl

/-- The positive-pole difference identity on the generator h(x)=(x-j)^(-1). -/
theorem shifted_positive_pole (k n : ℕ) (X : ℚ) :
    tauPoleNegative k n X - tauPolePositive k n X =
      -(1 / (((n + 1 : ℕ) : ℚ) ^ (2 * k + 1))) := by
  calc
    tauPoleNegative k n X - tauPolePositive k n X =
        -(tauPolePositive k n X - tauPoleNegative k n X) := by ring
    _ = -(1 / (((n + 1 : ℕ) : ℚ) ^ (2 * k + 1))) := by
      rw [even_pole_pair_generator]

/-- The negative-pole difference identity. -/
theorem shifted_negative_pole (k n : ℕ) (X : ℚ) :
    tauPoleNegative k (n + 1) X - tauPoleNegative k n X =
      1 / (((n + 1 : ℕ) : ℚ) ^ (2 * k + 1)) := by
  unfold tauPoleNegative
  rw [harmonic_succ]
  ring

/-- Theorem 5.4 on all positive integer pole indices, in paper notation.
This is the full generator-value identity, not an extension of tau to
higher-order poles or a proof of Lemma 2.2. -/
theorem even_pole_pair_for_positive_j (k j : ℕ) (hj : 1 ≤ j) (X : ℚ) :
    tauPolePositive k (j - 1) X - tauPoleNegative k (j - 1) X =
      1 / ((j : ℚ) ^ (2 * k + 1)) := by
  simpa only [Nat.sub_add_cancel hj] using
    even_pole_pair_generator k (j - 1) X


/-- Identity of the two prescribed pole values, derived from a finite sum. -/
theorem sum_reflected_poles (k n : ℕ) (X : ℚ) :
    tauPolePositive k n X + tauPoleNegative k n X =
      2 * (ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) - X) -
        1 / (((n + 1 : ℕ) : ℚ) ^ (2 * k + 1)) := by
  unfold tauPolePositive tauPoleNegative
  simp only [harmonic_succ]
  ring

/-- Finite-power cancellation used in the pullback's simple-pole term. -/
theorem pow_succ_reciprocal_cancel (n e : ℕ) :
    (((n + 1 : ℕ) : ℚ) ^ e) *
      (1 / (((n + 1 : ℕ) : ℚ) ^ (e + 1))) =
        1 / ((n + 1 : ℕ) : ℚ) := by
  have hj : (((n + 1 : ℕ) : ℚ) ≠ 0) := by positivity
  rw [pow_succ]
  field_simp [hj]

/-- Lemma 2.2, simple-pole GENERATOR step after finite partial fractions:

  -1/(2k) - j^(2k)/2 * (tau((x-j)^(-1)) + tau((x+j)^(-1)))
    = j^(2k) X + poleConstant(k,j),

with j=n+1>0. The full rational-function pullback is a separate goal. -/
theorem pullback_simple_pole_value (k n : ℕ) (hk : 0 < k) (X : ℚ) :
    -(1 / (2 * (k : ℚ))) -
        ((((n + 1 : ℕ) : ℚ) ^ (2 * k)) / 2) *
          (tauPolePositive k n X + tauPoleNegative k n X) =
      (((n + 1 : ℕ) : ℚ) ^ (2 * k)) * X +
        ManuscriptChain.Real.poleConstant k (n + 1) := by
  let j : ℚ := ((n + 1 : ℕ) : ℚ)
  have hj : j ≠ 0 := by dsimp [j]; positivity
  have hkq : (k : ℚ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hk)
  have hs := sum_reflected_poles k n X
  have hratio := pow_succ_reciprocal_cancel n (2 * k)
  change -(1 / (2 * (k : ℚ))) - (j ^ (2 * k) / 2) *
      (tauPolePositive k n X + tauPoleNegative k n X) =
      j ^ (2 * k) * X + ManuscriptChain.Real.poleConstant k (n + 1)
  change tauPolePositive k n X + tauPoleNegative k n X =
    2 * (ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) - X) -
      1 / j ^ (2 * k + 1) at hs
  change j ^ (2 * k) * (1 / j ^ (2 * k + 1)) = 1 / j at hratio
  rw [hs]
  calc
    -(1 / (2 * (k : ℚ))) - (j ^ (2 * k) / 2) *
          (2 * (ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) - X) -
            1 / j ^ (2 * k + 1)) =
        j ^ (2 * k) * X -
          j ^ (2 * k) * ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) +
          (j ^ (2 * k) * (1 / j ^ (2 * k + 1))) / 2 -
          1 / (2 * (k : ℚ)) := by ring
    _ = j ^ (2 * k) * X + ManuscriptChain.Real.poleConstant k (n + 1) := by
      rw [hratio]
      simp only [ManuscriptChain.Real.poleConstant]
      change j ^ (2 * k) * X - j ^ (2 * k) *
        ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) +
        (1 / j) / 2 - 1 / (2 * (k : ℚ)) =
        j ^ (2 * k) * X +
        (-j ^ (2 * k) * ManuscriptChain.Real.harmonic (2 * k + 1) (n + 1) +
          1 / (2 * j) - 1 / (2 * (k : ℚ)))
      field_simp [hj, hkq] <;> ring


end PaperChronology

#print axioms PaperChronology.harmonic_succ
#print axioms PaperChronology.even_pole_pair_generator
#print axioms PaperChronology.even_pole_pair_for_positive_j
#print axioms PaperChronology.pullback_simple_pole_value
