import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Proposition 3.2 -- corrected continuous-weight spectral core

The paper prints `(2*pi)^s/(2*Gamma s)` in the real-s density.  At
s=2*k+1 this is pi/2 times the coefficient of formula (3.1), not the
same coefficient. The corrected coefficient is
`2*(2*pi)^(s-1)/(Gamma s)`.

This module proves the odd-integer normalization comparison, positivity
of every finite exponential sum for ALL real s, and the general spectral
conclusions for a real-s symmetric pencil once its Gram positivity and
slope nonsingularity have been established.

FRONTIER: summability/integrability of the full real-s density, its
identification with the integral moments and the odd-weight specialization
of the *entire matrix* are not asserted here. No axioms or sorry.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3Continuous

/-- The coefficient as printed in Proposition 3.2, specialized to odd s. -/
def printedOddCoefficient (k : ℕ) (g : ℝ) : ℝ :=
  (2 * Real.pi) ^ (2 * k + 1) / (2 * g)

/-- Coefficient matching the Section 3.1 density at odd s. -/
def correctedOddCoefficient (k : ℕ) (g : ℝ) : ℝ :=
  2 * (2 * Real.pi) ^ (2 * k) / g

/-- The exact pi/2 normalization discrepancy; no approximation or Gamma identity. -/
theorem printed_eq_pi_over_two_times_corrected (k : ℕ) (g : ℝ) :
    printedOddCoefficient k g =
      (Real.pi / 2) * correctedOddCoefficient k g := by
  unfold printedOddCoefficient correctedOddCoefficient
  rw [pow_succ]
  simp only [div_eq_mul_inv]
  ring

/-- Applies the comparison to the Gamma factor of Proposition 3.2. -/
theorem proposition_3_2_printed_coefficient_at_odd (k : ℕ) :
    (2 * Real.pi) ^ (2 * k + 1) /
        (2 * Real.Gamma (2 * k + 1 : ℕ)) =
      (Real.pi / 2) *
        (2 * (2 * Real.pi) ^ (2 * k) /
          Real.Gamma (2 * k + 1 : ℕ)) := by
  exact printed_eq_pi_over_two_times_corrected k _

/-- Unnormalized individual Laplace mode at a REAL exponent `s-1`. -/
def realExponentTerm (s y : ℝ) (n : ℕ) : ℝ :=
  ((n + 1 : ℕ) : ℝ) ^ (s - 1) *
    Real.exp (-(2 * Real.pi * y) * ((n + 1 : ℕ) : ℝ))

/-- Every Laplace mode is strictly positive, including nonintegral s. -/
theorem realExponentTerm_pos (s y : ℝ) (n : ℕ) :
    0 < realExponentTerm s y n := by
  unfold realExponentTerm
  positivity

/-- Every nonempty finite partial sum is strictly positive, for arbitrary real s. -/
theorem realExponent_partial_sum_pos (s y : ℝ) (N : ℕ) :
    0 < (∑ n ∈ Finset.range (N + 1), realExponentTerm s y n) := by
  apply Finset.sum_pos
  · intro n _
    exact realExponentTerm_pos s y n
  · exact ⟨0, Finset.mem_range.mpr (Nat.zero_lt_succ N)⟩

/-- The algebraic real-s pencil of Proposition 3.2, centered at zeta(s).
Its Gram/slope analytic construction is a separate proof obligation. -/
def continuousPencil {n : ℕ} (s : ℝ)
    (A M : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsSymm) (hM : M.IsSymm) :
    ManuscriptChain.Spectral.SymmetricAffinePencil n where
  center := (riemannZeta (s : ℂ)).re
  base := A
  direction := M
  base_symmetric := hA
  direction_symmetric := hM

/-- Proposition 3.2's exact-degree step, with the two analytic/matrix
conditions visible rather than hidden inside a false unconditional claim. -/
theorem continuousPencil_degree {n : ℕ} (s : ℝ) (hs : 1 < s)
    (A M : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsSymm) (hM : M.IsSymm)
    (hPositive : A.PosDef) (hSlope : Matrix.det M ≠ 0) :
    (continuousPencil s A M hA hM).detPolynomial.natDegree = n := by
  exact ManuscriptChain.Spectral.theorem_3_1_degree_of_posDef
    (continuousPencil s A M hA hM) hPositive hSlope

/-- Proposition 3.2's real-root conclusion, for ALL real s > 1, once the
actual continuous-weight Gram moment identity is supplied and proved. -/
theorem continuousPencil_roots_real {n : ℕ} (s : ℝ) (hs : 1 < s)
    (A M : Matrix (Fin n) (Fin n) ℝ)
    (hA : A.IsSymm) (hM : M.IsSymm)
    (hPositive : A.PosDef) (hSlope : Matrix.det M ≠ 0)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (continuousPencil s A M hA hM).detPolynomial = 0) :
    z.im = 0 := by
  exact ManuscriptChain.Spectral.theorem_3_1_hyperbolicity_of_posDef
    (continuousPencil s A M hA hM) hPositive hSlope z hz

end PaperChronology.Section3Continuous

#print axioms PaperChronology.Section3Continuous.printed_eq_pi_over_two_times_corrected
#print axioms PaperChronology.Section3Continuous.realExponent_partial_sum_pos
#print axioms PaperChronology.Section3Continuous.continuousPencil_degree
#print axioms PaperChronology.Section3Continuous.continuousPencil_roots_real
