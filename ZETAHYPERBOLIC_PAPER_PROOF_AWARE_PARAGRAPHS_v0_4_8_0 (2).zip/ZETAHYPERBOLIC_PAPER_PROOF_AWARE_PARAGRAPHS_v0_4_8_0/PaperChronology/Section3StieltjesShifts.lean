import PaperChronology.Section3FiniteSupportSharp

/-!
# Corollary 3.6, corrected: the complete hierarchy of shifted finite Stieltjes energies

The finite spectral measure with nodes u_i > 0 and masses w_i > 0
has nonnegative quadratic forms for all polynomial tests and all shifts n.
For pairwise distinct u_i it is strictly positive on nonzero polynomials
of degree < h, while every shifted form has the explicit monic annihilator.

The square of the reciprocal distance to a rational shift is positive,
but its support points can collide even for DISTINCT real spectral roots:
q+t and q-t yield the same reciprocal-square node. Thus the paper's
unqualified strict positivity at all Hankel sizes is false, and a sharp
support-rank statement must count distinct reciprocal-square nodes.

All results below are elementary finite-dimensional real algebra and use
no hypotheses concerning zeta, prime sums, or analytic continuation.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperChronology.Section3StieltjesShifts
open PaperChronology.Section3FiniteSupport
open PaperChronology.Section3FiniteSupportSharp

/-- Finite Stieltjes moment associated to h atomic weights and nodes. -/
def atomicMoment {h : ℕ} (w u : Fin h → ℝ) (n : ℕ) : ℝ :=
  ∑ i : Fin h, w i * u i ^ n

/-- Weighted polynomial energy for the n-th shifted Stieltjes measure. -/
def shiftedEnergy {h : ℕ} (w u : Fin h → ℝ)
    (n : ℕ) (P : Polynomial ℝ) : ℝ :=
  polynomialEnergy (fun i => w i * u i ^ n) u P

/-- Nonnegative nodes and masses make every shifted mass nonnegative. -/
theorem shiftedMass_nonneg {h : ℕ} (w u : Fin h → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hu : ∀ i, 0 ≤ u i)
    (n : ℕ) (i : Fin h) : 0 ≤ w i * u i ^ n :=
  mul_nonneg (hw i) (pow_nonneg (hu i) n)

/-- Positive nodes and masses keep every shifted mass strictly positive. -/
theorem shiftedMass_pos {h : ℕ} (w u : Fin h → ℝ)
    (hw : ∀ i, 0 < w i) (hu : ∀ i, 0 < u i)
    (n : ℕ) (i : Fin h) : 0 < w i * u i ^ n :=
  mul_pos (hw i) (pow_pos (hu i) n)

/-- All finite Stieltjes moments of nonnegative atomic data are nonnegative. -/
theorem atomicMoment_nonneg {h : ℕ} (w u : Fin h → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hu : ∀ i, 0 ≤ u i)
    (n : ℕ) : 0 ≤ atomicMoment w u n := by
  unfold atomicMoment
  apply Finset.sum_nonneg
  intro i hi
  exact shiftedMass_nonneg w u hw hu n i

/-- A shifted moment is the shifted polynomial energy of the constant one. -/
theorem shiftedEnergy_one {h : ℕ} (w u : Fin h → ℝ) (n : ℕ) :
    shiftedEnergy w u n (1 : Polynomial ℝ) = atomicMoment w u n := by
  simp [shiftedEnergy, polynomialEnergy, atomicMoment]

/-- Every shifted Stieltjes polynomial energy is nonnegative. -/
theorem shiftedEnergy_nonneg {h : ℕ} (w u : Fin h → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hu : ∀ i, 0 ≤ u i)
    (n : ℕ) (P : Polynomial ℝ) :
    0 ≤ shiftedEnergy w u n P := by
  exact polynomialEnergy_nonneg (fun i => w i * u i ^ n) u
    (shiftedMass_nonneg w u hw hu n) P

/-- Every shifted energy has the SAME nonzero monic annihilator. -/
theorem shiftedEnergy_annihilator_zero {h : ℕ}
    (w u : Fin h → ℝ) (n : ℕ) :
    shiftedEnergy w u n (rootPolynomial u) = 0 := by
  exact polynomialEnergy_annihilator_zero
    (fun i => w i * u i ^ n) u

/-- Indeed the entire principal ideal of the annihilator lies in the kernel. -/
theorem shiftedEnergy_annihilator_mul_zero {h : ℕ}
    (w u : Fin h → ℝ) (n : ℕ) (P : Polynomial ℝ) :
    shiftedEnergy w u n (rootPolynomial u * P) = 0 := by
  unfold shiftedEnergy polynomialEnergy
  apply Finset.sum_eq_zero
  intro i hi
  have heval : (rootPolynomial u * P).eval (u i) = 0 := by
    simp [Polynomial.eval_mul, rootPolynomial_eval_at_atom]
  simp [heval]

/-- Strictly positive shifted masses give the exact finite-support kernel. -/
theorem shiftedEnergy_zero_iff {h : ℕ}
    (w u : Fin h → ℝ)
    (hw : ∀ i, 0 < w i) (hu : ∀ i, 0 < u i)
    (n : ℕ) (P : Polynomial ℝ) :
    shiftedEnergy w u n P = 0 ↔
      ∀ i : Fin h, P.eval (u i) = 0 := by
  exact energy_zero_iff_all_evaluations_zero
    (fun i => w i * u i ^ n) u
    (shiftedMass_pos w u hw hu n) P

/-- At h distinct atoms, all shifts are STRICT below the support cardinality. -/
theorem shiftedEnergy_strict_below_card {h : ℕ}
    (w u : Fin h → ℝ)
    (hw : ∀ i, 0 < w i) (hu : ∀ i, 0 < u i)
    (hinj : Function.Injective u) (n : ℕ)
    (P : Polynomial ℝ) (hdeg : P.natDegree < h) (hp : P ≠ 0) :
    0 < shiftedEnergy w u n P := by
  exact energy_strict_below_support_card
    (fun i => w i * u i ^ n) u
    (shiftedMass_pos w u hw hu n) hinj P hdeg hp

/-- A single theorem gives ALL shifts and a nonzero kernel at each shift. -/
theorem shifted_stieltjes_sharp {h : ℕ}
    (w u : Fin h → ℝ)
    (hw : ∀ i, 0 < w i) (hu : ∀ i, 0 < u i)
    (hinj : Function.Injective u) :
    (∀ n : ℕ, ∀ P : Polynomial ℝ,
      P.natDegree < h → P ≠ 0 → 0 < shiftedEnergy w u n P) ∧
    (∀ n : ℕ, ∃ P : Polynomial ℝ,
      P ≠ 0 ∧ shiftedEnergy w u n P = 0) := by
  constructor
  · intro n P hdeg hp
    exact shiftedEnergy_strict_below_card w u hw hu hinj n P hdeg hp
  · intro n
    exact ⟨rootPolynomial u, rootPolynomial_ne_zero u,
      shiftedEnergy_annihilator_zero w u n⟩

/-- The natural reciprocal-square node associated with a shifted real root. -/
def reciprocalSquare (x q : ℝ) : ℝ := ((x - q)⁻¹) ^ 2

/-- Each reciprocal-square node is positive away from the chosen shift. -/
theorem reciprocalSquare_pos (x q : ℝ) (hx : x ≠ q) :
    0 < reciprocalSquare x q := by
  unfold reciprocalSquare
  exact sq_pos_of_ne_zero (inv_ne_zero (sub_ne_zero.mpr hx))

/-- Two distinct spectral roots symmetric around q yield the same
    reciprocal-square support node. Positivity alone does not prevent
    these collisions. -/
theorem reciprocalSquare_symmetric (q t : ℝ) :
    reciprocalSquare (q + t) q = reciprocalSquare (q - t) q := by
  unfold reciprocalSquare
  have hp : q + t - q = t := by ring
  have hm : q - t - q = -t := by ring
  rw [hp, hm]
  simp

end PaperChronology.Section3StieltjesShifts

#print axioms PaperChronology.Section3StieltjesShifts.atomicMoment_nonneg
#print axioms PaperChronology.Section3StieltjesShifts.shiftedEnergy_nonneg
#print axioms PaperChronology.Section3StieltjesShifts.shiftedEnergy_one
#print axioms PaperChronology.Section3StieltjesShifts.shiftedEnergy_annihilator_mul_zero
#print axioms PaperChronology.Section3StieltjesShifts.shiftedEnergy_zero_iff
#print axioms PaperChronology.Section3StieltjesShifts.shiftedEnergy_strict_below_card
#print axioms PaperChronology.Section3StieltjesShifts.shifted_stieltjes_sharp
#print axioms PaperChronology.Section3StieltjesShifts.reciprocalSquare_pos
#print axioms PaperChronology.Section3StieltjesShifts.reciprocalSquare_symmetric
