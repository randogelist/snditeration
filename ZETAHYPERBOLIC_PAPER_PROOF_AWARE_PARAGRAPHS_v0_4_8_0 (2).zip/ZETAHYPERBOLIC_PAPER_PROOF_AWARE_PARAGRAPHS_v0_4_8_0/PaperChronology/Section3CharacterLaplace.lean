import PaperChronology.Section3CharacterSeries

/-!
# Theorem 3.9 — real-height Laplace substitution for five character series

This is a source-faithful, finite-to-infinite *character-block* implication.
For each positive real height y, the geometric substitution
z=exp(-2*pi*y/q) lies in (0,1); the five rational Fekete kernels and
corresponding completed periodic block series are therefore positive.
No Dirichlet L-value equality or full Hankel positive-definiteness is asserted.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3CharacterLaplace

open PaperChronology.Section3FeketeCharacter
open PaperChronology.Section3CharacterSeries

/-- Height-to-period geometric parameter for positive conductors q. -/
def heightParameter (q : ℕ) (y : ℝ) : ℝ :=
  Real.exp (-(2 * Real.pi * y / (q : ℝ)))

theorem heightParameter_pos (q : ℕ) (y : ℝ) :
    0 < heightParameter q y := by
  unfold heightParameter
  exact Real.exp_pos _

theorem heightParameter_lt_one (q : ℕ) (y : ℝ)
    (hq : 0 < q) (hy : 0 < y) :
    heightParameter q y < 1 := by
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast hq
  have hpositive : 0 < 2 * Real.pi * y / (q : ℝ) := by positivity
  have hnegative : -(2 * Real.pi * y / (q : ℝ)) < 0 :=
    neg_lt_zero.mpr hpositive
  have he := Real.exp_lt_exp.mpr hnegative
  simpa only [heightParameter, Real.exp_zero] using he

/-- Real-height form of the q=3 periodic character series. -/
theorem height_neg3_series (y : ℝ) (hy : 0 < y) :
    (∑' b : ℕ, fNeg3 (heightParameter 3 y) *
      heightParameter 3 y ^ (3 * b)) = kernelNeg3 (heightParameter 3 y) := by
  exact kernelNeg3_series _ (heightParameter_pos 3 y)
    (heightParameter_lt_one 3 y (by decide) hy)

theorem height_neg4_series (y : ℝ) (hy : 0 < y) :
    (∑' b : ℕ, fNeg4 (heightParameter 4 y) *
      heightParameter 4 y ^ (4 * b)) = kernelNeg4 (heightParameter 4 y) := by
  exact kernelNeg4_series _ (heightParameter_pos 4 y)
    (heightParameter_lt_one 4 y (by decide) hy)

theorem height_five_series (y : ℝ) (hy : 0 < y) :
    (∑' b : ℕ, f5 (heightParameter 5 y) *
      heightParameter 5 y ^ (5 * b)) = kernel5 (heightParameter 5 y) := by
  exact kernel5_series _ (heightParameter_pos 5 y)
    (heightParameter_lt_one 5 y (by decide) hy)

theorem height_eight_series (y : ℝ) (hy : 0 < y) :
    (∑' b : ℕ, f8 (heightParameter 8 y) *
      heightParameter 8 y ^ (8 * b)) = kernel8 (heightParameter 8 y) := by
  exact kernel8_series _ (heightParameter_pos 8 y)
    (heightParameter_lt_one 8 y (by decide) hy)

theorem height_neg8_series (y : ℝ) (hy : 0 < y) :
    (∑' b : ℕ, fNeg8 (heightParameter 8 y) *
      heightParameter 8 y ^ (8 * b)) = kernelNeg8 (heightParameter 8 y) := by
  exact kernelNeg8_series _ (heightParameter_pos 8 y)
    (heightParameter_lt_one 8 y (by decide) hy)

/-- All five periodic character series are strictly positive at every
positive height. This does not assume that they represent Dirichlet L values. -/
theorem all_five_height_series_positive (y : ℝ) (hy : 0 < y) :
    0 < (∑' b : ℕ, fNeg3 (heightParameter 3 y) *
      heightParameter 3 y ^ (3 * b)) ∧
    0 < (∑' b : ℕ, fNeg4 (heightParameter 4 y) *
      heightParameter 4 y ^ (4 * b)) ∧
    0 < (∑' b : ℕ, f5 (heightParameter 5 y) *
      heightParameter 5 y ^ (5 * b)) ∧
    0 < (∑' b : ℕ, f8 (heightParameter 8 y) *
      heightParameter 8 y ^ (8 * b)) ∧
    0 < (∑' b : ℕ, fNeg8 (heightParameter 8 y) *
      heightParameter 8 y ^ (8 * b)) := by
  rw [height_neg3_series y hy, height_neg4_series y hy,
    height_five_series y hy, height_eight_series y hy,
    height_neg8_series y hy]
  exact ⟨kernelNeg3_pos _ (heightParameter_pos 3 y)
      (heightParameter_lt_one 3 y (by decide) hy),
    kernelNeg4_pos _ (heightParameter_pos 4 y)
      (heightParameter_lt_one 4 y (by decide) hy),
    kernel5_pos _ (heightParameter_pos 5 y)
      (heightParameter_lt_one 5 y (by decide) hy),
    kernel8_pos _ (heightParameter_pos 8 y)
      (heightParameter_lt_one 8 y (by decide) hy),
    kernelNeg8_pos _ (heightParameter_pos 8 y)
      (heightParameter_lt_one 8 y (by decide) hy)⟩

end PaperChronology.Section3CharacterLaplace
