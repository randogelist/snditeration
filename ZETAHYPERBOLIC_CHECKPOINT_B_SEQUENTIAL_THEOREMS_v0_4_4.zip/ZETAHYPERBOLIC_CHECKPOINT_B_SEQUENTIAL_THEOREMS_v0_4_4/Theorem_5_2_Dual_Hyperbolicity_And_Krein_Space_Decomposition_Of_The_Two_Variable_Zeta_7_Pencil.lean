import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-!
# Theorem 5.2 (Dual hyperbolicity and Krein-space decomposition of the two-variable ζ(7) pencil)

PDF pp. 23-24. Replacement certificate implications for the definite-subspace
part, not a proof of the entire printed theorem. A finite sign certificate
and an explicit WeightSevenTailBound imply the corresponding sign of the
full form. The analytic tail bound remains an input. No unchecked infinite
signed tail is discarded, and no universal definite subspace is asserted.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Extensions
open ManuscriptChain.Real

def qform {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) : ℝ :=
  ∑ i, ∑ j, v i * A i j * v j

def PositiveQForm {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) : Prop :=
  ∀ v : Fin h → ℝ, v ≠ 0 → 0 < qform A v

def NegativeQForm {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) : Prop :=
  ∀ v : Fin h → ℝ, v ≠ 0 → qform A v < 0

theorem posDef_of_symmetric_positive_qform {h : ℕ}
    (A : Matrix (Fin h) (Fin h) ℝ) (symmetric : A.IsSymm)
    (positive : PositiveQForm A) : A.PosDef := by
  apply Matrix.posDef_iff_dotProduct_mulVec.mpr
  refine ⟨Matrix.isHermitian_iff_isSymm.mpr symmetric, ?_⟩
  intro v hv
  simpa [qform, dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc] using positive v hv

theorem qform_sub {h : ℕ} (A B : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) :
    qform (A - B) v = qform A v - qform B v := by
  simp [qform, mul_sub, sub_mul, Finset.sum_sub_distrib]

theorem qform_add {h : ℕ} (A B : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) :
    qform (A + B) v = qform A v + qform B v := by
  simp [qform, mul_add, add_mul, Finset.sum_add_distrib]

theorem qform_smul {h : ℕ} (a : ℝ) (A : Matrix (Fin h) (Fin h) ℝ)
    (v : Fin h → ℝ) : qform (a • A) v = a * qform A v := by
  unfold qform
  simp only [Matrix.smul_apply, smul_eq_mul]
  calc
    (∑ i, ∑ j, v i * (a * A i j) * v j) =
        ∑ i, ∑ j, a * (v i * A i j * v j) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          ring
    _ = a * ∑ i, ∑ j, v i * A i j * v j := by
      simp only [Finset.mul_sum]

theorem positive_of_tail_certificate {h : ℕ}
    (G H L : Matrix (Fin h) (Fin h) ℝ) (e : ℝ)
    (tail : ∀ v, |qform G v - qform H v| ≤ e * qform L v)
    (certificate : PositiveQForm (H - e • L)) : PositiveQForm G := by
  intro v hv
  have lower := (abs_le.mp (tail v)).1
  have margin := certificate v hv
  rw [qform_sub, qform_smul] at margin
  linarith

theorem negative_of_tail_certificate {h : ℕ}
    (G H L : Matrix (Fin h) (Fin h) ℝ) (e : ℝ)
    (tail : ∀ v, |qform G v - qform H v| ≤ e * qform L v)
    (certificate : NegativeQForm (H + e • L)) : NegativeQForm G := by
  intro v hv
  have upper := (abs_le.mp (tail v)).2
  have margin := certificate v hv
  rw [qform_add, qform_smul] at margin
  linarith

def integralMom {K : ℕ} (c : Fin (K + 1) → ℚ) (m ν : ℕ) : ℚ :=
  ∑ r, c r * (Nat.factorial ν : ℚ) /
    (((r.val + m + 1 : ℕ) : ℚ) ^ (ν + 1))

def weightSevenTruncation {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) :
    Matrix (Fin h) (Fin h) ℚ :=
  fun i j => ∑ m ∈ Finset.range (M + 1), ∑ ν ∈ Finset.range 6,
    (Nat.choose 5 ν : ℚ) / 720 * integralMom (c i) m ν *
      integralMom (c j) m (5 - ν)

def l2Gram {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℚ :=
  fun i j => ∑ r, ∑ t, c i r * c j t / ((r.val + t.val + 1 : ℕ) : ℚ)

def matrixToReal {h : ℕ} (A : Matrix (Fin h) (Fin h) ℚ) :
    Matrix (Fin h) (Fin h) ℝ := fun i j => (A i j : ℝ)

def tailError (M : ℕ) : ℚ := 13 / (10 * ((2 * M + 1 : ℕ) : ℚ) ^ 5)

def weightSevenGram {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => evalQ (dualEntry 7 c i j) (zeta 7)

def WeightSevenTailBound {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  ∀ v, |qform (weightSevenGram c) v -
    qform (matrixToReal (weightSevenTruncation c M)) v| ≤
      (tailError M : ℝ) * qform (matrixToReal (l2Gram c)) v

def FinitePositiveCertificate {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  PositiveQForm (matrixToReal (weightSevenTruncation c M) -
    (tailError M : ℝ) • matrixToReal (l2Gram c))

def FiniteNegativeCertificate {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  NegativeQForm (matrixToReal (weightSevenTruncation c M) +
    (tailError M : ℝ) • matrixToReal (l2Gram c))

theorem weight_seven_positive_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (tail : WeightSevenTailBound c M)
    (certificate : FinitePositiveCertificate c M) : PositiveQForm (weightSevenGram c) :=
  positive_of_tail_certificate _ _ _ _ tail certificate

theorem weight_seven_negative_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (tail : WeightSevenTailBound c M)
    (certificate : FiniteNegativeCertificate c M) : NegativeQForm (weightSevenGram c) :=
  negative_of_tail_certificate _ _ _ _ tail certificate

theorem weight_seven_posDef_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (symmetric : (weightSevenGram c).IsSymm)
    (tail : WeightSevenTailBound c M)
    (certificate : FinitePositiveCertificate c M) : (weightSevenGram c).PosDef :=
  posDef_of_symmetric_positive_qform _ symmetric
    (weight_seven_positive_from_finite_certificate c tail certificate)

end ManuscriptChain.Extensions
