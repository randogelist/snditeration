# Cross-reference repairs in the rebuilt PDF only

Original `Zetahyperbolic.tex` has been kept byte-identical to the uploaded source.
`Zetahyperbolic_REBUILT_WITH_PROOF_AUDIT_20261024.tex` fixes these
identifiers, without changing the mathematical wording of proofs:

- `thm:beta4_hyperbolic` -> `thm:beta4-hyperbolic`
- `thm:beta4_qadic` -> `thm:beta4-qadic`
- `eq:beta_pole` -> `eq:beta4-pole` (the named beta moment equation)
- `eq:detM-asymptotic` -> `eq:det-MK-asymptotic`
- `sec:outlook`: attached to original final Discussion and Open Problems heading

The editorial supplement is a separate inserted section; original theorem
claims are not certified merely because this PDF compiles.
