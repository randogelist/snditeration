# Direct odd-zeta irrationality: proved implication and open estimate

## Checked statements

For every admissible p=(k,m,N,K), let P_p be the positive primitive integer
normalization of the actual determinant Delta_p. Lean proves:

- P_p belongs to Z[X] and is primitive.
- degree P_p = K-N <= K.
- P_p(zeta(2k+1)) > 0.
- Every other positive rational rescaling of Delta_p with integer
  coefficients is d*P_p for a positive integer d. Its absolute value at
  every real point is therefore at least that of P_p.

These are properties of the original determinant family. No placeholder
polynomial or independent irrationality premise is used.

For each k>0, the remaining sufficient condition C_k is:

    There exists a sequence p_n=(k,m_n,N_n,K_n), every p_n admissible,
    with arbitrarily large K_n on every tail, and constants c>0, n0,
    such that P_(p_n)(zeta(2k+1)) <= exp(-c*K_n^2) for n>=n0.

The constants and sequence may depend on k. This condition is named
`GeneralIrrationality.OddWeightDecayHypothesis k`. The checked endpoints are

    C_k => Irrational(zeta(2k+1))
    (forall k>0, C_k) => forall k>0, Irrational(zeta(2k+1)).

The second endpoint is `GeneralIrrationality.all_odd_zeta_irrational` and
targets the real part of Mathlib's actual `riemannZeta` function. The
hypotheses C_k are not proved by the package.

## Preserved general linear-family interface

The reconciled package also retains `MAIN_CHAIN_ARITHMETIC` and its
`GeneralArithmetic.OddWeightFamily` interface. Its criterion uses
`degree Q_n <= D*(n+1)` and `|Q_n(center)| <= exp(-c*(n+1)^2)`.
The actual family `N=a*(n+1), K=b*(n+1)` has proved degree
`(b-a)*(n+1)` and the endpoint `LINEAR_FAMILY_IRRATIONALITY`.

The arbitrary-K route above uses `exp(-c*K_n^2)` instead. For linear
families, these rates convert by the factor b^2. They are distinct
sufficient formulations for arbitrary sequences. The theorem
`primitivePolynomial_eq_generalArithmetic` proves that both interfaces
use exactly the same canonical polynomial for the same parameters.

## Why the spectral estimate can be omitted

If zeta(2k+1)=a/b with integers a and b>=1, integrality and nonvanishing give

    1 <= b^(degree P_p) * P_p(a/b)
      <= exp(K*log(b)-c*K^2) < 1

for a sufficiently large K from the sequence. This is a contradiction.
Root separation is not used. It remains relevant to the separate effective
irrationality-measure argument.

## Concrete family and arbitrary explicit normalizations

The module also constructs the admissible family

    p_(k,n)=(k,3,3(n+1),30(n+1)),  h=27(n+1).

Its parameter conditions and unbounded K are proved. `AffineFamilyDecay k`
names the decay condition for this particular family and is a sufficient,
stronger target. No decay is asserted for this family at any new weight.
The general endpoint permits choosing a different family for each k.

Primitive minimality means one can search for any explicit positive
rational multiplier a_n such that Q_n=a_n*Delta_(p_n) has integer
coefficients. A quadratic value upper bound for these Q_n implies the same
upper bound for the canonical primitive polynomials. This transfer is
proved as `normalizedQuadraticDecay_of_integral_rescalings`.

## Exact remaining arithmetic comparison

The canonical version is now proved in Lean. Define

    Lambda_p = |leadingCoeff P_p| >= 1,
    R_p = det G_p(zeta(2k+1)) / |det M_p| > 0.

Then `LeadingCoefficientGap.primitivePolynomial_eval_eq` proves exactly

    P_p(zeta(2k+1)) = Lambda_p * R_p.

The checked `normalizedQuadraticDecay_of_gap` supplies decay from
eventual `Lambda_p <= exp(A*K^2)` and `R_p <= exp(-B*K^2)` with A<B.
`irrational_riemannZeta_of_gap` connects those estimates to the actual
Riemann zeta value for an admissible unbounded fixed-weight family.
Neither upper estimate has been proved for a new irrationality result.

For an explicit normalization written Q_(k,K)=m_(k,K)*F_(k,K), with both
factors positive at the center, sufficient bounds are

    limsup K^(-2)*log(m_(k,K)) <= A_k,
    limsup K^(-2)*log(F_(k,K)(zeta(2k+1))) <= U_k,
    A_k+U_k < 0.

They imply eventual quadratic decay with any 0<c<-(A_k+U_k).
This asymptotic formulation is an on-paper sufficient condition; the
Lean endpoint takes the explicit eventual exponential inequality.
Integer normalization and the analytic bound must concern the same family.

The separate note `docs/FixedWeightDeterminantComparison.md` derives, on
paper, that fixed odd weights have the same leading K^2 archimedean rate
when m is fixed and the geometry and scalar normalization are identical.
That comparison is not yet formalized in Lean. It does not transfer the
arithmetic multiplier rate, which remains weight-dependent.

The exact derivative reweighting factor is now checked in Lean as well.
Together with the classical Gram comparison it gives
`log(R_k/R_2) = O_(k,m)(K log K)` at fixed m,N,K.

## Arithmetic constraints on the family

`docs/ArithmeticFrontier.md` and its three supporting notes prove on paper:

- The exact large-prime denominator rank of the polynomial-quotient part,
  under a stated threshold, is `max(0,K+(2m-2)N-k(p-1))`.
- Under different explicit local conditions, a coefficient of the full
  determinant forces `v_p(Lambda_p) >= (2k+1)*(K-p+1)`.
- For fixed m and N/K tending to alpha in (0,1/3), these forced factors
  imply that primitive values grow at a positive quadratic rate at every
  sufficiently large fixed k. This fixed geometry therefore cannot work
  at every odd weight via normalized decay.
- The separate scalar family m=1, N=K-1 already has exponentially growing
  primitive values at every fixed k>=2.

These are independently audited classical proofs, not Lean-certified
arithmetic theorems. They rule out those parameter choices; they do not
rule out weight-dependent geometry or the irrationality objective.

## Weight five

`ZETA5_IRRATIONALITY_FROM_TWO_ESTIMATES` uses the already constructed
primitive family and requires only `MultiplierUpper` and `ArchimedeanUpper`.
`ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY` takes their combined value
bound instead. Positivity is supplied internally by the assembled theorem.

The multiplier and archimedean estimates remain unproved. The printed
spectral constant 11.411 is not required by either direct irrationality
endpoint; it remains an input to the legacy measure-25687 endpoint.

## What has not been concluded

No unconditional irrationality of zeta(5), zeta(7), or all odd zeta values
is asserted here. The new Lean result is the fully constructed implication
from a precise normalized decay estimate to the actual irrationality claim.
