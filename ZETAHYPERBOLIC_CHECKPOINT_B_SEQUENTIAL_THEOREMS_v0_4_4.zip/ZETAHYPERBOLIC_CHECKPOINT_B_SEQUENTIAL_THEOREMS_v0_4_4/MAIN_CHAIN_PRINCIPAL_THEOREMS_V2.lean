import MAIN_CHAIN_PRINCIPAL_THEOREMS_V1
import PaperOrder.Principal_Theorem_5_2_WeightSeven_Krein_Identity
import PaperOrder.Principal_Theorem_5_2_OneDimensional_Rational_Witness
import PaperOrder.Principal_Theorem_5_2_Finite_Krein_Cone

/-!
# Main principal theorems V2 — exact proof boundaries

(1) General dimensional spectral factorization under genuine row separation
    (from V1; not a 2x2 example).
(2) The exact weight-seven six-to-three channel bilinear Krein identity.
(3) Strict positive/negative finite-channel Gram conclusions.
(4) A concrete RATIONAL 1D Beukers pencil 37X-38, a root 38/37.

The scalar zeta(7) comparison and infinite analytic Krein tail remain
explicit mathematical frontiers, not supplied as new axioms.
-/

noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperOrder.PrincipalTheorems

/-- Explicit principal theorem 5.2: general real spectrum and exact Krein
mode identity are combined without claiming the infinite analytic bridge. -/
theorem MAIN_PRINCIPAL_THEOREMS_V2
    {h K : ℕ} (M : ℕ)
    (c : Fin h → Fin (K + 1) → ℝ)
    (A : Matrix (Fin h) (Fin h) ℝ)
    (hA : A.IsSymm)
    (hc : coefficientRowsSeparate c)
    (a b : ℕ → ℕ → ℝ) :
    (∃ p : PositiveSlopePencil h,
      p.constant = A ∧
      p.slope = coefficientSlope c ∧
      p.detPolynomial.natDegree = h ∧
      (∀ z : ℂ,
        Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0 → z.im = 0) ∧
      (∃ beta : Fin h → ℝ,
        p.detPolynomial =
          C (Matrix.det p.slope) * ∏ i, (X + C (beta i)))) ∧
    (∑ m ∈ Finset.range M, weightSevenPairing (a m) (b m)) =
      ∑ m ∈ Finset.range M, weightSevenKreinPairing (a m) (b m) := by
  exact ⟨MAIN_CHAIN_PRINCIPAL_THEOREMS_V1 c A hA hc,
    weightSeven_Krein_finite_modes M a b⟩

/-- The 1-dimensional actual polynomial certificate is unconditional;
its placement relative to zeta(7) uses the explicit scalar inequality. -/
theorem MAIN_PRINCIPAL_ONE_DIMENSIONAL_WITNESSES
    (hzeta : ManuscriptChain.Real.zeta 7 < (38 / 37 : ℝ)) :
    (ManuscriptChain.Real.dualDelta 7 negativeWeightSevenRow).eval
       (38 / 37 : ℚ) = 0 ∧
    ManuscriptChain.Real.evalQ
        (ManuscriptChain.Real.dualDelta 7 negativeWeightSevenRow)
        (ManuscriptChain.Real.zeta 7) < 0 ∧
    0 < ManuscriptChain.Real.evalQ
        (ManuscriptChain.Real.dualDelta 7 positiveWeightSevenRow)
        (ManuscriptChain.Real.zeta 7) := by
  exact ⟨negativeWeightSeven_rational_root,
    negativeWeightSeven_below_zero_at_zeta hzeta,
    positiveWeightSeven_at_zeta⟩

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.MAIN_PRINCIPAL_THEOREMS_V2
#print axioms PaperOrder.PrincipalTheorems.MAIN_PRINCIPAL_ONE_DIMENSIONAL_WITNESSES
