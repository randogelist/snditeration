# FIX15: derivative chain before scalar factorization

The Windows compiler confirmed 73 previously passed modules and reported
module 74 as the first failure. The preceding proof attempted to solve
scalar factorization with a single simplification followed by ring, leaving
an unresolved derivative expression.

The replacement first proves the exact first- and second-derivative
identities for C c * P. It then derives the Turán polynomial identity by a
three-step `calc`: derivative expansion, commutative-ring factorization,
and functoriality of the constant polynomial embedding (`map_pow`).

There are no new assumptions, `sorry`, or `axiom` declarations.
Modules 1–73 are unchanged from the last version. This module is awaiting
verification by the user's native Windows Lean 4.33.0 compiler.
No Lean compilation has been run locally.
