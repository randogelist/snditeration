import MAIN_CHAIN_PRINCIPAL_THEOREMS_V3
import PaperOrder.Principal_Theorem_5_2_Signed_Rational_Margin
import PaperOrder.Principal_Theorem_5_2_Actual_RankTwo_Signature
import PaperOrder.Principal_Theorem_5_2_RankTwo_Dual_Identification

/-!
# Principal theorems V4 - substantive PDF rebuilding checkpoint

1. Full-dimensional real spectrum (user-verified module 109).
2. Corrected principal minors (user-verified module 110).
3. Real weight-seven 1x1 dual witness 37X-38 (user-verified 113).
4. NEW unconditional zeta 7 rational tail bound and exact margin.
5. NEW actual 2x2 dual polynomial X²-X-1/36 and negative determinant
   on a rational interval containing zeta 7.

Neither the original unrestricted general-dimensional Krein cone nor
any claimed zeta(5) irrationality measure follows from these finite facts.
-/
noncomputable section
namespace PaperOrder.PrincipalTheorems

/-- The companion principal theorem endpoint includes exact rational
rank-one and rank-two consequences at the genuine ζ(7). -/
theorem MAIN_PRINCIPAL_THEOREMS_V4_SIGNED_TWO_DIMENSIONAL :
    (ManuscriptChain.Real.evalQ
       (ManuscriptChain.Real.dualDelta 7 negativeWeightSevenRow)
       (ManuscriptChain.Real.zeta 7)) ≤ -(27 / 64 : ℝ) ∧
    (weightSevenRankTwoMatrix (ManuscriptChain.Real.zeta 7)).det < 0 ∧
    ManuscriptChain.Real.evalQ
      (ManuscriptChain.Real.dualDelta 7 weightSevenTwoRows)
      (ManuscriptChain.Real.zeta 7) < 0 := by
  exact ⟨weightSeven_negative_margin_at_zeta,
    weightSevenRankTwoMatrix_det_neg_at_zeta,
    weightSevenTwoRows_det_negative_at_zeta⟩

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.MAIN_PRINCIPAL_THEOREMS_V4_SIGNED_TWO_DIMENSIONAL
