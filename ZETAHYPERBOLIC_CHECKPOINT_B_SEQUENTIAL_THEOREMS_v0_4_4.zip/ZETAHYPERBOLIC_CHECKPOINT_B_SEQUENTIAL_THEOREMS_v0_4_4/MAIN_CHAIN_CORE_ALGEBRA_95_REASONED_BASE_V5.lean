import MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V4
import PaperOrder.Theorem_5_2_Unimodular_Monomial_Basis
import PaperOrder.Corollary_3_6_Shifted_Atomic_Moment_Determinants
import PaperOrder.Theorem_6_10_Square_Integer_Gram_Barrier

/-!
# Chronological algebraic extension V5

This endpoint adds all-size rational basis changes of the two-variable
Beukers coefficient Gram slope and determinant leading coefficient,
shifted strictly positive finite atomic moments, and the square integer
Gram determinant barrier. Previous V4 chain is imported unchanged.
The 95% mathematical theorem-gate audit remains open.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra
open ManuscriptChain.Real

/-- Exact structural theorem: under arbitrary rational polynomial-basis
change, the derivative is congruent and the top coefficient scales by a
determinant square. The existing frozen V4 invariants remain accessible. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V5 {h K : ℕ}
    (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (A : Matrix (Fin h) (Fin h) ℚ) :
    (dualSlopeMatrix (dualRowChange A c) =
      A * dualSlopeMatrix c * A.transpose) ∧
    ((dualDelta s (dualRowChange A c)).coeff h =
      A.det ^ 2 * (dualDelta s c).coeff h) := by
  exact ⟨dualSlopeMatrix_rowChange A c,
    dualDelta_top_coeff_rowChange s A c⟩

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V5
