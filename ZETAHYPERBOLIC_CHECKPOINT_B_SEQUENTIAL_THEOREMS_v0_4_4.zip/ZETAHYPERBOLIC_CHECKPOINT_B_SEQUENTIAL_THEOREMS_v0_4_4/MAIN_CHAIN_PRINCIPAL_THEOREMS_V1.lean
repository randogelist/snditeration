import PaperOrder.Principal_Theorem_5_2_AllDimensional_Real_Spectrum
import PaperOrder.Principal_Theorem_3_4_All_Principal_Minors_Real_Rooted

/-!
# Principal theorem transition — exact h-dimensional dual hyperbolicity

This endpoint proves the finite-dimensional spectral part of Theorem 5.2(1)
for every h and every rectangular coefficient matrix whose rows are
independent over the real field. The theorem produces a concrete
positive-slope pencil and an eigenvalue factorization, not a postulated
spectral witness.

Full manuscript Theorem 5.2(2)-(3), Theorem 3.3 total positivity,
corrected Theorem 3.4 interlacing, and the Diophantine asymptotics in
Theorems 4.1--4.8 remain separate mathematical obligations.
-/

noncomputable section
open Polynomial
namespace PaperOrder.PrincipalTheorems

/-- An arbitrary independent polynomial coefficient family provides a
strictly positive Gram slope, a degree-h determinant, and exclusively
real spectral roots in *every* dimension h. -/
theorem MAIN_CHAIN_PRINCIPAL_THEOREMS_V1 {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℝ)
    (A : Matrix (Fin h) (Fin h) ℝ)
    (hA : A.IsSymm)
    (hc : coefficientRowsSeparate c) :
    ∃ (p : PositiveSlopePencil h),
      p.constant = A ∧
      p.slope = coefficientSlope c ∧
      p.detPolynomial.natDegree = h ∧
      (∀ z : ℂ,
        Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0 → z.im = 0) ∧
      (∃ beta : Fin h → ℝ,
        p.detPolynomial =
          C (Matrix.det p.slope) * ∏ i, (X + C (beta i))) := by
  let p : PositiveSlopePencil h :=
    { constant := A
      slope := coefficientSlope c
      constant_symmetric := hA
      slope_posDef := coefficientSlope_posDef c hc }
  refine ⟨p, rfl, rfl, ?_, ?_, ?_⟩
  · exact positiveSlopePencil_degree p
  · exact fun z hz => positiveSlopePencil_every_complex_root_real p z hz
  · exact positiveSlopePencil_factorization_exists p

/-- The jointly completed general finite-algebraic portions of the
principal spectral theorems 3.4 (corrected) and 5.2(1). -/
theorem MAIN_PRINCIPAL_3_4_AND_5_2 {n r h K : ℕ}
    (q : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hbase : q.base.PosDef)
    (e : Fin r → Fin n) (he : Function.Injective e)
    (c : Fin h → Fin (K + 1) → ℝ)
    (A : Matrix (Fin h) (Fin h) ℝ)
    (hA : A.IsSymm) (hc : coefficientRowsSeparate c) :
    (∀ z : ℂ,
      Polynomial.eval₂ (algebraMap ℝ ℂ) z
        (selectedPrincipalPencil q e).detPolynomial = 0 → z.im = 0) ∧
    (∃ beta : Fin h → ℝ,
      (Matrix.det (fun i j =>
        C (A i j) + X * C (coefficientSlope c i j)) : ℝ[X]) =
        C (Matrix.det (coefficientSlope c)) * ∏ i, (X + C (beta i))) := by
  constructor
  · intro z hz
    exact corrected_theorem_3_4_all_principal_zeros_real q hbase e he z hz
  · exact independent_coefficients_full_hyperbolicity c A hA hc

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.MAIN_CHAIN_PRINCIPAL_THEOREMS_V1

#print axioms PaperOrder.PrincipalTheorems.MAIN_PRINCIPAL_3_4_AND_5_2
