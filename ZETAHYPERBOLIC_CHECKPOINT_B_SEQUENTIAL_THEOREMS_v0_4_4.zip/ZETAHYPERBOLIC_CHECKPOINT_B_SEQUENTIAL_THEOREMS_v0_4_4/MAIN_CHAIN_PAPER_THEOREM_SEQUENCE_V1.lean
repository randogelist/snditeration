import MAIN_CHAIN_CHECKPOINT_B_THEOREM_BRIDGES_V1
import PaperBlueprint.Chapter3FiniteAlgebraProofs

/-!
# Original PDF: mathematical theorem closure, sequential build V1

This module depends on all earlier module checks in native order. It proves
only named subtheorems and three direct Chapter 3/5 blueprint goals.

Exact Chapter 2 proof bundle: FROZEN; no rerun.
Theorem 3.1: exact-degree and all-complex-roots-real blueprint.
Theorem 3.3: leading-coefficient equality (one component).
Theorem 3.4: corrected principal-minor root reality (not printed interlacing).
Corollary 3.6: n-dimensional finite atomic determinant positivity (restricted).
Theorem 3.7: first Turan Wronskian, all degrees, explicit split-root data.
Theorem 5.4: all weights, positive simple poles (not higher poles).

The 45 printed proof obligations remain NOT all completed; analytic and
arithmetic identification hypotheses and full-paper proof are outstanding.
-/

noncomputable section
namespace PaperCheckpointB

theorem chapter3_theorem3_3_leading
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).leadingCoeff =
      (ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p).det :=
  PaperBlueprint.Chapter3.theorem3_3_actual_leading_coefficient p

theorem chapter3_corollary3_6_finite_atomic
    {n : ℕ} (x w : Fin n → ℝ)
    (hx : Function.Injective x) (hw : ∀ k : Fin n, 0 < w k) :
    0 < (PaperOrder.CoreAlgebra.atomicMomentMatrix x w).det :=
  PaperBlueprint.Chapter3.corollary3_6_finite_atomic_full_rank x w hx hw

theorem chapter3_theorem3_7_first_turan
    (c : ℝ) (roots : List ℝ) (u : ℝ) :
    0 ≤ (PaperOrder.CoreAlgebra.turanWronskian
      (Polynomial.C c * PaperOrder.CoreAlgebra.rootListPolynomial roots)).eval u :=
  PaperBlueprint.Chapter3.theorem3_7_all_degree_first_turan c roots u

theorem still_partial :
    PaperCheckpointB.receipt.maturity = PaperCheckpointB.Maturity.mathematicalPartial :=
  PaperCheckpointB.checkpoint_B_status

end PaperCheckpointB

#print axioms PaperCheckpointB.chapter3_theorem3_3_leading
#print axioms PaperCheckpointB.chapter3_corollary3_6_finite_atomic
#print axioms PaperCheckpointB.chapter3_theorem3_7_first_turan
#print axioms PaperCheckpointB.still_partial
