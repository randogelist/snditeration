import Mathlib.Tactic.NormNum

/-!
Theorem 3.4 in the PDF cannot be used as printed: the first principal minor
of the genuine manuscript pencil can be constant. For k=2, m=1, N=1, K=6,
the weights gamma_a of its derivative (Theorem 2.5, formula 2.11) are:
  a=2: -1/840, a=3: 3/70, a=4: -16/63,
  a=5: 625/1386, a=6: -21/88.
Their sum is zero. The proof below kernel-checks the exact rational arithmetic.
For the full family K=30, N=3, m=3, k=2 the same phenomenon follows because
  t^2 * D_3(t)^5 / (D_30(t)/D_3(t)) = O(t^(-10)),
so its sum of residues vanishes. This more general rational-function identity
is presently justified in STRICT_SCOPE.md, not claimed by this Lean theorem.
-/

namespace PaperAudit

/-- Exact finite rational obstruction at (s,K,N,m)=(5,6,1,1). -/
theorem gamma6_residues_cancel :
    ((-1 : ℚ) / 840 + 3 / 70 - 16 / 63 + 625 / 1386 - 21 / 88) = 0 := by
  norm_num

end PaperAudit

#print axioms PaperAudit.gamma6_residues_cancel
