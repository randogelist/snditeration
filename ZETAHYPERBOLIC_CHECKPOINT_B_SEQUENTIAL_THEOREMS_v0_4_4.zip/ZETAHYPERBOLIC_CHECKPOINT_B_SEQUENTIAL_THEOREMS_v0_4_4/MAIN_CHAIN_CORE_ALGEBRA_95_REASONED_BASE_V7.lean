import MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V6
import PaperOrder.Theorem_5_2_Dual_Nonsingular_Slope_Degree
import PaperOrder.Corollary_3_6_Atomic_Weight_Order_Positive_Form
import PaperOrder.Theorem_5_2_Dual_Two_By_Two_Real_Root
import PaperOrder.Theorem_5_2_Dual_Two_By_Two_Strict_Discriminant

/-!
# Core algebra V7 — exact degree, mass monotonicity, real spectral roots

Retains all 97 previously Windows-certified V5 sources and all five
unverified V6 source files unchanged. This module requires the new proofs
and returns a substantive, combined unconditional algebraic theorem.
It does not claim the full paper or the 19/20 algebraic audit is proved.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra
open ManuscriptChain.Real

/-- The v7 output: a nonsingular rational basis change keeps the full
dual-pole determinant degree, and the 2x2 positive-slope spectral pencil
has a genuine real determinant zero. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V7
    {h K : ℕ} (s : ℕ)
    (A : Matrix (Fin h) (Fin h) ℚ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hA : A.det ≠ 0)
    (hslope : (dualSlopeMatrix c).det ≠ 0)
    (a b d u v w : ℝ) (hu : 0 < u)
    (hM : 0 < u * w - v ^ 2) :
    (dualDelta s (dualRowChange A c)).natDegree = h ∧
      ∃ x : ℝ,
        ( !![a + x * u, b + x * v; b + x * v, d + x * w] :
          Matrix (Fin 2) (Fin 2) ℝ).det = 0 := by
  exact ⟨dualDelta_degree_rowChange_of_nonsingular_slope s A c hA hslope,
    dualTwoByTwo_det_has_real_zero a b d u v w hu hM⟩

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V7
