# Scope and trust boundary - strict chronology

Target paper: *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, dated 21 October 2026 (52 pages).

## What is reusable without admitted analytic input

- `Definition_2_1_Order_s_Rational_Moment_Functional.lean`: actual rational functional, pencil and determinant.
- `Theorem_2_4_Canonical_Basis_Invariance.lean`: canonical polynomial basis invariance.
- `Theorem_2_5_Lagrange_Pole_Diagonalization.lean`: exact derivative factorization, invertibility, degree.
- `Theorem_3_1_*`: actual density, monomial moments, simple-pole evaluation, rational integral bridge and positive Gram.
- `MAIN_CHAIN_ASSEMBLED.lean`: real-rootedness and positive exact root-free disk for all admissible integer odd weights.
- `Theorem_2_4_Primitive_Normalization_Minimality.lean`: primitive normalization exists, is minimal among integral positive rescalings.
- `MAIN_CHAIN_IRRATIONALITY.lean`: real irrationality implication from decay. The decay is not proved.
- `PaperAudit/Theorem_5_4_Pole_Pair_Cancellation.lean`: algebraic cancellation of the two defining pole evaluations.

`Real.Admissible` expresses ONLY k>0,m>0,N>0,N<K, not an unproved analytic premise. These conditions are necessary to state the paper's parameterized theorem.

The previous archive has native Lean 4.33.0 validation records in `validation/`; their statements are retained *as records*. A compiler run in this delivery environment was not possible because Lean and Mathlib are not installed. Newly added Lean files are therefore source-level candidates, not newly compiled proofs. Run STRICT_RUN.cmd in your original Windows Lean environment with exactly the pinned dependency commit.

## Theorem 3.4 is untrue as printed

For `k=2, m=1, N=1, K=6`, the first derivative entry is

`M_00 = sum_(a=2)^6 gamma_a`, where

```
a    gamma_a
2    -1/840
3     3/70
4    -16/63
5    625/1386
6    -21/88
```

The five terms sum to **0** in exact rational arithmetic. This is the content of the new finite Lean certificate. The actual Gram entry at the zeta center is positive by Theorem 3.1. Thus the 1x1 minor is a nonzero constant, with **no roots**, contradicting any blanket assertion that it has one root in the interlacing sequence.

The paper's primary K=30n family has the same issue for all n>=1. For n=1,

`R(t) = D_3(t)^5 / prod_(a=4)^30 (t+a^2)`,

and `t^2 R(t) = O(t^-10)` as t tends to infinity. Its simple-pole residues sum to zero. These residues equal `a^4 * Res(R,-a^2) = gamma_a` because t^2=a^4 at the poles. Therefore M_00=0. This argument is mathematical audit, not yet a Lean theorem on the full K=30 pencil.

**Repair**: for each leading r x r pencil, define G_r positive definite, B_r=L_r^-1 M_r L_r^-T. Then B_r is real symmetric, but can have zero eigenvalues. The polynomial det(G_r + (X-xi)M_r) has degree `rank(M_r)` (not generally r), with roots `xi-1/beta` over nonzero eigenvalues beta. Eigenvalues interlace, counting zeros, via the Cholesky-compatible principal matrices; root interlacing needs case management across beta=0. The closest-root distance is defined only for nonconstant minors, or with an infinity convention.

## Corollary 3.5 correction

Writing `t=X-xi` and `Bhat_r=L_r^-1 M_r L_r^-T`, Cramer's rule gives

```
Delta_(h-1)(X)/Delta_h(X)
= (det G_(h-1)/det G_h)
  * det(I+t*Bhat_(h-1))/det(I+t*Bhat_h).
```

The printed J-fraction omits the ratio of Gram determinants and replaces `I+t*T` by `T+t*I`, which are different matrices. Lanczos also does not guarantee all positive subdiagonal entries unless the start vector is cyclic. The printed formula must be repaired before it is formalized.

## Proposition 3.2 normalization correction

The proposed real-s continuation uses `(2*pi)^s/(2*Gamma(s))` and claims coincidence with the odd-s density. At `s=2k+1`, this factor is pi/2 times the actual coefficient. The matching coefficient would be `2*(2*pi)^(s-1)/Gamma(s)`. This was already recorded in upstream `REPAIR_NOTES.md`.

## Theorem 6.10 rate direction

The paper infers `height/epsilon > 581` using `epsilon <= 1/2500` although the stated evaluation upper bound implies **epsilon >= 1/2500** for the decay-rate convention. The corrected condition needs an upper rate bound. `Zeta5Merge/Theorem6_10.lean` supplies an exact rational counterexample and a proved conditional repair. No energy comparison is silently assumed.

## Other unclosed statements

Theorem 4.4's actual 25687 measure: the uniform normalization multiplier and archimedean bounds plus spectral growth constant 11.411 are not all supplied. Theorem 4.5 mixed zeta(5)/zeta(3), Theorem 5.2 signed two-variable positive/negative cones, Theorems 5.6/5.7 p-adic estimates, and §§6.1-6.18 quantitative extensions are not all proved. The fifth and sixth sections contain some finite checked *replacements* but not their entire printed theorems. Theorem 4.11 is explicitly a conjecture.

No additional `sorry`, `axiom` or `constant` declaration has been inserted. Ordinary theorem arguments are not hidden assumptions; however the original optional modules still contain genuinely *conditional* arithmetic interfaces. `MAIN_CHAIN_STRICT` imports only the unconditional spectral core and exact finite repairs, not the conditional irrationality endpoints.

For up-to-date separate independent Lean proof of zeta(5) irrationality (not this manuscript's precise 25687 bound), see https://github.com/mo271/Zeta5 (different Lean toolchain and determinant normalization; independently verify its pinned dependencies and current proof graph before integration).
