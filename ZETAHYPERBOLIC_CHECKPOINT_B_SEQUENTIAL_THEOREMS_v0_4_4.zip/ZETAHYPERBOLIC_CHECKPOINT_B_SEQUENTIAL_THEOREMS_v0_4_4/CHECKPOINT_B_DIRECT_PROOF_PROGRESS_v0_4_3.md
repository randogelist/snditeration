# Checkpoint B / Direct Theorem Bridges v0.4.3

Prior user compiler result: **147/147 PASS** with 145 reused and 2 newly compiled.
All 147 prior source modules retain their byte-identical contents. This ZIP
will reuse the previous .olean files if the environment/dependencies match.

Four new/previously unverified modules are put at positions 148–151. They:

1. Connect the *actual* odd-weight Hankel determinant to the Chapter 3
   exact degree and complex real-root theorem (3.1).
2. Connect the *corrected* principal-minor real-root statement (3.4).
3. Prove even simple-pole cancellation for the actual tau-functional,
   paper equation (5.5), including j=1 (5.4).
4. Package those three proofs with the already certified Chapter 2 bundle.

Neither unrepaired original full interlacing, all-dimensional infinite Krein
construction, nor quantitative zeta(5) irrationality is claimed.

**NOT LOCALLY LEAN-COMPILED.** Submit to the user's Windows native Lean 4.33.
After a PASS, freeze the new 4 modules. Keep the 147 previous passes frozen.
