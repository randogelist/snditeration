# Formalization status and remaining scope

The general odd-weight spectral theorem is complete in Lean.

- The actual original rational pencil and reconstructed pencil agree exactly.
- Degree and derivative nonsingularity are proved algebraically.
- The positive density, monomial and simple-pole moments, measure construction,
  integrability, and Gram positivity are proved for every admissible instance.
- `MAIN_CHAIN_ASSEMBLED` yields the general theorem and exact zero-free disk
  with no analytic hypothesis. The default `Zetahyperbolic` import exports it.
- Primitive integer normalization, exact degree, and nonzero evaluations
  are constructed for arbitrary admissible fixed-odd-weight families.
- `MAIN_CHAIN_ARITHMETIC` proves `GENERAL_IRRATIONALITY` from the bundled
  `DecayHypothesis`: linear degree growth and quadratic exponential decay
  of the primitive integer evaluations. Its denominator-index selection is
  proved, without a quantitative spectral premise.
- The concrete proportional family `N=a*(n+1)`, `K=b*(n+1)` is admissible
  for positive `k,m,a` and `a < b`, and its degree is `(b-a)*(n+1)`.
  `LINEAR_FAMILY_IRRATIONALITY` requires only its `EventualQuadraticDecay`
  hypothesis in addition to those structural parameter conditions.

Remaining work is separate from this general endpoint:

1. Prove the normalized evaluation decay estimate for an actual fixed-weight
   family. No such estimate is proved here. A raw rational-determinant bound
   must be combined with control of the primitive normalization multiplier.
   This is the remaining quantitative input for the concrete linear-family
   irrationality implication.
2. For a quantitative irrationality measure, prove a compatible `IndexBudget`
   linking the evaluation upper bound, degree, denominators, and the actual
   spectral comparison radius. The general assembled measure endpoint
   constructs positivity and local comparison internally.
3. Correct and verify the normalization of the continuous-real-weight
   Proposition 3.2 before formalizing it. Its printed prefactor differs by
   `pi/2` from the original odd-weight formula.
4. Supply the multiplier and archimedean estimates for the direct zeta(5)
   irrationality endpoint. Positivity is supplied internally. The quantitative
   spectral estimate is needed additionally for the legacy measure endpoint.
5. Resolve the separately listed extension obligations in
   `ExternalAssumptions.md`, including finite certificates, signed-tail bounds,
   valuation identities, and energy-comparison directions.

No odd-zeta irrationality claim follows from the spectral theorem alone.
The new implications remain conditional until their decay hypotheses are proved.

`MAIN_CHAIN_IRRATIONALITY` also permits arbitrary unbounded K and proves
the all-odd-weight implication. Primitive normalization minimality transfers
any explicit positive integral-rescaling decay bound to its canonical family.
The independently reviewed comparison in `docs/FixedWeightDeterminantComparison.md`
is an on-paper result awaiting Lean formalization; arithmetic rates remain open.
