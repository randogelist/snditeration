# Direct principal-theorem progress: V2

**Compilation:** Not run locally. The sole compilation authority remains the user's native Windows Lean 4.33.0. All previously user-PASS source modules 1--100 are bitwise unchanged, and the frozen PASS-through-97 chain stays cached. Module 101 and modules 108--111 still await a user compilation checkpoint.

**Actual mathematical content in new Lean modules:**

- Theorem 5.2(2): exact binomial \((u+v)^5\), bilinear plus/minus Krein polarization with prefactor \(1/1440\), quadratic form, all finite cutoffs, and equality of the infinite mode series once summability of its terms is supplied. This is the **mode algebra**; identification with the paper's double integral remains an analytic obligation.
- Theorem 5.2(3), dimension one: **concrete rational polynomial** \(A(x)=1-6x\), coefficient row \((1,-6)\), with exact genuine dual pencil
  \[\Delta_A^{(7)}(X)=37X-38,\quad r=38/37.\]
  The constant polynomial \(A(x)=1\) gives the positive rational pencil \(\Delta_A^{(7)}(X)=X\). The Lean signed-at-zeta lemma assumes just the scalar inequality \(\zeta(7)<38/37\); the next paragraph supplies a separate, elementary handwritten proof, NOT currently kernel-verified.
- Finite-channel Krein sign theorem for all sizes: when one family of channels vanishes, genuine row separation makes the other signed Gram form strictly definite. This is not a proof that finite-mode annihilation controls infinite modes.

**Elementary analytic bound (paper proof, not yet Lean):**
For every integer \(n\ge2\), \(n^6\ge64(n-1)\): for \(n=2\) equality holds, and for \(n\ge3\), \(n^5\ge3^5>64\), whence \(n^6\ge64n\). Therefore
\[\frac1{n^7}\le\frac1{64n(n-1)}=\frac1{64}\left(\frac1{n-1}-\frac1n\right).\]
Summing the telescoping series gives
\[1<\zeta(7)\le1+\frac1{64}=\frac{65}{64}<\frac{38}{37}.\]
Thus \(37\zeta(7)-38<0\), providing a **fully explicit one-dimensional negative cone witness mathematically**. Formalize this scalar series comparison in Lean before claiming the entire witness theorem is Lean-unconditional.

**Crucial full-dimensional frontier:** for all \(h\), the printed Theorem 5.2(3) attempts to annihilate only finitely many negative modes and then simply omits the remaining infinite negative tail. The full quadratic form includes those tail modes. The implication is invalid without an exact tail estimate or a construction annihilating *all* negative modes. No general-h positive/negative polynomial-cone claim has been made in this package.

**Other full principal theorems remaining:** exact continuous positive moment bridge in Theorems 3.1 and 3.3; sign-alternation/inertia for genuine pole weights; corrected rank-sensitive interlacing in 3.4; quantitative Diophantine inputs for 4.1--4.8; general-h analytic polynomial cones 5.2(3); analytic identity/growth for 6.10.
