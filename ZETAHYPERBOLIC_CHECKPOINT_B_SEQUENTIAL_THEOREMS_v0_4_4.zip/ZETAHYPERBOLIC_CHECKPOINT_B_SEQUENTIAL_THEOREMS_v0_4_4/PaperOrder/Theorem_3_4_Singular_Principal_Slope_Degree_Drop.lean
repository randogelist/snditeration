import PaperOrder.Theorem_3_3_Exact_Pole_Determinant_Sign

/-!
# Corrected Theorem 3.4: singular derivative loses polynomial degree

The printed interlacing theorem implicitly assumes all principal derivative
matrices invertible. This is false. The correct *unconditional finite algebra*
is degree at most r, and degree strictly below r when the derivative is
singular and r is positive.
-/

noncomputable section
open Polynomial
namespace PaperOrder.CoreAlgebra

/-- Generic r-by-r rational affine pencil determinant. -/
def principalAffineDet {r : ℕ}
    (A M : Matrix (Fin r) (Fin r) ℚ) : Polynomial ℚ :=
  Matrix.det ((X : Polynomial ℚ) • (M.map Polynomial.C) +
    A.map Polynomial.C)

/-- Coefficient of the top possible degree is the derivative determinant. -/
theorem principalAffineDet_topCoeff {r : ℕ}
    (A M : Matrix (Fin r) (Fin r) ℚ) :
    (principalAffineDet A M).coeff r = M.det := by
  unfold principalAffineDet
  simpa using Polynomial.coeff_det_X_add_C_card M A

/-- Irrespective of slope singularities, its degree does not exceed r. -/
theorem principalAffineDet_degree_le {r : ℕ}
    (A M : Matrix (Fin r) (Fin r) ℚ) :
    (principalAffineDet A M).natDegree ≤ r := by
  unfold principalAffineDet
  simpa using Polynomial.natDegree_det_X_add_C_le M A

/-- Precise repair: a singular derivative cannot produce r finite roots
counted with degree, even when the pencil's determinant is nonzero. -/
theorem principalAffineDet_degree_lt_of_singular {r : ℕ}
    (A M : Matrix (Fin r) (Fin r) ℚ)
    (hr : 0 < r) (hM : M.det = 0) :
    (principalAffineDet A M).natDegree < r := by
  let q := principalAffineDet A M
  have hle : q.natDegree ≤ r := principalAffineDet_degree_le A M
  have hc : q.coeff r = 0 := by
    simpa [q, hM] using (principalAffineDet_topCoeff A M)
  -- Normalize the target to the local polynomial before invoking `omega`.
  -- Otherwise the negated goal and `hle` can be treated as distinct atoms.
  change q.natDegree < r
  by_contra hnot
  have hdegree : q.natDegree = r := by omega
  have hq : q ≠ 0 := by
    intro hzero
    have hz : q.natDegree = 0 := by simp [hzero]
    omega
  have hlead : q.leadingCoeff ≠ 0 := Polynomial.leadingCoeff_ne_zero.mpr hq
  have hleadzero : q.leadingCoeff = 0 := by
    rw [Polynomial.leadingCoeff, hdegree, hc]
  exact hlead hleadzero

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.principalAffineDet_topCoeff
#print axioms PaperOrder.CoreAlgebra.principalAffineDet_degree_lt_of_singular
