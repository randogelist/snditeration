import Zetahyperbolic.Section2Checked
import Definition_2_1_Order_s_Rational_Moment_Functional

/-!
# Definition 2.1, paper pages 3-4

The genuine rational-moment and pullback data are imported from the original
checked Section2Checked source. We expose concrete defining identities under
the PDF numbering, without replacing the functional by an arbitrary oracle.
-/

namespace PaperOrder.Section2

/-- Equation (2.1), D_0(t) = 1. -/
theorem definition_2_1_denominator_zero : Zetahyperbolic.D_poly 0 = 1 :=
  Zetahyperbolic.D_poly_zero

/-- The harmonic-number recursion for the coefficients in (2.3). -/
theorem definition_2_1_harmonic_step (s j : ℕ) :
    Zetahyperbolic.harmonicWeight s (j + 1) =
      Zetahyperbolic.harmonicWeight s j +
        (((j + 1 : ℕ) : ℚ) ^ s)⁻¹ :=
  Zetahyperbolic.harmonicWeight_succ s j

end PaperOrder.Section2

#print axioms PaperOrder.Section2.definition_2_1_denominator_zero
#print axioms PaperOrder.Section2.definition_2_1_harmonic_step
