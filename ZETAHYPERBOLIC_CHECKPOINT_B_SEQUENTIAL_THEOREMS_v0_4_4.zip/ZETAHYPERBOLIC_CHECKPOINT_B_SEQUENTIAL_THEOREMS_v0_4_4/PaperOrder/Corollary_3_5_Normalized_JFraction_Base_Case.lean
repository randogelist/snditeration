import PaperOrder.Theorem_3_4_Dodgson_Base_Case_Corrected

/-!
# Corollary 3.5: corrected 2x2 normalized Schur / J-fraction identity

For a normalized affine spectral pencil I+tB, B=[[a,b],[b,c]],
the determinant is (1+ta)(1+tc)-t²b². The Schur complement contains
1+tc and t²b²/(1+ta), not the unscaled denominators printed in (3.6).
The general Jacobi/Lanczos correspondence is NOT claimed here.
-/

namespace PaperOrder.Section3

/-- Exact determinant of the 2x2 normalized symmetric affine pencil. -/
def normalizedTwoDet (a b c t : ℝ) : ℝ :=
  (1+t*a)*(1+t*c) - (t*b)^2

theorem corollary_3_5_normalized_two_det (a b c t : ℝ) :
    (Matrix.det
      (![![1+t*a, t*b],![t*b,1+t*c]] : Matrix (Fin 2) (Fin 2) ℝ)) =
        normalizedTwoDet a b c t := by
  rw [theorem_3_4_dodgson_order_two]
  rfl

/-- Two-level J-fraction denominator, with the essential normalization. -/
theorem corollary_3_5_two_level_schur_identity
    (a b c t : ℝ) (h : 1+t*a ≠ 0) :
    (1+t*a) * (1+t*c - (t*b)^2/(1+t*a)) =
      normalizedTwoDet a b c t := by
  unfold normalizedTwoDet
  field_simp [h]

end PaperOrder.Section3

#print axioms PaperOrder.Section3.corollary_3_5_normalized_two_det
#print axioms PaperOrder.Section3.corollary_3_5_two_level_schur_identity
