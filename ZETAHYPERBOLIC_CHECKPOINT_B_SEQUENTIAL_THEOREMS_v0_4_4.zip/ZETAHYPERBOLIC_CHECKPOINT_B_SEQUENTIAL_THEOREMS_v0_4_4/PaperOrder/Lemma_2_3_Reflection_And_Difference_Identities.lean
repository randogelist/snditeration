import PaperOrder.Lemma_2_2_Pullback_Identity

/-!
# Lemma 2.3 — Reflection and difference identities (PDF pp. 5)

The proved identities are stated exactly on the monomial and simple-pole
generators of the paper's tau functional. The excluded pole indices r=0,1
for the finite difference identity are retained. Q-linearity of the functional
extends these generator results to its finite-span domain.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperOrder.Section2
open Zetahyperbolic

/-- Equation (2.6): monomial reflection. -/
theorem lemma_2_3_reflection_monomial (k d : ℕ) (hk : 1 ≤ k) :
    (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * tauMonomial k i) =
      -tauMonomial k d :=
  Zetahyperbolic.tau_reflection_monomial k d hk

/-- Equation (2.6): reflected integer-pole pair. -/
theorem lemma_2_3_reflection_pole (k : ℕ) (r : ℤ) :
    -tauPolePoly k (-1 - r) = -tauPolePoly k r :=
  Zetahyperbolic.tau_reflection_pole k r

/-- Equation (2.7), with the exact paper restrictions r≠0 and r≠1. -/
theorem lemma_2_3_difference_pole (k : ℕ) (r : ℤ)
    (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    tauPolePoly k (r - 1) - tauPolePoly k r =
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹) :=
  Zetahyperbolic.tau_difference_pole k r hr0 hr1

end PaperOrder.Section2

#print axioms PaperOrder.Section2.lemma_2_3_reflection_monomial
#print axioms PaperOrder.Section2.lemma_2_3_reflection_pole
#print axioms PaperOrder.Section2.lemma_2_3_difference_pole
