import PaperOrder.Principal_Theorem_5_2_ZetaSeven_Elementary_Bound
import Mathlib.Tactic.Linarith

/-!
# Theorem 5.2: an explicit nonzero signed margin at ζ(7)

The exact rational polynomial 37 X - 38 is not merely negative at the
actual ζ(7): its value is at most -27/64. This certificate is uniform
for every real x in the interval (0,65/64].

Unlike a floating-point check, this is an inequality in the concrete
weight-seven dual rational moment pencil. No infinite Krein tail is used.
-/
noncomputable section
namespace PaperOrder.PrincipalTheorems
open ManuscriptChain.Real

/-- Every real parameter up to 65/64 has a certified strict negative
rank-one direction with rational coefficient row (1,-6). -/
theorem negativeWeightSeven_uniform_margin (x : ℝ)
    (hx : x ≤ (65 / 64 : ℝ)) :
    evalQ (dualDelta 7 negativeWeightSevenRow) x ≤ -(27 / 64 : ℝ) := by
  rw [negativeWeightSeven_real_value]
  linarith

/-- The actual ζ(7) dual determinant has a rational negative margin. -/
theorem weightSeven_negative_margin_at_zeta :
    evalQ (dualDelta 7 negativeWeightSevenRow) (zeta 7) ≤
      -(27 / 64 : ℝ) :=
  negativeWeightSeven_uniform_margin (zeta 7) zetaSeven_le_65_div_64

/-- Unconditional simultaneous strict signs, with an explicit lower
bound for the magnitude of the negative witness. -/
theorem rankOne_weightSeven_both_signs_and_margin :
    0 < evalQ (dualDelta 7 positiveWeightSevenRow) (zeta 7) ∧
    evalQ (dualDelta 7 negativeWeightSevenRow) (zeta 7) ≤
      -(27 / 64 : ℝ) :=
  ⟨positiveWeightSeven_at_zeta, weightSeven_negative_margin_at_zeta⟩

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.negativeWeightSeven_uniform_margin
#print axioms PaperOrder.PrincipalTheorems.weightSeven_negative_margin_at_zeta
#print axioms PaperOrder.PrincipalTheorems.rankOne_weightSeven_both_signs_and_margin
