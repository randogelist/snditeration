import PaperOrder.Theorem_3_7_All_Degree_Turan_Wronskian

/-!
# Theorem 3.7: arbitrary nonzero leading coefficient

The previous result is monic. This lemma proves invariance of the Turán
positivity under arbitrary real scalar multiplication, and hence applies
to every real-rooted polynomial presented as c times its linear factors.
-/

noncomputable section
open Polynomial
namespace PaperOrder.CoreAlgebra

/-- Exact scaling identity for the Turán Wronskian. -/
theorem turanWronskian_smul (c : ℝ) (P : Polynomial ℝ) :
    turanWronskian (C c * P) = C (c^2) * turanWronskian P := by
  -- First certify the derivative of a scalar-multiplied polynomial.
  have hD : derivative (C c * P) = C c * derivative P := by
    simp only [derivative_mul, derivative_C, zero_mul, zero_add]
  have hDD : derivative (derivative (C c * P)) =
      C c * derivative (derivative P) := by
    rw [hD]
    simp only [derivative_mul, derivative_C, zero_mul, zero_add]
  calc
    turanWronskian (C c * P) =
        (C c * derivative P) * (C c * derivative P) -
        (C c * P) * (C c * derivative (derivative P)) := by
          unfold turanWronskian
          rw [hDD, hD]
    _ = (C c)^2 * turanWronskian P := by
          unfold turanWronskian
          ring
    _ = C (c^2) * turanWronskian P := by
          simp only [map_pow]

/-- Every scalar multiple of a real-rooted split polynomial obeys the
all-degree first Turán inequality (including negative or zero scalars). -/
theorem turanWronskian_split_polynomial_nonneg
    (c : ℝ) (roots : List ℝ) (x : ℝ) :
    0 ≤ (turanWronskian (C c * rootListPolynomial roots)).eval x := by
  rw [turanWronskian_smul]
  simp only [eval_mul, eval_C]
  exact mul_nonneg (sq_nonneg c)
    (turanWronskian_rootList_nonneg roots x)

/-- For nonzero leading coefficient, the inequality is strict away from
all roots of the polynomial. -/
theorem turanWronskian_split_polynomial_strict
    (c a : ℝ) (tail : List ℝ) (x : ℝ)
    (hc : c ≠ 0)
    (hx : (rootListPolynomial (a :: tail)).eval x ≠ 0) :
    0 < (turanWronskian (C c * rootListPolynomial (a :: tail))).eval x := by
  rw [turanWronskian_smul]
  simp only [eval_mul, eval_C]
  exact mul_pos (sq_pos_of_ne_zero hc)
    (turanWronskian_rootList_strict a tail x hx)

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.turanWronskian_split_polynomial_nonneg
#print axioms PaperOrder.CoreAlgebra.turanWronskian_split_polynomial_strict
