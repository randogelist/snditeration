import PaperOrder.Theorem_3_3_Total_Positivity_Leading_Sign_And_Signature
import PaperAudit.Theorem_3_4_Principal_Minor_Counterexample

/-!
# Theorem 3.4 — repair frontier

The theorem as PRINTED is not correct in full generality. The first principal
minor can be constant (its derivative is zero), so the claimed r eigenvalues
cannot all be inverted to finite roots. Below is a Lean-checked finite rational
obstruction; it does not pretend to prove the false printed theorem.
-/

namespace PaperOrder.Section3

/-- Explicit vanishing of the first-principal-minor slope at an admissible sample. -/
theorem theorem_3_4_first_principal_minor_obstruction :
    ((-1 : ℚ) / 840 + 3 / 70 - 16 / 63 + 625 / 1386 - 21 / 88) = 0 :=
  PaperAudit.gamma6_residues_cancel

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_4_first_principal_minor_obstruction
