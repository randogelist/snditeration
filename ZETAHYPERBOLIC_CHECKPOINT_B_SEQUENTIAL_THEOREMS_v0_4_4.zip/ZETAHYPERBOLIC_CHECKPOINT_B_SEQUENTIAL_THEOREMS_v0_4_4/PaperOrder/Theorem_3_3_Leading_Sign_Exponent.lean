import PaperOrder.Theorem_3_3_Total_Positivity_Leading_Sign_And_Signature

/-!
# Theorem 3.3, weight-five leading-sign exponent: exact arithmetic

The manuscript's sign exponent for K=30n, N=3n, h=27n, 2m=6 is
E(n) = (1539n² - 27n)/2.  The statements below prove the un-divided
integer polynomial identities required by the parity calculation.
They do NOT assert full total positivity or Sylvester inertia counts.
-/

namespace PaperOrder.Section3

/-- With h=27n, N=3n, and 2m-1=5, twice the determinant sign exponent
    is h(h-1)+2(2m-1)Nh = 1539n²-27n. -/
theorem theorem_3_3_weight_five_exponent_identity (n : ℤ) :
    (27*n)*(27*n-1) + 2*5*(3*n)*(27*n) =
      1539*n^2 - 27*n := by
  ring

/-- Algebraic decomposition of twice the sign exponent into the desired
    alternating-sign term and an explicitly divisible-by-two correction.
    The remaining parity fact uses n(n-1) even. -/
theorem theorem_3_3_weight_five_exponent_decomposition (n : ℤ) :
    1539*n^2 - 27*n =
      n*(n-1) + 2*(756*n^2 + 13*n*(n-1)) := by
  ring

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_3_weight_five_exponent_identity
#print axioms PaperOrder.Section3.theorem_3_3_weight_five_exponent_decomposition
