import PaperOrder.Corollary_3_6_Two_Atom_Moment_Strict_Minor

/-!
# Theorem 3.8: full finite pole-kernel matrix multiplication identity

For an arbitrary square coefficient matrix V and Gram-inverse candidate T,
the kernel matrix is exactly Vᵀ T V. This is the algebraic part of the
Christoffel-Darboux pole-kernel representation, not an analytic claim about
the true zeta-weight integral.
-/

namespace PaperOrder.CoreAlgebra

open PaperOrder.Section3
open scoped BigOperators

/-- Every matrix element of Vᵀ T V is the finite bilinear pole kernel. -/
theorem finite_pole_kernel_matrix_entry {n : ℕ}
    (V T : Matrix (Fin n) (Fin n) ℝ) (i j : Fin n) :
    (V.transpose * T * V) i j =
      finitePoleKernel T (fun a => V a i) (fun b => V b j) := by
  unfold finitePoleKernel
  simp only [Matrix.mul_apply, Matrix.transpose_apply]
  calc
    (∑ b : Fin n, (∑ a : Fin n, V a i * T a b) * V b j) =
        ∑ b : Fin n, ∑ a : Fin n, V a i * T a b * V b j := by
      apply Finset.sum_congr rfl
      intro b hb
      rw [Finset.sum_mul]
    _ = ∑ a : Fin n, ∑ b : Fin n, V a i * T a b * V b j := by
      rw [Finset.sum_comm]

/-- A symmetric coefficient matrix yields a symmetric pole-kernel matrix. -/
theorem finite_pole_kernel_matrix_symmetric {n : ℕ}
    (V T : Matrix (Fin n) (Fin n) ℝ)
    (hT : ∀ i j, T i j = T j i) (i j : Fin n) :
    (V.transpose * T * V) i j = (V.transpose * T * V) j i := by
  calc
    (V.transpose * T * V) i j =
        finitePoleKernel T (fun a => V a i) (fun b => V b j) :=
          finite_pole_kernel_matrix_entry V T i j
    _ = finitePoleKernel T (fun a => V a j) (fun b => V b i) :=
          theorem_3_8_finite_pole_kernel_symmetric T hT _ _
    _ = (V.transpose * T * V) j i :=
          (finite_pole_kernel_matrix_entry V T j i).symm

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.finite_pole_kernel_matrix_entry
#print axioms PaperOrder.CoreAlgebra.finite_pole_kernel_matrix_symmetric
