import PaperOrder.Corollary_3_6_Rectangular_Moment_Gram
import Mathlib.Tactic.Ring

/-!
# Corollary 3.6 — all-size finite atomic Hankel quadratic positivity

For *any* r-by-r moment truncation of *any* n-atomic measure, prove the
exact weighted sum-of-squares quadratic formula. In particular every
nonnegative-weight truncation is positive semidefinite. Strict positivity
is proved whenever the atomic evaluation map separates degree <r
coefficient vectors. There is no assumption of a positive integral
representation for the manuscript's continuous moment functional here.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra

/-- The real quadratic form of the actual rectangular atomic Hankel matrix. -/
def rectangularAtomicQuadraticForm {r n : ℕ}
    (x w : Fin n → ℝ) (v : Fin r → ℝ) : ℝ :=
  ∑ i : Fin r, ∑ j : Fin r,
    v i * rectangularAtomicHankel (r := r) x w i j * v j

/-- Exact weighted sum-of-squares, for every number of rows and atoms. -/
theorem rectangularAtomicQuadraticForm_sos {r n : ℕ}
    (x w : Fin n → ℝ) (v : Fin r → ℝ) :
    rectangularAtomicQuadraticForm x w v =
      ∑ k : Fin n, w k * (∑ i : Fin r, v i * x k ^ i.val) ^ 2 := by
  classical
  have hinner (k : Fin n) :
      (∑ i : Fin r, ∑ j : Fin r,
        (v i * x k ^ i.val) * (v j * x k ^ j.val) * w k) =
        w k * (∑ i : Fin r, v i * x k ^ i.val) ^ 2 := by
    calc
      (∑ i : Fin r, ∑ j : Fin r,
          (v i * x k ^ i.val) * (v j * x k ^ j.val) * w k) =
          (∑ i : Fin r, v i * x k ^ i.val) *
            ((∑ j : Fin r, v j * x k ^ j.val) * w k) := by
        rw [Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro i hi
        calc
          (∑ j : Fin r, (v i * x k ^ i.val) *
              (v j * x k ^ j.val) * w k) =
            (∑ j : Fin r, (v i * x k ^ i.val) *
              (v j * x k ^ j.val)) * w k := by rw [Finset.sum_mul]
          _ = ((v i * x k ^ i.val) *
              (∑ j : Fin r, v j * x k ^ j.val)) * w k := by
                rw [Finset.mul_sum]
          _ = (v i * x k ^ i.val) *
              ((∑ j : Fin r, v j * x k ^ j.val) * w k) := by ring
      _ = w k * (∑ i : Fin r, v i * x k ^ i.val) ^ 2 := by ring
  unfold rectangularAtomicQuadraticForm rectangularAtomicHankel
  calc
    (∑ i : Fin r, ∑ j : Fin r,
        v i * (∑ k : Fin n, w k * x k ^ (i.val + j.val)) * v j) =
      ∑ i : Fin r, ∑ j : Fin r, ∑ k : Fin n,
        (v i * x k ^ i.val) * (v j * x k ^ j.val) * w k := by
      apply Finset.sum_congr rfl
      intro i hi
      apply Finset.sum_congr rfl
      intro j hj
      rw [Finset.mul_sum, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro k hk
      rw [pow_add]
      ring
    _ = ∑ i : Fin r, ∑ k : Fin n, ∑ j : Fin r,
          (v i * x k ^ i.val) * (v j * x k ^ j.val) * w k := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [Finset.sum_comm]
    _ = ∑ k : Fin n, ∑ i : Fin r, ∑ j : Fin r,
          (v i * x k ^ i.val) * (v j * x k ^ j.val) * w k := by
      rw [Finset.sum_comm]
    _ = ∑ k : Fin n, w k * (∑ i : Fin r, v i * x k ^ i.val) ^ 2 := by
      apply Finset.sum_congr rfl
      intro k hk
      exact hinner k

/-- Every finite atomic Hankel truncation with nonnegative masses has
nonnegative quadratic form, including sizes r > n. -/
theorem rectangularAtomicQuadraticForm_nonneg {r n : ℕ}
    (x w : Fin n → ℝ) (hw : ∀ k : Fin n, 0 ≤ w k)
    (v : Fin r → ℝ) : 0 ≤ rectangularAtomicQuadraticForm x w v := by
  rw [rectangularAtomicQuadraticForm_sos]
  apply Finset.sum_nonneg
  intro k hk
  exact mul_nonneg (hw k) (sq_nonneg _)

/-- A separating evaluation map is exactly the sufficient nondegeneracy
condition to upgrade the atomic Gram form from PSD to positive definite. -/
def atomicEvaluationSeparates {r n : ℕ} (x : Fin n → ℝ) : Prop :=
  ∀ v : Fin r → ℝ,
    (∀ k : Fin n, (∑ i : Fin r, v i * x k ^ i.val) = 0) →
      v = 0

/-- Strict positivity for any number of rows, whenever the sampled
polynomial evaluation map is injective and all masses are strictly positive. -/
theorem rectangularAtomicQuadraticForm_pos_of_separation {r n : ℕ}
    (x w : Fin n → ℝ)
    (hx : atomicEvaluationSeparates (r := r) x)
    (hw : ∀ k : Fin n, 0 < w k)
    (v : Fin r → ℝ) (hv : v ≠ 0) :
    0 < rectangularAtomicQuadraticForm x w v := by
  classical
  have hthere : ∃ k : Fin n, (∑ i : Fin r, v i * x k ^ i.val) ≠ 0 := by
    by_contra hnone
    have hall : ∀ k : Fin n, (∑ i : Fin r, v i * x k ^ i.val) = 0 := by
      intro k
      by_contra hk
      exact hnone ⟨k, hk⟩
    exact hv (hx v hall)
  obtain ⟨k, hk⟩ := hthere
  rw [rectangularAtomicQuadraticForm_sos]
  have hle : w k * (∑ i : Fin r, v i * x k ^ i.val) ^ 2 ≤
      ∑ j : Fin n, w j * (∑ i : Fin r, v i * x j ^ i.val) ^ 2 := by
    exact Finset.single_le_sum
      (s := (Finset.univ : Finset (Fin n)))
      (f := fun j : Fin n => w j * (∑ i : Fin r, v i * x j ^ i.val) ^ 2)
      (by
        intro j hj
        exact mul_nonneg (le_of_lt (hw j)) (sq_nonneg _))
      (Finset.mem_univ k)
  exact lt_of_lt_of_le (mul_pos (hw k) (sq_pos_of_ne_zero hk)) hle

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_sos
#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_nonneg
#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_pos_of_separation
