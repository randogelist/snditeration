import PaperOrder.Corollary_3_5_Three_Level_Normalized_Continuant

/-!
# A sharp two-atom finite Stieltjes minor

The finite moment measure has PSD moment matrices; they are strictly
positive only while the minor order does not exceed the number of
distinct nonzero-mass support points. This module handles two atoms exactly.
-/

namespace PaperOrder.CoreAlgebra

/-- Two-atom 2x2 Hankel determinant: m0*m2-m1²=(u-v)². -/
theorem two_atom_hankel_determinant (u v : ℝ) :
    (2:ℝ)*(u^2+v^2) - (u+v)^2 = (u-v)^2 := by
  ring

/-- Every two-atom Hankel determinant of order two is nonnegative. -/
theorem two_atom_hankel_nonnegative (u v : ℝ) :
    0 ≤ (2:ℝ)*(u^2+v^2) - (u+v)^2 := by
  rw [two_atom_hankel_determinant]
  positivity

/-- Distinct support points make the order-two Hankel determinant strict. -/
theorem two_atom_hankel_strict_of_distinct (u v : ℝ)
    (huv : u ≠ v) :
    0 < (2:ℝ)*(u^2+v^2) - (u+v)^2 := by
  rw [two_atom_hankel_determinant]
  exact sq_pos_of_ne_zero (sub_ne_zero.mpr huv)

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.two_atom_hankel_determinant
#print axioms PaperOrder.CoreAlgebra.two_atom_hankel_strict_of_distinct
