import PaperOrder.Theorem_4_1_Finite_Spectral_Rational_Exclusion

/-!
# Theorem 4.1: uniform spectral transfer endpoint

This module joins the previously proved denominator squeeze, comparison
criterion, and index budget. LocalComparison, Decay, and IndexBudget are
transparent mathematical conditions in the current generalized interface.
No claim is made that the complete concrete paper estimates are discharged.
-/

noncomputable section
namespace PaperOrder.Section4
open ManuscriptChain.RealTransfer

/-- A uniform bound for all rational approximants, plus irrationality,
from explicitly named analytic/arithmetical conditions. -/
theorem theorem_4_1_uniform_measure_and_irrationality
    {Q : ℕ → Polynomial ℤ} {ξ : ℝ} {radius budget : ℕ → ℝ}
    {n₀ μ b₀ : ℕ}
    (comparison : LocalComparison Q ξ radius n₀)
    (decay : Decay Q ξ budget n₀)
    (index : IndexBudget Q radius budget n₀ μ b₀) :
    RationalMeasure ξ μ b₀ ∧ Irrational ξ := by
  constructor
  · exact conditional_measure comparison decay index
  · exact conditional_irrational comparison decay index

end PaperOrder.Section4

#print axioms PaperOrder.Section4.theorem_4_1_uniform_measure_and_irrationality
