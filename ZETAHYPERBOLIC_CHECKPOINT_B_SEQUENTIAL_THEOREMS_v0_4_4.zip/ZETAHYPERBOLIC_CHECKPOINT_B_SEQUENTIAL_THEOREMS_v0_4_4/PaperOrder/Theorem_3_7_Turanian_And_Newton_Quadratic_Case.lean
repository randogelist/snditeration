import PaperOrder.Corollary_3_6_Finite_Stieltjes_Correction

/-!
# Theorem 3.7 — quadratic real-rooted Turan and Newton subcase

The full statement of Theorem 3.7 requires arbitrary-degree real-rooted
polynomials. This file proves the exact two-root base case without assuming
positivity of the coefficients or of either root. These formulas are finite
algebra, not an unconditional completion of all of Theorem 3.7.
-/

namespace PaperOrder.Section3

/-- Exact quadratic Turan identity for a polynomial with roots a and b.
The quadratic polynomial is `(X-a)*(X-b)`; its first derivative is
`2*X-a-b` and its second derivative is `2`. -/
theorem theorem_3_7_quadratic_turan_identity (a b x : ℝ) :
    (2*x-a-b)^2 - 2*((x-a)*(x-b)) = (x-a)^2 + (x-b)^2 := by
  ring

/-- A degree-two real-rooted polynomial has nonnegative Turanian. -/
theorem theorem_3_7_quadratic_turan_nonnegative (a b x : ℝ) :
    0 ≤ (2*x-a-b)^2 - 2*((x-a)*(x-b)) := by
  rw [theorem_3_7_quadratic_turan_identity]
  positivity

/-- The normalized Newton inequality in the two-root case, with no
sign restriction on the two roots. -/
theorem theorem_3_7_quadratic_newton (a b : ℝ) :
    a*b ≤ ((a+b)/2)^2 := by
  have h : 0 ≤ (a-b)^2 := sq_nonneg (a-b)
  nlinarith

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_7_quadratic_turan_identity
#print axioms PaperOrder.Section3.theorem_3_7_quadratic_turan_nonnegative
#print axioms PaperOrder.Section3.theorem_3_7_quadratic_newton
