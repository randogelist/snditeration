import PaperOrder.Theorem_3_4_Dodgson_Three_By_Three

/-!
# Correct normalized 3-level J-fraction identity

The affine spectral pencil is I+tB; hence tridiagonal off-diagonals are
multiplied by t, and Schur complements involve t². These exact formulas
reinforce the corrected 2x2 version of Corollary 3.5.
-/

namespace PaperOrder.CoreAlgebra

/-- Three-level determinant of a tridiagonal normalized affine pencil. -/
def normalizedThreeContinuant (a b c d e t : ℝ) : ℝ :=
  (1+t*a)*((1+t*c)*(1+t*e)-(t*d)^2) - (t*b)^2*(1+t*e)

/-- The recurrence for the three-level continuant. -/
theorem normalized_three_continuant_recurrence (a b c d e t : ℝ) :
    normalizedThreeContinuant a b c d e t =
      (1+t*e)*((1+t*a)*(1+t*c)-(t*b)^2) -
         (t*d)^2*(1+t*a) := by
  unfold normalizedThreeContinuant
  ring

/-- The properly normalized nested three-level Schur complement. -/
theorem normalized_three_schur_identity (a b c d e t : ℝ)
    (h1 : 1+t*a ≠ 0)
    (h2 : 1+t*c - (t*b)^2/(1+t*a) ≠ 0) :
    (1+t*a) * (1+t*c - (t*b)^2/(1+t*a)) *
      (1+t*e - (t*d)^2/(1+t*c - (t*b)^2/(1+t*a))) =
        normalizedThreeContinuant a b c d e t := by
  -- Cancel the two Schur denominators separately.  This avoids forcing
  -- `field_simp` to clear an expanded nested rational expression.
  let aa : ℝ := 1 + t * a
  let bb : ℝ := 1 + t * c
  let cc : ℝ := 1 + t * e
  let pp : ℝ := (t * b) ^ 2
  let qq : ℝ := (t * d) ^ 2
  have haa : aa ≠ 0 := h1
  have hbb : bb - pp / aa ≠ 0 := h2
  have hcancel1 : aa * (pp / aa) = pp := by
    calc
      aa * (pp / aa) = (pp / aa) * aa := mul_comm _ _
      _ = pp := div_mul_cancel₀ pp haa
  have hcancel2 : (bb - pp / aa) * (qq / (bb - pp / aa)) = qq := by
    calc
      (bb - pp / aa) * (qq / (bb - pp / aa)) =
          (qq / (bb - pp / aa)) * (bb - pp / aa) := mul_comm _ _
      _ = qq := div_mul_cancel₀ qq hbb
  change aa * (bb - pp / aa) * (cc - qq / (bb - pp / aa)) =
    aa * (bb * cc - qq) - pp * cc
  calc
    aa * (bb - pp / aa) * (cc - qq / (bb - pp / aa)) =
        aa * ((bb - pp / aa) * cc -
          (bb - pp / aa) * (qq / (bb - pp / aa))) := by ring
    _ = aa * ((bb - pp / aa) * cc - qq) := by rw [hcancel2]
    _ = (aa * bb - pp) * cc - aa * qq := by
      calc
        aa * ((bb - pp / aa) * cc - qq) =
            (aa * (bb - pp / aa)) * cc - aa * qq := by ring
        _ = (aa * bb - pp) * cc - aa * qq := by
          rw [mul_sub, hcancel1]
    _ = aa * (bb * cc - qq) - pp * cc := by ring

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.normalized_three_continuant_recurrence
#print axioms PaperOrder.CoreAlgebra.normalized_three_schur_identity
