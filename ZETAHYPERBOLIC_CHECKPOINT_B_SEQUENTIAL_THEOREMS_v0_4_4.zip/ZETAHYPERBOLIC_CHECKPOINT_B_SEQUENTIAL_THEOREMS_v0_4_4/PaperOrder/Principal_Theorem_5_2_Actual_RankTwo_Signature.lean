import PaperOrder.Principal_Theorem_5_2_Signed_Rational_Margin
import PaperOrder.Theorem_5_2_Two_By_Two_Dual_Discriminant_SOS

/-!
# Theorem 5.2: exact rank-two signed matrix and determinant

The r=0,1 dual-moment submatrix has constant entries
[[0,1/6],[1/6,-1]] and slope I, hence its parameter-x matrix is
[[x,1/6],[1/6,x-1]]. The determinant is x²-x-1/36.

The Lean theorem here certifies this explicit matrix's determinant and
its strict negative value for every 0<x<=65/64, including x=ζ(7).
The identification with the original dual coefficient matrix is proved
in the subsequent bridge module, not assumed in this module.
-/
noncomputable section
namespace PaperOrder.PrincipalTheorems
open ManuscriptChain.Real

/-- Explicit two-by-two dual-moment matrix in the monomial coordinates
of polynomials 1 and t. -/
def weightSevenRankTwoMatrix (x : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![x, (1 / 6 : ℝ); (1 / 6 : ℝ), x - 1]

/-- No approximate constants: the determinant is an exact quadratic. -/
theorem weightSevenRankTwoMatrix_det (x : ℝ) :
    (weightSevenRankTwoMatrix x).det = x ^ 2 - x - (1 / 36 : ℝ) := by
  unfold weightSevenRankTwoMatrix
  rw [Matrix.det_fin_two_of]
  ring

/-- The entire real interval (0,65/64] lies in the negative determinant
region, including the number ζ(7). -/
theorem weightSevenRankTwoMatrix_det_neg (x : ℝ)
    (hx : 0 < x) (hupper : x ≤ (65 / 64 : ℝ)) :
    (weightSevenRankTwoMatrix x).det < 0 := by
  rw [weightSevenRankTwoMatrix_det]
  have hprod : 0 ≤ x * ((65 / 64 : ℝ) - x) :=
    mul_nonneg (le_of_lt hx) (sub_nonneg.mpr hupper)
  nlinarith

/-- A rank-two negative determinant is obtained at the ACTUAL ζ(7). -/
theorem weightSevenRankTwoMatrix_det_neg_at_zeta :
    (weightSevenRankTwoMatrix (zeta 7)).det < 0 := by
  exact weightSevenRankTwoMatrix_det_neg (zeta 7)
    (zeta_pos (s := 7) (by norm_num)) zetaSeven_le_65_div_64

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.weightSevenRankTwoMatrix_det
#print axioms PaperOrder.PrincipalTheorems.weightSevenRankTwoMatrix_det_neg
#print axioms PaperOrder.PrincipalTheorems.weightSevenRankTwoMatrix_det_neg_at_zeta
