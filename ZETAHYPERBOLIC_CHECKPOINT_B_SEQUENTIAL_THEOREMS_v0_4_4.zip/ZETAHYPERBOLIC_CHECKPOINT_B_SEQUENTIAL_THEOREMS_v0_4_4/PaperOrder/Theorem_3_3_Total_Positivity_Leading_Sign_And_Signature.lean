import PaperOrder.Proposition_3_2_Continuous_Hyperbolic_Pencil

/-!
# Theorem 3.3 — Total positivity, leading sign, and universal signature

Only the exact algebraic leading-coefficient and slope-determinant identities
are exported at this stage. The paper's stronger strict total-positivity and
inertia-count assertions require distinct proofs; NOT claimed here.
-/

namespace PaperOrder.Section3

/-- [X^h] Δ_K(X) = det M_K: algebraic part of the theorem. -/
theorem theorem_3_3_algebraic_leading_coefficient
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).leadingCoeff =
      (ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p).det :=
  ManuscriptChain.PoleDiagonalization.delta_leadingCoeff p

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_3_algebraic_leading_coefficient
