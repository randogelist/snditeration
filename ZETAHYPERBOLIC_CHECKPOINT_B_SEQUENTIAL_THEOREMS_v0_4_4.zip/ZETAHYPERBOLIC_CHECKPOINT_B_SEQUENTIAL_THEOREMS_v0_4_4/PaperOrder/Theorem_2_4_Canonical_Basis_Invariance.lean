import PaperOrder.Lemma_2_3_Reflection_And_Difference_Identities
import Theorem_2_4_Canonical_Basis_Invariance

/-!
# Theorem 2.4 — Canonical basis invariance (PDF p. 6)

The manuscript's Theorem 2.4 assumes that the rational Hankel determinant is
nonzero. Under exactly that premise, its primitive normalization is constructed
and is invariant up to sign under invertible rational basis changes.

The prior runner incorrectly checked `theorem_2_4_constructed_for_manuscript`,
which is only declared in the *next* file (Theorem_2_5_Lagrange_Pole_Diagonalization).
Here we use the already-proved result from the imported Theorem 2.4 module.
The unconditional determinant nonvanishing is discharged in Theorem 2.5.
-/

noncomputable section

namespace PaperOrder.Section2

/-- Theorem 2.4 with its explicit, PDF-stated nonzero determinant premise. -/
theorem theorem_2_4_canonical_basis_invariance
    (p : ManuscriptChain.Real.Parameters)
    (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0)
    (hdelta : ManuscriptChain.Real.delta p ≠ 0) :
    let n₀ := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p) hdelta
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
        (ManuscriptChain.Real.pencil p) A B hA hB).mpr hdelta)
    nAB.polynomial = n₀.polynomial ∨ nAB.polynomial = -n₀.polynomial :=
  ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance
    p A B hA hB hdelta

end PaperOrder.Section2

#check ManuscriptChain.BasisInvariance.det_changeBasisPencil
#check ManuscriptChain.BasisInvariance.primitive_scalar_unique
#check ManuscriptChain.BasisInvariance.primitiveNormalization_nonempty
#check ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance
#print axioms PaperOrder.Section2.theorem_2_4_canonical_basis_invariance
