import PaperOrder.Theorem_6_10_Square_Integer_Gram_Barrier
import Mathlib.Tactic.Ring
import Mathlib.Tactic

/-!
# Theorem 6.10 — exact 2x2 integer Gram/Hadamard identity

For arbitrary integer coefficient rows (a,b) and (c,d), the squared
integer determinant and squared scalar product sum exactly to the
product of the squared row norms. Thus nonzero determinant implies the
strict integer lower barrier and an unconditional finite Hadamard upper
bound. No asymptotic logarithmic height or analytic estimate is assumed.
-/

namespace PaperOrder.CoreAlgebra

/-- Elementary integer Lagrange identity: a complete Gram certificate. -/
theorem twoByTwo_integer_lagrange_identity (a b c d : ℤ) :
    (a * d - b * c) ^ 2 + (a * c + b * d) ^ 2 =
      (a ^ 2 + b ^ 2) * (c ^ 2 + d ^ 2) := by
  ring

/-- The exact two-by-two Hadamard inequality over the integers. -/
theorem twoByTwo_integer_hadamard (a b c d : ℤ) :
    (a * d - b * c) ^ 2 ≤ (a ^ 2 + b ^ 2) * (c ^ 2 + d ^ 2) := by
  have h := twoByTwo_integer_lagrange_identity a b c d
  have hnonneg : (0 : ℤ) ≤ (a * c + b * d) ^ 2 := sq_nonneg _
  omega

/-- A nonzero two-by-two integer determinant has squared absolute size
at least one. -/
theorem twoByTwo_integer_det_square_ge_one (a b c d : ℤ)
    (hne : a * d - b * c ≠ 0) :
    (1 : ℤ) ≤ (a * d - b * c) ^ 2 := by
  have hpos : (0 : ℤ) < (a * d - b * c) ^ 2 := sq_pos_of_ne_zero hne
  omega

/-- Exact two-sided barrier for an integer 2x2 nonsingular coefficient
matrix, without any unproved assumptions. -/
theorem twoByTwo_integer_gram_bounds (a b c d : ℤ)
    (hne : a * d - b * c ≠ 0) :
    (1 : ℤ) ≤ (a * d - b * c) ^ 2 ∧
      (a * d - b * c) ^ 2 ≤ (a ^ 2 + b ^ 2) * (c ^ 2 + d ^ 2) :=
  ⟨twoByTwo_integer_det_square_ge_one a b c d hne,
    twoByTwo_integer_hadamard a b c d⟩

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.twoByTwo_integer_lagrange_identity
#print axioms PaperOrder.CoreAlgebra.twoByTwo_integer_gram_bounds
