import PaperOrder.Corollary_3_5_Normalized_JFraction_Base_Case

/-!
# Corollary 3.6: finite Stieltjes measure and corrected positivity

Finite reciprocal-root power sums are moments of a discrete measure
with at most h support points. Their Hankel matrices factor as V V^T.
Such Hankel matrices are positive SEMIDEFINITE, not strictly positive
of every order: already for one atom the 2x2 Hankel determinant is zero.
This provides an unconditional, exact repair target for the PDF wording.
-/

open scoped BigOperators
namespace PaperOrder.Section3

/-- Moments of a finite discrete measure with unit masses. -/
def finiteStieltjesMoment {h : ℕ} (u : Fin h → ℝ) (n : ℕ) : ℝ :=
  ∑ i : Fin h, (u i)^n

/-- The moment Hankel matrix, not assumed to be invertible. -/
def finiteStieltjesHankel {h r : ℕ} (u : Fin h → ℝ) :
    Matrix (Fin r) (Fin r) ℝ :=
  fun i j => finiteStieltjesMoment u (i.val+j.val)

/-- Rectangular Vandermonde matrix for arbitrary real support points. -/
def finiteStieltjesVandermonde {h r : ℕ} (u : Fin h → ℝ) :
    Matrix (Fin r) (Fin h) ℝ :=
  fun i k => (u k)^i.val

/-- An exact finite identity H=V V^T, including degenerate support. -/
theorem corollary_3_6_finite_hankel_factorization {h r : ℕ}
    (u : Fin h → ℝ) :
    finiteStieltjesHankel (r:=r) u =
      finiteStieltjesVandermonde (r:=r) u *
        (finiteStieltjesVandermonde (r:=r) u).transpose := by
  ext i j
  simp only [finiteStieltjesHankel, finiteStieltjesMoment,
    finiteStieltjesVandermonde, Matrix.mul_apply, Matrix.transpose_apply,
    ← pow_add]

/-- Individual moments are nonnegative for nonnegative support. -/
theorem corollary_3_6_moment_nonnegative {h : ℕ}
    (u : Fin h → ℝ) (hu : ∀ i, 0 ≤ u i) (n : ℕ) :
    0 ≤ finiteStieltjesMoment u n := by
  unfold finiteStieltjesMoment
  apply Finset.sum_nonneg
  intro i hi
  exact pow_nonneg (hu i) n

/-- A one-atom measure has rank-one Hankel matrix: the determinant of its
    first 2x2 Hankel minor vanishes, contradicting strict positivity for
    all orders in the printed Corollary 3.6. -/
theorem corollary_3_6_single_atom_hankel_det_zero (u : ℝ) :
    (finiteStieltjesHankel (r:=2) (fun _ : Fin 1 => u)).det = 0 := by
  simp [Matrix.det_fin_two, finiteStieltjesHankel,
    finiteStieltjesMoment]
  ring

end PaperOrder.Section3

#print axioms PaperOrder.Section3.corollary_3_6_finite_hankel_factorization
#print axioms PaperOrder.Section3.corollary_3_6_single_atom_hankel_det_zero
