import PaperOrder.Theorem_3_4_Principal_Minor_Repair_Frontier
import PaperOrder.Theorem_3_3_Leading_Sign_Exponent

/-!
# Theorem 3.4, corrected finite-algebra base case

The printed interlacing statement needs repair: the 1x1 derivative may
vanish. This file proves the unconditional order-two Dodgson sign identity
for a symmetric pencil and the exact degenerate order-one alternative.
Neither proof assumes nonzero derivative minors.
-/

namespace PaperOrder.Section3

/-- The 2x2 symmetric determinant is the quadratic Dodgson expression. -/
theorem theorem_3_4_dodgson_order_two (a b c : ℝ) :
    (Matrix.det (![![a,b],![b,c]] : Matrix (Fin 2) (Fin 2) ℝ)) =
      a*c - b^2 := by
  -- First expand the determinant of the user's nested `![![...],![...]]`
  -- directly; this avoids treating it definitionally equal to `!![...]`.
  -- If simplification does not normalize the nested vector notation,
  -- extensionality converts it to the exact constructor of Mathlib's lemma.
  first
  | simpa [Matrix.det_fin_two, pow_two]
  | have hmatrix :
        (![![a, b], ![b, c]] : Matrix (Fin 2) (Fin 2) ℝ) =
          !![a, b; b, c] := by
      ext i j
      fin_cases i <;> fin_cases j <;> rfl
    rw [hmatrix]
    simpa only [pow_two] using (Matrix.det_fin_two_of a b b c)

/-- At a zero of the first leading minor, the full 2x2 determinant is
    nonpositive. This is the r=2 case of the manuscript's (3.5). -/
theorem theorem_3_4_dodgson_order_two_at_root (b c : ℝ) :
    (Matrix.det (![![(0:ℝ),b],![b,c]] : Matrix (Fin 2) (Fin 2) ℝ)) =
      -b^2 := by
  rw [theorem_3_4_dodgson_order_two]
  ring

theorem theorem_3_4_dodgson_order_two_nonpositive (b c : ℝ) :
    (Matrix.det (![![(0:ℝ),b],![b,c]] : Matrix (Fin 2) (Fin 2) ℝ)) ≤ 0 := by
  rw [theorem_3_4_dodgson_order_two_at_root]
  exact neg_nonpos.mpr (sq_nonneg b)

/-- If the first derivative entry is zero, the order-one pencil is
    constant and therefore has no root when its base entry is positive. -/
theorem theorem_3_4_first_minor_constant (g m center x : ℝ)
    (hm : m = 0) : g + (x-center)*m = g := by
  simp [hm]

theorem theorem_3_4_first_minor_no_real_root (g m center x : ℝ)
    (hg : 0 < g) (hm : m = 0) : g + (x-center)*m ≠ 0 := by
  rw [theorem_3_4_first_minor_constant g m center x hm]
  exact ne_of_gt hg

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_4_dodgson_order_two
#print axioms PaperOrder.Section3.theorem_3_4_dodgson_order_two_at_root
#print axioms PaperOrder.Section3.theorem_3_4_first_minor_no_real_root
