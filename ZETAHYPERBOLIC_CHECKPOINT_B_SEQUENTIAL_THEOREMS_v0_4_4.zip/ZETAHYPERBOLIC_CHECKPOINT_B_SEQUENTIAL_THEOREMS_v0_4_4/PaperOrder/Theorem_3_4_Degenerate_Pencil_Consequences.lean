import PaperOrder.Theorem_3_4_Singular_Slope_Real_Rootedness

/-!
# Corrected Theorem 3.4: spectral defects versus genuine roots

A zero eigenvalue corresponds to a constant factor 1. We record the exact
finite-polynomial consequences of the noninvertible-slope factorization.
-/

noncomputable section
open scoped BigOperators
open Polynomial ManuscriptChain.Spectral

namespace PaperOrder.CoreAlgebra

/-- The determinant polynomial never vanishes at the centre. -/
theorem weak_pencil_center_nonzero {n : ℕ}
    (p : SymmetricAffinePencil n) (h : p.base.PosDef) :
    p.detPolynomial.eval p.center ≠ 0 :=
  (weakSpectralFactorizationOfPosDef p h).center_ne_zero

/-- If the complete slope vanishes then the determinant is a constant, so
there are no finite complex roots at all. -/
theorem zero_direction_has_constant_determinant {n : ℕ}
    (p : SymmetricAffinePencil n) (hd : p.direction = 0) :
    p.detPolynomial = C (Matrix.det p.base) := by
  apply Polynomial.funext
  intro x
  rw [p.eval_detPolynomial]
  simp [SymmetricAffinePencil.detValue,
    SymmetricAffinePencil.matrixAt, hd]

/-- The same zero-slope pencil has no complex root if its base is definite. -/
theorem zero_direction_has_no_complex_root {n : ℕ}
    (p : SymmetricAffinePencil n) (positive : p.base.PosDef)
    (hd : p.direction = 0) (z : ℂ) :
    Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial ≠ 0 := by
  rw [zero_direction_has_constant_determinant p hd]
  simpa using
    (Complex.ofReal_ne_zero.mpr (ne_of_gt positive.det_pos))

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.zero_direction_has_constant_determinant
#print axioms PaperOrder.CoreAlgebra.zero_direction_has_no_complex_root
