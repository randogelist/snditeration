import PaperOrder.Theorem_5_2_Dual_Determinant_Top_Coefficient

/-!
# Theorem 3.3: constructive diagonal-congruence inertia certificate

Full signature requires the signs of the actual pole weights. Here the
congruence itself already provides a basis in which every coordinate is
exactly one diagonal weight. This is a structural, conditional-free identity
for the genuine rational derivative matrix, not an assumed inertia theorem.
-/

noncomputable section
open ManuscriptChain.PoleDiagonalization
namespace PaperOrder.CoreAlgebra

/-- All off-diagonal entries of the Lagrange-normalized derivative vanish. -/
theorem actual_pole_normalized_slope_offdiag
    (p : ManuscriptChain.Real.Parameters)
    (a b : Fin p.h) (hab : a ≠ b) :
    (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose) a b) = 0 := by
  rw [pole_slope_diagonal]
  simp [Matrix.diagonal_apply, hab]

/-- The entire normalized derivative has no hidden off-diagonal terms. -/
theorem actual_pole_normalized_slope_exact
    (p : ManuscriptChain.Real.Parameters) :
    (poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose =
        Matrix.diagonal (poleWeight p) :=
  pole_slope_diagonal p

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.actual_pole_normalized_slope_offdiag
