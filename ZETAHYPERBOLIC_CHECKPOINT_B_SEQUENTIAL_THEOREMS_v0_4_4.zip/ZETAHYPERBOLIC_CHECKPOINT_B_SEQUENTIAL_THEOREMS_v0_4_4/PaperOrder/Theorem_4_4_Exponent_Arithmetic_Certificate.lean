import PaperOrder.Proposition_4_3_Abstract_Ultrametric_Disk

/-!
# Theorem 4.4: exact rational exponent arithmetic

This module certifies the rational inequalities in the last step of the
paper's transfer to the advertised exponent 25687. It does not assert that
the spectral upper bound or determinant decay has been established.
-/

namespace PaperOrder.Section4

/-- The rounded index c=2251 lies on the required side of both rate margins. -/
theorem theorem_4_4_exact_rate_margins :
    (9 / 10 : ℚ) / 2251 < (1 / 2500 : ℚ) ∧
    (11411 / 1000 : ℚ) * 2251 < 25687 := by
  norm_num

/-- Exact margin between the paper's exponent 25687 and rho*c. -/
theorem theorem_4_4_exponent_margin :
    (25687 : ℚ) - (11411 / 1000 : ℚ) * 2251 = 839 / 1000 := by
  norm_num

/-- The coefficient-decay margin for the selected K-index is positive. -/
theorem theorem_4_4_decay_margin :
    (1 / 2500 : ℚ) - (9 / 10 : ℚ) / 2251 = 1 / 5627500 := by
  norm_num

end PaperOrder.Section4

#print axioms PaperOrder.Section4.theorem_4_4_exact_rate_margins
#print axioms PaperOrder.Section4.theorem_4_4_exponent_margin
