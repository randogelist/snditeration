import PaperOrder.Principal_Theorem_5_2_Actual_RankTwo_Signature
import PaperOrder.Theorem_5_2_Dual_Determinant_Top_Coefficient
import Mathlib.Tactic

/-!
# Principal 5.2, actual finite moment model (rank two)

The full 2 x 2 monomial rows 1 and t, padded to the legitimate
K=2 coefficient lattice, yield precisely the weight-seven real pencil
[[X, 1/6], [1/6, X-1]]. In particular its determinant is
X^2 - X - 1/36 and, evaluated at ζ(7), is strictly negative.

This bridge is a NEW proof module and must be checked by the user's
native compiler; the frozen 115-module base is unchanged.
-/
noncomputable section
open scoped BigOperators
open Polynomial
namespace PaperOrder.PrincipalTheorems
open ManuscriptChain.Real
open PaperOrder.CoreAlgebra

/-- Canonical full two-row monomial family, in the paper's K=2 space. -/
def weightSevenTwoRows : Fin 2 → Fin 3 → ℚ :=
  dualMonomialCoefficients 2

/-- The true dual pencil has rational constant matrix
[[0,1/6],[1/6,-1]]. -/
theorem weightSevenTwoRows_constant :
    dualConstantMatrix 7 weightSevenTwoRows =
      !![(0 : ℚ), (1 / 6 : ℚ); (1 / 6 : ℚ), (-1 : ℚ)] := by
  classical
  ext i j
  -- Every entry is a CLOSED equality in ℚ with indices in Fin 2.
  -- Reduce the four finite sums definitionally; avoid rewriting an
  -- open `if (0 : Fin 3) = 2` as though it were a polynomial atom.
  fin_cases i <;> fin_cases j <;>
    (first
      | decide
      | (simp [dualConstantMatrix, weightSevenTwoRows,
            dualMonomialCoefficients, ManuscriptChain.Real.dualConstant,
            ManuscriptChain.Real.harmonic,
            Fin.sum_univ_succ, Fin.sum_univ_zero] <;>
          norm_num <;> ring_nf))

/-- Under the genuine rational moment definition the rank-two slope is
exactly the identity, as proved in the frozen all-dimension module 79. -/
theorem weightSevenTwoRows_slope :
    dualSlopeMatrix weightSevenTwoRows = 1 := by
  exact dualMonomialSlope_eq_one 2

/-- Complete rational polynomial of the actual rank-two moment pencil. -/
theorem weightSevenTwoRows_det_polynomial :
    dualDelta 7 weightSevenTwoRows =
      X ^ 2 - X - C (1 / 36 : ℚ) := by
  classical
  unfold dualDelta
  rw [dualPencil_decomposition]
  rw [weightSevenTwoRows_slope, weightSevenTwoRows_constant]
  -- The closed rational constant is a PRODUCT after expanding the
  -- two-by-two determinant, not a power.  Certify the C-multiplication
  -- BEFORE the ring step so the factor can be rewritten exactly.
  have hC_mul :
      (C ((6 : ℚ)⁻¹) : Polynomial ℚ) * C ((6 : ℚ)⁻¹) =
        C ((36 : ℚ)⁻¹) := by
    rw [← map_mul]
    norm_num
  rw [Matrix.det_fin_two]
  simp [Matrix.add_apply, Matrix.smul_apply, Matrix.map_apply,
    Matrix.one_apply, Matrix.of_apply] <;>
    rw [hC_mul] <;>
    ring

/-- At the ACTUAL zeta value, the true two-row rational dual
Beukers determinant is strictly negative, not only the displayed matrix. -/
theorem weightSevenTwoRows_det_negative_at_zeta :
    evalQ (dualDelta 7 weightSevenTwoRows) (zeta 7) < 0 := by
  have heval :
      evalQ (dualDelta 7 weightSevenTwoRows) (zeta 7) =
        (zeta 7) ^ 2 - (zeta 7) - (1 / 36 : ℝ) := by
    rw [weightSevenTwoRows_det_polynomial]
    simp [evalQ, realPolynomial]
  rw [heval]
  simpa only [weightSevenRankTwoMatrix_det] using
    weightSevenRankTwoMatrix_det_neg_at_zeta

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.weightSevenTwoRows_constant
#print axioms PaperOrder.PrincipalTheorems.weightSevenTwoRows_slope
#print axioms PaperOrder.PrincipalTheorems.weightSevenTwoRows_det_polynomial

#print axioms PaperOrder.PrincipalTheorems.weightSevenTwoRows_det_negative_at_zeta
