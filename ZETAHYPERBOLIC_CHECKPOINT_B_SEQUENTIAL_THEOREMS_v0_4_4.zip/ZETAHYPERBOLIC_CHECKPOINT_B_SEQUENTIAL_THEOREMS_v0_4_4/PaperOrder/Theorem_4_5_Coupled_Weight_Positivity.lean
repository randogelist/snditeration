import PaperOrder.Theorem_4_4_Spectral_Gap_From_Beta_Bound
import Mathlib.Tactic

/-!
# Theorem 4.5 — positivity of the coupled zeta(5) and zeta(3) weight

For every t>=1 and b>0, a<kappa*b with kappa>0 implies
b*t-a/kappa>0. With kappa=pi^2/3 and t=l^2 this is precisely the
coefficient positivity underlying the manuscript's coupled weight
b*w5(y)-a*y^2*w3(y). Here the coefficient and finite positive-sum
implications are proved. The paper's analytic weight identity,
Archimedean determinant asymptotics and p-adic normalization remain
separate proof tasks, not hidden assumptions.
-/

namespace PaperOrder.Section4

/-- The sign condition for each normalized exponential coefficient. -/
theorem theorem_4_5_coupled_coefficient_positive
    (a b κ t : ℝ) (hb : 0 < b) (hκ : 0 < κ)
    (ha : a < κ * b) (ht : 1 ≤ t) :
    0 < b * t - a / κ := by
  have hdiv : a / κ < b :=
    (div_lt_iff₀ hκ).2 (by nlinarith [ha])
  have haux : 0 ≤ b * (t - 1) :=
    mul_nonneg (le_of_lt hb) (by linarith)
  nlinarith

/-- The precise pi-squared threshold in the manuscript, with t>=1. -/
theorem theorem_4_5_pi_weight_coefficient_positive
    (a b t : ℝ) (hb : 0 < b)
    (ha : a < (Real.pi ^ 2 / 3) * b) (ht : 1 ≤ t) :
    0 < b * t - a / (Real.pi ^ 2 / 3) := by
  have hπ : 0 < Real.pi := Real.pi_pos
  have hκ : 0 < (Real.pi ^ 2 / 3 : ℝ) := by positivity
  exact theorem_4_5_coupled_coefficient_positive
    a b (Real.pi ^ 2 / 3) t hb hκ ha ht

/-- An arbitrary finite positive combination of coupled coefficients
is strictly positive. This is a finite Gram-weight input, not a
completed determinant estimate. -/
theorem theorem_4_5_finite_coupled_weight_positive
    {ι : Type*} [DecidableEq ι] (s : Finset ι)
    (w t : ι → ℝ) (a b κ : ℝ)
    (hs : s.Nonempty)
    (hw : ∀ i ∈ s, 0 < w i)
    (ht : ∀ i ∈ s, 1 ≤ t i)
    (hb : 0 < b) (hκ : 0 < κ) (ha : a < κ * b) :
    0 < s.sum (fun i => w i * (b * t i - a / κ)) := by
  apply Finset.sum_pos
  · intro i hi
    exact mul_pos (hw i hi)
      (theorem_4_5_coupled_coefficient_positive a b κ (t i) hb hκ ha (ht i hi))
  · exact hs

end PaperOrder.Section4

#print axioms PaperOrder.Section4.theorem_4_5_coupled_coefficient_positive
#print axioms PaperOrder.Section4.theorem_4_5_pi_weight_coefficient_positive
#print axioms PaperOrder.Section4.theorem_4_5_finite_coupled_weight_positive
