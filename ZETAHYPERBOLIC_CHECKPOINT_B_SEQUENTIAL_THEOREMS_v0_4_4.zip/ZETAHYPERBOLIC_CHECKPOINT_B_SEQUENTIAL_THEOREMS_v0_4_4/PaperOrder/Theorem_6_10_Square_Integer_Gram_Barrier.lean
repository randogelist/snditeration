import PaperOrder.Theorem_5_2_Dual_Gram_Quadratic_SOS
import Mathlib.Tactic

/-!
# Theorem 6.10 — unconditional integer square-Gram determinant barrier

For a full-rank SQUARE integer coefficient matrix C, det(C Cᵀ) = det(C)^2
is a strictly positive integer, and is therefore at least one. This is an
honest finite-dimensional subcase of the manuscript's integer Gram bounds.
The rectangular case and its asymptotic logarithmic height require separate
results and are not silently claimed here.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra

/-- Exact Gram determinant square for arbitrary integer square matrices. -/
theorem squareIntegerGram_det (h : ℕ)
    (A : Matrix (Fin h) (Fin h) ℤ) :
    (A * A.transpose).det = A.det ^ 2 := by
  rw [Matrix.det_mul, Matrix.det_transpose]
  ring

/-- A nonzero integer determinant has square at least one. -/
theorem squareIntegerGram_det_ge_one (h : ℕ)
    (A : Matrix (Fin h) (Fin h) ℤ)
    (hA : A.det ≠ 0) :
    (1 : ℤ) ≤ (A * A.transpose).det := by
  rw [squareIntegerGram_det]
  have hpos : (0 : ℤ) < A.det ^ 2 := sq_pos_of_ne_zero hA
  omega

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.squareIntegerGram_det
#print axioms PaperOrder.CoreAlgebra.squareIntegerGram_det_ge_one
