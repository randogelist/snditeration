# FIX7 — Proposition 4.2 finite resultant product barrier

**Compiler checkpoint:** Modules 1–49 passed on the user's native Windows Lean 4.33.0. Module 50 failed at its integer absolute-value lower bound because `omega` had no hypothesis linking `|z|` to the nonzero input `z ≠ 0`.

Minimal repair:

```lean
  have hpos : (0 : ℤ) < |z| := abs_pos.mpr hz
  have hzint : (1 : ℤ) ≤ |z| := by
    omega
  exact_mod_cast hzint
```

This makes the elementary fact `0 < |z|` explicit; discrete integer arithmetic then gives `1 ≤ |z|`. All other Lean files remain unchanged. The next compiler check is 50/53, while 1–49 are eligible for frozen reuse.

The paper's full algebraic-height transfer and the concrete resultant identity are **not** implied by this small lemma.

**Validation:** No local Lean compilation was performed. The user's Windows Lean compiler remains authoritative.
