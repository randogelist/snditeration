# Original 52-page PDF: paragraph integration checkpoint V1

## Frozen compiler checkpoint

The user's native Windows Lean 4.33 runner reported `LEAN_BUILD=PASS`,
`FROZEN_PASS=130`, `UNCHANGED_SKIPPED=130`, `BUILD_FROM=NONE`. We preserve
those exact 130 source modules unchanged and append **14 new source-only
paragraph registry/checkpoint files**, to be verified by the user's compiler.

## Meaning of "paragraphs integrated in Lean"

The original paper's checked LaTeX source, typesetting the exact 52-page PDF,
was segmented at blank lines and each segment was embedded in the new
`PaperParagraph` Lean files as a typed, inert source string, with source line
numbers and SHA-256 receipts. This representation includes narrative, formula
blocks, headings, 46 numbered statements, 45 source proof environments, and
references; it does **not** mean that these statements are mathematically
proved. The PDF's 52 page text hashes and all 46 numbered headings have their
own Lean provenance registries, and PDF text-block receipts are in CSV.

| Source section | Indexed LaTeX units | Lean module |
|:--|--:|:--|
| FrontMatter | 3 | `PaperParagraph.FrontMatter` |
| Introduction | 10 | `PaperParagraph.Introduction` |
| Chapter2 | 17 | `PaperParagraph.Chapter2` |
| Chapter3 | 36 | `PaperParagraph.Chapter3` |
| Chapter4 | 36 | `PaperParagraph.Chapter4` |
| Chapter5 | 33 | `PaperParagraph.Chapter5` |
| Chapter6 | 83 | `PaperParagraph.Chapter6` |
| Discussion | 6 | `PaperParagraph.Discussion` |
| Bibliography | 17 | `PaperParagraph.Bibliography` |
| **Total** | **241** | |

The PDF extraction yields **1586 PDF text/layout blocks**, indexed
externally in the CSV receipt. PDF blocks often split displayed equations and
are not literal LaTeX paragraphs. The 241 LaTeX units are literal
blank-line-separated *source blocks* (including structural commands); they
should not be described as 241 narrative paragraphs.

## Compiler-visible conditions

- `sourceParagraphsRegistered`: exactly 241 authorial source blocks.
- `originalNumberedHeadingsRegistered`: 46 paper heading anchors.
- `originalPdfPagesRegistered`: 52 PDF pages.
- `PaperBlueprint.BlueprintBundle`: **still requires real proofs** for Chapters 3-6.
- Section 2's four generator/normal-form proofs continue to be reused,
  unchanged, from the existing user-verified `Chapter2Certified.lean`.
- Printed Theorem 3.4 still requires the corrected statement. Its original
  LaTeX source is preserved, rather than silently changed.

**When the user's next `run.cmd` returns `LEAN_BUILD=PASS`, freeze the
paragraph-integration checkpoint as a structural source coverage milestone,
not a claim that the full 52-page mathematical paper is proved.**

Source provenance: original PDF SHA256 `935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`.
