# Integration and repair notes — 23 October 2026

## General odd-weight main chain

The theorem-numbered modules are integrated into the original package.
`ManuscriptCompatibility.lean` proves equality of the original partial-fraction
construction and the chain's quotient/residue construction, entry by entry.
Consequently the actual original matrix pencil, determinant, and real Gram
evaluation agree for arbitrary `k,m,N,K`. The zeta series convention is also
identified with the real part of Mathlib's `riemannZeta` at each admissible
odd integer.

`MAIN_CHAIN.lean` now exposes the general Theorem 3.1 endpoint. After parameter
admissibility, its single analytic premise is positivity of the actual Gram
matrix at `zeta(2*k+1)`. The original-package `Zetahyperbolic.MAIN_CHAIN`
accepts the corresponding premise for the evaluated original `G_pencil`.
Full determinant degree and derivative nonsingularity are proved without this
premise. The chain constructs real nonzero spectral factors, identifies every
complex root as `zeta(2*k+1) - 1/beta_i`, and proves the positive zero-free
radius `1 / max_i |beta_i|`, including a root at that boundary distance.
"Distinct from zeta(s)" does not assert pairwise distinct or simple roots.

`Theorem_3_1_Positive_Moment_Realization.lean` supplies a proved analytic bridge
from a nonzero measure with no point masses, integrable finite moments, and
the actual entrywise moment identities to Gram positivity. Construction of
that realization for the manuscript's proposed hyperbolic weight remains
unproved; those analytic conditions remain explicit inputs to the bridge.

The default `Zetahyperbolic.lean` imports the general development.
`APPLICATIONS.lean` retains the specialized endpoints and `AUDITED_REPAIRS`.
The old zeta(5) endpoints have moved to `ZETA5_APPLICATION.lean` and
`Zetahyperbolic/Zeta5Application.lean`, and are renamed
`ZETA5_APPLICATION` and `ZETA5_APPLICATION_MEASURE` (with corresponding
variants). Their four uniform hypotheses are unchanged. Their primitive
normalization, explicit index budget, original S_K5 scaling, `mainF`
identification, and target identification remain proved. Theorem 4.1's
generic Diophantine transfer remains separate from the general spectral
endpoint. See `ExternalAssumptions.md` for the exact remaining inputs.

## Original admitted statements

The uploaded blueprint had 23 admitted declarations, and ExternalResults had
one admitted irrationality theorem. Their source text is preserved verbatim
under `provenance/`. This revision does not claim to solve all 24 obligations.
The checked default uses proved algebra plus explicit conditional replacements.
The external theorem name now requires its former assertion as an explicit
argument, and the main endpoint does not depend on that wrapper.

## Repairs by manuscript sector

| Sector | Change |
|---|---|
| Section 2 | Original algebra preserved; only Lean 4.33 tactic compatibility changes. Pole nonsingularity and primitive-content invariance remain proved. |
| Section 3 | General odd-weight spectral factors, exact real root description, and a positive complex zero-free disk follow from actual Gram positivity. The moment-realization bridge is proved, but its manuscript-specific realization remains open. |
| Proposition 3.2 | Audit the continuous-weight prefactor mismatch; no continuous-weight extension is certified. |
| Section 4 | Preserve generic conditional Diophantine transfer and the optional zeta(5) application. Primitive normalization and specialized index selection are proved; the four application estimates remain explicit. |
| 5.2 | Keep the signed infinite tail through a quantified tail-bound interface. |
| 6.3(2) | Replace the unsupported printed positive subspace with finite-certificate and tail hypotheses. The h=4 objection concerns the paper's specific construction; the old weakened Lean existential did not encode that construction. |
| 6.4 | Do not identify formal beta moments with the printed weight without an analytic bridge. |
| 6.8 | No mixed-zeta independence conclusion is inferred from a zeta(5)-only decay premise. |
| 6.9 | Define the corrected numerator with `(t-j)^6/(n!)^5`, the triple-pole functional, and the 9m-dimensional three-jet system. Prove finite congruence and conditional nonvanishing. |
| 6.10(1) | Prove the finite leading-coefficient/determinant identity. Retain no universal squared-polynomial perturbation assertion. Correct the decay-rate direction and require positivity plus an upper rate bound for the ratio >581. |
| 6.16 | Uniform comparison explicitly requires the actual compact ratio, continuity and positivity at both endpoints. |
| 6.17 | Correct the parity-dependent index shift and unique denominator-multiple window. |
| 6.18 | Retain only the exact degree and quotient-vanishing consequences under their stated hypotheses. |

The new Theorem 6.9 congruence theorem is finite algebra. It does not prove
that its supplied coefficients are those of the actual kernel, that a specific
jet table is invertible, or that the desired q-adic valuation follows.
The new Theorem 6.10 identity constructs the positive matrix square root and
proves the exact coefficient formula; no equilibrium asymptotic is inferred.

Several old statement titles were broader than their Lean conclusions
(e.g. continued fractions, full power-sum bounds, and the spectral theorem).
Those archived titles are not claims of coverage by the default build.

## Reproducibility

The original pin was Lean/Mathlib 4.35.0. This revision is checked with Lean
4.33.0 and the exact compatible Mathlib commit recorded in the README.
`Section3Elementary` uses the 4.33 name `Finset.one_le_prod`; two redundant
`ring` calls after `field_simp` were removed from the original content proof.
The compiler and axiom audit logs accompany the revised package.

No external GitHub repository has been created or modified by this revision.

## PDF alignment follow-up

The supplied PDF is byte-identical to the manuscript reference used for this
package. The principal general endpoint is its Theorem 3.1, covering odd
integer weights. Theorem 3.3's alternating-sign inertia argument is compatible
with the pole weights `sign(gamma_a) = (-1)^(a-1)`, but the general endpoint
does not claim to formalize the sign-count/inertia extension, strict total
positivity, or moment determinacy.

Proposition 3.2 prints the continuous-weight density prefactor
`(2*pi)^s / (2*Gamma(s))`. At `s=2*k+1` this is `pi/2` times the original
prefactor `2*(2*pi)^(2*k)/(2*k)!`. Its direction matrix is unchanged, so the
claimed exact odd-weight coincidence does not follow as printed. The matching
prefactor would be `2*(2*pi)^(s-1)/Gamma(s)`. This is an audited manuscript
issue, not a formalized correction to the continuous extension, and does not
change the scope of the odd-integer spectral endpoint.

Theorem 6.10, pp. 39–40, states the energy lower-bound constant
0.23310. The imported repair module previously used the stronger input 0.23338.
`Zeta5Merge.Theorem6_10.energyLower` now equals `2331/10000`, matching the PDF.
The implication to a height/decay ratio greater than 581 still compiles under
positive epsilon and the explicit upper bound epsilon <= 1/2500. The energy
lower bound and rate upper bound remain hypotheses; neither is proved by
this arithmetic correction. The four optional zeta(5)-application hypotheses
are unchanged.
