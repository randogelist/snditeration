# FIX9 — Theorem 3.4 singular principal-slope degree drop

User Windows Lean 4.33.0 checkpoint: 60 modules compiler-verified; module 61 failed at line 47 in an `omega` degree equality step.

**Diagnosis:** The proof introduced `let q := principalAffineDet A M`, but `by_contra` negated the expanded theorem target. `omega` then saw `q.natDegree` and `(principalAffineDet A M).natDegree` as distinct atoms. It cannot prove equality from that representation alone.

**Exact repair:** Immediately before `by_contra hnot`, add:

```lean
  change q.natDegree < r
```

The theorem statement is not weakened or changed; this is only a definitional normalization. The arithmetic contradiction and leading coefficient argument are preserved.

Only one Lean source is modified relative to v0.4.7. Modules 1–60 remain byte-for-byte identical. All unfinished modules 61–66 remain unverified until the user's own compiler runs them.

Run from Windows CMD:

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CORE_ALGEBRA_95_TARGET_v0_4_8_FROZEN_FASTCORE_FIX9.zip" && call "ZETAHYPERBOLIC_CORE_ALGEBRA_95_TARGET_v0_4_8_FROZEN_FASTCORE_FIX9\run.cmd"
```

One ZIP, one root `run.cmd`, existing frozen cache and native Lean 4.33.0. No Lean compilation was run by the assistant.
