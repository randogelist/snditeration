import PaperBlueprint.Master

/-!
ORIGINAL MANUSCRIPT PARAGRAPH-LEVEL STRUCTURAL REGISTRY
Source: original authorial Zetahyperbolic.tex (52-page PDF), and its included
Zetahyperbolic-bibliography.tex. One entry per blank-line-separated source
span. This is SOURCE INTEGRATION, never a proof of a mathematical theorem.
The source paragraphs contain LaTeX, not trusted Lean proof terms.
-/
namespace PaperParagraph

structure SourceSegment where
  id : Nat
  texFile : String
  lineFirst : Nat
  lineLast : Nat
  sectionNumber : Nat
  kind : String
  sourceText : String
  sha256Receipt : String

structure PDFTheoremAnchor where
  label : String
  chapter : Nat
  page : Nat
  pdfTextBlock : Nat
  goalIdentifier : String
  proofAuditStatus : String

end PaperParagraph
