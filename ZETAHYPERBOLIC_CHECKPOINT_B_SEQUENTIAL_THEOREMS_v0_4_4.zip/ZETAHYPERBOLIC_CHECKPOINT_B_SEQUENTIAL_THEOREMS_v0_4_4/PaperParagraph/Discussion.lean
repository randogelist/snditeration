import PaperParagraph.Foundation

/-! This module stores original-source LaTeX text as inert strings.
Nothing here is a mathematical proof or a new axiom. -/
namespace PaperParagraph.Discussion

def entries : Array SourceSegment := #[
  { id := 219, texFile := "Zetahyperbolic.tex",
    lineFirst := 1506, lineLast := 1506,
    sectionNumber := 7, kind := "heading",
    sourceText := "\\section{Discussion and Open Problems}",
    sha256Receipt := "28a6c92941cde06f3c7e4ffb1f14756b5801c93622e44cf48cf749c63825d665" },
  { id := 220, texFile := "Zetahyperbolic.tex",
    lineFirst := 1508, lineLast := 1508,
    sectionNumber := 7, kind := "narrative_or_math",
    sourceText := "We conclude by summarizing the structural bottlenecks identified by our analysis and outlining three problems for future research.",
    sha256Receipt := "91a3a86989108e206cb5c15224c9d34c1242728420e14dd660743b212b909773" },
  { id := 221, texFile := "Zetahyperbolic.tex",
    lineFirst := 1510, lineLast := 1511,
    sectionNumber := 7, kind := "narrative_or_math",
    sourceText := "\\begin{enumerate}\n\\item \\emph{Closing the gap between $\\rho_5^*$ and $\\rho_5^{\\mathrm{var}}$:} In Theorem 4.4, retaining the concave potential $\\Phi(u)$ of the residue weights $|r_j|$ on the single interval $[a, b] = [1/18, 1/3]$ reduced the spectral growth constant from $13.84$ to $11.411$, lowering the irrationality measure exponent of $\\zeta(5)$ from $31155$ to $25687$. Establishing Conjecture 4.11 (or bounding $\\|B_K^{(5)}\\|$ directly through the Christoffel--Darboux pole kernel of Theorem 3.8(1) against a multi-interval arcsine equilibrium measure on $[0, L_1]$) would reduce $\\rho_5$ toward $\\rho_5^{\\mathrm{var}}$. However, as shown in Remark 4.9, no improvement to $\\rho_5$ alone can push the irrationality exponent $\\mu = \\lambda \\rho_5 / \\epsilon$ below $10985$ while $\\epsilon = 0.0004$ is held fixed; achieving a substantially smaller irrationality measure requires simultaneously sharpening the $p$-adic prime-sum bound $A_M^{(5)}$ (or proving that the integer content $c_K = \\operatorname{cont}_{\\mathbb{Z}}(Q_K^{(5)})$ grows as $e^{\\delta K^2}$ with $\\delta > 0$).",
    sha256Receipt := "93e0045c3cc97696c8f8b5e6e3c37c4a8110012b694ac690d2dc727d5596dab7" },
  { id := 222, texFile := "Zetahyperbolic.tex",
    lineFirst := 1513, lineLast := 1513,
    sectionNumber := 7, kind := "narrative_or_math",
    sourceText := "\\item \\emph{The height barrier for quadratic approximations and two-variable height reduction:} Proposition 4.2 shows that an integer polynomial family $Q_K(X) \\in \\mathbb{Z}[X]$ of degree $h = \\lambda K$ with zero-free disk $e^{-\\rho K}$ excludes algebraic approximations of degree $d \\ge 2$ whenever its decay rate $\\epsilon$ at $\\xi$ exceeds $(d - 1)\\Lambda_{\\mathrm{height}}$. Theorem \\ref{thm:potential-gap-2v}(1) proves that for any one-variable positive-definite Hankel pencil with negative poles, $\\Lambda_{\\mathrm{lead}} + \\epsilon = \\mathcal{I}_B = \\mathcal{E}(\\mu_{\\mathrm{eq}}) - \\mathcal{E}_{\\mathrm{poles}}(\\nu_{\\mathrm{unif}}) \\ge 0.23310 \\gg 2\\epsilon$, obstructing degree-$d \\ge 2$ transfer within $G_K^{(5)}(X)$. On the other hand, Theorem \\ref{thm:potential-gap-2v}(2) demonstrates that passing to the two-variable Beukers architecture $M_{\\mathcal{A}_K}^{(s)} = C_K C_K^T$ reduces the quadratic growth rate of $\\log\\det M_{\\mathcal{A}_K}^{(s)}$ identically to zero. Combining $p$-adic residue-annihilating polynomial subspaces $C_K$ with the positive Krein cone $\\mathcal{V}_K^+$ of Theorem \\ref{thm:zeta7-nonvanish}(2) is thus a promising route toward algebraic independence and degree-$d \\ge 2$ approximation bounds.",
    sha256Receipt := "5fafe2dc97830c9a1ce8f8014bb617bd5eda8edf200f724cef03cac37d0de51d" },
  { id := 223, texFile := "Zetahyperbolic.tex",
    lineFirst := 1515, lineLast := 1516,
    sectionNumber := 7, kind := "narrative_or_math",
    sourceText := "\\item \\emph{Overcoming the weight-seven distribution barrier and extending multi-weight cones:} Theorem 2.4, Theorem 5.6, and Theorem \\ref{thm:div-diff-barrier} demonstrate that within the one-variable Hankel architecture and its symmetric divided-difference reduction, the $p^{-6}$ distribution prefactor and rank-two modulo-$p$ pole block $\\begin{pmatrix} 0 & 1/6 \\\\ 1/6 & -1 \\end{pmatrix}p^{-7}$ create an intrinsic local barrier for $\\zeta(7)$ alone. Three mechanisms developed in Sections 5 and 6 provide concrete paths forward: first, the asymmetric weight-$(6, 7)$ Beukers functional of Theorem \\ref{thm:sim-67}, which couples $\\zeta(6)$ and $\\zeta(7)$ with zero denominator overhead; second, the multi-weight differential-shift and Krein decompositions of Theorems \\ref{thm:multiweight-1v} and \\ref{thm:multiweight-2v} (together with the character--Vandermonde sign cancellation of Theorem \\ref{thm:beta4-hyperbolic} for $\\beta(2k)$); and third, the simultaneous multi-pole architectures of Theorems 5.7 and \\ref{thm:multipole-extensions}, where higher pole multiplicities unlock binomial $p$-adic cancellation across residue classes.\n\\end{enumerate}",
    sha256Receipt := "2caa40c3ad96cc45d4172e7e824445f0ad7697402ba491170cdb8048a3608df1" },
  { id := 224, texFile := "Zetahyperbolic.tex",
    lineFirst := 1520, lineLast := 1520,
    sectionNumber := 7, kind := "source_command",
    sourceText := "\\input{Zetahyperbolic-bibliography}",
    sha256Receipt := "1980ecbe5df4d8e12f127792fab2df07c0834ec08649ea7313acf4b1ea4d9c58" }
]

theorem entries_count : entries.size = 6 := by rfl

end PaperParagraph.Discussion
