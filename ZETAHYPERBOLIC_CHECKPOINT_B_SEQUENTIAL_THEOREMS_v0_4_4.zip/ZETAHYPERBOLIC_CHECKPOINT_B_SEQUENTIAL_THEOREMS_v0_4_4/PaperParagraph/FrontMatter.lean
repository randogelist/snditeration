import PaperParagraph.Foundation

/-! This module stores original-source LaTeX text as inert strings.
Nothing here is a mathematical proof or a new axiom. -/
namespace PaperParagraph.FrontMatter

def entries : Array SourceSegment := #[
  { id := 1, texFile := "Zetahyperbolic.tex",
    lineFirst := 55, lineLast := 55,
    sectionNumber := 0, kind := "source_command",
    sourceText := "\\begin{document}",
    sha256Receipt := "49d34b0366eb0a68eb35c75d6d8aeb1d60be3c49779501a7e1cdf4941acdab46" },
  { id := 2, texFile := "Zetahyperbolic.tex",
    lineFirst := 57, lineLast := 59,
    sectionNumber := 0, kind := "narrative_or_math",
    sourceText := "\\begin{abstract}\nWe study the zero locus and arithmetic properties of integer polynomials $P_K^{(s)}(X) \\in \\mathbb{Z}[X]$ arising from Hankel determinants attached to rational moment functionals for $\\zeta(2k+1)$ and related $L$-values. By diagonalizing the matrix pencil in a Lagrange basis over the negative square poles, we prove that all roots of $P_K^{(2k+1)}(X)$ are real, interlace symmetrically across $\\zeta(2k+1)$, and admit an explicit exponential zero-free disk. This spectral separation overcomes the growing-degree barrier in determinantal Diophantine approximation, yielding the effective irrationality measure $|\\zeta(5) - a/b| > b^{-25687}$ for all sufficiently large $b$, as well as effective measures for linear forms $b\\zeta(5) + a\\zeta(3)$. Furthermore, we discover a character--Vandermonde sign cancellation for Dirichlet beta values $\\beta(2k) = L(2k, \\chi_{-4})$ that forces a unilateral $(h, 0)$ root signature, and we establish potential-gap identities that govern height growth in two-variable Beukers extensions.\n\\end{abstract}",
    sha256Receipt := "11d079458762433ce5ea4a0ba4364a48a5bd2c59aaca5adb3187bca8081307c1" },
  { id := 3, texFile := "Zetahyperbolic.tex",
    lineFirst := 62, lineLast := 62,
    sectionNumber := 0, kind := "source_command",
    sourceText := "\\maketitle",
    sha256Receipt := "66cd782567cea37bd98f32fc53f26630d55f24107cbb50d091ef757c8931466d" }
]

theorem entries_count : entries.size = 3 := by rfl

end PaperParagraph.FrontMatter
