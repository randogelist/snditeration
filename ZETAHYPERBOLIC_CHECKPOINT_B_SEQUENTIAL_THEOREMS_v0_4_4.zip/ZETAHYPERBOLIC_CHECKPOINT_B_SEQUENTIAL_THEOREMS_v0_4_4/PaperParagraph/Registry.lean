import PaperParagraph.FrontMatter
import PaperParagraph.Introduction
import PaperParagraph.Chapter2
import PaperParagraph.Chapter3
import PaperParagraph.Chapter4
import PaperParagraph.Chapter5
import PaperParagraph.Chapter6
import PaperParagraph.Discussion
import PaperParagraph.Bibliography
import PaperParagraph.PDFAnchors
import PaperParagraph.PDFPageReceipts

/-!
Every blank-line-separated SOURCE segment (including bibliography) is present
in a named Lean array and linked by numeric ID and source-line span.
This is NOT an inhabitation of `PaperBlueprint.BlueprintBundle`.
-/
namespace PaperParagraph

def allSections : Array (Array SourceSegment) := #[
  FrontMatter.entries, Introduction.entries, Chapter2.entries, Chapter3.entries,
  Chapter4.entries, Chapter5.entries, Chapter6.entries,
  Discussion.entries, Bibliography.entries
]
def sourceBlockCount : Nat :=
  FrontMatter.entries.size + Introduction.entries.size + Chapter2.entries.size + Chapter3.entries.size + Chapter4.entries.size + Chapter5.entries.size + Chapter6.entries.size + Discussion.entries.size + Bibliography.entries.size

theorem allSourceSegmentsIndexed : sourceBlockCount = 241 := by decide
theorem sectionArrayCount : allSections.size = 9 := by rfl
theorem numberedItemsAnchored : PDFAnchors.items.size = 46 := PDFAnchors.item_count

end PaperParagraph

#print axioms PaperParagraph.allSourceSegmentsIndexed
#print axioms PaperParagraph.numberedItemsAnchored
