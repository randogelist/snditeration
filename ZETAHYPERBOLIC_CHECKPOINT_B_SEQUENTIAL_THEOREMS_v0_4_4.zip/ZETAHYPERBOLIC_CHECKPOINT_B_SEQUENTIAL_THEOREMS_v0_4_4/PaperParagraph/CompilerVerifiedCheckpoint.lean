import MAIN_CHAIN_PAPER_PARAGRAPH_CHECKPOINT_V1

/-!
# Native-compiler checkpoint: structural integration of the original manuscript

The user-provided Lean 4.33 log verified all 144 modules in the preceding
checkpoint. Those 144 .lean sources are deliberately unchanged. Theorems here
refer to the verified structural receipts; they DO NOT assert mathematical
proofs of every authorial paragraph or the full paper.
-/

namespace PaperParagraph.CompilerVerified

/-- Original-LaTeX source blocks, in nine section arrays. -/
theorem all_241_source_blocks_registered :
    PaperParagraph.sourceBlockCount = 241 :=
  PaperParagraph.Checkpoint.sourceParagraphsRegistered

/-- One numbered PDF anchor per 45 proof items and Definition 2.1. -/
theorem all_46_headings_registered :
    PaperParagraph.PDFAnchors.items.size = 46 :=
  PaperParagraph.Checkpoint.originalNumberedHeadingsRegistered

/-- All 52 pages have textual provenance receipts. -/
theorem all_52_pages_registered :
    PaperParagraph.PDFPageReceipts.extractedTextBlockCounts.size = 52 :=
  PaperParagraph.Checkpoint.originalPdfPagesRegistered

end PaperParagraph.CompilerVerified

#print axioms PaperParagraph.CompilerVerified.all_241_source_blocks_registered
#print axioms PaperParagraph.CompilerVerified.all_46_headings_registered
#print axioms PaperParagraph.CompilerVerified.all_52_pages_registered
