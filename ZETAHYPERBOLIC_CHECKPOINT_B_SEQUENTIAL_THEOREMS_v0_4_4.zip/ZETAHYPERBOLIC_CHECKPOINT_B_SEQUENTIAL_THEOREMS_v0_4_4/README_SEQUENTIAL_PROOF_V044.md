# Native Windows Lean 4.33 sequential proof run — v0.4.4

## Freeze boundary

Prior user confirmation: 147/147 PASS (all retained byte-for-byte).  Those
modules must not be recompiled unless the toolchain, dependencies or exact
source changed. Next unverified module is 148, not 1.

## Safe stale-lock recovery

The previous run exited before compilation, reporting
`ERROR=CACHE_BUILD_ALREADY_RUNNING_OR_STALE_LOCK`. This package introduces
`run.cmd recover-lock`, explicitly requested by the user's call line. It checks
Windows `tasklist` for any `lean.exe` processes. If any exist, it aborts and
DOES NOT remove the lock. If no Lean process exists and the lock directory is
empty, it removes that empty stale directory and reacquires the exclusive
lock. If the directory is nonempty or cannot be removed, the runner aborts.
This does not change the persistent verified olean cache or source receipts.

When multiple Lean builds are being launched at once, DO NOT recover the lock;
wait for the active owner to finish. The runner cannot distinguish another
build in the small interval before that build launches its first Lean process;
never run the recovery mode concurrently with another package.

## Sequential proof targets

- 148: theorem 3.1 exact degree + real zeros; corrected theorem 3.4 real roots
- 149: theorem 5.4 simple-pole cancellation (including j=1)
- 150: typed proof bundle (3.1, corrected 3.4, 5.4)
- 151: frozen Checkpoint B status, integrated with the new exact proof bundle
- 152: theorem 3.3 leading coefficient, 3.6 finite atomic determinant, 3.7
  all-degree first Turan Wronskian, reusing prior native Lean verified lemmas
- 153: sequenced chapter endpoint and axiom audits

This package is NOT compiled locally, awaiting the user's native Windows
Lean compiler and `#print axioms` outputs. This is not full formalization of
the original paper.
