# v0.3.1 FIX1 — Chapter 4 Lean parser correction

User's native Lean 4.33.0 compiler verified 123 of 130 build modules.
The first failure at module 124 `PaperBlueprint/Chapter4.lean` was
`unexpected token 'λ'; expected ')'` (lines 30, 43, 53).
`λ` is Lean lambda syntax and cannot be used as an ordinary binder identifier.
All occurrences of the binder and its uses in Chapter 4 are renamed to
`degreeRate`, preserving the formal proposition and every numeric constant.

All 123 previously passing Lean sources remain bit-for-bit unchanged.
The remaining Chapter 4-6 interfaces continue to be blueprints; this package
does not assert a complete proof of the manuscript.
The user is the compilation authority; this archive has not been Lean compiled locally.
