# Principal theorems and reconstructed manuscript: v0.2.0

This release preserves unchanged Lean modules 1-115 (already passed on the
user's native Windows Lean 4.33.0), fixes non-passed source 116, and
introduces modules 118-121. No Lean compiler was run while packaging.

The amended paper PDF `Zetahyperbolic_REBUILT_WITH_PROOF_AUDIT_20261024.pdf`
is compiled from the author's existing 52-page TeX source with a clearly
identified **editorial status supplement**. It preserves the original main
manuscript text; that text contains unverified claims, distinguished by the
new supplement. The PDF is not a claim of formalization completeness.

- Module 116: corrects unknown `tsum_le_of_sum_range_le` to
  `Real.tsum_le_of_sum_range_le` and exposes the explicit zeta bound.
- Module 118: proves explicit negative rational margin <= -27/64.
- Module 119: proves exact rank-two determinant and strict negative sign.
- Module 120: attempts a source-level exact two-row identification with
  the manuscript's actual rational dual matrix, not an invented matrix.
- Module 121: combined theorem checkpoint.

Latest user checkpoint: 115/115 completed, native compiler PASS.
118-121 have NOT been compiler-certified; if errors occur, send the first
new compiler error with the source and line number. The runner reuses the
115 frozen modules and compiles only changed/new code.

**Mathematical limits**: The original paper's 95% core algebra target remains
awaiting theorem-by-theorem audit. The unrestricted infinite-mode Krein
positivity and the claimed zeta(5) irrationality measure are NOT proved by
this package. The manuscript's printed Theorem 3.4 interlacing requires a
rank-sensitive correction. See the PDF supplement for precise boundaries.
