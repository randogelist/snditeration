# Frozen-pass policy

A module is considered validated only after an actual successful Lean compiler
result. An exact source stamp + `.olean` + pinned environment + import-generation
receipts are saved outside the versioned ZIP. New ZIPs reuse the same persistent
folder and skip unchanged modules, including after an interrupted failed build.

The wrapper for Theorem 2.4 (module 10) was repaired in v0.3.3 but has not yet
been confirmed by the user's compiler. Do not mark it FROZEN until PASS.

The reported passes 1–9 occurred under v0.3.2. For migration this runner checks
`.source` copies, old signature and actual `.olean` artifacts. User log by itself
is not treated as a substitute for executable cache artifacts.

This workflow never creates Lean axioms to force paper theorem closure. Sections
3–6 remain at the stated proof borders.

## v0.3.5 safety amendment
A zero exit code alone is insufficient for `CHECK_PASS`: the runner also requires a nonempty final `.olean`, validated source receipt, environment receipt, dependency generations and last-committed generation receipt. Staging avoids replacing frozen artifacts before successful publication. See `FIX2_RUNNER_NOTES.md`.
