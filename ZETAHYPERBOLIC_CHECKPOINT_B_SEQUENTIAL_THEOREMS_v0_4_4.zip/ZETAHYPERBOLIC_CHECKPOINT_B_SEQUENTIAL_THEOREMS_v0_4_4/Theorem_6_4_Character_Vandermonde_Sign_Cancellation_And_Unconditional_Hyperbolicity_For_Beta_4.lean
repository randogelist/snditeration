import Definition_2_1_Order_s_Rational_Moment_Functional
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Integral.IntegrableOn
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-!
# Theorem 6.4 (Character–Vandermonde sign cancellation and unconditional hyperbolicity for β(4))

PDF pp. 33-34. Auxiliary replacement-model interfaces only. BetaRepairData
and BetaCandidateRealization require consistent moments and pole identities
as supplied data. The mass-consistency consequences below are proved.
The incompatible printed beta identities and unconditional hyperbolicity
claim are not imported or established. "Unconditional" is the PDF title.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Real

def beta (s : ℕ) : ℝ :=
  ∑' n : ℕ, (-1 : ℝ) ^ n / ((2 * n + 1 : ℕ) : ℝ) ^ s

structure BetaRepairData where
  moment : ℕ → ℚ
  poleConstant : ℕ → ℚ
  poleSlope : ℕ → ℚ
  poleLocation : ℕ → ℚ

end ManuscriptChain.Real

open MeasureTheory Set

namespace ManuscriptChain.Extensions
open ManuscriptChain.Real

structure BetaCandidateRealization (d : BetaRepairData) (target : ℝ)
    (w : ℝ → ℝ) : Prop where
  poles_negative : ∀ j, d.poleLocation j < 0
  monomial_integrable : ∀ e, IntegrableOn (fun y : ℝ => y ^ (2 * e) * w y) (Ioi 0)
  monomial_eq : ∀ e, (∫ y in Ioi (0 : ℝ), y ^ (2 * e) * w y) = (d.moment e : ℝ)
  pole_integrable : ∀ j, IntegrableOn
    (fun y : ℝ => w y / (y ^ 2 - (d.poleLocation j : ℝ))) (Ioi 0)
  pole_eq : ∀ j, (∫ y in Ioi (0 : ℝ), w y / (y ^ 2 - (d.poleLocation j : ℝ))) =
    (d.poleConstant j : ℝ) + (d.poleSlope j : ℝ) * target

theorem beta_constant_mass {d : BetaRepairData} {target : ℝ} {w : ℝ → ℝ}
    (realization : BetaCandidateRealization d target w) :
    (∫ y in Ioi (0 : ℝ), w y) = (d.moment 0 : ℝ) := by
  simpa using realization.monomial_eq 0

theorem beta_same_weight_same_constant {d₁ d₂ : BetaRepairData}
    {target₁ target₂ : ℝ} {w : ℝ → ℝ}
    (r₁ : BetaCandidateRealization d₁ target₁ w)
    (r₂ : BetaCandidateRealization d₂ target₂ w) :
    (d₁.moment 0 : ℝ) = (d₂.moment 0 : ℝ) := by
  rw [← beta_constant_mass r₁, ← beta_constant_mass r₂]

end ManuscriptChain.Extensions
