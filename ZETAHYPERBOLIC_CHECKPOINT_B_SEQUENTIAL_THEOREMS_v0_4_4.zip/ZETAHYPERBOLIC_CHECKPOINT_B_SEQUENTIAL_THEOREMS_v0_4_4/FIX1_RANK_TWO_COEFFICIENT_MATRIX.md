# Native Lean 4.33.0 — principal theorems patch 1

**Compiler checkpoint received:** 119 verified (115 previously frozen and 4 newly passed), source 120 failed, source 121 blocked.

**Changed Lean source:** `PaperOrder/Principal_Theorem_5_2_RankTwo_Dual_Identification.lean` only.

**Error 1:** Four `Fin 2` coefficient-matrix cases left unsimplified conditional branches like `if 0 = 2 then ...`; finish the numeric normalization using `simp_all` and `norm_num`.

**Error 2:** The polynomial ring normalizer did not identify the constants `C (1/6)^2` and `C (1/36)`; add an explicit constant-polynomial map-power calculation before the determinant simplification.

No previously user-verified `.lean` module or its cache receipt has been changed. The existing 52-page original and 58-page rebuilt PDFs are preserved byte-for-byte. Build only source 120 and invalidated source 121; reusing 119 user-frozen modules. No local Lean execution or PASS claim made for this untested patch.
