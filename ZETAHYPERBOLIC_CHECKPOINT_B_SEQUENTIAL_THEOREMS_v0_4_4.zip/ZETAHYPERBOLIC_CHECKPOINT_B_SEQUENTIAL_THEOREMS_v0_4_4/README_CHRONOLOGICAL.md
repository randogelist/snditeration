# Zetahyperbolic: chronological Lean reconstruction v0.3.0

**Only one `run.cmd`. No compilation was performed while assembling this ZIP.**
Lean toolchain pin remains `leanprover/lean4:v4.33.0`; the pinned Mathlib git
revision is unchanged. `run.cmd` is intended for the user's Windows environment.

## Chronological entry point

`MAIN_CHAIN_PAPER_ORDER.lean` imports, in strict PDF order:

1. `PaperOrder/Definition_2_1_Order_s_Rational_Moment_Functional.lean`
2. `PaperOrder/Lemma_2_2_Pullback_Identity.lean`
3. `PaperOrder/Lemma_2_3_Reflection_And_Difference_Identities.lean`
4. `PaperOrder/Theorem_2_4_Canonical_Basis_Invariance.lean`
5. `PaperOrder/Theorem_2_5_Lagrange_Pole_Diagonalization.lean`
6. `PaperOrder/Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk.lean`
7. `PaperOrder/Proposition_3_2_Continuous_Hyperbolic_Pencil.lean` **PARTIAL**
8. `PaperOrder/Theorem_3_3_Total_Positivity_Leading_Sign_And_Signature.lean` **PARTIAL**
9. `PaperOrder/Theorem_3_4_Principal_Minor_Repair_Frontier.lean` **FALSE AS PRINTED**

## Current proved mathematical output

The actual general odd-weight manuscript pencil has the archived Lean 4.33
unconditional spectral theorem from `MAIN_CHAIN_ASSEMBLED`, with the usual
parameter restrictions k,m,N>=1 and K>N. Section 2's tau identities are now
raised to named, chronological interfaces, including a new proof on finite
normal forms. This proof has not been checked by a Lean compiler in this session.

**Main entry point:**
`PaperOrder.MAIN_CHAIN_PAPER_ORDER (p) (hp) : ManuscriptChain.General.GeneralStatement p`.

Do NOT interpret Section 3.2+ wrappers as complete proofs where the files say
PARTIAL. The rest of the PDF (through 6.18) is indexed in
`PAPER_THEOREM_INDEX.csv` and `PAPER_THEOREM_INDEX.md`, and the blockers are
listed in `PAPER_CORRECTIONS_AND_PROOF_BORDERS.md`.

## Running

Unzip in a Windows folder. Start a native Lean 4.33 terminal with pinned
Mathlib dependencies already present, then execute `run.cmd` and return the
first Lean error (if any) and final lines. This package never compiles itself.

## Witness policy

The old `MAIN_CHAIN_WITNESS_ONLY.lean` remains in the source for Section 4
work. Its single `PaperWitness` hypothesis is not imported into the universal
Section 2→3.1 theorem and cannot be used to assume later sections. Any final
irrationality assertion must continue to state the witness explicitly until
its actual proof is supplied.

## Audit

The attached PDF contains **51** unique numbered definitions, lemmas,
theorems, propositions, corollaries, remarks, and conjectures in Sections 2–6.
This is a *full chronological coverage register*, not a claim that all were proved.
