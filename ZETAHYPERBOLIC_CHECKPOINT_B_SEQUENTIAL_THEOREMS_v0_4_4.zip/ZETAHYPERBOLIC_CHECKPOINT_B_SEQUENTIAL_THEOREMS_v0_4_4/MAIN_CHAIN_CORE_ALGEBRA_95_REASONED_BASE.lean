import PaperOrder.Theorem_3_3_Abstract_Inertia_Sign_Certificate

/-!
# Core Algebra 95% — reasoning-first cumulative entry point

Previously compiler-verified modules remain byte-for-byte frozen. This is a
strictly stronger *mathematical* endpoint: the actual Hankel pole determinant
is assembled with (i) weak hyperbolicity for singular affine slopes,
(ii) all-degree first Turán inequality, (iii) rectangular finite Hankel Gram
factorization, and (iv) the exact dual Beukers X-leading coefficient.

This does NOT claim 95% of the 20 mathematical gates complete. The still-open
continuous total-positivity, exact pole sign counts, all principal-minor
interlacing, full higher Turán, etc. are explicitly disclosed in the ledger.
-/

noncomputable section
open scoped BigOperators
open ManuscriptChain.PoleDiagonalization
namespace PaperOrder.CoreAlgebra

/-- Main reasoned base theorem: the actual manuscript pole structure plus
unconditional universal finite algebraic laws. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.delta p).natDegree = p.h) ∧
    (0 < (rationalDerivativeMatrix p).det *
      (∏ a : Fin p.h, poleWeight p a)) ∧
    (∀ (n : ℕ) (x w : Fin n → ℝ), Function.Injective x →
      (∀ k : Fin n, 0 < w k) → 0 < (atomicMomentMatrix x w).det) ∧
    (∀ (c : ℝ) (roots : List ℝ) (x : ℝ),
      0 ≤ (turanWronskian (Polynomial.C c * rootListPolynomial roots)).eval x) ∧
    (∀ (r n : ℕ) (x w : Fin n → ℝ),
      rectangularAtomicHankel (r:=r) x w =
        rectangularMomentVandermonde (r:=r) x * Matrix.diagonal w *
          (rectangularMomentVandermonde (r:=r) x).transpose) ∧
    (∀ (h K s : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
      (ManuscriptChain.Real.dualDelta s c).coeff h =
        (dualCoefficientMatrix c * (dualCoefficientMatrix c).transpose).det) := by
  refine ⟨ManuscriptChain.PoleDiagonalization.delta_natDegree p,
    pole_derivative_det_times_weights_pos p, ?_, ?_, ?_, ?_⟩
  · intro n x w hx hw
    exact atomicMomentMatrix_det_pos x w hx hw
  · intro c roots x
    exact turanWronskian_split_polynomial_nonneg c roots x
  · intro r n x w
    exact rectangularAtomicHankel_factorization x w
  · intro h K s c
    calc
      (ManuscriptChain.Real.dualDelta s c).coeff h =
          (dualSlopeMatrix c).det :=
        dualDelta_coefficient_dimension s c
      _ = (dualCoefficientMatrix c *
            (dualCoefficientMatrix c).transpose).det := by
        rw [dualSlopeMatrix_eq_CCT]

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE
