import PaperParagraph.CompilerVerifiedCheckpoint
import PaperBlueprint.Chapter3DirectProofs
import PaperBlueprint.Chapter5SimplePoleProof

/-!
# Chapter proof-bridge checkpoint V2

This is the next stage after the 144/144 compiler-verified PARAGRAPH
integration milestone. It supplies explicit proof terms for the actual
Section 3.1 goal, the corrected Section 3.4 component, and Section 5.4's
simple-pole goal. It does NOT inhabit BlueprintBundle and does NOT prove
the whole source paper or the printed uncorrected 3.4 statement.
-/

namespace PaperBlueprint

structure CertifiedSourceEndpoints : Type where
  theorem3_1 : Chapter3.Goal_3_1
  correctedTheorem3_4 : Chapter3.Goal_3_4
  theorem5_4 : Chapter5.Goal_5_4

/-- The three source-aligned proof obligations are discharged by original
published (compiler-frozen) upstream mathematical theorems. -/
def certifiedSourceEndpoints : CertifiedSourceEndpoints where
  theorem3_1 := Chapter3.exact_theorem_3_1_goal
  correctedTheorem3_4 := Chapter3.corrected_theorem_3_4_goal
  theorem5_4 := Chapter5.exact_theorem_5_4_simple_pole_goal

end PaperBlueprint

#print axioms PaperBlueprint.certifiedSourceEndpoints
