# Core algebra — explicit 95% target

**Target:** 19 of 20 mathematically specified algebraic gates genuinely proved (not 19 file imports). See `CORE_ALGEBRA_20_GATE_LEDGER.csv`.

**User-compiler checkpoint:** 60 modules PASS per user log (59 prior + module 60). Those sources remain byte-for-byte unchanged.

**New core-algebra modules 60–66 (module 60 verified by user; 61–66 pending):**

- 60: exact sign certificate for the *actual* rational pole-derivative determinant and nonzero normalized pole directions.
- 61: general principal affine polynomial degree ≤ r and degree drop when its derivative matrix is singular.
- 62: nontrivial 3x3 symmetric Dodgson condensation identity, plus sign-at-root consequence.
- 63: correct three-level normalized spectral J-fraction and continuant recurrence.
- 64: strict 2-atom moment Hankel determinant criterion and nonnegativity.
- 65: exact finite Christoffel–Darboux pole-kernel matrix entry and symmetry.
- 66: one conjunction-form chronological core-algebra main-chain endpoint.

These extensions are designed to **advance toward** 95%; the 95% completion claim is **NOT yet established**. Full total positivity, alternating inertia, general principal-minor interlacing and general J-fractions still require further Lean work. The paper has statements requiring mathematical correction. This package does not introduce any custom axioms or sorry/admit.

**Compile only on user's Windows Lean 4.33.0:**

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CORE_ALGEBRA_95_TARGET_v0_4_7.zip" && call "ZETAHYPERBOLIC_CORE_ALGEBRA_95_TARGET_v0_4_7\run.cmd"
```

Frozen build reads only 7 new modules unless source/environment/dependency changes.
