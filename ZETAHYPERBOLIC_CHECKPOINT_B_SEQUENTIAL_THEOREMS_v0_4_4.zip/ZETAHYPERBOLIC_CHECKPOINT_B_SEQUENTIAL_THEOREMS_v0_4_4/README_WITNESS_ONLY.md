# Witness-only reconstruction of the attached 52-page paper (v0.2.0)

**Lean:** pinned Lean 4.33.0 + cached Mathlib in the supplied base.  No `sorry`, `admit`, custom `axiom`, or opaque placeholder declarations are introduced by this reconstruction.  **Verification:** source audit completed here; no local Lean compiler or Mathlib cache was available, so the four newly added files have **not** yet been elaborated. Run `run.cmd` on Windows and inspect output; the upstream compiled-module records are preserved, not rerun.

## Exact statement — sole input `PaperWitness`

```
PaperWitnessOnly.MAIN_CHAIN_WITNESS_ONLY (w : PaperWitnessOnly.Witness) :
  (∀ p : ManuscriptChain.Real.Parameters,
     ManuscriptChain.Real.Admissible p →
     ManuscriptChain.General.GeneralStatement p) ∧
  Irrational (riemannZeta (5 : ℂ)).re
```

The first conjunct is unconditional: actual paper-defined moments, exact pencil dimension, Gram positive definiteness, determinant degree, real roots, and an exact nonzero root-free disk.  The second conjunct assumes **exactly one conditional argument `w`**.

`PaperWitness` is the source-based content of Eq. (4.3), not a tautology equivalent to irrationality:

```
∃ start Q m, (∀ n≥start+1, m_n>0)
  ∧ (∀ n≥start+1, map_ℚ Q_n = C(m_n) * S_(30n) * Δ_(30n))
  ∧ (∀ n≥start+1, |Q_n(ζ(5))| ≤ exp(-(30n)^2 / 2500)).
```

For the paper-defined weight-five family, `deg Q_n = 27n` follows from the identity and existing determinant-degree theorem; positive evaluation follows from Gram positivity and positive multiplier.  The positive integer contradiction is:

```
ζ(5) = a/b, b>0  ⇒  1 ≤ b^(27n) Q_n(a/b)
                     ≤ exp(27n log b - (30n)^2/2500) → 0
```

The package also includes a smaller `PrimitiveWitness`: just the quadratic tail bound on the **constructed primitive normalization**. `primitive_of_paper` transfers the paper's integer-scaled certificate to this minimal witness using the primitive-minimality theorem (uncompiled in this runtime).

## Stronger PDF theorem 4.4

The PDF further claims the effective irrationality measure exponent **25687**. The `Theorem_4_4_Measure_Reduction.lean` file checks the precise *conditional reduction* from (i) the paper witness and (ii) the uniform spectral estimate `‖B_(30n)‖ ≤ exp(11.411 * 30n)` (encoded by `MainSpectralData`).  This uniform estimate is proved on paper but **not yet unconditionally formalized** in the current Lean graph. Thus no theorem with just the arithmetic `PaperWitness` proving exponent 25687 is claimed.

## Why one witness does not make the entire 52-page PDF formalized

Some paper claims require independent proofs and some require edits to the text. The preserved previous `PAPER_THEOREM_LEDGER.md` identifies the full scope. Specifically, original Theorem 3.4 is false for an admissible principal minor; Corollary 3.5 needs normalization and cyclicity corrections; Theorem 6.10 includes a reversed rate deduction. No witness about weight-five arithmetic implies those independent assertions or arbitrary ζ(7)/beta/q-adic theorems.

The correct target is a *repaired main chain* with one arithmetic witness, not the verbatim paper. After a checked proof of the quantitative spectrum, the exponent-25687 transfer will also become witness-only.

## Chronological Lean route

```
Definition_2_1_Order_s_Rational_Moment_Functional
    ↓
Theorem_2_5_Lagrange_Pole_Diagonalization
    ↓
Theorem_3_1_Concrete_Moment_Realization
    ↓
Theorem_3_1_Pole_Integral_Identity
    ↓
MAIN_CHAIN_ASSEMBLED (Gram positivity / exact root-free region)
    ↓
Theorem_2_4_Primitive_Normalization_Minimality
    ↓
Theorem_4_1_Direct_Irrationality_From_Decay
    ↓
Equation_4_3_Paper_Witness (SOLE CONDITIONAL INPUT)
    ↓
MAIN_CHAIN_WITNESS_ONLY (ζ(5) irrational conditional on witness)

Separate for quantitative bound:
Theorem_4_4_Measure_Reduction + unconditional spectral theorem (NOT YET PROVED)
    ↓
measure exponent 25687
```

The file `PAPER_THEOREM_LEDGER.md` is retained unchanged as an exhaustive content map. This package has not fabricated proofs of open numbered theorems.
