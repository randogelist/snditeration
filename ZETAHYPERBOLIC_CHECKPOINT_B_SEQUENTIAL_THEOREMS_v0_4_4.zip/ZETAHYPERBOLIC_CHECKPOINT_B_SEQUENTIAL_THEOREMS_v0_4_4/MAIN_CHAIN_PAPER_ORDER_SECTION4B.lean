import MAIN_CHAIN_PAPER_ORDER_SECTION4A
import PaperOrder.Proposition_4_8_Factor_Distance_Bounds

/-!
# Chronological manuscript checkpoint through Proposition 4.8

Modules through Section 4A are frozen and reused. The new sequence
proves finite algebraic cores of Theorems 4.4–4.7 and Proposition 4.8.
The paper's specific determinant asymptotics, full Section 4.4 measure,
prime valuation estimates and first-order Lee–Yang phase claim remain
unproved in this chronological chain. No witness is silently assumed.
-/

namespace PaperOrder

/-- The unconditional general odd-weight pencil endpoint is retained. -/
theorem MAIN_CHAIN_PAPER_ORDER_SECTION4B
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  MAIN_CHAIN_PAPER_ORDER_SECTION4A p hp

/-- The new spectral-zero gap has no analytic premise other than the
explicit numerical bound on the relative eigenvalue. -/
theorem MAIN_CHAIN_PAPER_ORDER_SECTION4B_ROOT_GAP
    (ξ β r B : ℝ) (hB : 0 < B)
    (hβ : |β| ≤ B) (hroot : β * (ξ - r) = 1) :
    1 / B ≤ |ξ - r| :=
  Section4.theorem_4_4_root_gap_of_bounded_beta ξ β r B hB hβ hroot

end PaperOrder

#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_SECTION4B
#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_SECTION4B_ROOT_GAP
