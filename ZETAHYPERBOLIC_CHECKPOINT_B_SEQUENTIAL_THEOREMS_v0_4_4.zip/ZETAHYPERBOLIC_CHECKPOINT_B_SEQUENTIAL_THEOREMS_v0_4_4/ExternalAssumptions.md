# Proof status and remaining obligations

## General odd-weight endpoint: analytic inputs discharged

The assembled endpoint is

```lean
ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
    (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p
```

`Real.Admissible p` means `k,m,N >= 1` and `N < K`. These are structural
parameter conditions. **No unproved analytic premise remains** for this endpoint.

The original-pencil endpoint `Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL` accepts
`HankelParams` and `k >= 1`; compatibility and admissibility are proved internally.

The checked analytic chain proves:

1. Positivity, convergence, and measurability of the actual hyperbolic density.
2. Exact Bernoulli monomial moments and all required integrability.
3. The exact simple-pole identity `Hyperbolic.poleIntegralIdentity` for every
   positive integer weight index and every positive integer pole index.
4. Finite partial-fraction assembly into the actual original Gram entries.
5. A concrete atomless nonzero moment measure and strict Gram positivity.

The simple-pole proof uses existing cotangent partial fractions, scaling,
geometric series, and Gamma integrals. Hermite's formula is not an assumption.

`MAIN_CHAIN_ASSEMBLED.lean` supplies these results to the existing spectral
implication. It proves full degree, derivative nonsingularity, real nonzero
spectral factors, real roots avoiding the center, and a positive zero-free disk.
The separate exact-disk theorems also prove that a root attains its boundary.
Pairwise distinct roots and strict total positivity are not asserted.

The old interfaces `MAIN_CHAIN`, `MAIN_CHAIN_FROM_MOMENTS`, and
`MAIN_CHAIN_FROM_POLE_INTEGRALS` intentionally retain their arguments as reusable
lemmas. Those argument lists no longer describe an open analytic gap: the
assembled theorem constructs their inputs.

The theorem concerns the actual rational moment functional and pencil, with the
center identified with Mathlib's Riemann zeta function. It does not prove
irrationality, an irrationality measure, or all extensions in the paper.

## Separate continuous-weight extension

Proposition 3.2 concerns a separate continuous-real-weight extension. Its
printed prefactor `(2*pi)^s / (2*Gamma(s))` is `pi/2` times the original
odd-weight prefactor when `s = 2*k+1`, while its direction matrix is unchanged.
The prefactor `2*(2*pi)^(s-1) / Gamma(s)` would match the original odd weights.
This normalization issue is audited but the continuous extension is not
formalized here.

## General irrationality: the precise remaining hypothesis

`MAIN_CHAIN_ARITHMETIC.lean` constructs Gram positivity for every admissible
member of `GeneralArithmetic.OddWeightFamily`. The actual primitive integer
polynomials `F.Q n` are constructed from the rational determinants, their
degrees are exactly `(F.parameters n).h`, and their evaluations at the common
center `zeta(2*F.k+1)` are nonzero on the admissible tail. None of these facts
is an additional hypothesis of `ManuscriptChain.GENERAL_IRRATIONALITY`.

The endpoint has one bundled input, `DecayHypothesis F`. It asserts the
existence of `D : Nat` and `c : Real`, with `c > 0`, such that for all
`n >= F.onset`:

1. The structural degree bound is `h_n <= D*(n+1)`.
2. The primitive integer evaluation satisfies
   `|Q_n(zeta(2*F.k+1))| <= exp(-c*(n+1)^2)`.

These imply `Irrational F.center`; the equivalent Mathlib-named endpoint is
`GENERAL_RIEMANN_ZETA_IRRATIONALITY`. The denominator contradiction and its
index selection are proved in `Theorem_4_1_Integer_Polynomial_Irrationality`.
No quantitative spectral bound is needed for this implication.

`Theorem_4_1_Linear_Odd_Zeta_Family` constructs the family
`N=a*(n+1)`, `K=b*(n+1)` for fixed positive `k,m,a` and `a < b`.
Its admissibility and degree `(b-a)*(n+1)` are proved for all indices.
`ManuscriptChain.LINEAR_FAMILY_IRRATIONALITY` consequently needs only the
quantitative hypothesis `EventualQuadraticDecay`: there exist `n0` and
`c > 0` such that the normalized evaluation bound holds for every `n >= n0`.

**That decay estimate remains unproved.** The result is a conditional theorem
for each fixed odd weight, not a proof that all odd zeta values are irrational.
The hypothesis concerns the primitive integer polynomials. An estimate for
the raw rational determinant requires a compatible normalization-multiplier
estimate before it can discharge this hypothesis.

## Direct arbitrary-K and zeta(5) interfaces

### Direct general odd-weight irrationality

`MAIN_CHAIN_IRRATIONALITY.lean` constructs `primitivePolynomial p` from the
actual rational determinant `Real.delta p`. Its coefficients are integers,
its degree is `p.h <= p.K`, and its value at the actual odd zeta center is
strictly positive for every admissible `p`.

The single estimate is `NormalizedQuadraticDecay p`: there exist `c > 0`
and `n0` such that for every `n >= n0` the primitive normalized value is at
most `exp(-c * (p n).K^2)`. The parameter sequence must be admissible, have
one fixed weight, and have arbitrarily large `K` on every tail. These family
conditions and the estimate are bundled in `OddWeightDecayHypothesis k`.

The checked theorem `all_odd_zeta_irrational` proves that supplying this
hypothesis for every `k > 0` gives irrationality of every corresponding
`(riemannZeta (2*k+1)).re`. The family-wise decay is not proved here.

The direct contradiction uses a nonzero integer `b^degree * Q(a/b)`.
No local root comparison or quantitative spectral-growth estimate is needed.
Primitive-normalization minimality also proves that a value bound on any
positive integral rescaling bounds the primitive polynomial's value.

### Direct zeta(5) irrationality

`ZETA5_DIRECT_IRRATIONALITY.lean` supplies Gram positivity internally and
proves `ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY` from the single combined
value bound. `ZETA5_IRRATIONALITY_FROM_TWO_ESTIMATES` instead accepts
`MultiplierUpper (primitiveMainNormalization start)` and
`ArchimedeanUpper (start+1)`. Both remain unproved estimates. A spectral
bound is not an argument of these new endpoints.

## Quantitative Diophantine applications

Theorem 4.1 supplies a generic conditional transfer with `LocalComparison`,
`Decay`, and `IndexBudget` inputs. The general spectral statement alone does
not provide the arithmetic decay or index budget for every odd zeta value.

The general assembled endpoint `GeneralArithmetic.measure_and_irrational`
constructs nonvanishing and local comparison. Its remaining inputs are
`EvaluationUpper` for the primitive-normalized family and `IndexBudget`
for its actual spectral comparison radius. The index budget must hold for
all sufficiently large positive denominators, using the same indices and
decay budget. It is an explicit additional quantitative premise, not a
consequence of the bare irrationality criterion.

The legacy endpoint `Zetahyperbolic.ZETA5_APPLICATION` retains four uniform
proof arguments. The first, Gram positivity, is now proved by the general theorem
for admissible parameters; the remaining three estimates are still open. Choose a natural number `start`; the required estimates must hold for all
`n >= start + 1` in the same family `K=30n`, `N=3n`, `h=27n`, `m=3`, `k=2`:

1. **Gram positivity:**
   `(ManuscriptChain.Real.gram (mainParameters n) (zeta 5)).PosDef`.
2. **Primitive multiplier bound:**
   `MultiplierUpper (primitiveMainNormalization start)` for the constructed
   primitive multiplier. The exponential rate is
   `-232425/100000 + 1/100000` in the `K^2` scale.
3. **Archimedean determinant bound:**
   `ArchimedeanUpper (start+1)` for the same scaled determinant `mainF`, with
   exponential rate `232380/100000 + 1/100000`.
4. **Quantitative spectral bound:** each constructed spectral factor satisfies
   `|beta_i| <= exp((11411/1000)*K)`.

These remain explicit arguments in the legacy wrapper. Gram positivity is no
longer an unproved mathematical input; the other three quantitative estimates
are not supplied by the general spectral theorem. Primitive normalization
existence, polynomial transport, spectral factorization from positivity, and
the large-denominator index budget are proved internally. The companion
`Zetahyperbolic.ZETA5_APPLICATION_MEASURE` concludes exponent 25687 beyond
the proved denominator threshold. No imported irrationality assertion is used.

## Extensions have separate gaps

| Sector | Checked content | Still needed for the manuscript claim |
|---|---|---|
| 5.1 | Exact formal moment data and stated analytic interface | Integral/moment identification |
| 5.2 / 6.3 | Finite positivity transfer with signed tail bound | Actual finite certificate and tail control for the proposed basis |
| 6.4 | Formal beta data and conditional realization interface | Correct beta functional/weight identification |
| 6.9 | Corrected triple-pole objects and finite Hermite algebra | Actual Laurent coefficient identification and q-adic conclusions |
| 6.10 | Finite affine determinant identity and corrected rate arithmetic | Valid new-equilibrium/energy comparison; positive decay with the necessary upper bound |
| 6.16 | Uniform comparison from a continuous positive compactified ratio | Actual ratio identity, continuity, and both positive endpoints |
| 6.17 | Correct parity-dependent basis indices and harmonic windows | Full valuation and determinant congruence |
| 6.18 | Degree/barrier implications under their exact inputs | Actual beta moment/scaling and arithmetic estimates |
| Mixed zeta / 6.8 | No unconditional mixed endpoint imported | Independent mixed-family arithmetic decay; zeta(5)-only decay is insufficient |

The constant ratio `height/epsilon > 581` needs `epsilon > 0` and a suitable
**upper** bound on epsilon, in addition to its sum/energy bound. An upper bound
on a positive polynomial evaluation gives a **lower** bound on its negative
logarithmic decay rate. The original variational step does not supply the
missing direction.

## Trust boundary

The checked source graph has no admitted proofs or declared custom axioms.
Standard Mathlib/Lean logical axioms are reported in the generated audit log.
`ExternalResults.lean` is a legacy wrapper with an explicit irrationality
premise; it is not used by the general endpoint or its zeta(5) application.

The original source archive has 23 blueprint admissions plus one external
admission. Their unchanged text remains available for review, but is not
compiled or relied upon. The original ledger's count of 29 was stale.
