import Equation_4_3_Paper_Witness
import Witness_Primitive_Conversion
import MAIN_CHAIN_ASSEMBLED

/-!
# Final paper-chain entry point: ONE conditional argument

The real Hankel determinant's hyperbolicity, positive Gram realization,
integer-polynomial degree/normalization and the irrationality transfer
are unconditional theorems in this source graph. We combine them with
one explicit quantitative witness for (4.3), without postulating further
Gram / integral / spectral / degree / limit lemmas.

This DOES NOT assert that every sentence of the 52-page manuscript has
been formalized. In particular Theorem 3.4 needs correction, while the
stronger measure 25687 needs an unconditional spectral estimate. Other
sections have their own mathematical content and are not consequences
of this witness.
-/

noncomputable section
namespace PaperWitnessOnly

/-- The strong, honest one-input endpoint, combining the universal
spectral structure and the concrete conditional ζ(5) irrationality proof. -/
theorem MAIN_CHAIN_WITNESS_ONLY (w : Witness) :
    (∀ p : ManuscriptChain.Real.Parameters,
       ManuscriptChain.Real.Admissible p →
       ManuscriptChain.General.GeneralStatement p) ∧
    Irrational (riemannZeta (5 : ℂ)).re := by
  constructor
  · intro p hp
    exact ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp
  · exact ZETA5_IRRATIONALITY_FROM_PAPER_WITNESS w

/-- General conditional architecture. ONE witness per odd weight is required;
this theorem does not import the paper's weight-five certificate as an
unjustified weight-seven or all-odd certificate. -/
theorem ODD_ZETA_IRRATIONALITY_FROM_WITNESS
    (k : ℕ) (hk : 0 < k)
    (w : ManuscriptChain.GeneralIrrationality.AffineFamilyDecay k) :
    Irrational (riemannZeta ((2 * k + 1 : ℕ) : ℂ)).re := by
  exact ManuscriptChain.GeneralIrrationality.irrational_riemannZeta_of_normalized_decay
    k hk (ManuscriptChain.GeneralIrrationality.affineFamily k)
    (ManuscriptChain.GeneralIrrationality.affineFamily_admissible k hk)
    (ManuscriptChain.GeneralIrrationality.affineFamily_k k)
    (ManuscriptChain.GeneralIrrationality.affineFamily_unbounded k) w

end PaperWitnessOnly

#print axioms PaperWitnessOnly.MAIN_CHAIN_WITNESS_ONLY
#print axioms PaperWitnessOnly.ODD_ZETA_IRRATIONALITY_FROM_WITNESS
