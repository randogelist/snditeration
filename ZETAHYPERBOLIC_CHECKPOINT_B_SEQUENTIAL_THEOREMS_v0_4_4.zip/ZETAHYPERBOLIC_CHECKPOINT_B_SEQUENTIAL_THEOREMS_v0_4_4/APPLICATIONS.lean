import Zetahyperbolic.Zeta5Application
import ZETA5_DIRECT_IRRATIONALITY
import AUDITED_REPAIRS

/-! Optional specialized applications and audited finite repairs.
Their exact analytic and arithmetic assumptions remain explicit in each module.
The default general endpoint does not import this module. -/
