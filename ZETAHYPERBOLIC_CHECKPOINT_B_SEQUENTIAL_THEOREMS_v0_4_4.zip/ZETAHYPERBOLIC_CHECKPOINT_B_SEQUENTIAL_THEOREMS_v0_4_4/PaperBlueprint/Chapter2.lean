import PaperBlueprint.Foundations

/-!
# Section 2, original PDF pp. 3-7: algebraic moment foundations

Definition 2.1 is already a construction, not a proposition to prove.
Each of the following four named goals is a source-aligned statement.
The current project's completed generator/normal-form identities and
basis-invariance/diagonalization proofs can be installed into these fields
without changing frozen sources. The equality between normal-form and the
entire rational-function domain remains a scope-identification check.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperBlueprint.Chapter2

abbrev Definition_2_1 := ManuscriptChain.Real.Parameters

/-- Lemma 2.2, formula (2.5), on the project's actual rational normal form. -/
def Goal_2_2 : Prop :=
  ∀ (k : ℕ) (R : Zetahyperbolic.RatMomentElem), 1 ≤ k →
    Zetahyperbolic.muFunctionalPoly k R =
      PaperOrder.Section2.tauPullbackNormalForm k R

/-- Lemma 2.3: reflection on both generators and pole differences,
    retaining the paper's exclusions r = 0 and r = 1. -/
def Goal_2_3 : Prop :=
  (∀ (k d : ℕ), 1 ≤ k →
    (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
        -Zetahyperbolic.tauMonomial k d) ∧
  (∀ (k : ℕ) (r : ℤ),
    -Zetahyperbolic.tauPolePoly k (-1 - r) =
      -Zetahyperbolic.tauPolePoly k r) ∧
  (∀ (k : ℕ) (r : ℤ), r ≠ 0 → r ≠ 1 →
    Zetahyperbolic.tauPolePoly k (r - 1) -
      Zetahyperbolic.tauPolePoly k r =
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹))

/-- Theorem 2.4: canonical primitive polynomial is unchanged up to sign
    under any two invertible rational polynomial-basis transforms. -/
def Goal_2_4 : Prop :=
  ∀ (p : ManuscriptChain.Real.Parameters)
    (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0)
    (hdelta : ManuscriptChain.Real.delta p ≠ 0),
    let n0 := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p) hdelta
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
        (ManuscriptChain.Real.pencil p) A B hA hB).mpr hdelta)
    nAB.polynomial = n0.polynomial ∨ nAB.polynomial = -n0.polynomial

/-- Theorem 2.5: complete affine pole diagonalization and degree. -/
def Goal_2_5 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ((∀ a b : Fin p.h, a ≠ b →
      ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a b =
        Polynomial.C
          (ManuscriptChain.PoleDiagonalization.poleConstantMatrix p a b)) ∧
      (∀ a : Fin p.h,
        ManuscriptChain.PoleDiagonalization.poleWeight p a ≠ 0)) ∧
    (ManuscriptChain.Real.delta p).natDegree = p.h

/-- Four proof terms close Section 2 at the stated normal-form scope. -/
structure Proofs : Type where
  lemma2_2 : Goal_2_2
  lemma2_3 : Goal_2_3
  theorem2_4 : Goal_2_4
  theorem2_5 : Goal_2_5

end PaperBlueprint.Chapter2
