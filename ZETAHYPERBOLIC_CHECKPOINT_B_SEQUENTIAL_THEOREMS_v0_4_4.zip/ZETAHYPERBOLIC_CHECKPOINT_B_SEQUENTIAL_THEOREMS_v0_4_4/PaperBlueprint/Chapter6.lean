import PaperBlueprint.Chapter5

/-!
# Section 6, original PDF pp. 29-50: 18 theorem-level blueprints

This chapter contains analytic, valuation, arithmetic, multi-weight and
transcendence claims. They are represented as explicit propositions over a
DATA INTERFACE, not as proved theorems about the manuscript objects.
Each interface must be identified with its printed defining expression.
Especially: the printed inference in 6.10 lacks an UPPER bound on the
quadratic decay-rate parameter. It is not inferred from a lower bound.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperBlueprint.Chapter6

structure Data where
  primeValuation : ℕ → ℚ → ℤ
  simultaneousMomentSix : ℕ → ℝ
  simultaneousMomentSeven : ℕ → ℝ
  qAdicSevenDet : ℕ → ℚ
  betaKernel : ℝ → ℝ
  betaSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  betaConstant : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  qAdicBetaDet : ℕ → ℚ
  multiSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  multiConstant : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  positiveKreinGram : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  negativeKreinGram : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  independenceCone : ℚ → ℚ → ℚ → Prop
  triplePoleDet : ℕ → ℚ
  potentialGap : ℝ
  derivativeGrowth : ℝ
  heightRate : ℝ
  decayRate : ℝ
  distributionGrowth : ℝ
  twoAdicQuotient : ℕ → ℚ
  signFlippedSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  secantCentralFactorial : ℕ → ℚ
  laplaceMode : ℕ → ℝ
  coshEvenPoleWeight : ℝ → ℝ
  evenPoleSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  transcendenceCandidate : ℝ
  positiveOneVariableWeight : ℝ → ℝ
  multizetaBetaSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  beukersZetaBetaConstant : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  beukersZetaBetaSlope : (n : ℕ) → Matrix (Fin n) (Fin n) ℝ
  dyadicPrincipalMinor : ℕ → ℚ
  dyadicHeight : ℕ → ℝ

/-- 6.1: v_p of genuine off-diagonal ζ(7) divided differences is -7
    on the two-pole residue classes. -/
def Goal_6_1 (d : Data) : Prop :=
  ∀ (p r t : ℕ), Nat.Prime p → 11 ≤ p →
    r < p → p ≤ t → r % p = t % p → r ≠ t →
    d.primeValuation p (ManuscriptChain.Real.dualConstant 7 r t) = -7

/-- 6.2: simultaneous 6/7 diagonal moments of the Beukers functional. -/
def Goal_6_2 (d : Data) : Prop :=
  ∀ r : ℕ,
    d.simultaneousMomentSix r =
      ManuscriptChain.Real.zeta 6 -
        (ManuscriptChain.Real.harmonic 6 r : ℝ) ∧
    d.simultaneousMomentSeven r =
      zetaSeven - (ManuscriptChain.Real.harmonic 7 r : ℝ)

/-- 6.3: q-adic non-vanishing AND positive polynomial cones.
    Construction and the infinite-mode tail remain separate obligations. -/
def Goal_6_3 (d : Data) : Prop :=
  (∀ (q : ℕ), Nat.Prime q → q % 9 = 1 → d.qAdicSevenDet q ≠ 0) ∧
  (∀ h : ℕ, 0 < h →
    ∃ K : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
      PaperOrder.CoreAlgebra.dualCoefficientRowsSeparate c ∧
      StrictPositiveForm (actualWeightSevenGram c))

/-- 6.4: character-Vandermonde sign cancellation yields a positive slope,
    not merely a formal finite polynomial factorization. -/
def Goal_6_4 (d : Data) : Prop :=
  (∀ y : ℝ, 0 < y → 0 < d.betaKernel y) ∧
    (∀ h : ℕ, (d.betaSlope h).PosDef) ∧
    (∀ h : ℕ, EveryComplexZeroReal
      (affineDet (d.betaConstant h) (d.betaSlope h)))

/-- 6.5: beta(4) q-adic nonvanishing in the stated progression. -/
def Goal_6_5 (d : Data) : Prop :=
  ∀ q : ℕ, Nat.Prime q → q % 9 = 1 → d.qAdicBetaDet q ≠ 0

/-- 6.6: positive-slope pencils for simultaneous multi-weight moments. -/
def Goal_6_6 (d : Data) : Prop :=
  ∀ n : ℕ, (d.multiSlope n).PosDef ∧
    EveryComplexZeroReal (affineDet (d.multiConstant n) (d.multiSlope n))

/-- 6.7: signed two-variable Krein cones in every finite dimension.
    Integral/mode matching is part of the separate Chapter 5 interface. -/
def Goal_6_7 (d : Data) : Prop :=
  ∀ n : ℕ, 0 < n →
    StrictPositiveForm (d.positiveKreinGram n) ∧
    StrictNegativeForm (d.negativeKreinGram n)

/-- 6.8: only the paper's specified coefficient cone is in scope.
    This is NOT a claim of unrestricted independence of 1, ζ(5), ζ(7). -/
def Goal_6_8 (d : Data) : Prop :=
  ∀ a b c : ℚ, d.independenceCone a b c →
    (a : ℝ) + (b : ℝ) * zetaFive + (c : ℝ) * zetaSeven ≠ 0

/-- 6.9: triple-pole determinant non-vanishing. -/
def Goal_6_9 (d : Data) : Prop :=
  ∀ q : ℕ, Nat.Prime q → 11 ≤ q →
    d.triplePoleDet q ≠ 0

/-- 6.10 CORRECTED: potential-gap identity and the quantified implication
    for a height/decay ratio require an UPPER decay estimate. -/
def Goal_6_10 (d : Data) : Prop :=
  0 < d.potentialGap ∧ d.derivativeGrowth = 0 ∧
  (0 < d.decayRate → d.decayRate ≤ (1 / 2500 : ℝ) →
    581 < d.heightRate / d.decayRate)

/-- 6.11: distribution growth law and a 2-adic polynomial-quotient barrier.
    The quantitative growth constant must be connected to the source. -/
def Goal_6_11 (d : Data) : Prop :=
  0 ≤ d.distributionGrowth ∧
    (∃ n : ℕ, d.primeValuation 2 (d.twoAdicQuotient n) < 0)

/-- 6.12: sign-flip positive definiteness and q-adic nonvanishing. -/
def Goal_6_12 (d : Data) : Prop :=
  (∀ n : ℕ, (d.signFlippedSlope n).PosDef) ∧
  (∀ q : ℕ, Nat.Prime q → 11 ≤ q → d.qAdicBetaDet q ≠ 0)

/-- 6.13: secant central-factorial identity and Laplace-mode annihilation;
    the central-factorial coefficients require their printed normalization. -/
def Goal_6_13 (d : Data) : Prop :=
  (∀ n : ℕ, 0 ≤ d.secantCentralFactorial n) ∧
  (∀ n : ℕ, d.laplaceMode n = 0)

/-- 6.14: cosh even-pole scaling and positive Zeta-Beta pencils. -/
def Goal_6_14 (d : Data) : Prop :=
  (∀ y : ℝ, 0 < y → 0 < d.coshEvenPoleWeight y) ∧
  (∀ n : ℕ, (d.evenPoleSlope n).PosDef)

/-- 6.15: actual transcendence means nonvanishing at EVERY nonzero
    integer polynomial, plus strictly positive one-variable measure. -/
def Goal_6_15 (d : Data) : Prop :=
  (∀ p : Polynomial ℤ, p ≠ 0 →
    evalIntegerPolynomial p d.transcendenceCandidate ≠ 0) ∧
  (∀ y : ℝ, 0 < y → 0 < d.positiveOneVariableWeight y)

/-- 6.16: multi-weight Zeta-Beta positive-definite pencil endpoint. -/
def Goal_6_16 (d : Data) : Prop :=
  ∀ n : ℕ, (d.multizetaBetaSlope n).PosDef

/-- 6.17: two-variable Beukers Zeta-Beta real spectrum plus the missing
    q-adic determinant nonvanishing, not just a finite-index lemma. -/
def Goal_6_17 (d : Data) : Prop :=
  (∀ n : ℕ,
    (d.beukersZetaBetaSlope n).PosDef ∧
    EveryComplexZeroReal
      (affineDet (d.beukersZetaBetaConstant n) (d.beukersZetaBetaSlope n))) ∧
  (∀ q : ℕ, Nat.Prime q → 11 ≤ q → d.qAdicBetaDet q ≠ 0)

/-- 6.18: principal-minor 2-adic integrality and dyadic height bound. -/
def Goal_6_18 (d : Data) : Prop :=
  (∀ n : ℕ, 0 ≤ d.primeValuation 2 (d.dyadicPrincipalMinor n)) ∧
  (∃ C : ℝ, 0 < C ∧
    ∀ n : ℕ, d.dyadicHeight n ≤ C * ((n : ℝ) ^ 2))

structure Proofs (d : Data) : Type where
  theorem6_1 : Goal_6_1 d
  theorem6_2 : Goal_6_2 d
  theorem6_3 : Goal_6_3 d
  theorem6_4 : Goal_6_4 d
  theorem6_5 : Goal_6_5 d
  theorem6_6 : Goal_6_6 d
  theorem6_7 : Goal_6_7 d
  corollary6_8 : Goal_6_8 d
  theorem6_9 : Goal_6_9 d
  theorem6_10_corrected : Goal_6_10 d
  theorem6_11 : Goal_6_11 d
  theorem6_12 : Goal_6_12 d
  theorem6_13 : Goal_6_13 d
  theorem6_14 : Goal_6_14 d
  theorem6_15 : Goal_6_15 d
  theorem6_16 : Goal_6_16 d
  theorem6_17 : Goal_6_17 d
  theorem6_18 : Goal_6_18 d

end PaperBlueprint.Chapter6
