import PaperBlueprint.Chapter3

/-!
# Section 4, original PDF pp. 14-22: eight quantitative obligations

These are targets, not proofs of the zeta(5) irrationality measure.
The `Data` model is NOT YET identified with the analytic and arithmetic
estimates of the paper. The transfer theorem 4.1 is a conditional result;
its witness hypotheses may not be suppressed. Constants 25687, 11.411,
1/2500 and the 30n/27n schedule are preserved verbatim.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperBlueprint.Chapter4

structure Data where
  integerPolynomials : ℕ → Polynomial ℤ
  spectralNorm : ℕ → ℝ
  logDeterminantAbs : ℕ → ℝ
  logCoefficientHeight : ℕ → ℝ
  roots : (n : ℕ) → Fin (27 * n) → ℝ
  algebraicCandidate : ℝ → Prop
  algebraicHeight : ℝ → ℝ
  localAbsoluteValue : ℚ → ℝ

/-- Exact finite witness hypotheses required by the paper's Theorem 4.1.
    Without these, no irrationality-measure conclusion is licensed. -/
def WitnessHypotheses (ξ ε ρ degreeRate : ℝ)
    (Q : ℕ → Polynomial ℤ) : Prop :=
  ∃ K0 : ℕ, ∀ K : ℕ, K0 ≤ K →
    ((Q K).natDegree : ℝ) ≤ degreeRate * (K : ℝ) ∧
    0 < |evalIntegerPolynomial (Q K) ξ| ∧
    |evalIntegerPolynomial (Q K) ξ| ≤
      Real.exp (-ε * (K : ℝ) ^ 2) ∧
    (∀ z : ℂ,
      Polynomial.eval₂ (Int.castRingHom ℂ) z (Q K) = 0 →
        Real.exp (-ρ * (K : ℝ)) ≤ ‖z - (ξ : ℂ)‖)

/-- 4.1: all inputs exposed; no hidden root-gap or decay assumption. -/
def Goal_4_1 : Prop :=
  ∀ (ξ ε ρ degreeRate : ℝ) (Q : ℕ → Polynomial ℤ) (m : ℕ),
    0 < ε → 0 < ρ → 0 < degreeRate →
    WitnessHypotheses ξ ε ρ degreeRate Q →
    degreeRate * ρ / ε < (m : ℝ) →
    RationalSeparation ξ m

/-- 4.2: conditional algebraic transfer. The model's `algebraicCandidate`
    must be IDENTIFIED with degree-at-most-d algebraic numbers, and its
    height must agree with the height used in the paper. -/
def Goal_4_2 (d : Data) : Prop :=
  ∀ (m degreeBound : ℕ) (ξ ε ρ degreeRate Λ : ℝ),
    0 < ε → 0 < ρ → 0 < degreeRate → 0 < degreeBound →
    WitnessHypotheses ξ ε ρ degreeRate d.integerPolynomials →
    (∃ K0 : ℕ, ∀ K : ℕ, K0 ≤ K →
      d.logCoefficientHeight K ≤ Λ * (K : ℝ) ^ 2) →
    (degreeBound : ℝ) * degreeRate * ρ <
      (m : ℝ) * (ε - ((degreeBound : ℝ) - 1) * Λ) →
    0 < ε - ((degreeBound : ℝ) - 1) * Λ →
    ∃ b0 : ℝ, ∀ x : ℝ,
      d.algebraicCandidate x →
      b0 ≤ d.algebraicHeight x →
      1 / (d.algebraicHeight x ^ m) < |ξ - x|

/-- 4.3: abstract p-adic-style root exclusion with all ultrametric
    axioms as named PREMISES. To cover C_p, replace this rational model
    with the actual complete valued-field construction. -/
def Goal_4_3 (d : Data) : Prop :=
  (∀ (x y : ℚ),
    d.localAbsoluteValue (x + y) ≤
      max (d.localAbsoluteValue x) (d.localAbsoluteValue y)) →
  (∀ (x y : ℚ),
    d.localAbsoluteValue (x * y) =
      d.localAbsoluteValue x * d.localAbsoluteValue y) →
  (∀ x : ℚ, 0 ≤ d.localAbsoluteValue x) →
  (∀ (P : Polynomial ℚ) (ξ α : ℚ),
    (∀ n : ℕ, d.localAbsoluteValue (P.coeff n) ≤ 1) →
    d.localAbsoluteValue ξ ≤ 1 →
    d.localAbsoluteValue α ≤ 1 →
    0 < d.localAbsoluteValue (P.eval ξ) →
    d.localAbsoluteValue (α - ξ) < d.localAbsoluteValue (P.eval ξ) →
      d.localAbsoluteValue (P.eval α) = d.localAbsoluteValue (P.eval ξ))

/-- 4.4: the actual 11.411 exponential norm estimate and 25687 measure. -/
def Goal_4_4 (d : Data) : Prop :=
  (∃ n0 : ℕ, ∀ n : ℕ, n0 ≤ n →
    d.spectralNorm (30 * n) ≤
      Real.exp ((11411 / 1000 : ℝ) * ((30 * n : ℕ) : ℝ))) ∧
    RationalSeparation zetaFive 25687

/-- 4.5: effective measures of the stated zeta(5),zeta(3) combinations. -/
def Goal_4_5 : Prop :=
  ∀ a b : ℤ, 0 < b →
    (a : ℝ) < Real.pi ^ 2 / 3 * (b : ℝ) →
      RationalSeparation ((b : ℝ) * zetaFive + (a : ℝ) * zetaThree) 25687

/-- 4.6: two-sided K^2 determinant bounds and coefficient heights.
    This is an eventual-with-slack form of the manuscript liminf/limsup. -/
def Goal_4_6 (d : Data) : Prop :=
  ∀ δ : ℝ, 0 < δ → ∃ n0 : ℕ, ∀ n : ℕ,
    n0 ≤ n → 0 < n →
      (23310 / 100000 : ℝ) - δ ≤
        d.logDeterminantAbs (30 * n) / (((30 * n : ℕ) : ℝ) ^ 2) ∧
      d.logDeterminantAbs (30 * n) / (((30 * n : ℕ) : ℝ) ^ 2) ≤
        (373980 / 100000 : ℝ) + δ ∧
      d.logCoefficientHeight (30 * n) / (((30 * n : ℕ) : ℝ) ^ 2) ≤
        (1027 / 100 : ℝ) + δ

/-- 4.7: at least 1.40 percent of the finite roots have exponential
    distance ≤ exp(-0.10 K). Roots have multiplicity through Fin indices. -/
def Goal_4_7 (d : Data) : Prop :=
  ∃ n0 : ℕ, ∀ n : ℕ, n0 ≤ n → 0 < n →
    ∃ S : Finset (Fin (27 * n)),
      (14 / 1000 : ℝ) * (((27 * n : ℕ) : ℝ)) ≤ (S.card : ℝ) ∧
      ∀ i : Fin (27 * n), i ∈ S →
        |d.roots n i - zetaFive| ≤
          Real.exp (-(1 / 10 : ℝ) * (((30 * n : ℕ) : ℝ)))

/-- 4.8: exclusion of rational roots with denominators up to exp(K/2251). -/
def Goal_4_8 (d : Data) : Prop :=
  ∃ n0 : ℕ, ∀ (n : ℕ) (a : ℤ) (b : ℕ),
    n0 ≤ n → 0 < b →
    (b : ℝ) ≤ Real.exp ((((30 * n : ℕ) : ℝ)) / 2251) →
      evalIntegerPolynomial (d.integerPolynomials (30 * n))
        ((a : ℝ) / (b : ℝ)) ≠ 0

structure Proofs (d : Data) : Type where
  theorem4_1 : Goal_4_1
  proposition4_2 : Goal_4_2 d
  proposition4_3 : Goal_4_3 d
  theorem4_4 : Goal_4_4 d
  theorem4_5 : Goal_4_5
  theorem4_6 : Goal_4_6 d
  theorem4_7 : Goal_4_7 d
  proposition4_8 : Goal_4_8 d

end PaperBlueprint.Chapter4
