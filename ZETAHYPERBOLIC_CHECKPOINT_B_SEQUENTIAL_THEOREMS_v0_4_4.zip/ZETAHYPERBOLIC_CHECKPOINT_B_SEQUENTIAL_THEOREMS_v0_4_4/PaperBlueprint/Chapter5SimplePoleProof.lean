import PaperBlueprint.Chapter5
import PaperOrder.Lemma_2_3_Reflection_And_Difference_Identities

/-!
# Original paper §5, Theorem 5.4: even simple-pole cancellation

Directly inhabits the actual Chapter5.Goal_5_4 for every weight s=2k+1
and every j>=1. The exceptional j=1 case is proved from definitions,
without falsely applying the difference identity at excluded pole r=1.
No higher-pole or infinite-Krein assertion is claimed.
-/

noncomputable section
open Polynomial
open Zetahyperbolic
namespace PaperBlueprint.Chapter5

/-- Equation (5.5), for all weights and positive pole indices. -/
theorem exact_theorem_5_4_simple_pole_goal : Goal_5_4 := by
  intro k j hk hj
  by_cases hj1 : j = 1
  · subst j
    norm_num [tauPolePoly, dIndex, harmonicWeight]
  · have hj0 : (j : ℤ) ≠ 0 := by
      exact_mod_cast (Nat.ne_of_gt (lt_of_lt_of_le (by decide : 0 < 1) hj))
    have hj1' : (j : ℤ) ≠ 1 := by
      exact_mod_cast hj1
    have hstep := tau_difference_pole k (j : ℤ) hj0 hj1'
    have hreflect := tauPolePoly_reflect k ((j : ℤ) - 1)
    have hneg : (-1 : ℤ) - ((j : ℤ) - 1) = -(j : ℤ) := by ring
    rw [hneg] at hreflect
    calc
      tauPolePoly k (j : ℤ) - tauPolePoly k (-(j : ℤ)) =
          -(tauPolePoly k ((j : ℤ) - 1) - tauPolePoly k (j : ℤ)) := by
            rw [hreflect]
            abel
      _ = -(Polynomial.C (-(((j : ℚ) ^ (2 * k + 1))⁻¹))) := by
            rw [hstep]
      _ = Polynomial.C (1 / ((j : ℚ) ^ (2 * k + 1))) := by
            simp [one_div]

end PaperBlueprint.Chapter5

#print axioms PaperBlueprint.Chapter5.exact_theorem_5_4_simple_pole_goal
