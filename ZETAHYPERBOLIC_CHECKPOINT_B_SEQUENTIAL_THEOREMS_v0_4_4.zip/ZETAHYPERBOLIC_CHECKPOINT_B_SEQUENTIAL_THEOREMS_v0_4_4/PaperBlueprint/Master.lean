import PaperBlueprint.Chapter2Certified
import PaperBlueprint.Chapter3
import PaperBlueprint.Chapter4
import PaperBlueprint.Chapter5
import PaperBlueprint.Chapter6

/-!
# Complete original-paper PROOF OBLIGATION REGISTRY

The original PDF has 46 numbered non-remark items: 1 definition and 45
proof items. The five chapter bundles list all 45 items. Compound printed
theorems (e.g. 3.3, 5.2) deliberately have multiple proof fields.

A `BlueprintBundle` is a type of proof certificates; this source DOES NOT
provide an inhabitant of that type. In particular, compiling this file
is not a proof of the 52-page paper, and the data interfaces must still
be shown equal to the source's analytic/p-adic constructions.

Corrected theorem targets are labelled explicitly. Uncorrected false or
unestablished statements are not automatically certified.
-/

noncomputable section
namespace PaperBlueprint

structure Model where
  section3 : Chapter3.Data
  section4 : Chapter4.Data
  section5 : Chapter5.Data
  section6 : Chapter6.Data

/-- The complete proof-bundle TYPE: its existence is NOT asserted. -/
structure BlueprintBundle (d : Model) : Type where
  algebra : Chapter2.Proofs
  spectral : Chapter3.Proofs d.section3
  diophantine : Chapter4.Proofs d.section4
  beukers : Chapter5.Proofs d.section5
  generalizations : Chapter6.Proofs d.section6

/-- The already-certified Section 2 proof bundle can be reused in every
    proposed full-paper certificate, with zero changed frozen files. -/
def reuseSection2 : Chapter2.Proofs := Chapter2.certifiedProofs

/-- This merely packages four submitted chapter proofs with our completed
    Section 2. It does NOT construct the other four chapter proofs. -/
def assembleWithCertifiedSection2 (d : Model)
    (s3 : Chapter3.Proofs d.section3)
    (s4 : Chapter4.Proofs d.section4)
    (s5 : Chapter5.Proofs d.section5)
    (s6 : Chapter6.Proofs d.section6) : BlueprintBundle d where
  algebra := reuseSection2
  spectral := s3
  diophantine := s4
  beukers := s5
  generalizations := s6

end PaperBlueprint

#print axioms PaperBlueprint.Chapter2.certifiedProofs
#print axioms PaperBlueprint.assembleWithCertifiedSection2
