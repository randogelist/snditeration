import PaperBlueprint.Chapter2

/-!
# Section 3, original PDF pp. 7-14: spectral theorem blueprints

Paper 3.2: continuous weight normalization requires correction.
Paper 3.4: interlacing as printed is not valid for rank-deficient slopes.
Paper 3.5: positive Lanczos coefficients require cyclicity and correct scaling.
Paper 3.6: a finite atomic measure cannot have strictly positive Hankel
  determinants of every size; positivity is limited by support rank.
The `Data` fields are intended mathematical models, NOT proof assumptions.
Their identification with the paper's constructions is a separate bridge.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperBlueprint.Chapter3

structure Data where
  continuousDet : ℝ → ℕ → Polynomial ℝ
  relativeEigenvalues : (p : ManuscriptChain.Real.Parameters) → Fin p.h → ℝ
  jFractionDenominator : ℕ → Polynomial ℝ
  jFractionA : ℕ → ℝ
  jFractionB : ℕ → ℝ
  kernelCharacteristic : ℕ → Polynomial ℝ
  relativeCharacteristic : ℕ → Polynomial ℝ
  hurwitzDet : ℕ → Polynomial ℝ
  dirichletDet : ℕ → Polynomial ℝ
  dirichletKernel : ℝ → ℝ

/-- 3.1: real zeros and exact degree at the actual algebraic pencil.
    The analytic identification with the positive Gram integral is separate. -/
def Goal_3_1 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      (ManuscriptChain.Real.delta p).natDegree = p.h ∧
      EveryComplexZeroReal
        (ManuscriptChain.Real.realPolynomial (ManuscriptChain.Real.delta p))

/-- 3.2: continuous s>1 target, after correcting the printed factor π/2. -/
def Goal_3_2 (d : Data) : Prop :=
  ∀ (s : ℝ) (h : ℕ), 1 < s →
    (d.continuousDet s h).natDegree = h ∧
      EveryComplexZeroReal (d.continuousDet s h)

/-- 3.3: the strict total-positivity component for the actual Gram matrix.
    The exact inertia/signature component is tracked separately. -/
def Goal_3_3 : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      StrictTotalPositive
        (ManuscriptChain.Real.gram p
          (ManuscriptChain.Real.zeta p.weight))

/-- 3.3: genuine spectral inertia counts, relative to the alternating
    pole-derivative weights. Identifying `relativeEigenvalues` with the
    generalized symmetric pencil is an explicit analytic/algebraic bridge. -/
def Goal_3_3_Inertia (d : Data) : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      (∀ i : Fin p.h, d.relativeEigenvalues p i ≠ 0) ∧
      (Finset.univ.filter (fun j : Fin p.h =>
        0 < d.relativeEigenvalues p j)).card =
      (Finset.univ.filter (fun j : Fin p.h =>
        (p.N + j.val) % 2 = 0)).card ∧
      (Finset.univ.filter (fun j : Fin p.h =>
        d.relativeEigenvalues p j < 0)).card =
      (Finset.univ.filter (fun j : Fin p.h =>
        (p.N + j.val) % 2 = 1)).card

/-- 3.3 combines the total-positivity and exact-signature demands. -/
def Goal_3_3_Full (d : Data) : Prop :=
  Goal_3_3 ∧ Goal_3_3_Inertia d

/-- 3.4 CORRECTED endpoint: every selected principal subpencil retains
    real-rootedness, even when its polynomial degree drops. -/
def Goal_3_4 : Prop :=
  ∀ (n r : ℕ) (p : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hbase : p.base.PosDef) (e : Fin r → Fin n)
    (he : Function.Injective e),
    EveryComplexZeroReal
      ((PaperOrder.PrincipalTheorems.selectedPrincipalPencil p e).detPolynomial)

/-- 3.5: formal finite three-term J-fraction determinant recurrence;
    identifying these denominators with consecutive manuscript minors
    and proving cyclicity are distinct obligations. -/
def Goal_3_5 (d : Data) : Prop :=
  (∀ j : ℕ, 0 < d.jFractionB j) ∧
  (∀ j : ℕ, 2 ≤ j →
    d.jFractionDenominator (j + 1) =
      (Polynomial.X - Polynomial.C (d.jFractionA j)) *
        d.jFractionDenominator j -
      Polynomial.C ((d.jFractionB j) ^ 2) *
        d.jFractionDenominator (j - 1))

/-- 3.6 CORRECTED: strict finite-atomic moment determinants for orders
    at most the number of distinct reciprocal-square support points. -/
def Goal_3_6 : Prop :=
  ∀ (n : ℕ) (roots : Fin n → ℝ) (q : ℝ),
    (∀ i : Fin n, roots i ≠ q) →
    (∀ (i j : Fin n), i ≠ j →
      (roots i - q) ^ 2 ≠ (roots j - q) ^ 2) →
    ∀ (r : ℕ), r ≤ n →
      0 < Matrix.det (fun (i : Fin r) (j : Fin r) =>
        finiteRootMoment roots q (i.val + j.val))

/-- Repeated polynomial differentiation, to state the all-degree Turán
    inequalities without a proof or special-case assumption. -/
def iteratedDerivative : ℕ → Polynomial ℝ → Polynomial ℝ
  | 0, p => p
  | n + 1, p => Polynomial.derivative (iteratedDerivative n p)

/-- 3.7: the real-rooted polynomial Wronskian inequality. -/
def Goal_3_7 : Prop :=
  ∀ (p : Polynomial ℝ) (m : ℕ) (x : ℝ),
    EveryComplexZeroReal p → 1 ≤ m → m < p.natDegree →
    0 ≤ ((iteratedDerivative m p).eval x) ^ 2 -
      (iteratedDerivative (m - 1) p).eval x *
      (iteratedDerivative (m + 1) p).eval x

/-- 3.8: Christoffel-Darboux characteristic identity. Jacobi's
    analytic parameter-derivative is a separate source-bridge obligation. -/
def Goal_3_8 (d : Data) : Prop :=
  ∀ n : ℕ,
    d.kernelCharacteristic n = d.relativeCharacteristic n

/-- 3.9: Hurwitz/Dirichlet positive kernels and full real spectrum.
    This must be linked to the actual residue functional, not a free model. -/
def Goal_3_9 (d : Data) : Prop :=
  (∀ y : ℝ, 0 < y → 0 < d.dirichletKernel y) ∧
  (∀ n : ℕ,
    EveryComplexZeroReal (d.hurwitzDet n) ∧
    EveryComplexZeroReal (d.dirichletDet n))

structure Proofs (d : Data) : Type where
  theorem3_1 : Goal_3_1
  proposition3_2 : Goal_3_2 d
  theorem3_3 : Goal_3_3_Full d
  theorem3_4_corrected : Goal_3_4
  corollary3_5_corrected : Goal_3_5 d
  corollary3_6_rankLimited : Goal_3_6
  theorem3_7 : Goal_3_7
  theorem3_8 : Goal_3_8 d
  theorem3_9 : Goal_3_9 d

end PaperBlueprint.Chapter3
