import PaperBlueprint.Chapter3
import PaperOrder.Theorem_3_3_Total_Positivity_Leading_Sign_And_Signature
import PaperOrder.Theorem_3_7_All_Degree_Turan_Leading_Scalar
import PaperOrder.Corollary_3_6_General_Atomic_Hankel_Determinant

/-!
# Original paper Section 3 — next three algebraic subtheorems

Each item here is a DIRECT PROOF from an already native-compiler-certified
algebraic lemma, not another proposal or merely an index of LaTeX paragraphs.

Theorem 3.3: exact leading-coefficient determinant identity ONLY;
strict continuous total positivity and universal spectral signature are open.

Corollary 3.6: exact strict determinant positivity for n positive weighted,
distinct real atoms at FULL size n; the continuous / infinite-order
Stieltjes determinant assertion is not claimed.

Theorem 3.7: all finite degrees, FIRST Turan Wronskian for a polynomial
represented as a scalar times its real linear factors. The complete
higher-derivative / Newton / strict equality statements are still open.
-/

noncomputable section
namespace PaperBlueprint.Chapter3

/-- The paper's actual rational determinant leading coefficient equals the
pole-slope matrix determinant, for each admissible parameter tuple. -/
theorem theorem3_3_actual_leading_coefficient
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).leadingCoeff =
      (ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p).det :=
  PaperOrder.Section3.theorem_3_3_algebraic_leading_coefficient p

/-- Fully finite, full-support atomic Hankel determinant positivity. -/
theorem corollary3_6_finite_atomic_full_rank
    {n : ℕ} (x w : Fin n → ℝ)
    (hx : Function.Injective x) (hw : ∀ k : Fin n, 0 < w k) :
    0 < (PaperOrder.CoreAlgebra.atomicMomentMatrix x w).det :=
  PaperOrder.CoreAlgebra.atomicMomentMatrix_det_pos x w hx hw

/-- Arbitrary-degree m=1 Turan inequality of a real-split polynomial. -/
theorem theorem3_7_all_degree_first_turan
    (c : ℝ) (roots : List ℝ) (u : ℝ) :
    0 ≤ (PaperOrder.CoreAlgebra.turanWronskian
      (Polynomial.C c * PaperOrder.CoreAlgebra.rootListPolynomial roots)).eval u :=
  PaperOrder.CoreAlgebra.turanWronskian_split_polynomial_nonneg c roots u

end PaperBlueprint.Chapter3

#print axioms PaperBlueprint.Chapter3.theorem3_3_actual_leading_coefficient
#print axioms PaperBlueprint.Chapter3.corollary3_6_finite_atomic_full_rank
#print axioms PaperBlueprint.Chapter3.theorem3_7_all_degree_first_turan
