import PaperBlueprint.Chapter3
import PaperOrder.Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import PaperOrder.Principal_Theorem_3_4_All_Principal_Minors_Real_Rooted

/-!
# Original paper §3: two actual theorem-goal bridges

Theorem 3.1 is proved for the genuine odd-weight rational moment pencil,
using the upstream unconditional Gram-positive result. Theorem 3.4 is only
its CORRECTED full-principal-subpencil real-rootedness assertion; the false
unrestricted printed interlacing claim is not asserted or proved.

These are proof terms for the actual Chapter3.Goal_3_1 and Goal_3_4 targets,
not source-text receipts or abstract placeholders.
-/

noncomputable section
namespace PaperBlueprint.Chapter3

/-- Proof of the actual exact-degree and every-complex-zero-real target. -/
theorem exact_theorem_3_1_goal : Goal_3_1 := by
  intro p hp
  refine ⟨ManuscriptChain.General.delta_degree p, ?_⟩
  intro z hz
  have hroot : ManuscriptChain.General.ComplexRoot p z := by
    unfold ManuscriptChain.General.ComplexRoot
    calc
      Polynomial.eval₂ (algebraMap ℚ ℂ) z (ManuscriptChain.Real.delta p) =
          Polynomial.eval₂ (algebraMap ℝ ℂ) z
            (ManuscriptChain.Real.manuscriptPencil p).detPolynomial :=
        (ManuscriptChain.General.complex_eval_transport p z).symm
      _ = Polynomial.eval₂ (algebraMap ℝ ℂ) z
            (ManuscriptChain.Real.realPolynomial (ManuscriptChain.Real.delta p)) := by
        rw [ManuscriptChain.Real.manuscriptPencil_detPolynomial]
      _ = 0 := hz
  exact ManuscriptChain.General.roots_real p
    (ManuscriptChain.GRAM_POSITIVE p hp) z hroot

/-- Corrected theorem 3.4, allowing singular principal slope matrices. -/
theorem corrected_theorem_3_4_goal : Goal_3_4 := by
  intro n r p hp e he z hz
  exact PaperOrder.PrincipalTheorems.corrected_theorem_3_4_all_principal_zeros_real
    p hp e he z hz

end PaperBlueprint.Chapter3

#print axioms PaperBlueprint.Chapter3.exact_theorem_3_1_goal
#print axioms PaperBlueprint.Chapter3.corrected_theorem_3_4_goal
