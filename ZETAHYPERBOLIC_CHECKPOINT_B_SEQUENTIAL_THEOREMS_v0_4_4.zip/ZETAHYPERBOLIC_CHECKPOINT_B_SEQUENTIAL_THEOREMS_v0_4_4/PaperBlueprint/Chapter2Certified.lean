import PaperBlueprint.Chapter2

/-!
# Closed Section 2 proof registry, using previously certified theorems

No mathematical premise is fabricated here. Four source-aligned Chapter 2
blueprint entries are assembled from user-PASS native Lean modules. Scope:
actual generator / rational-normal-form domain, rather than an unformalized
claim about an arbitrary external rational-function representation.
-/

noncomputable section
namespace PaperBlueprint.Chapter2

/-- These FOUR proof fields are discharged from the preserved Lean base. -/
def certifiedProofs : Proofs where
  lemma2_2 := by
    intro k R hk
    exact PaperOrder.Section2.lemma_2_2_normal_form k hk R
  lemma2_3 := by
    refine ⟨?_, ?_, ?_⟩
    · intro k d hk
      exact PaperOrder.Section2.lemma_2_3_reflection_monomial k d hk
    · intro k r
      exact PaperOrder.Section2.lemma_2_3_reflection_pole k r
    · intro k r hr0 hr1
      exact PaperOrder.Section2.lemma_2_3_difference_pole k r hr0 hr1
  theorem2_4 := by
    intro p A B hA hB hdelta
    exact PaperOrder.Section2.theorem_2_4_canonical_basis_invariance
      p A B hA hB hdelta
  theorem2_5 := by
    intro p
    have h := PaperOrder.Section2.theorem_2_5_pencil_and_degree p
    exact ⟨⟨h.1.1, fun a => (h.1.2 a).2⟩, h.2⟩

end PaperBlueprint.Chapter2

#print axioms PaperBlueprint.Chapter2.certifiedProofs
