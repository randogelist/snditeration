import MAIN_CHAIN_PRINCIPAL_THEOREMS_V3
import PaperOrder.Principal_Theorem_3_4_All_Principal_Minors_Real_Rooted
import PaperOrder.Theorem_2_5_Lagrange_Pole_Diagonalization
import PaperOrder.Theorem_5_2_Dual_Row_Separation_PosDef

/-!
# Original 52-page paper: chapter-by-chapter proof blueprints

All targets in this namespace are DEFINITIONS OF PROPOSITIONS, not new proofs.
Declaring a goal does not prove or discharge it. This file imports only
modules already certified by the user's native Windows Lean 4.33 compiler.

The 46 numbered non-remark items comprise Definition 2.1 and 45 proof
obligations (4 + 9 + 8 + 6 + 18). A later `Proofs` structure lists each
actual proof term required. Separate analytic identification goals prevent a
proof for arbitrary surrogate data from being passed off as a paper theorem.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperBlueprint

/-- The paper's zeta values use its existing, certified real series. -/
def zetaThree : ℝ := ManuscriptChain.Real.zeta 3
def zetaFive : ℝ := ManuscriptChain.Real.zeta 5
def zetaSeven : ℝ := ManuscriptChain.Real.zeta 7

/-- Actual evaluation of a polynomial with integer coefficients in the real field. -/
def evalIntegerPolynomial (p : Polynomial ℤ) (x : ℝ) : ℝ :=
  Polynomial.eval₂ (Int.castRingHom ℝ) x p

/-- Exact complex-real-root predicate, with multiplicities left to degree. -/
def EveryComplexZeroReal (p : Polynomial ℝ) : Prop :=
  ∀ z : ℂ, Polynomial.eval₂ (algebraMap ℝ ℂ) z p = 0 → z.im = 0

/-- Strict root exclusion around a real center. -/
def GapAt (p : Polynomial ℝ) (center radius : ℝ) : Prop :=
  ∀ x : ℝ, p.eval x = 0 → radius ≤ |x - center|

/-- Determinant of a symmetric affine pencil over the real numbers. -/
def affineDet {n : ℕ} (A B : Matrix (Fin n) (Fin n) ℝ) : Polynomial ℝ :=
  Matrix.det (fun (i : Fin n) (j : Fin n) =>
    Polynomial.C (A i j) + Polynomial.X * Polynomial.C (B i j))

/-- Quadratic form, with no positivity silently inferred. -/
def quadraticForm {n : ℕ} (A : Matrix (Fin n) (Fin n) ℝ)
    (v : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, ∑ j : Fin n, v i * A i j * v j

def StrictPositiveForm {n : ℕ} (A : Matrix (Fin n) (Fin n) ℝ) : Prop :=
  ∀ v : Fin n → ℝ, v ≠ 0 → 0 < quadraticForm A v

def StrictNegativeForm {n : ℕ} (A : Matrix (Fin n) (Fin n) ℝ) : Prop :=
  ∀ v : Fin n → ℝ, v ≠ 0 → quadraticForm A v < 0

/-- All ORDER-PRESERVING minors, not minors with arbitrary row permutations. -/
def StrictTotalPositive {n : ℕ} (A : Matrix (Fin n) (Fin n) ℝ) : Prop :=
  ∀ (r : ℕ) (rows cols : Fin r → Fin n),
    StrictMono rows → StrictMono cols →
      0 < Matrix.det (fun (i : Fin r) (j : Fin r) => A (rows i) (cols j))

/-- The exact dual pencil's evaluation, already defined upstream over Q[X]. -/
def actualWeightSevenGram {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => ManuscriptChain.Real.evalQ
    (ManuscriptChain.Real.dualEntry 7 c i j) zetaSeven

/-- Genuine two-variable algebra: off-diagonal divided difference,
    diagonal zeta-seven term. This is NOT yet its integral realization. -/
def expectedWeightSevenMoment (r t : ℕ) : ℝ :=
  (ManuscriptChain.Real.dualConstant 7 r t : ℝ) +
    (if r = t then zetaSeven else 0)

/-- An effective irrationality-measure target at exponent m. -/
def RationalSeparation (x : ℝ) (m : ℕ) : Prop :=
  ∃ b0 : ℕ, ∀ (a : ℤ) (b : ℕ),
    b0 ≤ b → 0 < b →
      1 / ((b : ℝ) ^ m) < |x - (a : ℝ) / (b : ℝ)|

/-- A finite positive-root-moment model. Roots are indexed with multiplicity. -/
def finiteRootMoment {n : ℕ} (roots : Fin n → ℝ) (q : ℝ) (k : ℕ) : ℝ :=
  ∑ j : Fin n, (1 / ((roots j - q) ^ 2)) ^ k

end PaperBlueprint
