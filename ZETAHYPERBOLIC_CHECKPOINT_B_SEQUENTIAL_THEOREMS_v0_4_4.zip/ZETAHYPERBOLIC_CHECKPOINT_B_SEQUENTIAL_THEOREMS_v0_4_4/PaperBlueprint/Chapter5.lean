import PaperBlueprint.Chapter4

/-!
# Section 5, original PDF pp. 22-29: the 2-variable weight-seven theory

The actual finite dual pencil is connected to `ManuscriptChain.Real.dualEntry`.
The integral moment formula and the infinite Krein expansion remain analytic
IDENTIFICATION targets: a finite-channel sign identity does NOT cancel the
infinite tail. The all-h cone goal is expressed on the actual dual Gram.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperBlueprint.Chapter5

structure Data where
  beukersMoments : ℕ → ℕ → ℝ
  betaMoments : ℕ → ℕ → ℝ
  betaFour : ℝ
  doubleIntegralQuadratic : (ℝ → ℝ) → ℝ
  positiveMode : (ℝ → ℝ) → ℕ → ℝ
  negativeMode : (ℝ → ℝ) → ℕ → ℝ
  outerPrimeIntegral : ℝ
  innerPrimeTail : ℝ
  localRefinementGain : ℝ
  doublePoleDeterminant : ℕ → ℚ
  primeValuation : ℕ → ℚ → ℤ

/-- 5.1: diagonal ζ(7)-H^(7), off-diagonal rational divided differences.
    `beukersMoments` must subsequently be IDENTIFIED with formula (5.1). -/
def Goal_5_1 (d : Data) : Prop :=
  ∀ r t : ℕ,
    d.beukersMoments r t = expectedWeightSevenMoment r t

/-- 5.2(1): the true rational-coefficient slope is strictly positive. -/
def Goal_5_2_Slope : Prop :=
  ∀ (h K : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
    PaperOrder.CoreAlgebra.dualCoefficientRowsSeparate c →
      StrictPositiveForm
        (fun i j => (PaperOrder.CoreAlgebra.dualSlopeMatrix c i j : ℝ))

/-- 5.2(2): the INFINITE signed mode expansion; equality, convergence and
    passage to the integral have not been supplied by finite Krein algebra. -/
def Goal_5_2_InfiniteKrein (d : Data) : Prop :=
  ∀ f : ℝ → ℝ,
    (Summable (fun m => d.positiveMode f m ^ 2 - d.negativeMode f m ^ 2)) ∧
    d.doubleIntegralQuadratic f =
      ∑' m : ℕ, (d.positiveMode f m ^ 2 - d.negativeMode f m ^ 2)

/-- 5.2(3): actual finite-dimensional polynomial cones at ζ(7).
    The existential families are over Q-polynomials; no unused tail is dropped. -/
def Goal_5_2_AllDimensionalCones : Prop :=
  ∀ h : ℕ, 0 < h →
    ∃ K : ℕ, h ≤ K + 1 ∧
      (∃ cPlus : Fin h → Fin (K + 1) → ℚ,
        PaperOrder.CoreAlgebra.dualCoefficientRowsSeparate cPlus ∧
        StrictPositiveForm (actualWeightSevenGram cPlus)) ∧
      (∃ cMinus : Fin h → Fin (K + 1) → ℚ,
        PaperOrder.CoreAlgebra.dualCoefficientRowsSeparate cMinus ∧
        StrictNegativeForm (actualWeightSevenGram cMinus))

/-- The full printed 5.2 needs BOTH its finite slope and its INFINITE
    analytic identity and universal polynomial-cone construction. -/
def Goal_5_2 (d : Data) : Prop :=
  Goal_5_2_Slope ∧ Goal_5_2_InfiniteKrein d ∧
  Goal_5_2_AllDimensionalCones

/-- 5.3: beta(4) diagonal and off-diagonal moments. The actual square
    integral and Dirichlet beta definition must still be connected. -/
def Goal_5_3 (d : Data) : Prop :=
  ∀ r : ℕ,
    d.betaMoments r r = d.betaFour -
      (ManuscriptChain.Real.harmonic 4 (2 * r) : ℝ)

/-- 5.4: the simple-pole x-even identity; higher poles are NOT claimed. -/
def Goal_5_4 : Prop :=
  ∀ (k j : ℕ), 1 ≤ k → 1 ≤ j →
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
      Polynomial.C (1 / ((j : ℚ) ^ (2 * k + 1)))

/-- 5.6: the paper's exact outer prime integral, inner tail estimate, and
    +1/3 valuation gain, each with a separate definition bridge. -/
def Goal_5_6 (d : Data) : Prop :=
  d.outerPrimeIntegral = (453803 / 288000 : ℝ) ∧
  d.innerPrimeTail ≤ -(33104 / 576000 : ℝ) ∧
  (1 / 3 : ℝ) ≤ d.localRefinementGain

/-- 5.7: q ≡ 1 mod 9 gives v_q(J_(2m)) = -36m, independently of
    the still-missing p-adic interpolation and determinant bridge. -/
def Goal_5_7 (d : Data) : Prop :=
  ∀ (q m : ℕ), Nat.Prime q →
    q = 9 * m + 1 → 0 < m →
      d.primeValuation q (d.doublePoleDeterminant (2 * m)) =
        -(36 * (m : ℤ))

structure Proofs (d : Data) : Type where
  theorem5_1 : Goal_5_1 d
  theorem5_2 : Goal_5_2 d
  proposition5_3 : Goal_5_3 d
  theorem5_4 : Goal_5_4
  theorem5_6 : Goal_5_6 d
  theorem5_7 : Goal_5_7 d

end PaperBlueprint.Chapter5
