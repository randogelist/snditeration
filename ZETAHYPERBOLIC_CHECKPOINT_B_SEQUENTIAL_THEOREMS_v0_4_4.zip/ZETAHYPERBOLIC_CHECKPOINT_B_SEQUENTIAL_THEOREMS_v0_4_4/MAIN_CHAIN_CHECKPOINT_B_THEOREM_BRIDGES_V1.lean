import PaperCheckpointB.DirectTheoremReceipts

/-!
# FROZEN CHECKPOINT B + THREE CHAPTER-SPECIFIC MATHEMATICAL PROOFS

Previous modules 1–147 are frozen and reused from the user compiler.
This new endpoint must be run by the user's Lean 4.33 compiler.

Important scope:
 * Paragraph index: 52 pages, 241 source units, 46 statement anchors;
 * Chapter 2: old certified algebra proof bundle;
 * Chapter 3: exact real-rootedness/degree and corrected minor statement;
 * Chapter 5: even-pole cancellation for SIMPLE poles only;
 * Sections 3–6 not fully proved; full 45-obligation bundle uninhabited.
-/

namespace PaperCheckpointB

theorem direct_chapter3_root_goal : PaperBlueprint.Chapter3.Goal_3_1 :=
  directTheoremReceipts.original3_1

theorem direct_chapter3_corrected_minor_goal : PaperBlueprint.Chapter3.Goal_3_4 :=
  directTheoremReceipts.corrected3_4

theorem direct_chapter5_simple_pole_goal : PaperBlueprint.Chapter5.Goal_5_4 :=
  directTheoremReceipts.original5_4_simplePoles

theorem checkpoint_B_remains_partial :
    receipt.maturity = Maturity.mathematicalPartial := checkpoint_B_status

end PaperCheckpointB

#print axioms PaperCheckpointB.direct_chapter3_root_goal
#print axioms PaperCheckpointB.direct_chapter3_corrected_minor_goal
#print axioms PaperCheckpointB.direct_chapter5_simple_pole_goal
#print axioms PaperCheckpointB.checkpoint_B_remains_partial
