# Zetahyperbolic — general odd-weight theorem and irrationality bridge

The general spectral theorem is now proved in Lean with **parameter
admissibility as its only input**. The actual simple-pole integral identity,
positive moment realization, and Gram positivity are proved internally.

```lean
ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
    (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p
```

Admissibility means `k,m,N >= 1` and `N < K`; the weight is `s = 2*k+1` and
matrix dimension is `h = K-N`. There is no remaining analytic premise for
this general endpoint.

The package also proves the direct conditional irrationality implication
for the actual primitive integer determinant polynomials:

```lean
ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational
    (h : ∀ k : Nat, 0 < k → OddWeightDecayHypothesis k) :
    ∀ k : Nat, 0 < k →
      Irrational (riemannZeta ((2*k+1 : Nat) : Complex)).re
```

Here the explicit remaining hypothesis supplies an unbounded admissible
fixed-weight family whose primitive normalized values eventually satisfy
`Q(zeta(2*k+1)) <= exp(-c*K^2)` for some `c > 0`. Integrality, degree at most
`K`, positivity, and identification with the actual Riemann zeta function
are proved internally. This implication does not assume a spectral growth
estimate. The decay hypothesis itself is **not proved**.

`IRRATIONALITY_FRONTIER.md` gives the exact reduction and the distinction
between direct irrationality and an effective irrationality measure.

The new checked identity sharpens the arithmetic target:

```text
P_p(zeta(2*k+1)) = Lambda_p * R_p
Lambda_p = |leadingCoeff P_p| >= 1
R_p = det G_p(zeta(2*k+1)) / |det M_p| > 0
```

`Theorem_4_1_Leading_Coefficient_Gap.lean` proves that eventual bounds
`Lambda_p <= exp(A*K^2)` and `R_p <= exp(-B*K^2)` with `A < B` imply
the required decay and irrationality. The bounds remain hypotheses.
`Theorem_2_5_Weight_Change.lean` proves the exact derivative-determinant
factor `product a^(2*d)` when the weight index increases by d.

`docs/ArithmeticFrontier.md` develops the resulting classical arithmetic
analysis. In particular, a fixed m and a fixed limiting ratio
`0 < N/K < 1/3` cannot supply primitive decay at all sufficiently high
fixed odd weights. A separate proof excludes the scalar family
`m=1, N=K-1` for every fixed odd weight at least five. These obstructions
and the local prime calculations are independently reviewed on-paper
proofs, not Lean theorems. They leave weight-dependent families open.

## Conclusions

Writing `xi = zeta(s)`, the proved chain constructs real nonzero spectral
factors `beta_i` and gives

```text
degree Delta = h
det derivativeMatrix != 0
Delta(x) = det G(xi) * product_i (1 + (x-xi)*beta_i)
all complex roots are real and have the form xi - 1/beta_i
|z-xi| < 1 / max_i |beta_i|  =>  Delta(z) != 0
```

The radius is positive and is attained by a root. Thus it is the exact
distance from the center to the nearest root. The roots avoid `xi`;
pairwise distinctness is not asserted. The center is identified with the
real part of Mathlib's `riemannZeta` at the same odd integer.

The original uploaded pencil is covered directly:

```lean
Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL
    (p : HankelParams) (k : Nat) (hk : 1 <= k) :
    ManuscriptChain.General.GeneralStatement
      (Zetahyperbolic.ManuscriptCompatibility.toParameters p k)
```

`HankelParams` already contains the required dimension conditions.
`Zetahyperbolic.ORIGINAL_EXACT_ZERO_FREE_DISK` states the real-root,
positive-radius, and boundary-attainment conclusions on the actual
original `Delta_poly`.

## Analytic proof and assembly

`MAIN_CHAIN_ASSEMBLED.lean` connects the complete analytic proof to the
existing algebraic and spectral chain. `Zetahyperbolic.lean` exports it by
default. The former conditional interfaces remain available as reusable
lemmas, but their analytic inputs are supplied internally by the assembled
endpoint.

The final analytic theorem is

```lean
ManuscriptChain.Hyperbolic.poleIntegralIdentity
    (k : Nat) (hk : 0 < k) : PoleIntegralIdentity k
```

Its proof uses Mathlib's cotangent partial-fraction expansion, justified
changes of variables and integral/series exchanges, a geometric series,
and Gamma integrals. It does not assume Hermite's formula or introduce an
extra mathematical axiom. The density, all monomial moments, the atomless
nonzero measure, and all required weighted integrability are also proved.

`ANALYTIC_PROOF.md` explains the formalized route.
`ANALYTIC_PROOF_DETAILS.txt` retains the independent classical Hermite
argument for comparison; that alternative derivation is not needed by Lean.

## Preserved linear-family and measure interfaces


For a fixed odd weight `s = 2*k+1`, `OddWeightFamily` describes an admissible
sequence of the actual manuscript parameters. Its integer polynomial `F.Q n`
is the primitive normalization of `Delta_n`; it is constructed internally,
has degree `h_n`, and satisfies `Q_n(zeta(s)) != 0` on the admissible tail.

`MAIN_CHAIN_ARITHMETIC.lean`, exported by the default import, proves:

```lean
ManuscriptChain.GENERAL_IRRATIONALITY
    (F : GeneralArithmetic.OddWeightFamily)
    (decay : GeneralArithmetic.DecayHypothesis F) :
    Irrational F.center
```

`DecayHypothesis F` bundles the following conditions for some natural `D` and
real `c > 0`, for every `n >= F.onset`:

```text
h_n <= D*(n+1)
|Q_n(zeta(2*k+1))| <= exp(-c*(n+1)^2)
```

This implication needs no quantitative spectral estimate. At a rational
`a/b`, a nonzero integer-polynomial evaluation has absolute value at least
`b^(-degree)`. Quadratic exponential decay contradicts this lower bound when
the degree grows at most linearly. Lean constructs the required index.
`GENERAL_RIEMANN_ZETA_IRRATIONALITY` states the same conclusion for the real
part of Mathlib's named `riemannZeta` value.

For the concrete family `N=a*(n+1)`, `K=b*(n+1)`, with fixed positive `k,m,a`
and `a < b`, admissibility and the exact degree `(b-a)*(n+1)` are proved.
`ManuscriptChain.LINEAR_FAMILY_IRRATIONALITY` therefore leaves only
`EventualQuadraticDecay`: for some `n0` and `c > 0`, the displayed normalized
evaluation bound holds for every `n >= n0`. This estimate remains unproved.
Bundling or naming it does not establish it; decay of the raw rational
determinant alone would not suffice without controlling its normalization.

The stronger `GeneralArithmetic.measure_and_irrational` endpoint still takes
`EvaluationUpper` and `IndexBudget`. The latter connects the denominator,
polynomial degree, decay budget, and the constructed spectral comparison radius.
Gram positivity and local spectral comparison are supplied internally.

Both arithmetic interfaces use exactly the same canonical primitive polynomial;
`primitivePolynomial_eq_generalArithmetic` proves their equality.

## Scope and remaining work

The general odd-integer-weight spectral theorem is unconditional for
admissible parameters. Irrationality requires the remaining normalized decay
estimate. Positive primitive normalization is proved minimal among all
positive rational rescalings yielding integer polynomials, so an explicit
integer normalization can supply a decay certificate for the primitive one.

For zeta(5), `ZETA5_DIRECT_IRRATIONALITY.lean` now proves irrationality from
either the single normalized decay bound or the two separate multiplier and
archimedean bounds. The old quantitative spectral input is unnecessary for
this direct implication. It remains an input to the separate effective
irrationality-measure endpoint. None of these outstanding estimates is
asserted unconditionally.

The separate note `docs/FixedWeightDeterminantComparison.md` derives
`log(det G_k / det G_2) = O_(k,m)(K log K)` for fixed k,m and common
geometry. It preserves the leading quadratic archimedean rate under a
common scalar normalization. This is an independently reviewed classical
proof, not yet a Lean theorem; arithmetic multiplier bounds remain open.

`APPLICATIONS.lean` keeps the specialized endpoints and audited extensions
separate. `ExternalAssumptions.md` records their exact outstanding inputs.
The continuous-real-weight extension in Proposition 3.2 is not certified;
its printed normalization differs from the odd-weight formula. Simple roots,
all extensions in the paper, and odd-zeta irrationality are not asserted.

The original admitted blueprint and external irrationality assertion remain
as text under `provenance/`, outside the active import graph. Retaining their
text does not prove those original assertions. The manuscript TeX is retained
as a source document and has not been editorially rewritten.

## Build and validation

- Lean: `leanprover/lean4:v4.33.0`
- Mathlib: `db584cd6d46c92f209a44c0f1c829460d327499d`
- Exact transitive pins: `lake-manifest.json`
- Complete proof-module list: `MODULES_CHECKED.txt`

With the pinned dependencies and compiled caches available, run `lake build`
from the extracted project directory. A fresh environment requires dependency
setup; without existing caches this is not an offline build.

`VALIDATION.md` records the compiler checks, standard-axiom audit, and exact
current source hashes. Current combined logs are under
`validation/arithmetic_frontier/`; `validation/combined/` retains the
preceding merged checks and `validation/assembled/` the complete analytic
build.

## Source-only distribution

This unencrypted ZIP contains UTF-8 Lean sources, dependency pins, manuscript
text, documentation, and validation logs. It contains no runner scripts,
executable binaries, compiled caches, symlinks, or nested archives. The removed
Windows/Linux runners and Python helper have not been hidden under other names.
`SHA256SUMS.txt` covers every distributed file except itself.
