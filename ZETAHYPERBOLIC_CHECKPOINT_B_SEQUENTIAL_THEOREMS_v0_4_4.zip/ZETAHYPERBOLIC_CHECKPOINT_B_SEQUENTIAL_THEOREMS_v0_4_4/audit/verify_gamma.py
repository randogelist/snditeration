from fractions import Fraction

def gamma(K,N,m,k,a):
    out=Fraction(a**(2*k),1)
    for b in range(1,N+1):
        out *= (b*b-a*a)**(2*m-1)
    for b in range(N+1,K+1):
        if b!=a: out /= (b*b-a*a)
    return out

for K,N,m,k in [(6,1,1,2),(30,3,3,2)]:
    values=[gamma(K,N,m,k,a) for a in range(N+1,K+1)]
    assert sum(values,Fraction(0)) == 0
    print(f'K={K} N={N} m={m} k={k}: M00=0, terms={len(values)}')
    if K==6: print(values)
