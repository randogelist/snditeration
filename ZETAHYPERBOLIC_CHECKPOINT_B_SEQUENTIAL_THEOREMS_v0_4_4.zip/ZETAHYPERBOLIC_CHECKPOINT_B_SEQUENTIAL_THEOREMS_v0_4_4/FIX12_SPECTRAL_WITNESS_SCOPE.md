# FIX12 — Theorem 3.4 singular-slope real-rootedness

User compiler checkpoint: modules 1–70 PASS; module 71 failed because the namespace
variable `w : WeakSpectralFactorization p` was omitted from two declarations whose
statement did not syntactically mention `w`, although their proof bodies used it.

This package adds `include w` to the `WeakSpectralFactorization` namespace after
`variable ... (w : WeakSpectralFactorization p)`. It follows the established convention
already used in `Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk.lean`,
namespace `RootFactorization`. This forces `w` into the proof context for
`every_complex_zero_real` and `center_ne_zero` and makes the downstream instance
method notation type-directed. No witness axiom is introduced: `w` is explicitly
constructed using the proof of positive-definite spectral factorization in this
module. All 70 verified sources and the remaining future modules are unchanged.

The Lean 4.33 compiler on the user's Windows host is the only authority;
this package has NOT been Lean-compiled here. It retains the single native
Windows `run.cmd` and the existing persistent frozen receipt cache.
