import PaperOrder.Theorem_3_8_Jacobi_Two_By_Two_Affine

/-!
# Strengthened core-algebra chain — post-59 frozen checkpoint

The previous 66 modules are unchanged.  New proof objects genuinely
advance general n-atom Hankel determinant positivity, cubic Newton
inequalities, and a 2x2 Jacobi derivative identity.  The all-order
strict total positivity and full interlacing paper statements remain
explicitly open, not hidden behind this theorem.
-/

namespace PaperOrder.CoreAlgebra

open ManuscriptChain.PoleDiagonalization
open scoped BigOperators

/-- The frozen actual-pole core theorem together with universal
finite-atomic moment positivity and cubic Newton log-concavity. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_ADVANCED
    (p : ManuscriptChain.Real.Parameters) :
    (((ManuscriptChain.Real.delta p).natDegree = p.h) ∧
      (0 < (rationalDerivativeMatrix p).det *
        (∏ a : Fin p.h, poleWeight p a)) ∧
      (∀ a : Fin p.h,
         (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
           ((poleVandermonde p)⁻¹).transpose) a a) ≠ 0)) ∧
    (∀ (n : ℕ) (x w : Fin n → ℝ), Function.Injective x →
      (∀ k : Fin n, 0 < w k) → 0 < (atomicMomentMatrix x w).det) ∧
    (∀ a b c : ℝ,
      3*cubicSym2 a b c ≤ (cubicSym1 a b c)^2 ∧
      3*cubicSym1 a b c*cubicSym3 a b c ≤ (cubicSym2 a b c)^2) ∧
    (∀ a b c d α β γ δ t : ℚ,
      (Polynomial.derivative (affineTwoDet a b c d α β γ δ)).eval t =
        α * (d + δ*t) + δ * (a + α*t) -
        β * (c + γ*t) - γ * (b + β*t)) := by
  refine ⟨MAIN_CHAIN_CORE_ALGEBRA_95_FRONTIER p, ?_, ?_, ?_⟩
  · intro n x w hx hw
    exact atomicMomentMatrix_det_pos x w hx hw
  · intro a b c
    exact ⟨cubic_newton_first a b c, cubic_newton_second a b c⟩
  · intro a b c d α β γ δ t
    exact affineTwoDet_jacobi_eval a b c d α β γ δ t

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_ADVANCED
