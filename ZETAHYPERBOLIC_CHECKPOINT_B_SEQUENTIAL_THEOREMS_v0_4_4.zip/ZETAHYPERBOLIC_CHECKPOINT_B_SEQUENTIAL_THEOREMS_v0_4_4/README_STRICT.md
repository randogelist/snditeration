# STRICT AUDIT, not a false full-paper completion

The task was to import candidate sources and formalize every theorem of the attached 52-page manuscript without `sorry`, additional axioms, or unproved hypotheses. **The exact manuscript cannot satisfy this request as written**: printed Theorem 3.4 is false for an admissible instance; printed Corollary 3.5 has normalization errors; Theorem 6.10 has a reversed logical deduction. The necessary repairs are stated in `STRICT_SCOPE.md` and named in the ledger. No axiom or placeholder is used to hide the problem.

## Use

On Windows with Lean 4.33.0 and a **preinstalled pinned Mathlib** dependency (`db584cd6d46c92f209a44c0f1c829460d327499d`): run `STRICT_RUN.cmd`. It builds the preserved base, compiles two small new finite-obstruction/pole-pair modules, and elaborates `MAIN_CHAIN_STRICT.lean`, which prints the theorem's axioms. Linux: `./STRICT_RUN.sh`.

The previous source graph's validation records (see `VALIDATION.md`) show 59 modules audited and no custom axioms in the active graph; they are **historical records, not a compilation run in this session**. The new additions are not claimed checked until your compiler logs confirm them.

### Unconditional theorem actually exposed

```
PaperAudit.MAIN_CHAIN_STRICT (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p
```

This states exact degree `K-N`, determinant slope nonsingularity, identification with the genuine odd Riemann zeta value, real roots disjoint from it, and a positive zero-free disk. The exact radius has a boundary root. `hp` is only the structural assumptions of the paper (`k,m,N>0, N<K`).

### What is not claimed

- The entire printed 52-page paper.
- The paper's proposed exponent-25687 irrationality measure at zeta(5).
- Any new unconditional irrationality statement for zeta(7), all odd zeta values, or mixed zeta combinations.
- The full two-variable Krein space theorem or all q-adic extensions.

For exact source matches, see `SOURCE_CROSSWALK.md`; for every named statement see `PAPER_THEOREM_LEDGER.md`.
