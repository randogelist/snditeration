# An obstruction for the scalar family at every odd weight at least five

**Status.** This is a classical mathematical proof, not a new Lean theorem. It uses the actual rational pencil and the concrete integral representation proved in the accompanying sources. Its conclusion rules out one particular choice of parameters as a source of small primitive integer values. It does not rule out other parameter families or prove any irrationality statement.

Fix an integer $k\geq2$, and put $s=2k+1$. For each integer $K\geq2$, take

\[
m=1,\qquad N=K-1,\qquad h=K-N=1.
\]

Let $\Delta_K(X)$ be the actual one-dimensional determinant polynomial in the package, and let $Q_K(X)$ be its primitive integer normalization obtained by a **positive** rational rescaling. Then

\[
\boxed{\displaystyle
\liminf_{K\to\infty}\frac{\log Q_K(\zeta(s))}{K}
\ \geq\ \frac{s}{2}-\log4\ >0.}
\tag{1}
\]

In particular, these primitive values tend to infinity exponentially. They cannot satisfy the positive decay estimate required by the irrationality criterion. This is an obstruction for the actual primitive normalization, not merely a failure to find a sufficiently good denominator bound.

## 1. The exact rational polynomial and its primitive normalization

Use the density notation

\[
w_k(y)=\frac{2(2\pi)^{2k}}{(2k)!}\,y^{2k+1}
       \sum_{n=1}^{\infty}n^{2k}e^{-2\pi n y},\qquad y>0,
\]

so that $k$ indexes the odd weight $2k+1$. Define

\[
D_j(T)=\prod_{a=1}^{j}(T+a^2),\qquad
r_K=D_{K-1}(-K^2)
    =(-1)^{K-1}\frac{(2K-1)!}{K},
\tag{2}
\]

and

\[
q_K(T)=\frac{D_{K-1}(T)-r_K}{T+K^2}\in\mathbb Z[T].
\tag{3}
\]

The last assertion follows by monic polynomial division. The factorial identity in (2) follows from

\[
\prod_{a=1}^{K-1}(a^2-K^2)
=(-1)^{K-1}(K-1)!\frac{(2K-1)!}{K!}.
\]

Write $q_K(T)=\sum_j q_{K,j}T^j$. The checked monomial functional is

\[
\mu_{k,j}
=(-1)^j B_{2j+2}
 \frac{(2j+2k+1)!}{(2k)!(2j+2)!},
\qquad
M_K=\sum_j q_{K,j}\mu_{k,j},
\tag{4}
\]

where $B_{2j+2}$ is the Bernoulli number in the package's convention. Only positive even indices occur, so the convention for $B_1$ is irrelevant. Put

\[
H_K^{(s)}=\sum_{a=1}^{K}\frac1{a^s}.
\]

The definitions of `numerator`, `quotient`, `residue`, `poleConstant`, and `pencil` in `Definition_2_1_Order_s_Rational_Moment_Functional.lean` give exactly

\[
\Delta_K(X)=A_K+B_KX,
\]

\[
\begin{aligned}
B_K&=r_KK^{2k}\ne0,\\
A_K&=M_K+r_K\left(-K^{2k}H_K^{(s)}
                 +\frac1{2K}-\frac1{2k}\right).
\end{aligned}
\tag{5}
\]

Thus its rational root is

\[
\alpha_K=-\frac{A_K}{B_K}
=H_K^{(s)}-\frac1{2K^s}
 +\frac1{(s-1)K^{s-1}}-\frac{M_K}{B_K}.
\tag{6}
\]

Write $\alpha_K=u_K/v_K$ in lowest terms, with $u_K\in\mathbb Z$, $v_K\in\mathbb Z_{>0}$, and $\gcd(u_K,v_K)=1$. The primitive integer polynomial with the required positive orientation is

\[
Q_K(X)=\frac{v_K}{|B_K|}\Delta_K(X)
      =\operatorname{sgn}(B_K)(v_KX-u_K).
\tag{7}
\]

Its coefficients are integers with gcd one, and the rescaling factor is positive. This identifies the primitive normalization uniquely. The proved integral identity gives

\[
\Delta_K(\zeta(s))
=I_K:=\int_0^\infty
 \frac{D_{K-1}(y^2)}{y^2+K^2}w_k(y)\,dy>0.
\tag{8}
\]

Consequently

\[
Q_K(\zeta(s))=v_K|\zeta(s)-\alpha_K|
            =v_K\frac{I_K}{|B_K|}>0.
\tag{9}
\]

This equation is the link between the analytic approximation error and the arithmetic denominator. A small rational approximation error alone is insufficient.

## 2. The precise analytic approximation error

Define the finite products and the value of the rational kernel at zero by

\[
P_j(y)=\prod_{a=1}^{j}\left(1+\frac{y^2}{a^2}\right),
\qquad
R_K(0)=\frac{((K-1)!)^2}{K^2}.
\]

Then the following identity holds for every $y>0$:

\[
\frac{D_{K-1}(y^2)}{(y^2+K^2)R_K(0)}
=\frac{P_{K-1}(y)}{1+y^2/K^2}
=\frac{P_{K-1}(y)^2}{P_K(y)}.
\tag{10}
\]

Euler's product for the hyperbolic sine gives

\[
P_\infty(y):=\prod_{a=1}^{\infty}\left(1+\frac{y^2}{a^2}\right)
=\frac{\sinh(\pi y)}{\pi y}.
\tag{11}
\]

For each fixed $y$, the expression in (10) tends to $P_\infty(y)$. It is positive and bounded above by $P_\infty(y)$ for every $K$. The function $w_k(y)P_\infty(y)$ is integrable: near zero, $w_k(y)\to1/\pi$ and $P_\infty(y)\to1$; at infinity,

\[
w_k(y)P_\infty(y)
\sim\frac{(2\pi)^{2k}}{\pi(2k)!}\,y^{2k}e^{-\pi y}.
\]

The endpoint facts for $w_k$ follow directly from the finite geometric-series identity proved in Section 2 of `FixedWeightDeterminantComparison.md`. Thus dominated convergence applies to (8), and yields

\[
\frac{I_K}{R_K(0)}\longrightarrow
C_k:=\int_0^\infty w_k(y)\frac{\sinh(\pi y)}{\pi y}\,dy,
\qquad 0<C_k<\infty.
\tag{12}
\]

There is an exact factorial cancellation:

\[
\frac{R_K(0)}{|B_K|}
=\frac{((K-1)!)^2}{K^{2k+1}(2K-1)!}
=\frac{2}{K^{2k+2}\binom{2K}{K}}.
\tag{13}
\]

Combining (12) and (13) proves

\[
\boxed{\displaystyle
|\zeta(s)-\alpha_K|
\sim\frac{2C_k}{K^{s+1}\binom{2K}{K}}.}
\tag{14}
\]

In particular, Stirling's formula gives the exact exponential rate

\[
\log|\zeta(s)-\alpha_K|
=-K\log4-\left(s+\frac12\right)\log K
 +\log(2C_k\sqrt\pi)+o(1).
\tag{15}
\]

For completeness, the limiting constant can also be evaluated in even zeta values:

\[
C_k=\frac{2}{\pi^2}\sum_{\ell=1}^{k}
 \binom{2k}{2\ell-1}(1-2^{-2\ell})\zeta(2\ell).
\tag{16}
\]

To verify this, expand the positive density series in (12) and integrate the difference of exponentials furnished by $\sinh(\pi y)$. This gives

\[
C_k=\frac{2^{2k}}{\pi^2}\sum_{n=1}^{\infty}n^{2k}
 \left((2n-1)^{-s}-(2n+1)^{-s}\right).
\]

Shift the second sum only in finite partial sums. The unmatched boundary term has absolute value $M^{2k}/(2M+1)^s$, which tends to zero. This avoids separating the two individually divergent infinite sums. The resulting numerator difference is

\[
\left(\frac{a+1}{2}\right)^{2k}
-\left(\frac{a-1}{2}\right)^{2k}
=2^{1-2k}\sum_{\ell=1}^{k}\binom{2k}{2\ell-1}a^{2k-2\ell+1}.
\]

The terms before integration are nonnegative, and the resulting sums converge, so these operations are justified by Tonelli and finite algebra. For example, $C_2=1+\pi^2/12$.

## 3. Exact prime denominators of the rational root

Let $p$ be a prime such that

\[
\max(2k,K/2)<p<K.
\tag{17}
\]

In particular $p\geq5$, $p<K<2p$, and $p\nmid K$. Also $p^2>4p>2K$, so Legendre's factorial formula applied to (2) gives

\[
v_p(r_K)=\left\lfloor\frac{2K-1}{p}\right\rfloor\in\{2,3\},
\qquad
v_p(B_K)=v_p(r_K).
\tag{18}
\]

Here $v_p(p)=1$. Rewrite the factorial quotient in (4) as

\[
\mu_{k,j}
=\frac{(-1)^jB_{2j+2}}{(2k)!}
  \prod_{a=1}^{2k-1}(2j+2+a).
\tag{19}
\]

The von Staudt-Clausen theorem states that the denominator of a positive even-index Bernoulli number is squarefree. Therefore $v_p(B_{2j+2})\geq-1$. Since $p>2k$, the denominator $(2k)!$ in (19) is a $p$-adic unit, and the product is integral. Thus

\[
v_p(\mu_{k,j})\geq-1,
\qquad
v_p(M_K)\geq-1,
\qquad
v_p(M_K/B_K)\geq-4.
\tag{20}
\]

The middle inequality uses $q_{K,j}\in\mathbb Z$; it remains valid if the sum is zero. Because $p<K<2p$, exactly one denominator in $H_K^{(s)}$ is divisible by $p$, namely the denominator of $p^{-s}$. Hence

\[
H_K^{(s)}=p^{-s}+u,\qquad u\in\mathbb Z_p.
\]

The other two explicit rational terms in (6) are $p$-integral, since $p$ divides none of $2$, $K$, and $s-1=2k$. As $s\geq5$, the term $p^{-s}$ has valuation strictly smaller than every other term in (6). The ultrametric valuation rule therefore proves the exact statement

\[
\boxed{v_p(\alpha_K)=-s,\qquad v_p(v_K)=s.}
\tag{21}
\]

There is no assumption about a $p$-adic zeta value here. Every quantity in this calculation is rational; $\mathbb Z_p$ only records the integrality of rational remainders.

Taking the product over the distinct primes in (17) gives the explicit finite lower bound

\[
v_K\geq\prod_{\max(2k,K/2)<p<K}p^s.
\tag{22}
\]

Let $\vartheta(x)=\sum_{p\leq x}\log p$. The prime number theorem in the form $\vartheta(x)=x+o(x)$ implies

\[
\sum_{\max(2k,K/2)<p<K}\log p=\frac K2+o(K).
\]

The fixed cutoff $2k$ eventually has no effect, and excluding a possible endpoint prime $K$ changes the sum by at most $\log K$. Therefore

\[
\liminf_{K\to\infty}\frac{\log v_K}{K}\geq\frac s2.
\tag{23}
\]

## 4. The obstruction and its scope

Equations (9), (15), and (23) give (1). Since $s\geq5$,

\[
\frac s2-\log4\geq\frac52-\log4>0.
\]

Thus, for every fixed real $c$ with $0<c<s/2-\log4$, eventually

\[
Q_K(\zeta(s))\geq e^{cK}.
\tag{24}
\]

Every other positive rational rescaling of $\Delta_K$ having integer coefficients is a positive integer multiple of $Q_K$. Consequently no such rescaling can restore positive decay for this parameter family. This last minimality property is also proved abstractly in `Theorem_2_4_Primitive_Normalization_Minimality.lean`.

The argument requires $k\geq2$: when $k=1$, the harmonic valuation is $-3$, and the strict dominance used in (20)-(21) is not available. No conclusion for that case is asserted here. Nor does this argument exclude $h>1$, $m>1$, or a different relation between $N$ and $K$.

## 5. A sharper fixed-dimension analytic comparison

The dominated-convergence argument also gives a useful positive result. Fix an integer $h\geq1$, keep $m=1$, and put $N=K-h$. Let $G_{k,h}$ denote the full $h\times h$ Gram matrix. Set

\[
\rho_{K,h}=\frac{(N!)^4}{(K!)^2}.
\]

The rational kernel divided by its value at zero satisfies

\[
\frac{D_N(y^2)^2}{D_K(y^2)\rho_{K,h}}
=\frac{P_N(y)^2}{P_K(y)}
\longrightarrow P_\infty(y),
\qquad
0<\frac{P_N(y)^2}{P_K(y)}\leq P_\infty(y).
\]

All polynomial multiples of $w_kP_\infty$ are integrable. Entrywise dominated convergence gives

\[
\rho_{K,h}^{-1}G_{k,h}\longrightarrow
H_{k,h}:=
\left[\int_0^\infty y^{2(i+j)}w_k(y)P_\infty(y)\,dy\right]_{0\leq i,j<h}.
\tag{25}
\]

The limiting density is strictly positive, so $H_{k,h}$ is positive definite and has positive determinant. Continuity of the determinant therefore proves

\[
\frac{\det G_{k,h}}{\det G_{2,h}}
\longrightarrow\frac{\det H_{k,h}}{\det H_{2,h}}\in(0,\infty).
\tag{26}
\]

For fixed $h$ and $m=1$, the logarithmic fixed-weight comparison thus improves to $O_{k,h}(1)$. This sharpening concerns the analytic determinants. The scalar obstruction above shows why it does not by itself supply small primitive integer values.

The classical ingredients used here are Euler's hyperbolic-sine product, dominated convergence, Stirling's formula, von Staudt-Clausen, and the prime number theorem. Their use does not make this new argument part of the Lean-checked dependency graph. The accompanying mathlib snapshot does contain `Bernoulli.vonStaudt_clausen`; the new denominator argument and asymptotic combination in this document have not been formalized.
