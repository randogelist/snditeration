# Fixed-weight determinant comparison

**Status:** This document gives a classical mathematical proof. The new determinant comparison and exponential-moment estimate below have **not** been formalized in Lean. They use the concrete density and Gram representation already identified in the checked package. They do not prove an arithmetic normalization bound or an irrationality result.

## 1. Statement and connection to the checked definitions

Put $b=2\pi$. For an integer $k\geq1$, write

\[
w_k(y)=\frac{2b^{2k}}{(2k)!}y^{2k+1}
       \sum_{n=1}^{\infty}n^{2k}e^{-bny},\qquad y>0.
\]

Here the subscript $k$ denotes the index of the odd weight $2k+1$: in the PDF's notation, this is $w_{2k+1}$. Thus $w_2$ is the weight-five density. This convention avoids using the odd weight itself as an index throughout the proof.

Fix integers $m\geq1$ and $1\leq N<K$, and put

\[
D_j(t)=\prod_{a=1}^{j}(t+a^2),\qquad
R_{N,K,m}(y)=\frac{D_N(y^2)^{2m}}{D_K(y^2)}.
\]

For $1\leq r\leq K$, define the $r\times r$ real moment matrix

\[
G_{k,r}=
\left[\int_0^\infty y^{2(i+j)}R_{N,K,m}(y)w_k(y)\,dy\right]_{0\leq i,j<r}.
\tag{1}
\]

These definitions agree with the following package objects:

- `ManuscriptChain.Hyperbolic.density` in `Theorem_3_1_Hyperbolic_Weight.lean` is $w_k$. Its sum starts at a natural index $n=0$, with the summand using $n+1$.
- `ManuscriptChain.ConcreteMoment.weightedDensity` in `Theorem_3_1_Concrete_Moment_Realization.lean` is $R_{N,K,m}w_k$. The measure there is pushed forward by $y\mapsto y^2$ to obtain the moment measure.
- `ManuscriptChain.Real.gram` and `ManuscriptChain.Real.delta` in `Definition_2_1_Order_s_Rational_Moment_Functional.lean` define the algebraic pencil and its determinant.
- `ManuscriptChain.Hyperbolic.gram_eq_weighted_integral` in `Theorem_3_1_Rational_Integral_Bridge.lean`, together with the proved `ManuscriptChain.Hyperbolic.poleIntegralIdentity` in `Theorem_3_1_Pole_Integral_Identity.lean`, identifies (1), when $r=h=K-N$, with that algebraic Gram matrix at $\zeta(2k+1)$. For $r\leq h$, (1) is its leading principal submatrix.

**Theorem.** For each fixed pair of integers $k,m\geq1$, there is a constant $C_{k,m}<\infty$, independent of $N,K,r$, such that

\[
\left|\log\frac{\det G_{k,r}}{\det G_{2,r}}\right|
\leq C_{k,m}K\log(K+1)
\qquad(1\leq N<K,\ 1\leq r\leq K).
\tag{2}
\]

In particular, the estimate is uniform for the full dimension $r=K-N$, and for all its leading principal minors. The explicit bounds in Sections 4 and 5 specify constants from which $C_{k,m}$ can be chosen. The theorem holds with $k,m$ fixed; it does not assert uniformity when either grows with $K$.

## 2. A uniform comparison of the densities

We first prove

\[
c_k(1+y^2)^{k-2}w_2(y)
\leq w_k(y)\leq
C_k(1+y^2)^{k-2}w_2(y),\qquad y>0,
\tag{3}
\]

where $0<c_k\leq C_k<\infty$ depend only on $k$. The negative exponent for $k=1$ is included.

Here is a finite identity that proves the required endpoint limits without interchanging a limit with an infinite series. For an integer $d\geq1$ and $0<q<1$, let

\[
T_d(q)=\sum_{n=1}^\infty n^d q^n.
\]

The polynomial identity

\[
n^d=\sum_{j=1}^d {d\brace j}\,j!\binom nj
\]

uses the nonnegative Stirling numbers of the second kind. It follows inductively from their recurrence, or from counting maps from a $d$-element set by the size of their image. Since

\[
\sum_{n=0}^\infty\binom nj q^n=
\frac{q^j}{(1-q)^{j+1}},
\]

obtained by differentiating the geometric series $j$ times inside its radius of convergence, we get the finite formula

\[
T_d(q)=\sum_{j=1}^d {d\brace j}\,
       \frac{j!q^j}{(1-q)^{j+1}}.
\tag{4}
\]

For $q=e^{-x}$ and $x\downarrow0$, one has $(1-e^{-x})/x\to1$. In $x^{d+1}T_d(e^{-x})$, the term $j=d$ in (4) tends to $d!$, while every term $j<d$ tends to zero because it has an additional factor $x^{d-j}$. Therefore

\[
\lim_{x\downarrow0}x^{d+1}T_d(e^{-x})=d!.
\tag{5}
\]

For $q\downarrow0$, (4) and ${d\brace1}=1$ give $T_d(q)/q\to1$. Taking $d=2k$ proves

\[
\lim_{y\downarrow0}w_k(y)=\frac2b=\frac1\pi,
\qquad
w_k(y)\sim\frac{2b^{2k}}{(2k)!}y^{2k+1}e^{-by}
\quad(y\to\infty).
\tag{6}
\]

In particular, all the densities have the same finite positive limit at zero. Formula (4) also proves their continuity and positivity on $(0,\infty)$. Define

\[
f_k(y)=\frac{w_k(y)}{(1+y^2)^{k-2}w_2(y)}.
\]

Equations (6) give

\[
\lim_{y\downarrow0}f_k(y)=1,
\qquad
\lim_{y\to\infty}f_k(y)=
a_k:=\frac{24b^{2k-4}}{(2k)!}>0.
\tag{7}
\]

For precise constants, extend the function

\[
F_k(u)=f_k\!\left(\frac{u}{1-u}\right),\qquad0<u<1,
\]

to $[0,1]$ by $F_k(0)=1$, $F_k(1)=a_k$, and set

\[
c_k=\min_{0\leq u\leq1}F_k(u),\qquad
C_k=\max_{0\leq u\leq1}F_k(u).
\tag{8}
\]

These are well-defined constants depending only on $k$. Positivity and continuity on the compact interval show $0<c_k\leq C_k<\infty$, proving (3). For $k=2$, both constants equal one.

## 3. The determinant probability measure and its exponential moment

All moments in (1) are finite. At zero, $R_{N,K,m}$ has a finite positive limit and (6) applies. At infinity, $R_{N,K,m}$ has at most polynomial growth, while $w_k$ is a polynomial times an exponentially decreasing function by (6). Also, for any nonzero real polynomial $p$ of degree less than $r$,

\[
\int_0^\infty |p(y^2)|^2R_{N,K,m}(y)w_k(y)\,dy>0.
\]

Indeed, the density is positive and a nonzero polynomial has only finitely many roots. Hence $G_{k,r}$ is positive definite and its determinant is strictly positive.

Let

\[
V(y)=\prod_{1\leq i<j\leq r}(y_j^2-y_i^2),\qquad
Z=\int_{(0,\infty)^r}V(y)^2
      \prod_{i=1}^r R_{N,K,m}(y_i)w_2(y_i)\,dy.
\]

Expanding the two Vandermonde determinants and using finite sums and the finite moments just proved gives the determinant integral identity

\[
Z=r!\det G_{2,r}.
\tag{9}
\]

This is the usual Andreief identity, but the finite expansion also proves it directly here. The same identity holds with $w_2$ replaced by $w_k$. In particular $0<Z<\infty$. Define a probability measure $\mathbb P$ on $(0,\infty)^r$ by dividing the displayed integrand by $Z$. Then

\[
\frac{\det G_{k,r}}{\det G_{2,r}}
=\mathbb E\prod_{i=1}^r\frac{w_k(y_i)}{w_2(y_i)}.
\tag{10}
\]

Put

\[
S=\sum_{i=1}^r y_i,
\qquad D=2r(r-1)+6r+4mNr=r(2r+4+4mN).
\tag{11}
\]

**Exponential-moment bound.** For $0\leq\theta<b$,

\[
\mathbb E e^{\theta S}\leq(1-\theta/b)^{-D}.
\tag{12}
\]

To prove this, put $c=1-\theta/b\in(0,1]$. Expand each weight-five factor as

\[
w_2(y)=\frac{b^4}{12}y^5\sum_{n\geq1}n^4e^{-bny}.
\]

All summands in the resulting integral are nonnegative, so Tonelli's theorem permits the expansion even before finiteness of the exponential moment is known. For every $n\geq1$,

\[
bn-\theta\geq bcn,
\qquad
e^{\theta y}e^{-bny}\leq e^{-bcny}.
\tag{13}
\]

In this upper-bound integral make the substitution $v_i=cy_i$ for all $i$. The individual factors contribute:

- $V(y)^2=c^{-2r(r-1)}V(v)^2$, since every pair contributes degree four.
- $\prod_i y_i^5=c^{-5r}\prod_i v_i^5$.
- $dy_1\cdots dy_r=c^{-r}dv_1\cdots dv_r$.
- The exponential series becomes exactly the original series at $v_i$.

For the rational kernel, each numerator factor satisfies

\[
v^2/c^2+a^2\leq c^{-2}(v^2+a^2),
\]

and each denominator factor satisfies $v^2/c^2+a^2\geq v^2+a^2$. Thus

\[
R_{N,K,m}(v/c)\leq c^{-4mN}R_{N,K,m}(v).
\tag{14}
\]

Combining these powers gives precisely $c^{-D}Z$. Division by $Z$ proves (12), and also proves the required exponential integrability. In particular, the denominator of the rational kernel contributes no adverse factor to this upper bound.

Since $r,N\leq K$ and $K\geq2$,

\[
0<D\leq(6+4m)K^2.
\tag{15}
\]

Choose, from now on,

\[
\theta_0=\frac{b}{D+1}.
\]

Then $0<\theta_0<b$, and (12) gives

\[
\mathbb E e^{\theta_0S}
\leq\left(1+\frac1D\right)^D\leq e.
\tag{16}
\]

For every integer $L\geq0$, the exponential power series yields

\[
(1+S)^L\leq L!\theta_0^{-L}e^{\theta_0(1+S)},
\]

and consequently

\[
\mathbb E(1+S)^L\leq
e^{1+\theta_0}L!\left(\frac{D+1}{b}\right)^L.
\tag{17}
\]

We will also use the simple bound

\[
\mathbb ES\leq\frac e{\theta_0}
=\frac{e(D+1)}b,
\tag{18}
\]

which follows from $\theta_0S\leq e^{\theta_0S}$ and (16). No differentiation of an integral is needed.

## 4. Comparison for $k\geq2$

Set $d=k-2\geq0$ and $L=2dr$. Equations (3) and (10) give

\[
c_k^r\leq\frac{\det G_{k,r}}{\det G_{2,r}}
\leq C_k^r\mathbb E\prod_{i=1}^r(1+y_i^2)^d.
\]

Since $0\leq y_i\leq S$ and $1+y_i^2\leq(1+S)^2$, (17) proves the explicit estimate

\[
\boxed{\quad
c_k^r\leq\frac{\det G_{k,r}}{\det G_{2,r}}
\leq C_k^r e^{1+\theta_0}L!
       \left(\frac{D+1}{b}\right)^L,
\qquad L=2(k-2)r.
\quad}
\tag{19}
\]

For $k=2$ the ratio is exactly one; (19) is merely a loose upper bound in this case. For fixed $k,m$, we have $L\leq2(k-2)K$, (15), and $L!\leq\max(1,L)^L$. Taking logarithms in (19) therefore gives the upper bound in (2), while the lower bound $r\log c_k$ has magnitude at most $K|\log c_k|$. All constants depend only on $k,m$.

## 5. The lower-weight case $k=1$

Equation (3) has exponent $-1$, so (10) gives

\[
c_1^r\mathbb E\prod_{i=1}^r(1+y_i^2)^{-1}
\leq\frac{\det G_{1,r}}{\det G_{2,r}}\leq C_1^r.
\]

The pointwise inequality $1+y_i^2\leq(1+S)^2$ now implies

\[
\prod_{i=1}^r(1+y_i^2)^{-1}\geq(1+S)^{-2r}.
\]

The function $x\mapsto(1+x)^{-2r}$ is convex on $[0,\infty)$, since its second derivative is $2r(2r+1)(1+x)^{-2r-2}>0$. Because $\mathbb ES<\infty$ by (18), Jensen's inequality applies. That function is also decreasing. Hence

\[
\mathbb E(1+S)^{-2r}\geq(1+\mathbb ES)^{-2r}
\geq\left(1+\frac{e(D+1)}b\right)^{-2r}.
\]

We have proved the explicit two-sided estimate

\[
\boxed{\quad
c_1^r\left(1+\frac{e(D+1)}b\right)^{-2r}
\leq\frac{\det G_{1,r}}{\det G_{2,r}}\leq C_1^r.
\quad}
\tag{20}
\]

Using (15) and $r\leq K$, its logarithm is bounded in absolute value by $O_m(K\log(K+1))$. This proves (2) also for $k=1$, completing the theorem.

## 6. What the comparison says about normalization and decay

Let $K\to\infty$ along any fixed sequence of admissible integers, with fixed $m,k$, and let $N=N_K$, $r=r_K\leq K$ be arbitrary allowed sequences. Let $S_K>0$ be any scalar used **identically at every weight**, and define

\[
F_{K,k}=S_K\det G_{k,r_K}.
\]

Then (2) gives

\[
\log F_{K,k}=\log F_{K,2}+O_{k,m}(K\log(K+1)).
\tag{21}
\]

Consequently the limsup and liminf of $K^{-2}\log F_{K,k}$ agree with those for $k=2$, including when a limit is infinite. In particular, a finite quadratic archimedean growth rate, when established at weight five for this common choice of geometry and scalar, is the same for every fixed odd weight.

For the full dimension $r=h=K-N$, write

\[
\Delta_{K,k}(X)=\det\bigl(\text{the weight-}(2k+1)\text{ algebraic pencil at }X\bigr).
\]

The checked integral representation identifies

\[
\Delta_{K,k}(\zeta(2k+1))=\det G_{k,h}>0.
\]

Suppose separately that positive rational numbers $a_{K,k}$ have been proved to satisfy

\[
Q_{K,k}(X):=a_{K,k}S_K\Delta_{K,k}(X)\in\mathbb Z[X].
\tag{22}
\]

This document does not construct or bound these arithmetic multipliers. If finite real constants $A_k,U$ have independently been established with

\[
\limsup_{K\to\infty}\frac{\log a_{K,k}}{K^2}\leq A_k,
\qquad
\limsup_{K\to\infty}\frac{\log(S_K\det G_{2,h})}{K^2}\leq U,
\]

then (21) gives the sufficient bound

\[
\limsup_{K\to\infty}
\frac{\log Q_{K,k}(\zeta(2k+1))}{K^2}\leq A_k+U.
\tag{23}
\]

Thus a verified strict inequality $A_k+U<0$ would provide positive quadratic decay at that fixed weight: for every $0<\varepsilon<-(A_k+U)$, eventually

\[
0<Q_{K,k}(\zeta(2k+1))\leq e^{-\varepsilon K^2}.
\tag{24}
\]

The new reduction is that $U$ need not be recomputed for each fixed odd weight when the kernel geometry and the scalar $S_K$ are shared. The arithmetic rate $A_k$ remains a separate problem and is not shown to be independent of $k$.

In particular, (21) cannot be applied to primitive integer polynomials by silently using a weight-dependent rational content as though it were a common scalar. The theorem also gives no bound for an individual eigenvalue, the spectral norm of the relative pencil, or the distance of its nearest root. No numerical archimedean or arithmetic constant from the PDF is assumed or verified by this argument.

## 7. An elementary local-denominator diagnostic

The analytic comparison does not assert that the arithmetic multiplier can be retained when the weight is raised. The following exact computation illustrates the distinction at the level of a single pole.

Fix an integer $k\geq1$, put $s=2k+1$, and let $p$ be a prime satisfying $p>\max(2k,2)$ and $K/2<p\leq K$. For a positive integer $a\leq K$, consider the rational polynomial

\[
L_{k,a}(X)=a^{2k}\bigl(X-H_a^{(2k+1)}\bigr)
          +\frac1{2a}-\frac1{2k},
\qquad
H_a^{(2k+1)}=\sum_{j=1}^{a}j^{-(2k+1)}.
\tag{25}
\]

This is precisely the paper's formal simple-pole value. Here it is evaluated in $\mathbb Q_p$, using the natural embedding of its rational coefficients, at any $X\in\mathbb Z_p$. This is a statement about a rational polynomial at a $p$-adic integral input; it does not assign a $p$-adic interpretation to the real number $\zeta(2k+1)$. Normalize the valuation by $v_p(p)=1$.

If an integer $a$ satisfies $p<a\leq K$, then $a<2p$ because $K<2p$, so $a$ is a $p$-adic unit. Exactly one integer in $\{1,\ldots,a\}$ is divisible by $p$, namely $p$. Consequently

\[
H_a^{(2k+1)}=p^{-(2k+1)}+u,\qquad u\in\mathbb Z_p.
\]

Since $a$, $2$, and $2k$ are $p$-adic units and $X\in\mathbb Z_p$, substitution into (25) gives

\[
L_{k,a}(X)=-a^{2k}p^{-(2k+1)}+v,
\qquad v\in\mathbb Z_p.
\]

The displayed first term has strictly smaller valuation than the remainder. The ultrametric valuation rule therefore gives the exact identity

\[
\boxed{v_p\bigl(L_{k,a}(X)\bigr)=-(2k+1)
       \quad\text{if }p<a\leq K.}
\tag{26}
\]

The case $a=p$ is different. Writing $H_p^{(2k+1)}=p^{-(2k+1)}+u$ with $u\in\mathbb Z_p$, one obtains

\[
L_{k,p}(X)=p^{2k}(X-u)-\frac1p+\frac1{2p}-\frac1{2k}
          =-\frac1{2p}+v,\qquad v\in\mathbb Z_p,
\]

and hence

\[
\boxed{v_p\bigl(L_{k,p}(X)\bigr)=-1.}
\tag{27}
\]

For $k\geq2$ and $p<a\leq K$, (26) exhibits an increase of $2(k-2)$ in the denominator depth relative to weight five at that pole, while (27) is independent of the weight. If $p=K$, there are no integers $a$ in the range of (26), and that part of the diagnostic is vacuous.

These are exact local statements about individual pole values. The pencil entries also contain residues and polynomial contributions, and a determinant can have additional divisibility or cancellation. Thus (26) neither determines nor bounds from below the optimal whole-determinant arithmetic rate $A_k$. It explains why the common quadratic archimedean rate proved above cannot, by itself, justify carrying an arithmetic multiplier from weight five to every higher odd weight.
