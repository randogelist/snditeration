# Polynomial-moment denominator rank at large primes

**Status:** Classical proof, not yet formalized in Lean. This note proves an exact local rank formula and sufficient determinant-denominator bounds for the actual rational moment functional. It does not establish a negative global normalized determinant rate or irrationality. Numerical checks reported at the end are secondary checks, not the proof.

## 1. Definitions and local notation

Fix integers $k,m\geq1$ and $1\leq N<K$, and put $h=K-N$. Define

\[
D_j(t)=\prod_{a=1}^{j}(t+a^2),\qquad
T(t)=\prod_{a=N+1}^{K}(t+a^2),\qquad
F(t)=D_N(t)^{2m-1}.
\]

For $0\leq i,j<h$, let $Q_{ij}(t)$ be the polynomial quotient in the division of $F(t)t^{i+j}$ by $T(t)$. Since $T$ is monic with integer coefficients, $Q_{ij}\in\mathbb Z[t]$. These are exactly the quotients in `ManuscriptChain.Real.quotient` in `Definition_2_1_Order_s_Rational_Moment_Functional.lean`.

Write the package's monomial moment as

\[
\mu_{k,e}=(-1)^e B_{2e+2}
 \frac{(2e+2k+1)!}{(2k)!(2e+2)!},\qquad e\geq0,
\tag{1}
\]

and define the polynomial contribution to the constant matrix by

\[
P_{ij}=\sum_{e\geq0}[t^e]Q_{ij}(t)\,\mu_{k,e}.
\tag{2}
\]

The sum is finite. This is the `polynomialMoment` term in `ManuscriptChain.Real.entryA`; the simple-pole contribution is excluded from $P$.

Let $p>2k$ be a prime. In particular $p$ is odd. Let

\[
\mathbb Z_{(p)}=\{a/b\in\mathbb Q:p\nmid b\}
\]

be the local ring of rational numbers integral at $p$, and let a bar denote its reduction to $\mathbb F_p$. Normalize $v_p(p)=1$. All the computations below can be made in this rational local ring; no interpretation of real zeta values in $\mathbb Q_p$ is used.

We use the classical [von Staudt–Clausen theorem](https://dlmf.nist.gov/24.10#i). This theorem itself is available in the pinned Mathlib source as `Bernoulli.vonStaudt_clausen` in `Mathlib/NumberTheory/Bernoulli.lean`; the deductions in this note have not been formalized.

## 2. The first monomial moment with a denominator at $p$

**Lemma 1.** Every $\mu_{k,e}$ lies in $p^{-1}\mathbb Z_{(p)}$. The first index at which it does not lie in $\mathbb Z_{(p)}$ is

\[
e_0=k(p-1)-1.
\tag{3}
\]

At this index its residue is exactly

\[
\overline{p\mu_{k,e_0}}=-(2k)^{-1}\quad\text{in }\mathbb F_p.
\tag{4}
\]

**Proof.** Set $n=2e+2$. Formula (1) becomes

\[
\mu_{k,e}=\frac{(-1)^eB_n}{(2k)!}
          \prod_{j=1}^{2k-1}(n+j).
\tag{5}
\]

The denominator $(2k)!$ is a $p$-adic unit. For positive even $n$, von Staudt–Clausen implies:

- If $p-1\nmid n$, then $B_n\in\mathbb Z_{(p)}$.
- If $p-1\mid n$, then $v_p(B_n)=-1$ and $\overline{pB_n}=-1$.

Indeed, isolate the $1/p$ term in $B_n+\sum_{q-1\mid n}1/q\in\mathbb Z$; all terms with $q\ne p$ are integral at $p$. In particular, every moment has valuation at least $-1$.

When $n=\ell(p-1)$, one has $n+j\equiv j-\ell\pmod p$. Thus the precise general criterion is

\[
\mu_{k,e}\notin\mathbb Z_{(p)}
\quad\Longleftrightarrow\quad
p-1\mid n\ \text{ and }\quad
\ell\bmod p\notin\{1,\ldots,2k-1\},
\qquad \ell=\frac n{p-1}.
\tag{6}
\]

If the right-hand side holds, the valuation is exactly $-1$. If it fails because one numerator factor is divisible by $p$, that factor cancels the only possible factor $p$ in the denominator.

For $e<e_0$, a possible positive integer $\ell$ is at most $2k-1$, so (6) shows integrality. At $e=e_0$, one has $n=2k(p-1)$ and $\ell=2k<p$, so no numerator factor vanishes modulo $p$. Moreover $e_0$ is odd, since $p-1$ is even, and

\[
\prod_{j=1}^{2k-1}(n+j)
\equiv\prod_{j=1}^{2k-1}(j-2k)
=-(2k-1)!\pmod p.
\]

Combining this with $(-1)^{e_0}=-1$ and $\overline{pB_n}=-1$ in (5) gives (4). This proves the lemma.

**Immediate integrality range.** Every monomial moment of degree at most $E\geq0$ is integral at $p$ whenever

\[
E<k(p-1)-1,
\quad\text{equivalently}\quad
2E+2<2k(p-1).
\tag{7}
\]

For fixed $p$ with $p>2k$, raising $k$ moves this first denominator to a higher polynomial degree. Therefore the polynomial contribution alone does not have an inevitable increasing denominator loss with the weight.

## 3. Exact rank of the polynomial denominator matrix

Put

\[
d_0=2mN-K,\qquad H=K+(2m-2)N=d_0+2h,
\qquad
\rho_p=\min\bigl(h,\max(0,H-k(p-1))\bigr).
\tag{8}
\]

**Theorem 2.** The matrix $pP$ has entries in $\mathbb Z_{(p)}$, and

\[
\operatorname{rank}_{\mathbb F_p}(\overline{pP})\leq\rho_p.
\tag{9}
\]

If

\[
k(p-1)\geq(2m-1)N,
\tag{10}
\]

then this is an equality, with the simpler expression

\[
\boxed{\quad
\operatorname{rank}_{\mathbb F_p}(\overline{pP})
=\max\bigl(0,K+(2m-2)N-k(p-1)\bigr).
\quad}
\tag{11}
\]

The expression on the right of (11) is at most $h$ under assumption (10).

**Proof.** Integrality of $pP$ follows from Lemma 1 and $Q_{ij}\in\mathbb Z[t]$. The degree difference in the division defining $Q_{ij}$ is $d_0+i+j$. If it is negative, the quotient is zero. Otherwise the quotient is monic of degree exactly $d_0+i+j$, because numerator and denominator are monic.

Let $L=e_0-d_0$. By Lemma 1, these degree facts give

\[
\overline{pP_{ij}}=0\quad\text{if }i+j<L,
\qquad
\overline{pP_{ij}}=u\quad\text{if }i+j=L,
\qquad u=-(2k)^{-1}\ne0.
\tag{12}
\]

The second assertion uses the leading coefficient one of the quotient; all its lower-degree moments are integral at $p$.

Assume first $L\geq h-1$, which is exactly (10). If $L>2h-2$, every entry is zero and (11) follows. Otherwise put

\[
r=2h-1-L,\qquad a=h-r=L-h+1.
\]

Then $1\leq r\leq h$ and $a\geq0$. Every row indexed by $i<a$ is zero, since $i+j\leq L-1$ for all $j<h$. The same holds for columns indexed by $j<a$. In the remaining $r\times r$ block, indexed by $i=a+i'$ and $j=a+j'$, (12) says that entries vanish for $i'+j'<r-1$ and equal $u$ for $i'+j'=r-1$. Reversing the columns produces a triangular matrix with diagonal $u$. Its determinant is

\[
(-1)^{r(r-1)/2}u^r\ne0.
\]

Thus the rank is exactly $r$. Substitution gives

\[
r=2h-1-e_0+d_0=d_0+2h-k(p-1)=H-k(p-1),
\]

proving (11). If $L<h-1$, then $H-k(p-1)>h$, so (9) is just the general rank bound $\operatorname{rank}\leq h$. This proves the universal bound as well.

**Example of the parameter formula.** For the PDF's weight-seven geometry $k=3$, $m=4$, $N=3K/40$, one has $H=29K/20$. At primes satisfying (10), the exact rank is

\[
\max(0,29K/20-3(p-1)).
\]

After division by $K$ and writing $y=p/K$, its limiting profile is $\max(0,29/20-3y)$, the polynomial-part rank term appearing in the PDF's Theorem 5.6. The proof above derives this term for arbitrary admissible geometry and weight, independently of that theorem's other estimates.

## 4. A determinant-denominator consequence

**Lemma 3.** Let $B(X)\in M_h(\mathbb Z_{(p)}[X])$. If $r=\operatorname{rank}(\overline{pP})$, then

\[
p^r\det\bigl(B(X)+P\bigr)\in\mathbb Z_{(p)}[X].
\tag{13}
\]

In particular, $p^{\rho_p}$ is always sufficient in (13).

**Proof.** Factor the rank-$r$ matrix $\overline{pP}$ as $\overline U\,\overline V$, with $\overline U$ of size $h\times r$ and $\overline V$ of size $r\times h$. Lift their entries to integers. Then

\[
P=C+p^{-1}UV,\qquad C\in M_h(\mathbb Z_{(p)}).
\]

Expand $\det(B+C+p^{-1}UV)$ by multilinearity in its columns. A term choosing more than $r$ columns from $UV$ is zero, because those columns lie in the span of the $r$ columns of $U$. Every other term has at most $r$ factors $p^{-1}$ and all its remaining coefficients are integral at $p$. Multiplication by $p^r$ therefore makes every coefficient integral.

This gives a denominator bound, not an exact denominator valuation of the determinant: additional cancellation or divisibility may improve it. Application to the complete pencil also requires control of its pole contribution. The pole contribution is generally not integral at primes below $K$.

## 5. The derivative matrix is integral

For completeness, the $X$-derivative matrix of the actual pencil causes no additional rational denominator. Let

\[
R_{ij}(t)=\frac{F(t)t^{i+j}}{T(t)}
         =Q_{ij}(t)+\sum_{a=N+1}^{K}\frac{c_{ij,a}}{t+a^2}.
\]

The package defines

\[
M_{ij}=\sum_{a=N+1}^{K}c_{ij,a}a^{2k}.
\]

The coefficient of $t^{-1}$ in the Laurent expansion of $t^kR_{ij}(t)$ at infinity equals $\sum_a c_{ij,a}(-a^2)^k$. On the other hand, this Laurent expansion has integer coefficients. To see the latter directly, substitute $z=1/t$: the reciprocal polynomial $z^hT(1/z)$ belongs to $\mathbb Z[z]$ and has constant coefficient one, so its reciprocal power series has integer coefficients, obtained recursively without division. The numerator also has integer coefficients. Hence

\[
M_{ij}=(-1)^k[t^{-1}]\bigl(t^kR_{ij}(t)\bigr)\in\mathbb Z.
\tag{14}
\]

This proof concerns the actual monomial-basis derivative matrix, despite its definition as a sum of rational residues.

## 6. Combining the polynomial rank with pole denominators

A useful generalization of Lemma 3 handles nonintegral pole terms without treating every entry as though it had the worst denominator.

Let an $h\times h$ polynomial matrix have the form

\[
B(X)+\sum_{\nu=1}^{q}p^{-d_\nu}u_\nu v_\nu^{T},
\]

where $B(X)$ is integral at $p$, the column vectors $u_\nu,v_\nu$ are integral at $p$, and $d_\nu$ are positive integers. Let $D$ be the sum of the largest $\min(h,q)$ members of the multiset $\{d_\nu\}$. Then $p^D$ times its determinant is integral at $p$ coefficientwise. Indeed, expand the determinant by columns. A nonzero term can select at most one column from each rank-one matrix, because two such columns are proportional, and at most $h$ rank-one contributions in total. Its denominator depth is therefore at most $D$.

For the actual pencil define

\[
\gamma_a=\frac{F(-a^2)}{T'(-a^2)},\qquad
b_{k,a}=-a^{2k}H_a^{(2k+1)}+\frac1{2a}-\frac1{2k},
\qquad
v_a=\bigl((-a^2)^i\bigr)_{0\leq i<h}.
\]

Then its constant matrix is exactly

\[
A=P+\sum_{a=N+1}^{K}\gamma_a b_{k,a}\,v_av_a^T.
\tag{15}
\]

For a nonzero scalar $\gamma_ab_{k,a}$ put $d_a=\max(0,-v_p(\gamma_ab_{k,a}))$; put $d_a=0$ if it is zero. Decompose $P$ as in Lemma 3 and use (14) to absorb $XM$ into the integral matrix. It follows that a sufficient denominator exponent for the full determinant at $p$ is the sum of the $h$ largest depths in the following multiset, or of all its members if there are fewer than $h$:

- one copy of $d_a$ for each pole with $d_a>0$;
- $\rho_p$ copies of $1$.

Using the actual rank in place of $\rho_p$ gives the same or a better bound. This is an explicit finite sufficient bound on the actual rational polynomial, not a hypothesis about unknown decay. It can still be far from optimal: different poles can cancel, and a change of local basis can expose those cancellations. No lower bound on primitive normalization follows from this sufficient denominator estimate alone.

## 7. Scope of the PDF's Theorem 6.11

Theorem 6.11 is stated for the odd-square construction for the Dirichlet beta values $\beta(2k)$, with fixed geometric parameters $\alpha=N/K$ and $m$. It is not a theorem about the present Riemann zeta functional.

Even within that beta construction, distinguish three statements: a loss in a specified local valuation bound, the growth of a resulting chosen multiplier, and a lower bound on the optimal primitive normalization. The first does not imply the third.

For example, its displayed beta half-weight formula changes by exactly $-(k-1)$ from weight two to weight $2k$, since

\[
\left\lceil\frac{l_K+2k-1}{2}\right\rceil
-\left\lceil\frac{l_K+1}{2}\right\rceil=k-1.
\]

Thus that specified inner-prime bound changes by $-2(k-1)\sum_a L_a$. The sum counts the tail poles in nonzero square classes; it equals $h$ minus the number of tail poles divisible by $p$. This explains the inner-range term displayed in the paper. It does not by itself compute contributions from the other prime ranges, prove that no different valuation argument is better, or determine the primitive content.

For the actual zeta polynomial contribution, Theorem 2 shows that increasing $k$ instead decreases the large-prime denominator rank, in the range $p>2k$. Its interaction with the pole part must be assessed rather than replaced by the beta formula. Neither this improvement nor the beta inner-range loss alone settles the sign of the normalized determinant's quadratic rate. Changing the geometry with the weight is also outside a fixed-geometry growth claim.

## 8. Secondary exact checks

As a consistency check, the exact rank formula (11) was tested in 844 cases using rational arithmetic. The ranges were $k\in\{1,2,3\}$, $m\in\{1,2\}$, $3\leq K\leq8$, $1\leq N<K$, and $p\in\{3,5,7,11,13,17,19\}$, retaining precisely the cases with $p>2k$ and (10). Bernoulli numbers were generated by their rational recurrence; polynomial division was performed with integer coefficients; ranks were computed by elimination in $\mathbb F_p$. All cases agreed. Lemmas 1–3 and the anti-triangular argument provide the proof for arbitrary parameters.

The finite local arguments above use von Staudt–Clausen, but not a prime-distribution asymptotic. For global prime-sum applications in the companion `ArithmeticFrontier.md`, the standard [prime number theorem](https://dlmf.nist.gov/27.2#E3) supplies that additional input.
