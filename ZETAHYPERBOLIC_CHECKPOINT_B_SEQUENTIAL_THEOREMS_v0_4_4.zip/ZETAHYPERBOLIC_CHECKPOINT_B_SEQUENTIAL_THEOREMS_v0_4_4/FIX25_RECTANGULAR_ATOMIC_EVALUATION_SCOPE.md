# FIX25 — rectangular atomic evaluation separation binder

Affected: `PaperOrder/Corollary_3_6_Rectangular_Atomic_Quadratic_SOS.lean` (module 98/107).

The predicate `atomicEvaluationSeparates` has the implicit size parameter `r` and only an atom-array argument `x : Fin n → ℝ`. The parameter `r` therefore cannot be inferred when the predicate appears in the theorem binder before subsequent variables are elaborated. Specify it in the assumption:

```lean
(hx : atomicEvaluationSeparates (r := r) x)
```

The mathematical statement is unchanged: the r-row evaluation map must be injective. No axioms, sorry, admits, or compilation. Previously passed modules 1–97 have not been changed. The sole new Lean input relative to v0.5.22 is the header correction in module 98. The package still uses one root `run.cmd` with the persistent frozen FASTCORE.
