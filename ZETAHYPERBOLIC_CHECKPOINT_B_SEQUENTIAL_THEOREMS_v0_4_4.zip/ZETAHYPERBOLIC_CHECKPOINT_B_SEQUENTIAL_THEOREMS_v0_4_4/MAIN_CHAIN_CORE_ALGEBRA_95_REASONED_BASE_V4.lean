import MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V3
import PaperOrder.Theorem_2_5_Weight_Change_Sign_Invariance
import PaperOrder.Theorem_5_2_Dual_Leading_Coefficient_Weight_Invariance

/-!
# Reasoned algebraic continuation V4

Combines genuine two-family algebraic invariants (one-variable pole weights
and the dual two-variable coefficient Gram matrix). This is not a claim
that the 95% mathematical-gate audit is complete, and makes no claim about
the still-open analytic irrationality measure estimates.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra
open ManuscriptChain.PoleDiagonalization ManuscriptChain.Real

/-- Every odd-weight change preserves one-variable determinant degree,
positivity of its derivative determinant under upward shifts, and the
highest coefficient of the dual Beukers determinant. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V4
    (p : ManuscriptChain.Real.Parameters) :
    (∀ (k step : ℕ),
       (0 : ℚ) < (rationalDerivativeMatrix (reweight p (k + step))).det /
         (rationalDerivativeMatrix (reweight p k)).det) ∧
    (∀ (k l : ℕ),
       (ManuscriptChain.Real.delta (reweight p k)).natDegree =
         (ManuscriptChain.Real.delta (reweight p l)).natDegree) ∧
    (∀ (h K s t : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
       (dualDelta s c).coeff h = (dualDelta t c).coeff h) := by
  constructor
  · intro k step
    exact derivative_det_reweight_ratio_pos p k step
  constructor
  · intro k l
    exact delta_natDegree_reweight_invariant p k l
  · intro h K s t c
    exact dualDelta_top_coefficient_weight_independent s t c

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V4
