# FIX11 — affine 2x2 Jacobi derivative coefficient normalization

The user's native Lean 4.33.0 compilation reported `sorryAx` on
`affineTwoDet_derivative` and `affineTwoDet_jacobi_eval` in module 63.
The derivative tactic simplified the left side but could not normalize
`Polynomial.C (α*d + a*δ - β*c - b*γ)` against products of constants.
The revised proof first applies polynomial derivative rules, then uses
`map_add`, `map_sub`, `map_mul`, `map_ofNat` to expose the coefficient
ring homomorphism before `ring`.

This modifies only `PaperOrder/Theorem_3_8_Jacobi_Two_By_Two_Affine.lean`
and the runner's package label. Previous successful cached Lean artifacts
are unchanged. No Lean compilation was performed locally.

The last user-reported successful checkpoint is modules 1-62 (cached).
The new module 63 and successors require compilation by the user's compiler.
