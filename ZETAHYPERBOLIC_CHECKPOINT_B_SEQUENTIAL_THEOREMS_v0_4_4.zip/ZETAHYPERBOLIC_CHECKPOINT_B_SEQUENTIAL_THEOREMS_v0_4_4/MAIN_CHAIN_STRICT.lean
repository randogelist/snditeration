import MAIN_CHAIN_ASSEMBLED
import Theorem_2_4_Primitive_Normalization_Minimality
import Theorem_2_5_Weight_Change
import Zeta5Merge.Theorem6_10
import Zeta5Merge.Theorem6_17
import Zeta5Merge.Theorem6_18
import PaperAudit.Theorem_3_4_Principal_Minor_Counterexample
import PaperAudit.Theorem_5_4_Pole_Pair_Cancellation

/-!
The unconditional core of the uploaded 52-page manuscript, with its exact
mathematical conclusion and standard parameter conditions. The full paper has
NOT been formalized. In particular no theorem below asserts an unconditional
height bound or measure-25687 result. The two PaperAudit files check exact
finite arithmetic and a simple-pole cancellation, not the entire sections.
-/

namespace PaperAudit

/-- Real-rootedness, exact determinant degree, center identification and a
positive zero-free disk for the ACTUAL rational moment pencil. No unproved
analytic, decay or spectral-growth premise is required; `hp` consists solely
of k>0, m>0, N>0, N<K. -/
theorem MAIN_CHAIN_STRICT (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- A root lies on the boundary of the exact zero-free disk. -/
theorem EXACT_ZERO_FREE_DISK_STRICT (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
        ¬ ManuscriptChain.General.ComplexRoot p z) ∧
      (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
        ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

end PaperAudit

#print axioms PaperAudit.MAIN_CHAIN_STRICT
#print axioms PaperAudit.EXACT_ZERO_FREE_DISK_STRICT
#print axioms PaperAudit.gamma6_residues_cancel
#print axioms PaperAudit.even_pole_pair_cancellation
