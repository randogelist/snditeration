# Reasoned base — scope and verification

This package has 70 unchanged legacy source files plus 10 new Lean source files.
Last confirmed user-compiler checkpoint: 60/66 in core95, and 59/59 in original 4B.
Modules 61–70 await the user's compiler; no new passes are claimed.

New formal developments:
- Nonsingular Gram + singular symmetric slope: complex roots all real,
  via the full Hermitian spectral factorization with zero eigenvalues allowed.
- The first Turán/Laguerre Wronskian inequality in arbitrary finite degree,
  proved inductively and stable under arbitrary real scalar multiplication.
- Rectangular weighted atomic Hankel Gram formula for all r,n.
- Theorem 5.1/5.2: rational dual-moment symmetry, CC^T coefficient matrix,
  exact X^h coefficient of the two-variable Beukers determinant.
- Full actual pole slope's diagonal congruence entry and vanishing off diagonal.

No Lean compilation performed by the assistant.

Remaining unproved PDF assertions include: continuous-measure strict total
positivity of all minors, alternating signs of all actual pole weights, exact
inertia counts, corrected global interlacing, all-order Newton inequalities,
analytic Beukers integral realization, and quantitative ζ(5) estimates.

The 95% core-algebra gate remains open, and source files alone do not count
as verified until the user's native Windows Lean 4.33.0 compiler passes them.

Additional v0.5.1 proofs: dual Gram slope quadratic sum-of-squares in all dimensions and exact full-monomial dual-penciled degree/monicity. New modules 81-83 are NOT yet compiler-verified.

Build-order repair v0.5.2: include the existing theorem-5.1 source in the
incremental compilation order, before the new §5 modules. Module indices
71-84 use exact declared direct dependencies, not artificial build-order
chains. Last user-verified checkpoint remains 60, with 61-84 unverified.

V3 adds modules 85-88 as detailed in README_REASONED_BASE_V3.md; pending user compiler.
