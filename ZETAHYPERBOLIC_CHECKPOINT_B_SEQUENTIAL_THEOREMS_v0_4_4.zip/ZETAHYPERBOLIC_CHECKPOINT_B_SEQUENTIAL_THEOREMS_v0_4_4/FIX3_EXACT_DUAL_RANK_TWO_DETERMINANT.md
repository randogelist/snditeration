# FIX3: exact rank-two polynomial determinant, module 128/130

The user's compiler certified modules 1-127, but module 128 failed on
- a proof step `simp only [map_pow]` which could not rewrite C(1/6)^2, and
- `rw [hC_sq]` because the explicit 2x2 determinant contains
  C(6^-1) * C(6^-1), not syntactically C(6^-1)^2.

Repair: prove the closed polynomial equality
`C(6^-1) * C(6^-1) = C(36^-1)` by `rw [← map_mul]; norm_num`.
Use the resulting identity after `Matrix.det_fin_two`, and finish
by `ring`.  Everything else, including modules 1-127 and the
unchanged 130-step build order, is preserved.

This package is SOURCE-REPAIRED, not locally Lean-compiled. The user's
native Lean 4.33.0 compiler remains the sole authority.
