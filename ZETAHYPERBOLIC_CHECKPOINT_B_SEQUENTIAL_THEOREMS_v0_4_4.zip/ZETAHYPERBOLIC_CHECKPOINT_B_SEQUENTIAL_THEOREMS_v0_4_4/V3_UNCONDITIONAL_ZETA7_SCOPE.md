# V3 — unconditional scalar witness for the actual weight-seven pencil

User compiler checkpoint: 115/115 passed; this package preserves the entire
115-module frozen graph and adds two source modules (116, 117), leaving all
old Lean files byte-identical. The user’s native Windows Lean 4.33.0 remains
the sole authority for compiling the NEW files.

New direct mathematics:

* `(n+2)^6 >= 64*(n+1)` for all natural n.
* A pointwise telescoping comparison of the ζ(7) tail.
* `ζ(7) <= 65/64 < 38/37` from the defined convergent Dirichlet series.
* Therefore the previously verified explicit rational polynomial
  `37X-38` is strictly negative at ζ(7). The constant-polynomial pencil is
  strictly positive. The root 38/37 is rational.

Proof boundary: this is an unconditional signed 1x1 **finite** witness.
The manuscript's unrestricted two-variable Krein cone construction and
infinite analytic bridge remain open. No claims of 95% core-algebra gate
coverage or full-paper Lean proof.

The runner reuses unchanged frozen modules and only compiles changed/new
modules and dependency-invalidated descendants.
