# Original 52-page PDF: Lean chapter blueprint and closure ledger

**Scope.** Original *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, 52 pages. The modified 58-page supplement is a separate editorial artifact.
**Census.** 51 indexed objects = 46 numbered non-remark items (1 definition + 45 proof obligations) + 4 remarks + 1 conjecture.
**Compiler checkpoint.** 119 of the old 121 files passed in the last user log; source #120 failed, and #121 was blocked. The current ZIP relocates those two UNCERTIFIED files after eight independent new blueprint modules. It does NOT alter the 119 verified .lean files.
**Blueprint vs proof.** Goal definitions create propositions; they do not prove them. The `BlueprintBundle` has no provided inhabitant. Arbitrary data models must be formally identified with the paper construction before theorem claims can be upgraded.

## Chapter closures

| Section | Original obligations | Current algebra | Key closure |
|---|---:|---|---|
| 2 | 4 proofs + 1 definition | User-PASS core proofs; NEW `Chapter2Certified` assembly | normal form ↔ full rational-function domain |
| 3 | 9 | proven finite spectral and corrected principal real-rootedness | continuous measure, TP, exact signature, rank-aware interlacing, J-fraction |
| 4 | 8 | abstract transfer and several finite algebraic barriers | quantitative ζ(5) witness, exp(11.411K), 25687 measure; p-adic |
| 5 | 6 | finite rational dual pencil, rank-one/two signs and spectrum | actual double integral, infinite Krein tail, all-h polynomial cones |
| 6 | 18 | scattered finite local statements | multi-weight analytic and q-adic bridges, potential-gap correction |

## Logical rules

1. An identity in a copied or constructed matrix is not enough: prove its entries are the EXACT PDF moment functional.
2. `FROZEN_PASS` is a compilation certificate for unchanged sources, not automatically a theorem-completeness certificate.
3. Every numerical or p-adic bound must be supplied as a proven inequality or an explicitly named witness verified by a terminating checker.
4. A corrected target is distinct from the false printed statement; record the correction in the PDF before claiming full-paper completion.
5. The original 3.6 claims strict positivity of ALL Hankel determinants of a finite atomic measure, which is false once the order exceeds the number of distinct support atoms. This package uses the rank-limited correction.
6. In 6.10 the decay parameter needs an UPPER bound to infer `height/decay > 581`; an existing LOWER decay estimate is not sufficient.

## 46 numbered items and open proof bridges

### Section 2
- **2.1 Order-s rational moment functional** (PDF p.3): `Definition_2_1`; **DEFINITION_IN_SOURCE**. None; the source definition is present.
- **2.2 Pullback identity** (PDF p.4): `Goal_2_2`; **FROZEN_NORMAL_FORM_PROOF**. Normal-form ↔ unrestricted rational function identification.
- **2.3 Reflection and difference identities for tau** (PDF p.5): `Goal_2_3`; **FROZEN_GENERATOR_PROOF**. Scope/linearity bridge across full rational-function span.
- **2.4 Canonical basis invariance** (PDF p.6): `Goal_2_4`; **FROZEN_THEOREM**. No additional finite algebra gap.
- **2.5 Lagrange pole diagonalization** (PDF p.6): `Goal_2_5`; **FROZEN_THEOREM**. No additional finite algebra gap.

### Section 3
- **3.1 Universal hyperbolicity and zero-free disk** (PDF p.7): `Goal_3_1`; **FROZEN_SPECTRAL_CORE**. Verify identical parameter restrictions and measure realization.
- **3.2 Continuous hyperbolic pencil for all real s > 1** (PDF p.8): `Goal_3_2`; **CORRECT_NORMALIZATION_REQUIRED**. PDF continuous weight differs by factor pi/2 at odd integers.
- **3.3 Total positivity, leading sign, and universal signature** (PDF p.8): `Goal_3_3_Full (Goal_3_3 + Goal_3_3_Inertia)`; **PARTIAL**. Strict total positivity, Carleman, universal inertia/signature.
- **3.4 Root interlacing and Dodgson condensation for principal minors** (PDF p.9): `Goal_3_4 (corrected)`; **CORRECTED_ONLY**. Unrestricted interlacing false for singular principal slopes.
- **3.5 Stieltjes J-fraction from interlacing roots** (PDF p.10): `Goal_3_5`; **CORRECTION_REQUIRED**. J-fraction normalization and positive Lanczos coeffs require cyclicity.
- **3.6 Stieltjes reciprocal-root power sums** (PDF p.11): `Goal_3_6 (rank-limited correction)`; **CORRECTION_REQUIRED**. Finite support implies large Hankel minors vanish, not strictly positive.
- **3.7 Turanian non-negativity and Newton log-concavity** (PDF p.11): `Goal_3_7`; **FROZEN_FINITE_COMPONENTS**. Connect Wronskian inequalities to full printed coefficient equality cases.
- **3.8 Christoffel-Darboux pole representation and Jacobi derivative identity** (PDF p.12): `Goal_3_8`; **FROZEN_FINITE_COMPONENTS**. Full CD kernel and Jacobi analytic derivative.
- **3.9 Hyperbolicity for Hurwitz and Dirichlet Hankel determinants** (PDF p.13): `Goal_3_9`; **PARTIAL**. Hurwitz and character-kernel positivity with actual residue functional.

### Section 4
- **4.1 Spectral irrationality measure criterion** (PDF p.14): `Goal_4_1`; **FROZEN_ABSTRACT_TRANSFER**. Proof of both full witness hypotheses, not just polynomial small value.
- **4.2 Transfer criterion for algebraic approximations** (PDF p.15): `Goal_4_2`; **PARTIAL**. Resultant/height control and algebraic degree case.
- **4.3 Ultrametric zero-free disk over Qp** (PDF p.15): `Goal_4_3`; **PARTIAL**. Actual Qp/Cp valuation and ultrametric Taylor bounds.
- **4.4 Sharpened spectral bound and effective irrationality measure for zeta(5)** (PDF p.16): `Goal_4_4`; **OPEN_PRINCIPAL**. Quantified spectral norm <= exp(11.411K) and integral/p-adic witness.
- **4.5 Irrationality and effective measure for b*zeta(5)+a*zeta(3)** (PDF p.18): `Goal_4_5`; **OPEN_PRINCIPAL**. Combined positive weight and arithmetic denominator transfer.
- **4.6 Two-sided determinant bounds and coefficient heights** (PDF p.19): `Goal_4_6`; **PARTIAL**. Determinant energies and asymptotic upper/lower bounds.
- **4.7 Macroscopic exponential root collapse and root separation** (PDF p.21): `Goal_4_7`; **PARTIAL**. Macroscopic count after quantitative determinant estimates.
- **4.8 Rational root exclusion and degree bounds for cluster factors** (PDF p.21): `Goal_4_8`; **PARTIAL**. Rational exclusion + irreducible factor lower bounds.

### Section 5
- **5.1 Two-variable Beukers measure for zeta(7)** (PDF p.22): `Goal_5_1`; **FINITE_MOMENTS_PROVED**. Full two-variable integral = matrix entry, integrability, Fubini.
- **5.2 Dual hyperbolicity and Krein-space decomposition** (PDF p.23): `Goal_5_2 (finite slope + infinite Krein + cones)`; **FINITE_SPECTRUM_PROVED**. Infinite signed Krein identity, universal rational polynomial cones.
- **5.3 Two-variable Beukers measure and dual pencil for beta(4)** (PDF p.24): `Goal_5_3`; **OPEN**. Beta(4) integral, signs, normalization.
- **5.4 Cancellation of higher zeta values on even pole pairs** (PDF p.25): `Goal_5_4`; **FINITE_GENERATOR_PROVED**. Ensure exact x-even pole-pair scope, not higher poles.
- **5.6 Weight-seven prime-sum evaluation and pole-ordered refinement** (PDF p.26): `Goal_5_6`; **OPEN**. Piecewise exact outer integral and inner p-adic refinement.
- **5.7 Simultaneous double-pole Hankel determinant for 1,zeta(5),zeta(6)** (PDF p.28): `Goal_5_7`; **OPEN**. Unconditional Hermite interpolation q-adic determinant valuation.

### Section 6
- **6.1 Divided-difference p-adic valuation law and intrinsic p^-6 barrier** (PDF p.29): `Goal_6_1`; **OPEN**. Exact vp=-7 divided differences from actual p-adic valuation.
- **6.2 Simultaneous weight-(6,7) Beukers functional** (PDF p.31): `Goal_6_2`; **OPEN**. Simultaneous weight (6,7) integration/denominator identity.
- **6.3 Unconditional q-adic non-vanishing and positive-cone approximations** (PDF p.32): `Goal_6_3`; **PARTIAL**. Actual q-adic nonvanishing and all-dimensional positive cone.
- **6.4 Character-Vandermonde sign cancellation and beta(4) hyperbolicity** (PDF p.33): `Goal_6_4`; **PARTIAL**. Character-Vandermonde beta positivity/integral identification.
- **6.5 Unconditional q-adic nonvanishing for beta(4)** (PDF p.34): `Goal_6_5`; **OPEN**. Beta q-adic determinant local certificate.
- **6.6 Generalized multi-weight positive-definite pencil** (PDF p.35): `Goal_6_6`; **OPEN**. Multi-weight positive pencil kernel.
- **6.7 Universal multi-weight two-variable Beukers Krein decomposition** (PDF p.37): `Goal_6_7`; **OPEN**. Universal infinite signed cone and tail.
- **6.8 Unconditional three-term linear independence cone** (PDF p.38): `Goal_6_8`; **OPEN**. Precisely defined three-term coefficient cone, not unrestricted independence.
- **6.9 Triple-pole and multi-weight Hankel determinants** (PDF p.38): `Goal_6_9`; **PARTIAL**. Triple pole q-adic endpoint.
- **6.10 Universal potential-gap identity and vanishing quadratic derivative growth** (PDF p.39): `Goal_6_10 (corrected upper-decay premise)`; **CORRECTION_REQUIRED**. Missing UPPER decay rate; lower rate does not imply >581.
- **6.11 Distribution growth law and 2-adic polynomial-quotient obstruction** (PDF p.40): `Goal_6_11`; **OPEN**. 2-adic quotient obstruction and growth.
- **6.12 Sign-flip restoration of positive definiteness and q-adic non-vanishing** (PDF p.42): `Goal_6_12`; **OPEN**. Sign-flip positive definite measure and local valuation.
- **6.13 Central-factorial secant differential identity and Laplace mode annihilation** (PDF p.43): `Goal_6_13`; **OPEN**. Central-factorial secant coefficient identity and annihilated modes.
- **6.14 Even-pole scaling via cosh and positive-definite Zeta-Beta pencils** (PDF p.45): `Goal_6_14`; **OPEN**. Cosh scaling and positive Zeta-Beta measure.
- **6.15 Arithmetic transcendence and strictly positive one-variable measure** (PDF p.46): `Goal_6_15`; **OPEN**. Specified transcendence candidate and full polynomial nonvanishing.
- **6.16 Generalized multi-weight Zeta-Beta positive-definite pencil** (PDF p.47): `Goal_6_16`; **PARTIAL**. Uniform Zeta-Beta positivity bounds.
- **6.17 Universal two-variable Beukers Zeta-Beta pencil** (PDF p.48): `Goal_6_17`; **PARTIAL**. Finite index vs infinite two-variable and q-adic endpoint.
- **6.18 Principal-minor 2-adic integrality and dyadic height bounds** (PDF p.49): `Goal_6_18`; **PARTIAL**. 2-adic principal minor valuations and dyadic heights.

## One-run incremental compilation

The user runs `run.cmd` only with their pinned native Lean 4.33.0, 16 threads and cached Mathlib. Unchanged certified sources 1-119 are skipped by receipts. Modules 120-127 check the blueprints and assembly first. The previous two unresolved files follow at 128-129; endpoint 130 composes both branches.

`run.cmd full` is an available MANUAL full rebuild, not the default.

Compilation pass of the blueprints means their TYPES elaborate. It does not establish that any remaining `Goal_*` is true.
