# PDF corrections and logical frontiers — do NOT assume these silently

## Section 2

- 2.1: genuine rational moment and denominator definitions are present.
- 2.2: the finite normal-form pullback is formalized using existing checked
  generator identities; the fully general rational-function identity requires
  identifying the normal form with the rational-function domain.
- 2.3: the generator identities are proved; the difference identity excludes
  r=0,1 exactly as in the printed statement.
- 2.4: basis invariance is a finite rational theorem, established upstream.
- 2.5: exact Vandermonde structure, Lagrange evaluation and degree are established.

## Section 3

- 3.1: unconditional odd-weight Gram/spectral theorem is already in the archived
  checked sources. Newly reassembled wrapper awaits the user's Lean compiler.
- 3.2: PDF prints w_s(y)=(2π)^s/(2Γ(s)) · y^s · Σ l^(s-1)e^(-2πly). At
  s=2k+1 this differs from (3.1) by a factor π/2. The corrected normalization
  matching (3.1) is 2(2π)^(s-1)/Γ(s). The finite abstract positive-pencil
  spectral transfer is genuine, but the continuous analytic realization remains.
- 3.3: the full total-positivity and inertia/signature theorem remains open.
  Only the exact leading-coefficient identity is exported.
- 3.4: the printed statement is FALSE without treating zero derivative
  eigenvalues. Example k=2, m=1, N=1, K=6 has zero 1×1 slope; the precise
  rational certificate is formalized in PaperAudit. Root interlacing may be
  formulated using only the nonzero generalized eigenvalues, with the loss
  of degree tracked explicitly.
- 3.5: dependent J-fraction formulation needs determinant normalization and
  a cyclicity condition; cannot be imported as printed.

## Sections 4–6

- Section 4.3/4.4 normalization and decay are a *witness* in the main
  irrationality branch. The separate spectral growth exponent is not already
  implied by this witness, so 25687 is not shown by the new paper-order chain.
- Section 5 contains genuine two-variable analytic and p-adic proofs not
  implied by any Section 4 witness.
- 4.11 is explicitly a conjecture, not a theorem to invent a proof for.
- 6.10 uses an UPPER bound epsilon_tilde <= 0.0004 on the decay-rate
  parameter, but the small-value estimate in Section 4 supplies a LOWER
  decay-rate bound instead. If the missing UPPER rate bound is independently
  proved, then the printed height/epsilon_tilde > 581 deduction from the
  positive potential gap is arithmetically valid. Existing
  Zeta5Merge.Theorem6_10 proves this corrected conditional deduction and
  shows why a LOWER rate bound alone is insufficient.

No additional `axiom`, `sorry`, `admit`, or hypothesis of the conjectured final
conclusion has been added in this package. Pending statements are recorded as
PENDING instead of becoming fake Lean theorems.
