# CHRONOLOGICAL EXTENSION v0.3.7 (43 modules)

Only five new Lean modules are added. All 38 previously user-verified Lean source files are bitwise unchanged, as is the persistent frozen cache root. Do NOT compile Lean on the assistant side. Your Windows compiler is the authority.

## Added in PDF order

1. `Theorem_3_3_Leading_Sign_Exponent`: exact integral-polynomial factor identities for the weight-five determinant sign exponent, but not yet the matrix inertia theorem.
2. `Theorem_3_4_Dodgson_Base_Case_Corrected`: exact symmetric 2-by-2 Dodgson identity, inequality at a vanishing leading minor, and the constant first-minor case.
3. `Corollary_3_5_Normalized_JFraction_Base_Case`: exact scaled 2-by-2 Schur-complement identity for `I+tB`; no unjustified Lanczos cyclicity.
4. `Corollary_3_6_Finite_Stieltjes_Correction`: finite moment/Hankel/Vandermonde factorization and a one-atom determinant-zero counterexample to unconditional strict positivity of all orders.
5. `MAIN_CHAIN_PAPER_ORDER_EXTENDED`: imports original frozen main chain and new components.

## Mathematical correction

The PDF Corollary 3.6 says that a discrete Stieltjes moment sequence with only `h` atoms has *strictly positive Hankel determinants* of every order. This cannot hold beyond the support rank `h`. Already at `h=1` the 2-by-2 Hankel determinant is zero. The PDF's bound on reciprocal-root moment asymptotics also reverses its displayed inequalities; the proof has the correct ordering. These are manuscript repairs, not hypotheses or new axioms.

## Compiler strategy

- Persistent cache: `%USERPROFILE%\lean-native\zetahyperbolic_paper_frozen_lean433_v1`
- Expected, if previous artifacts match: `FROZEN_SKIP=1/43` through `FROZEN_SKIP=38/43`, then `CHECK=39/43` through `CHECK=43/43`.
- Only one root `run.cmd`; pinned native Lean 4.33.0, 16 threads, no Lake/network/Python/PowerShell/WSL.
- No local Lean compilation performed. New source files await verification from your compiler.

## FIX4 (v0.3.8) — user's module 40 log

Module 39 passed on the user's compiler. Module 40 has a source-only repair using the dedicated `Matrix.det_fin_two_of` lemma. Module 40 and its dependents 41–43 await the user's compiler. Frozen modules 1–39 are preserved unchanged.

## v0.3.9 FIX5
Repaired the Theorem 3.4 2x2 matrix constructor mismatch (see FIX5_THEOREM_3_4_MATRIX_NOTATION.md). Frozen 1–39 unchanged. Only the user compiler will verify the new source.


See `README_SECTION3.md` for the new chronological extension through Theorem 3.9.
