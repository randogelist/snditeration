import Zetahyperbolic.Foundations
import Zetahyperbolic.CoreLinearAlgebra
import Zetahyperbolic.LagrangeBasis
import Zetahyperbolic.Section2Algebra
import Zetahyperbolic.Section3Elementary
import Zetahyperbolic.Section2Checked
import Zetahyperbolic.ManuscriptCompatibility
import Zetahyperbolic.MainChain
import MAIN_CHAIN_ASSEMBLED
import MAIN_CHAIN_ARITHMETIC
import MAIN_CHAIN_IRRATIONALITY
import Theorem_2_4_Primitive_Normalization_Minimality
import Theorem_2_5_Weight_Change
import Theorem_4_1_Leading_Coefficient_Gap

/-!
# Zetahyperbolic: general odd-weight Hankel theorem

`Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL` covers arbitrary admissible k,m,N,K.
The actual positive moment realization and its integral identities are proved.
The endpoint establishes full determinant degree, real roots, spectral
factorization, and a positive zero-free disk. The exact radius is attained
by a root, as stated in `ORIGINAL_EXACT_ZERO_FREE_DISK`.
The general arithmetic implication is exported by MAIN_CHAIN_ARITHMETIC:
normalized quadratic decay and linear degree growth imply irrationality.
The decay estimate remains an explicit hypothesis.
The exact leading-coefficient/determinant-ratio identity and strict-gap
criterion are exported by Theorem_4_1_Leading_Coefficient_Gap.
Specialized arithmetic applications remain separate in APPLICATIONS.
-/
namespace Zetahyperbolic

theorem setup_smoke_test : 1 + 1 = 2 := by norm_num

end Zetahyperbolic

namespace ManuscriptChain.GeneralIrrationality

/-- Both arithmetic interfaces use the same canonical primitive polynomial. -/
theorem primitivePolynomial_eq_generalArithmetic (p : Real.Parameters) :
    primitivePolynomial p = GeneralArithmetic.primitivePolynomial p := rfl

end ManuscriptChain.GeneralIrrationality
