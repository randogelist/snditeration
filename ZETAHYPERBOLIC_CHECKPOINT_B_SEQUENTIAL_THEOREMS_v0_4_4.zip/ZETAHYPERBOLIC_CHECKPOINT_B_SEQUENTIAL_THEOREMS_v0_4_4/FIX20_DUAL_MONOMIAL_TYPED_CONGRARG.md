# FIX20: Explicit Fin-indexed equality under `congrArg`

Compiler checkpoint: modules 1–78 previously verified; module 79 failed in the `dualMonomialSlope_eq_one` proof, where `congrArg Fin.val` inferred the wrong `Fin` index under the expected type.

Repair: explicitly type the argument as `fun k : Fin (h + 1) => k.val`, obtaining the equality of values of `Fin.castSucc i` and `Fin.castSucc j`, and then use definitional reduction to deduce `i.val = j.val`. This establishes `i = j` via `Fin.ext`, contrary to `hij`.

No mathematical theorem statements or previous Lean sources were altered. This proof and subsequent modules await the user's Lean 4.33.0 compiler. No local Lean compilation performed.
