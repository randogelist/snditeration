# The closed analytic proof and assembled general theorem

The analytic development is now proved in Lean. The assembled endpoint requires
only the structural conditions $k,m,N\ge1$ and $N<K$:

```lean
ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
    (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p
```

The proof below follows the implemented cotangent and Gamma route. The
independent Hermite derivation is retained in `ANALYTIC_PROOF_DETAILS.txt`;
that alternative is not an assumption or dependency of the Lean proof.

Put $s=2k+1$, $b=2\pi$, $C_k=2b^{2k}/(2k)!$, and

\[
D_n(t)=\prod_{a=1}^n(t+a^2),\qquad h=K-N.
\]

## 1. Positive density and monomial moments

For $y>0$, the actual density is

\[
w_s(y)=C_k y^{2k+1}\sum_{n=1}^{\infty}n^{2k}e^{-bny}>0.
\]

The series converges for every positive $y$. Nonnegative integration,
Gamma integrals, and the convergent even-zeta series give

\[
\begin{aligned}
\int_0^\infty y^{2e}w_s(y)\,dy
&=\frac{2(2e+2k+1)!}{(2k)!b^{2e+2}}\zeta(2e+2)\\
&=\frac{(-1)^eB_{2e+2}(2e+2k+1)!}{(2k)!(2e+2)!}
=\mu_{\zeta(s)}^{(s)}(t^e).
\end{aligned}
\]

Every required monomial is integrable. These statements are proved in
`Theorem_3_1_Hyperbolic_Weight.lean` and
`Theorem_3_1_Hyperbolic_Moments.lean`.

## 2. Scaling the simple-pole integral

Fix a positive integer $a$. Expanding the density and substituting $t=ny$
in each summand gives

\[
\begin{aligned}
I_{k,a}
&=\int_0^\infty\frac{w_s(y)}{y^2+a^2}\,dy\\
&=C_k\int_0^\infty t^{2k+1}e^{-bt}
\left(\sum_{n=1}^{\infty}\frac1{t^2+a^2n^2}\right)dt.
\end{aligned}
\]

The first exchange is justified by bounding each pole term by $a^{-2}$ times
its corresponding integrable density term. For the second exchange, the
scaled summand is bounded by $a^{-2}n^{-2}t^{2k+1}e^{-bt}$.
The sum of its integral norms is finite. The change of variables and both
exchanges are proved in `Theorem_3_1_Pole_Scaling.lean`.

## 3. Evaluate the resolvent sum

Mathlib's proved cotangent partial-fraction theorem, evaluated at the
imaginary argument $it/a$, yields for $t,a>0$

\[
\sum_{n=1}^{\infty}\frac1{t^2+a^2n^2}
=\frac{\pi}{at}\left(\frac12+\frac1{e^{bt/a}-1}\right)
-\frac1{2t^2}.
\]

`Theorem_3_1_Coth_Partial_Fractions.lean` proves this real identity from
`cot_series_rep'` and `Complex.cot_pi_eq_exp_ratio`, including the exact
complex-to-real conversion and convergence of the series.

## 4. Geometric series and Gamma integrals

For $t>0$, expand $(e^{bt/a}-1)^{-1}$ as its positive geometric series.
Termwise Gamma integration, justified by the convergent shifted $s$-series,
gives

\[
\begin{aligned}
B_{k,a}
&=\int_0^\infty\frac{t^{2k}e^{-bt}}{e^{bt/a}-1}\,dt\\
&=\frac{(2k)!a^{2k+1}}{b^{2k+1}}
\sum_{n=1}^{\infty}(a+n)^{-(2k+1)}\\
&=\frac{(2k)!a^{2k+1}}{b^{2k+1}}
\left(\zeta(2k+1)-H_a^{(2k+1)}\right).
\end{aligned}
\]

The integral is finite because $k\ge1$. The shifted-series subtraction and
integrability are proved in `Theorem_3_1_Zeta_Tail.lean` and
`Theorem_3_1_Bose_Tail_Integral.lean`.

Substituting the resolvent identity into the scaled integral yields

\[
I_{k,a}=C_k\left[
\frac{\pi}{a}B_{k,a}
+\frac{\pi}{2a}\frac{(2k)!}{b^{2k+1}}
-\frac12\frac{(2k-1)!}{b^{2k}}
\right].
\]

All three terms are integrable. Cancelling factorials and powers of $b=2\pi$
proves the exact identity

\[
\boxed{
I_{k,a}=a^{2k}\left(\zeta(2k+1)-H_a^{(2k+1)}\right)
+\frac1{2a}-\frac1{2k}.
}
\]

This is precisely the existing `PoleIntegralIdentity`, including its harmonic
index, signs, and constants. `Theorem_3_1_Pole_Integral_Identity.lean` proves

```lean
Hyperbolic.poleIntegralIdentity
    (k : Nat) (hk : 0 < k) : Hyperbolic.PoleIntegralIdentity k
```

No special-function evaluation remains as a theorem argument.

## 5. Actual Gram matrix and strict positivity

For rational functions in the functional's domain—finite combinations of
polynomials and terms $1/(t+a^2)$ with positive integer $a$—partial fractions
combine the monomial and simple-pole identities:

\[
\mu_{\zeta(s)}^{(s)}(R)=\int_0^\infty R(y^2)w_s(y)\,dy.
\]

For the actual matrix, put

\[
W_p(y)=\frac{D_N(y^2)^{2m}}{D_K(y^2)}w_s(y)>0.
\]

The denominator is at least one on the positive half-line and the numerator
is a polynomial in $y^2$. The established monomial bounds therefore prove
all required integrability. Exact algebraic compatibility gives

\[
(G_p(\zeta(s)))_{ij}=\int_0^\infty y^{2(i+j)}W_p(y)\,dy.
\]

The pushforward of $W_p(y)\,dy$ under $y\mapsto y^2$ is a constructed nonzero
measure with zero mass at every singleton. A nonzero polynomial has only
finitely many roots, so

\[
\boxed{
v^*G_p(\zeta(s))v
=\int_0^\infty W_p(y)
\left|\sum_{i=0}^{h-1}v_i y^{2i}\right|^2dy>0
\quad(v\ne0).
}
\]

The measure, weighted integrability, exact entry identities, and strict
positivity are all proved in Lean. Thus

\[
\forall p,\quad\operatorname{Admissible}(p)
\Longrightarrow G_p(\zeta(2k+1))\succ0.
\]

## 6. The assembled endpoint

`MAIN_CHAIN_ASSEMBLED.lean` supplies this positivity to the existing spectral
chain. It proves `GeneralStatement p` for every admissible parameter choice,
and separately proves that the zero-free disk has a root on its boundary.
The original-pencil version discharges admissibility from `HankelParams`
and $k\ge1$ internally. `Zetahyperbolic.lean` exports these endpoints.

Only standard Lean/Mathlib logical axioms occur in the audit. No custom axiom,
admitted proof, Gram-positivity premise, or integral identity is supplied by
the user. `VALIDATION.md` records the compiler and complete-project audit.

This concludes the general odd-integer-weight spectral theorem. The arithmetic
and quantitative estimates for irrationality measures, pairwise root simplicity,
and the continuous-real-weight extension are outside this conclusion.
