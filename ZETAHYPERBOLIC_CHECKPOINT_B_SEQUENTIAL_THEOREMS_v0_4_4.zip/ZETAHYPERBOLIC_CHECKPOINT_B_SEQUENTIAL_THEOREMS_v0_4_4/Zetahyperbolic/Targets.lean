import Mathlib.Analysis.PSeries

/-! Concrete target, separated from any irrationality assertion. -/
namespace Zetahyperbolic

/-- The real value ζ(5); the n = 0 term is zero under Lean's total division. -/
noncomputable def zetaFiveReal : ℝ := ∑' n : ℕ, 1 / (n : ℝ) ^ 5

end Zetahyperbolic
