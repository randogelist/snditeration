import Zetahyperbolic.ManuscriptCompatibility
import Zetahyperbolic.Targets
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5

/-! Specialized Section 4 compatibility, separate from the general framework. -/
noncomputable section
open scoped BigOperators Matrix Polynomial
open Polynomial
namespace Zetahyperbolic

/-- Original Equation (4.2) normalization: K = 30n, N = 3n, h = 27n. -/
def S_K5 (n : ℕ) : ℚ :=
  let K := 30 * n
  let N := 3 * n
  let h := 27 * n
  ((Nat.factorial K : ℚ) ^ (2 * h) * 4 ^ (h - 1)) /
    ((Nat.factorial N : ℚ) ^ (12 * h) *
      ∏ i ∈ Finset.Icc 1 (h - 1), (Nat.factorial (2 * i) : ℚ) ^ 2)

/-- The original combinatorial normalization is strictly positive at every index. -/
lemma S_K5_pos (n : ℕ) : 0 < S_K5 n := by
  unfold S_K5
  positivity

namespace ManuscriptCompatibility

/-- The manuscript's actual K = 30n, N = 3n, m = 3 structural family. -/
def mainHankelParams (n : ℕ) (hn : 1 ≤ n) : HankelParams where
  N := 3 * n
  K := 30 * n
  m := 3
  hN := by omega
  hK := by omega
  hm := by norm_num

@[simp] theorem mainHankelParams_toParameters (n : ℕ) (hn : 1 ≤ n) :
    toParameters (mainHankelParams n hn) 2 = ManuscriptChain.Real.mainParameters n := rfl

/-- The determinant in the checked endpoint is exactly the uploaded construction. -/
theorem mainDelta_eq_original (n : ℕ) (hn : 1 ≤ n) :
    ManuscriptChain.Real.mainDelta n = Delta_poly (mainHankelParams n hn) 2 := by
  rw [Delta_poly_eq_delta, mainHankelParams_toParameters]
  rfl

/-- The checked chain preserves the original combinatorial scaling exactly. -/
theorem S_K5_eq_section4Scale (n : ℕ) :
    S_K5 n = ManuscriptChain.Real.section4Scale n := by
  unfold ManuscriptChain.Real.section4Scale
  dsimp only
  rw [ManuscriptChain.MainChain.main_dimension]
  rfl

/-- Both the determinant and its Section 4 normalization are the original objects. -/
theorem mainF_eq_original (n : ℕ) (hn : 1 ≤ n) :
    ManuscriptChain.Real.mainF n =
      C (S_K5 n) * Delta_poly (mainHankelParams n hn) 2 := by
  unfold ManuscriptChain.Real.mainF
  rw [← S_K5_eq_section4Scale, mainDelta_eq_original n hn]

/-- The original zero-index Dirichlet series is the same ζ(5) used in the chain. -/
theorem zetaFiveReal_eq_zeta : zetaFiveReal = ManuscriptChain.Real.zeta 5 := by
  have hs : Summable (fun n : ℕ => 1 / (n : ℝ) ^ 5) :=
    _root_.Real.summable_one_div_nat_pow.mpr (by norm_num)
  have h := hs.sum_add_tsum_nat_add 1
  simpa [zetaFiveReal, ManuscriptChain.Real.zeta] using h.symm

theorem zetaFiveReal_eq_riemannZeta_re : zetaFiveReal = (riemannZeta 5).re := by
  rw [zetaFiveReal_eq_zeta, ManuscriptChain.Real.zeta_five_eq_riemannZeta_re]

end ManuscriptCompatibility
end Zetahyperbolic

#print axioms Zetahyperbolic.ManuscriptCompatibility.mainF_eq_original
#print axioms Zetahyperbolic.ManuscriptCompatibility.zetaFiveReal_eq_riemannZeta_re
