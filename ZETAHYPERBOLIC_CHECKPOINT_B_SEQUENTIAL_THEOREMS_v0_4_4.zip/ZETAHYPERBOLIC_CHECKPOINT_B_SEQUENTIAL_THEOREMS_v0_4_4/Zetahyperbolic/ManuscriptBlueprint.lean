import Zetahyperbolic.Section2Checked
import Zetahyperbolic.MainChain

/-!
Checked replacement entry point for the uploaded manuscript blueprint.
The original statement scaffold is retained verbatim as
provenance/ManuscriptBlueprint.lean.txt, outside the Lean import graph.
Its 23 admitted declarations are not exported as theorems by this module.
Theorem-named modules in MAIN_CHAIN give the general odd-weight spectral chain;
Zetahyperbolic.MainChain identifies it with the original pencil and determinant.
See ExternalAssumptions.md for the remaining Gram realization and extension gaps.
-/
