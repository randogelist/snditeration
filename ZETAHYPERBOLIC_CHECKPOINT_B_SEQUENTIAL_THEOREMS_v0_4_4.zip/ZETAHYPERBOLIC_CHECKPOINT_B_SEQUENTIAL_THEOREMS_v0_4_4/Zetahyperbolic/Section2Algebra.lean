import Zetahyperbolic.Foundations
import Zetahyperbolic.CoreLinearAlgebra
import Zetahyperbolic.LagrangeBasis

/-!
# Section 2: algebraic consequences for the pole functional

These exact finite algebraic consequences support manuscript Theorems 2.4
and 2.5. The determinant-scaling theorem is imported from CoreLinearAlgebra;
the results here isolate the affine pole dependence and the invertibility
consequence of the Lagrange evaluation law.
-/

namespace Zetahyperbolic

/-- For a fixed positive pole index, the pole functional is injective in X:
its slope is the nonzero rational number j^(2k). -/
theorem oddZetaPoleMoment_injective (k j : ℕ) (hj : 0 < j) :
    Function.Injective (oddZetaPoleMoment k j) := by
  intro X Y hXY
  have hzero : oddZetaPoleMoment k j X - oddZetaPoleMoment k j Y = 0 := by
    rw [hXY]
    ring
  rw [oddZetaPoleMoment_sub] at hzero
  have hjq : (j : ℚ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt hj)
  have hpow : (j : ℚ) ^ (2 * k) ≠ 0 := pow_ne_zero _ hjq
  have hdiff : X - Y = 0 := (mul_eq_zero.mp hzero).resolve_left hpow
  exact sub_eq_zero.mp hdiff

/-- The affine dependence on X has exact coefficient j^(2k). -/
theorem oddZetaPoleMoment_shift (k j : ℕ) (X d : ℚ) :
    oddZetaPoleMoment k j (X + d) - oddZetaPoleMoment k j X =
      (j : ℚ) ^ (2 * k) * d := by
  rw [oddZetaPoleMoment_add]
  ring

/-- The Lagrange evaluation matrix is invertible, with explicit determinant
one; this is the finite interpolation-basis input to Theorem 2.5. -/
theorem lagrangePoleEvaluationMatrix_isUnit (N K : ℕ) :
    IsUnit (Matrix.det (lagrangePoleEvaluationMatrix N K)) := by
  rw [det_lagrangePoleEvaluationMatrix]
  norm_num

end Zetahyperbolic
